# العمار ستور (El-Ammar Store)

كتالوج إلكتروني سريع وخفيف لبيع **الأحذية الحريمي، الشنط، الدهب الصيني، والإكسسوارات** — مصمم خصيصًا ليفتح بسلاسة داخل متصفح فيسبوك وإنستجرام على الموبايل، مع إتمام الطلب عبر **واتساب** أو **ماسنجر** أو **طلب مكالمة هاتفية** بدون تسجيل حساب أو دفع أونلاين.

- **التقنيات**: React 19 + TypeScript + Vite + Tailwind CSS 4 + Supabase + PWA (`HashRouter`)
- **التكلفة التشغيلية**: مجانية 100% (Static SPA + باقة Supabase المجانية) بدون خوادم وسيطة.

---

## 1) التشغيل المحلي (Local Development)

1. تأكد من استخدام **Node.js 20+** (ملف `.nvmrc` مضبوط على `20`).
2. انسخ ملف البيئة وأضف بيانات مشروعك على Supabase:
   ```bash
   cp .env.example .env
   ```
   ثم املأ:
   ```env
   VITE_SUPABASE_URL=https://YOUR-PROJECT.supabase.co
   VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
   ```
   *(لو تُركت القيم فارغة، يعمل المتجر تلقائيًا في **الوضع التجريبي Demo Mode** ببيانات نموذجية).*
3. ثبّت الحزم وشغّل الموقع:
   ```bash
   npm install
   npm run dev
   ```
4. للتحقق من الأنواع وبناء نسخة الإنتاج:
   ```bash
   npm run lint
   npm run build
   ```

---

## 2) إعداد قاعدة البيانات في Supabase

داخل **SQL Editor** في لوحة Supabase:

1. شغّل ملف التأسيس الأساسي أولًا (للإنشاء الجديد فقط):
   - `supabase/schema.sql`
2. ثم شغّل ملف التحديثات (آمن للتشغيل المتكرر — Idempotent):
   - `supabase/migration_v2.sql`
   يضيف الملف عمود `code` للمنتجات، ورقم الموبايل وقناة `callback` للطلبات، ودوال `is_default_reset_pin()` و `get_storage_usage_bytes()` لمتابعة استهلاك مساحة الصور.
3. من **Authentication → Users** أضف حساب الإدارة (البريد وكلمة المرور)، ثم أضف نفس البريد في جدول `public.admin_emails`:
   ```sql
   insert into public.admin_emails (email) values ('owner@example.com') on conflict do nothing;
   ```
4. **هام للأمان**: افتح لوحة الإدارة (`/#/admin`) ← **الإعدادات** ← **إعادة التعيين والرقم السري** وغيّر الرقم السري الافتراضي `1234` فورًا.

---

## 3) النشر المجاني الأساسي: Cloudflare Pages (المُوصى به)

1. ارفع المشروع إلى مستودع خاص أو عام على **GitHub**.
2. افتح لوحة **Cloudflare Dashboard** ← **Workers & Pages** ← **Create** ← **Pages** ← **Connect to Git**.
3. اختر المستودع واضبط إعدادات البناء:
   - **Framework preset**: `Vite`
   - **Build command**: `npm run build`
   - **Build output directory**: `dist`
4. أضف متغيرات البيئة (**Environment Variables**) لكل من Production و Preview:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
5. اضغط **Save and Deploy** — يتم تطبيق ملف `public/_headers` تلقائيًا لضبط الكاش على الأصول الثابتة وتحديث `index.html` و `sw.js` فورًا.

---

## 4) البديل المجاني: Netlify

المشروع يحتوي بالفعل على ملف `netlify.toml` جاهز للنشر:

1. افتح **Netlify** ← **Add new site** ← **Import an existing project** ← اختر المستودع من GitHub.
2. سيتعرف Netlify تلقائيًا على `npm run build` ومجلد `dist` من `netlify.toml`.
3. أضف نفس متغيري البيئة في **Site configuration → Environment variables**:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
4. انشر الموقع (**Deploy site**).

---

## 5) تفعيل نبض الاستيقاظ الأسبوعي (Supabase Keepalive)

تُوقف باقة Supabase المجانية المشروع بعد 7 أيام بدون نشاط. لتجنّب ذلك تلقائيًا عبر `.github/workflows/keepalive.yml`:

1. افتح مستودع GitHub ← **Settings** ← **Secrets and variables** ← **Actions**.
2. أضف السرّين التاليين (**New repository secret**):
   - `SUPABASE_URL`: رابط مشروع Supabase (مثال: `https://xxxx.supabase.co`)
   - `SUPABASE_ANON_KEY`: مفتاح `anon` أو `sb_publishable_...`
3. سيعمل الفحص أسبوعيًا كل يوم أحد الساعة 03:00 بتوقيت UTC، ويمكنك تشغيله يدويًا من تبويب **Actions → Supabase Keepalive → Run workflow**.

---

## 6) قائمة فحص ما قبل الإطلاق (Pre-Launch Checklist)

- [ ] **تشغيل الترقية**: تم تشغيل `supabase/migration_v2.sql` بنجاح في SQL Editor بدون أخطاء.
- [ ] **الأمان و RLS**: التحقق من أن `admin_emails` يحتوي فقط على بريد الإدارة، وتغيير الرقم السري الافتراضي `1234`.
- [ ] **تجربة الموبايل (360px)**: فحص الرئيسية، الكتالوج وفلتر «مقاسي»، صفحة المنتج، والسلة على عرض `360px` بدون قص أو تمرير أفقي.
- [ ] **محاكاة Slow 3G**: فتح DevTools ← Network ← `Slow 3G` والتأكد من سرعة عرض الصور المصغرة (`WebP 360px`) وعدم حجب المحتوى.
- [ ] **اختبار القنوات الثلاث**: تجربة طلب عبر **واتساب**، و**ماسنجر** (النسخ ثم اللصق)، و**اطلبي ونكلمك** (`01xxxxxxxxx`) والتأكد من ظهور الطلب في تبويب الطلبات.
- [ ] **وضع الـ Demo**: التأكد من عمل التطبيق بسلاسة عند غياب متغيرات Supabase كنسخة عرض تجريبية.
