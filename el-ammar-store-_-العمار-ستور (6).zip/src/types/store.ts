export type SizeStatus = 'available' | 'sold';

export interface Category {
  id: string;
  name: string;
  image_url: string | null;
  sort: number;
  visible: boolean;
  parent_id: string | null;
}

export interface ProductSize {
  id: string;
  color_id: string;
  size: string | null;
  status: SizeStatus;
  sold_at?: string | null;
}

export interface ProductImage {
  full: string;
  thumb: string;
  focus_x: number;
  focus_y: number;
}

export interface ProductColor {
  id: string;
  product_id: string;
  name: string | null;
  hex: string | null;
  images: ProductImage[];
  sort: number;
  sizes: ProductSize[];
}

export interface Product {
  id: string;
  name: string;
  code?: string | null;
  category_id: string | null;
  subcategory_id: string | null;
  description: string;
  price: number;
  old_price: number | null;
  visible: boolean;
  featured: boolean;
  is_permanent: boolean;
  listed_at: string;
  created_at: string;
  colors: ProductColor[];
}

export type BannerType =
  | 'offer'
  | 'new_arrivals'
  | 'biggest_discount'
  | 'featured_product'
  | 'message';

export interface Banner {
  id: string;
  image_url: string | null;
  title: string;
  subtitle: string;
  btn_text: string;
  link: string;
  active: boolean;
  sort: number;
  type: BannerType;
  product_id: string | null;
  category_id: string | null;
  ends_at: string | null;
}

export interface ReviewScreenshot {
  id: string;
  image_url: string;
  caption?: string;
}

export type TrustIconType = 'sparkles' | 'shield' | 'message' | 'check' | 'heart' | 'tag';

export interface TrustItem {
  id: string;
  icon: TrustIconType;
  text: string;
}

export interface StoreFeatures {
  announcement_bar: {
    enabled: boolean;
    text: string;
  };
  offers_countdown: {
    enabled: boolean;
    end_date: string;
  };
  share_button: {
    enabled: boolean;
  };
  recently_viewed: {
    enabled: boolean;
  };
  customer_reviews: {
    enabled: boolean;
    items: ReviewScreenshot[];
  };
  floating_chat: {
    enabled: boolean;
  };
  trust_strip: {
    enabled: boolean;
  };
  follow_us: {
    enabled: boolean;
  };
  fb_closing_line?: string;
}

export interface StoreSettings {
  id: number;
  store_name: string;
  logo_url: string;
  whatsapp: string;
  messenger_url: string;
  instagram_url: string;
  facebook_url: string;
  whatsapp_group_url: string;
  welcome: string;
  order_intro: string;
  trust_items: TrustItem[];
  pixel_id: string;
  expiry_days: number;
  backup_retention_days: number;
  caption_template: string;
  features: StoreFeatures;
}

export type OrderStatus = 'new' | 'delivered' | 'cancelled';
export type OrderChannel = 'whatsapp' | 'messenger' | 'callback';

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string | null;
  color_id: string | null;
  size_id: string | null;
  name_snapshot: string;
  color_snapshot: string | null;
  size_snapshot: string | null;
  price_snapshot: number;
  qty: number;
  thumbnail_url?: string | null;
}

export interface Order {
  id: string;
  order_no: number;
  created_at: string;
  status: OrderStatus;
  channel: OrderChannel;
  customer_phone?: string | null;
  items: OrderItem[];
}

export interface CartItem {
  key: string; // `${productId}__${colorId}__${sizeId}`
  product_id: string;
  color_id: string;
  size_id: string;
  name: string;
  color_name: string | null;
  size_name: string | null;
  price: number;
  qty: number;
  image: string;
  focus_x?: number;
  focus_y?: number;
  code?: string | null;
}

export interface BackupCounts {
  products: number;
  categories: number;
  banners: number;
}

export interface BackupSnapshot {
  categories: Category[];
  products: Array<Omit<Product, 'colors'>>;
  product_colors: Array<Omit<ProductColor, 'sizes'>>;
  product_sizes: ProductSize[];
  banners: Banner[];
  settings: Omit<StoreSettings, 'id'> & {id?: number};
}

export interface BackupRecord {
  id: string;
  created_at: string;
  label: string;
  counts: BackupCounts;
  image_paths: string[];
  snapshot: BackupSnapshot;
}

export interface StorageDeleteResult {
  deletedProducts: number;
  deletedImages: number;
  pinnedImages: number;
  failedPaths: string[];
}

export interface BulkDraftItem {
  tempId: string;
  name: string;
  code?: string;
  price: string;
  oldPrice: string;
  categoryId: string;
  subcategoryId: string;
  colorName?: string;
  colorHex?: string;
  sizes: string[];
  images: ProductImage[];
  error?: string | null;
}

export interface ArchiveImageRef {
  path: string;
  focus_x: number;
  focus_y: number;
}

export interface ArchiveProductEntry {
  id: string;
  name: string;
  code?: string | null;
  description: string;
  price: number;
  old_price: number | null;
  visible: boolean;
  featured: boolean;
  is_permanent: boolean;
  listed_at: string;
  created_at: string;
  category_id: string | null;
  category_name: string | null;
  subcategory_id: string | null;
  subcategory_name: string | null;
  colors: Array<{
    id: string;
    name: string | null;
    hex: string | null;
    sort: number;
    images: ArchiveImageRef[];
    sizes: Array<{
      id: string;
      size: string | null;
      status: SizeStatus;
      sold_at?: string | null;
    }>;
  }>;
}

export interface ArchiveManifest {
  archive_id: string;
  created_at: string;
  part: number;
  total_parts: number;
  products: ArchiveProductEntry[];
}

