import {lazy, Suspense} from 'react';
import {HashRouter, Navigate, Route, Routes} from 'react-router-dom';
import {FlyToCartOverlay, ToastBanner} from './components/BrandElements';
import {Layout} from './components/Layout';
import {StoreProvider} from './context/StoreContext';
import {CartPage} from './pages/CartPage';
import {CatalogPage} from './pages/CatalogPage';
import {HomePage} from './pages/HomePage';
import {ProductPage} from './pages/ProductPage';

const AdminPage = lazy(() => import('./pages/AdminPage').then((m) => ({default: m.AdminPage})));
const HowToOrderPage = lazy(() =>
  import('./pages/HowToOrderPage').then((m) => ({default: m.HowToOrderPage}))
);

const RouteFallback = () => (
  <div className="min-h-[50dvh] flex items-center justify-center text-sm font-bold text-[#0F4C3A]">
    جاري التحميل...
  </div>
);

export default function App() {
  return (
    <StoreProvider>
      <HashRouter>
        <Routes>
          <Route
            path="/admin"
            element={
              <Suspense fallback={<RouteFallback />}>
                <AdminPage />
              </Suspense>
            }
          />
          <Route
            path="*"
            element={
              <Layout>
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/catalog" element={<CatalogPage />} />
                  <Route path="/c/:categoryId" element={<CatalogPage />} />
                  <Route path="/offers" element={<CatalogPage />} />
                  <Route path="/p/:id" element={<ProductPage />} />
                  <Route path="/cart" element={<CartPage />} />
                  <Route
                    path="/how"
                    element={
                      <Suspense fallback={<RouteFallback />}>
                        <HowToOrderPage />
                      </Suspense>
                    }
                  />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </Layout>
            }
          />
        </Routes>
        <FlyToCartOverlay />
        <ToastBanner />
      </HashRouter>
    </StoreProvider>
  );
}
