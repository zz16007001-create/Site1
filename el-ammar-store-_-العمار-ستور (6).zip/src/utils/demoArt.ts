// Studio-styled SVG artwork data URLs for Demo Mode so every image loads
// deterministically without external domains or broken links.

function encodeSvg(svg: string): string {
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg.replace(/\s+/g, ' ').trim())}`;
}

export function createHeelSvg(primary = '#0F4C3A', accent = '#E8A91A', bg = '#F6EFE0'): string {
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
      <defs>
        <radialGradient id="g" cx="50%" cy="45%" r="60%">
          <stop offset="0%" stop-color="#FFFFFF" stop-opacity="0.9"/>
          <stop offset="100%" stop-color="${bg}"/>
        </radialGradient>
        <linearGradient id="shoe" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="${primary}"/>
          <stop offset="100%" stop-color="#141413"/>
        </linearGradient>
      </defs>
      <rect width="400" height="400" fill="url(#g)"/>
      <ellipse cx="205" cy="316" rx="115" ry="18" fill="#000" opacity="0.12"/>
      <!-- Back Heel -->
      <path d="M126 168 L138 296 L152 296 L152 212 Z" fill="#141413"/>
      <path d="M108 164 C118 142 152 145 170 185 C195 240 232 272 295 276 C318 278 326 292 308 298 C252 305 198 286 164 232 C148 206 136 184 108 164 Z" fill="${primary}" opacity="0.82"/>
      <!-- Front High Heel -->
      <path d="M98 184 L112 308 L126 308 L124 224 Z" fill="#1A1A1A"/>
      <path d="M84 180 C92 156 128 158 148 198 C174 252 214 282 282 288 C308 290 314 306 292 312 C230 318 176 296 140 242 C122 214 110 194 84 180 Z" fill="url(#shoe)"/>
      <!-- Gold Tip & Inner Lining -->
      <path d="M276 289 C298 291 312 301 294 310 C282 312 270 312 260 310 C272 304 276 296 276 289 Z" fill="${accent}"/>
      <path d="M106 174 C122 172 138 190 156 226 C174 260 202 282 246 290" fill="none" stroke="${accent}" stroke-width="3" opacity="0.8"/>
    </svg>
  `);
}

export function createSneakerSvg(primary = '#FBF6EA', accent = '#E8A91A', bg = '#EEF2EE'): string {
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
      <rect width="400" height="400" fill="${bg}"/>
      <ellipse cx="200" cy="306" rx="135" ry="18" fill="#000" opacity="0.1"/>
      <path d="M72 254 C74 228 96 205 126 202 L160 165 C180 175 206 174 224 164 L268 205 C304 212 332 232 332 262 L332 278 L72 278 Z" fill="${primary}" stroke="#141413" stroke-width="2.5"/>
      <path d="M68 272 L336 272 C338 290 326 298 308 298 L92 298 C74 298 66 288 68 272 Z" fill="#FFFFFF" stroke="#141413" stroke-width="2"/>
      <path d="M150 226 L236 226 C252 226 266 244 266 254 L142 254 Z" fill="${accent}" opacity="0.9"/>
      <line x1="172" y1="186" x2="206" y2="186" stroke="#141413" stroke-width="3.5" stroke-linecap="round"/>
      <line x1="182" y1="198" x2="218" y2="198" stroke="#141413" stroke-width="3.5" stroke-linecap="round"/>
    </svg>
  `);
}

export function createBagSvg(primary = '#E8A91A', hardware = '#0F4C3A', bg = '#FBF4E4'): string {
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
      <rect width="400" height="400" fill="${bg}"/>
      <ellipse cx="200" cy="322" rx="110" ry="16" fill="#000" opacity="0.12"/>
      <!-- Top Handle -->
      <path d="M148 148 C148 92 252 92 252 148" fill="none" stroke="${primary}" stroke-width="14" stroke-linecap="round"/>
      <path d="M148 148 C148 92 252 92 252 148" fill="none" stroke="#141413" stroke-width="1.5" opacity="0.25"/>
      <!-- Bag Body -->
      <path d="M98 154 L302 154 L318 302 C318 310 312 316 304 316 L96 316 C88 316 82 310 82 302 Z" fill="${primary}" stroke="#141413" stroke-width="2"/>
      <!-- Flap -->
      <path d="M94 152 L306 152 L298 220 C296 228 288 232 280 232 L120 232 C112 232 104 228 102 220 Z" fill="${primary}" filter="brightness(1.06)" stroke="#141413" stroke-width="2"/>
      <!-- Strap & Clasp -->
      <rect x="114" y="198" width="172" height="12" rx="6" fill="#F6CF5A" stroke="#141413" stroke-width="1.5"/>
      <rect x="184" y="192" width="32" height="24" rx="5" fill="${hardware}" stroke="#F6CF5A" stroke-width="2"/>
      <circle cx="200" cy="204" r="4" fill="#F6CF5A"/>
      <!-- Padlock Charm -->
      <rect x="234" y="216" width="22" height="26" rx="4" fill="#F6CF5A" stroke="#141413" stroke-width="1.5"/>
      <path d="M239 216 C239 205 251 205 251 216" fill="none" stroke="#141413" stroke-width="2"/>
    </svg>
  `);
}

export function createCrossbodyBagSvg(primary = '#1F1F1D', accent = '#E8A91A', bg = '#F4EFE6'): string {
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
      <rect width="400" height="400" fill="${bg}"/>
      <ellipse cx="200" cy="316" rx="108" ry="15" fill="#000" opacity="0.12"/>
      <!-- Gold Chain -->
      <path d="M122 175 C122 86 278 86 278 175" fill="none" stroke="${accent}" stroke-width="6" stroke-dasharray="9 5"/>
      <!-- Quilted Body -->
      <rect x="92" y="168" width="216" height="136" rx="22" fill="${primary}" stroke="#000" stroke-width="2"/>
      <path d="M94 182 L200 248 L306 182" fill="${primary}" stroke="${accent}" stroke-width="1.5" opacity="0.5"/>
      <line x1="120" y1="220" x2="170" y2="298" stroke="#FFFFFF" stroke-width="1" opacity="0.16"/>
      <line x1="175" y1="220" x2="225" y2="298" stroke="#FFFFFF" stroke-width="1" opacity="0.16"/>
      <line x1="230" y1="220" x2="280" y2="298" stroke="#FFFFFF" stroke-width="1" opacity="0.16"/>
      <!-- Clasp -->
      <rect x="184" y="232" width="32" height="22" rx="6" fill="${accent}"/>
      <circle cx="200" cy="243" r="4" fill="#141413"/>
    </svg>
  `);
}

export function createGoldJewelrySvg(variant: 'necklace' | 'bracelet' | 'earrings' = 'necklace', bg = '#FBF3DF'): string {
  if (variant === 'bracelet') {
    return encodeSvg(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
        <defs>
          <linearGradient id="gold" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#FFF0A8"/>
            <stop offset="45%" stop-color="#E8A91A"/>
            <stop offset="100%" stop-color="#9A6806"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="${bg}"/>
        <ellipse cx="200" cy="306" rx="102" ry="15" fill="#000" opacity="0.1"/>
        <ellipse cx="200" cy="204" rx="92" ry="74" fill="none" stroke="url(#gold)" stroke-width="22"/>
        <ellipse cx="200" cy="204" rx="92" ry="74" fill="none" stroke="#FFF7CC" stroke-width="3" stroke-dasharray="14 10"/>
        <circle cx="200" cy="278" r="14" fill="#0F4C3A" stroke="url(#gold)" stroke-width="4"/>
        <circle cx="152" cy="268" r="7" fill="#FFFFFF" stroke="url(#gold)" stroke-width="2"/>
        <circle cx="248" cy="268" r="7" fill="#FFFFFF" stroke="url(#gold)" stroke-width="2"/>
      </svg>
    `);
  }
  if (variant === 'earrings') {
    return encodeSvg(`
      <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
        <defs>
          <linearGradient id="gold2" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stop-color="#FFF0A8"/>
            <stop offset="50%" stop-color="#E8A91A"/>
            <stop offset="100%" stop-color="#9E6B06"/>
          </linearGradient>
        </defs>
        <rect width="400" height="400" fill="${bg}"/>
        <circle cx="155" cy="145" r="18" fill="url(#gold2)"/>
        <path d="M155 168 L182 225 L155 278 L128 225 Z" fill="#0F4C3A" stroke="url(#gold2)" stroke-width="6"/>
        <circle cx="245" cy="145" r="18" fill="url(#gold2)"/>
        <path d="M245 168 L272 225 L245 278 L218 225 Z" fill="#0F4C3A" stroke="url(#gold2)" stroke-width="6"/>
      </svg>
    `);
  }
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
      <defs>
        <linearGradient id="gold3" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stop-color="#FFF2B8"/>
          <stop offset="50%" stop-color="#E8A91A"/>
          <stop offset="100%" stop-color="#9B6805"/>
        </linearGradient>
      </defs>
      <rect width="400" height="400" fill="${bg}"/>
      <path d="M98 92 C110 218 290 218 302 92" fill="none" stroke="url(#gold3)" stroke-width="8" stroke-linecap="round"/>
      <path d="M120 96 C135 256 265 256 280 96" fill="none" stroke="url(#gold3)" stroke-width="5" stroke-dasharray="8 4"/>
      <circle cx="200" cy="242" r="24" fill="url(#gold3)" stroke="#FFF7CC" stroke-width="3"/>
      <circle cx="200" cy="242" r="11" fill="#0F4C3A"/>
      <circle cx="200" cy="186" r="10" fill="url(#gold3)"/>
    </svg>
  `);
}

export function createAccessorySvg(bg = '#EDF4F1'): string {
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400">
      <rect width="400" height="400" fill="${bg}"/>
      <ellipse cx="200" cy="296" rx="116" ry="14" fill="#000" opacity="0.1"/>
      <!-- Sunglasses + Silk Scarf Charm -->
      <path d="M88 186 C88 156 176 156 176 186 C176 226 142 238 118 238 C98 238 88 214 88 186 Z" fill="#141413" stroke="#E8A91A" stroke-width="7"/>
      <path d="M224 186 C224 156 312 156 312 186 C312 214 302 238 282 238 C258 238 224 226 224 186 Z" fill="#141413" stroke="#E8A91A" stroke-width="7"/>
      <path d="M176 184 Q200 172 224 184" fill="none" stroke="#E8A91A" stroke-width="7"/>
      <line x1="106" y1="176" x2="132" y2="210" stroke="#FFF" stroke-width="4" opacity="0.28" stroke-linecap="round"/>
      <line x1="242" y1="176" x2="268" y2="210" stroke="#FFF" stroke-width="4" opacity="0.28" stroke-linecap="round"/>
    </svg>
  `);
}

export function createReviewScreenshotSvg(title: string, msg: string, reply: string): string {
  return encodeSvg(`
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 440">
      <rect width="360" height="440" rx="24" fill="#EFEAE2"/>
      <rect width="360" height="68" fill="#0F4C3A"/>
      <circle cx="310" cy="34" r="18" fill="#E8A91A"/>
      <text x="280" y="39" text-anchor="end" font-family="sans-serif" font-size="16" font-weight="bold" fill="#FFFFFF">${title}</text>
      <rect x="34" y="100" width="276" height="96" rx="16" fill="#FFFFFF"/>
      <text x="292" y="138" text-anchor="end" font-family="sans-serif" font-size="15" fill="#141413">${msg}</text>
      <text x="292" y="168" text-anchor="end" font-family="sans-serif" font-size="13" fill="#5B5B5B">بجد تحفة تسلم إيديكم</text>
      <rect x="48" y="220" width="276" height="80" rx="16" fill="#DCF8C6"/>
      <text x="306" y="264" text-anchor="end" font-family="sans-serif" font-size="15" fill="#0F4C3A">${reply}</text>
    </svg>
  `);
}
