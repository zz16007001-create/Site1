import {strFromU8, strToU8, unzipSync, zipSync, type Zippable} from 'fflate';
import type {
  ArchiveImageRef,
  ArchiveManifest,
  ArchiveProductEntry,
  Category,
  Product,
} from '../types/store';

export const ARCHIVE_MAX_PRODUCTS_PER_PART = 40;
export const ARCHIVE_MAX_BYTES_PER_PART = 58 * 1024 * 1024; // ~58MB safety margin under 60MB

export interface PreparedArchivePart {
  partNumber: number;
  productIds: string[];
  productCount: number;
  imageCount: number;
  sizeBytes: number;
  filename: string;
  blob: Blob;
}

export interface BuiltArchiveResult {
  archiveId: string;
  createdAt: string;
  parts: PreparedArchivePart[];
  failedImages: number;
}

function guessExtensionFromMimeOrUrl(mime: string, url: string): string {
  const lowerMime = (mime || '').toLowerCase();
  if (lowerMime.includes('svg')) return 'svg';
  if (lowerMime.includes('png')) return 'png';
  if (lowerMime.includes('webp')) return 'webp';
  const cleanUrl = url.split('?')[0].toLowerCase();
  if (cleanUrl.endsWith('.png')) return 'png';
  if (cleanUrl.endsWith('.webp')) return 'webp';
  if (cleanUrl.endsWith('.svg')) return 'svg';
  return 'jpg';
}

async function fetchUrlAsBytes(url: string): Promise<{bytes: Uint8Array; ext: string} | null> {
  if (!url) return null;
  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const blob = await res.blob();
    const arr = new Uint8Array(await blob.arrayBuffer());
    const ext = guessExtensionFromMimeOrUrl(blob.type, url);
    return {bytes: arr, ext};
  } catch {
    return null;
  }
}

function sealArchivePart(params: {
  archiveId: string;
  createdAt: string;
  partNumber: number;
  totalPartsEstimate: number;
  entries: ArchiveProductEntry[];
  fileMap: Record<string, Uint8Array>;
  imageCount: number;
}): PreparedArchivePart {
  const manifest: ArchiveManifest = {
    archive_id: params.archiveId,
    created_at: params.createdAt,
    part: params.partNumber,
    total_parts: Math.max(params.totalPartsEstimate, params.partNumber),
    products: params.entries,
  };

  const zipInput: Zippable = {
    'archive.json': [strToU8(JSON.stringify(manifest, null, 2)), {level: 6}],
  };
  for (const [path, bytes] of Object.entries(params.fileMap)) {
    // Store images uncompressed (level 0) for speed & minimal memory
    zipInput[path] = [bytes, {level: 0}];
  }

  const zipped = zipSync(zipInput);
  const exactBytes = zipped.slice();
  const blob = new Blob([exactBytes.buffer], {type: 'application/zip'});

  return {
    partNumber: params.partNumber,
    productIds: params.entries.map((p) => p.id),
    productCount: params.entries.length,
    imageCount: params.imageCount,
    sizeBytes: blob.size,
    filename: `elamar-archive-${params.createdAt.slice(0, 10)}-part-${params.partNumber}.zip`,
    blob,
  };
}

/**
 * Build ZIP archive parts for offline phone backup:
 * - Up to 40 products or ~58-60MB per ZIP part
 * - Includes archive.json + FULL images only (thumbnails regenerated on restore)
 * - Releases raw image buffers between parts to keep mobile memory low
 */
export async function buildPhoneArchiveZipParts(params: {
  products: Product[];
  categories: Category[];
  onProgress?: (progress: {
    doneProducts: number;
    totalProducts: number;
    currentPart: number;
  }) => void;
}): Promise<BuiltArchiveResult> {
  const {products, categories, onProgress} = params;
  const archiveId = `arch-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
  const createdAt = new Date().toISOString();
  const catNameMap = new Map(categories.map((c) => [c.id, c.name]));

  // Rough planned part count based on 40-product ceiling
  const plannedTotalParts = Math.max(1, Math.ceil(products.length / ARCHIVE_MAX_PRODUCTS_PER_PART));

  const parts: PreparedArchivePart[] = [];
  let partNumber = 1;
  let currentEntries: ArchiveProductEntry[] = [];
  let currentFileMap: Record<string, Uint8Array> = {};
  let currentBytes = 0;
  let currentImageCount = 0;
  let failedImages = 0;

  for (let i = 0; i < products.length; i++) {
    const prod = products[i];
    const prodFileMap: Record<string, Uint8Array> = {};
    let prodBytes = 0;
    let prodImageCount = 0;

    const archiveColors: ArchiveProductEntry['colors'] = [];
    for (let cIdx = 0; cIdx < prod.colors.length; cIdx++) {
      const col = prod.colors[cIdx];
      const archiveImgs: ArchiveImageRef[] = [];

      for (let imgIdx = 0; imgIdx < col.images.length; imgIdx++) {
        const imgObj = col.images[imgIdx];
        const fetched =
          (await fetchUrlAsBytes(imgObj.full)) ||
          (imgObj.thumb && imgObj.thumb !== imgObj.full
            ? await fetchUrlAsBytes(imgObj.thumb)
            : null);

        if (!fetched) {
          failedImages += 1;
          continue;
        }

        const safePath = `images/${prod.id}/${cIdx + 1}-${imgIdx + 1}.${fetched.ext}`;
        prodFileMap[safePath] = fetched.bytes;
        prodBytes += fetched.bytes.byteLength;
        prodImageCount += 1;
        archiveImgs.push({
          path: safePath,
          focus_x: imgObj.focus_x,
          focus_y: imgObj.focus_y,
        });
      }

      archiveColors.push({
        id: col.id,
        name: col.name,
        hex: col.hex,
        sort: col.sort,
        images: archiveImgs,
        sizes: col.sizes.map((s) => ({
          id: s.id,
          size: s.size,
          status: s.status,
          sold_at: s.sold_at ?? null,
        })),
      });
    }

    const entry: ArchiveProductEntry = {
      id: prod.id,
      name: prod.name,
      description: prod.description || '',
      price: prod.price,
      old_price: prod.old_price,
      visible: prod.visible,
      featured: prod.featured,
      is_permanent: prod.is_permanent,
      listed_at: prod.listed_at || prod.created_at,
      created_at: prod.created_at,
      category_id: prod.category_id,
      category_name: prod.category_id ? catNameMap.get(prod.category_id) || null : null,
      subcategory_id: prod.subcategory_id,
      subcategory_name: prod.subcategory_id ? catNameMap.get(prod.subcategory_id) || null : null,
      colors: archiveColors,
    };

    const wouldExceedCount = currentEntries.length >= ARCHIVE_MAX_PRODUCTS_PER_PART;
    const wouldExceedBytes =
      currentEntries.length > 0 && currentBytes + prodBytes > ARCHIVE_MAX_BYTES_PER_PART;

    if (wouldExceedCount || wouldExceedBytes) {
      parts.push(
        sealArchivePart({
          archiveId,
          createdAt,
          partNumber,
          totalPartsEstimate: plannedTotalParts,
          entries: currentEntries,
          fileMap: currentFileMap,
          imageCount: currentImageCount,
        })
      );
      partNumber += 1;
      currentEntries = [];
      currentFileMap = {};
      currentBytes = 0;
      currentImageCount = 0;
    }

    currentEntries.push(entry);
    Object.assign(currentFileMap, prodFileMap);
    currentBytes += prodBytes;
    currentImageCount += prodImageCount;

    onProgress?.({
      doneProducts: i + 1,
      totalProducts: products.length,
      currentPart: partNumber,
    });
  }

  if (currentEntries.length > 0) {
    parts.push(
      sealArchivePart({
        archiveId,
        createdAt,
        partNumber,
        totalPartsEstimate: parts.length + 1,
        entries: currentEntries,
        fileMap: currentFileMap,
        imageCount: currentImageCount,
      })
    );
  }

  // Normalize download filenames with accurate total count
  const totalParts = parts.length;
  for (const part of parts) {
    part.filename = `elamar-archive-${createdAt.slice(0, 10)}-part-${part.partNumber}-of-${totalParts}.zip`;
  }

  return {archiveId, createdAt, parts, failedImages};
}

export interface OpenedArchiveReader {
  manifest: ArchiveManifest;
  extractImageBlob: (zipPath: string) => Blob | null;
  release: () => void;
}

function mimeFromPath(path: string): string {
  const lower = path.toLowerCase();
  if (lower.endsWith('.svg')) return 'image/svg+xml';
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  return 'image/jpeg';
}

/**
 * Opens an archive ZIP file and parses archive.json first without decompressing
 * all images at once; extractImageBlob() decodes one image at a time on demand.
 */
export async function openArchiveZipFile(file: File): Promise<OpenedArchiveReader> {
  let zipBytes: Uint8Array | null = new Uint8Array(await file.arrayBuffer());

  const jsonFiles = unzipSync(zipBytes, {
    filter: (info) => {
      const normalized = info.name.replace(/^\/+/, '');
      return normalized === 'archive.json' || normalized.endsWith('/archive.json');
    },
  });

  const jsonKey = Object.keys(jsonFiles)[0];
  if (!jsonKey) {
    zipBytes = null;
    throw new Error('ملف archive.json غير موجود داخل الأرشيف');
  }

  const manifest = JSON.parse(strFromU8(jsonFiles[jsonKey])) as ArchiveManifest;
  if (!manifest || !Array.isArray(manifest.products)) {
    zipBytes = null;
    throw new Error('صيغة ملف الأرشيف غير صالحة');
  }

  // Support optional folder prefix if the user re-zipped a folder
  const prefix = jsonKey.slice(0, jsonKey.length - 'archive.json'.length);

  return {
    manifest,
    extractImageBlob: (zipPath: string) => {
      if (!zipBytes) return null;
      const normalizedTarget = zipPath.replace(/^\/+/, '');
      const prefixedTarget = `${prefix}${normalizedTarget}`;
      const matched = unzipSync(zipBytes, {
        filter: (info) => {
          const clean = info.name.replace(/^\/+/, '');
          return clean === normalizedTarget || clean === prefixedTarget;
        },
      });
      const entryKey = Object.keys(matched)[0];
      if (!entryKey) return null;
      const bytes = matched[entryKey].slice();
      return new Blob([bytes.buffer], {type: mimeFromPath(entryKey)});
    },
    release: () => {
      zipBytes = null;
    },
  };
}
