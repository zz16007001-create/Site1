declare global {
  interface Window {
    fbq?: ((...args: unknown[]) => void) & {
      callMethod?: (...args: unknown[]) => void;
      queue?: unknown[];
      loaded?: boolean;
      version?: string;
      push?: (...args: unknown[]) => void;
    };
    _fbq?: unknown;
  }
}

let initializedPixelId = '';

export function initMetaPixel(pixelId: string): void {
  const cleanId = (pixelId || '').replace(/[^\d]/g, '').trim();
  if (!cleanId) return;
  if (initializedPixelId === cleanId && window.fbq) return;

  if (!window.fbq) {
    const fbqFunc: NonNullable<Window['fbq']> = function (...args: unknown[]) {
      if (fbqFunc.callMethod) {
        fbqFunc.callMethod(...args);
      } else {
        fbqFunc.queue = fbqFunc.queue || [];
        fbqFunc.queue.push(args);
      }
    };
    fbqFunc.push = fbqFunc;
    fbqFunc.loaded = true;
    fbqFunc.version = '2.0';
    fbqFunc.queue = [];
    window.fbq = fbqFunc;
    window._fbq = fbqFunc;

    const script = document.createElement('script');
    script.async = true;
    script.src = 'https://connect.facebook.net/en_US/fbevents.js';
    document.head.appendChild(script);
  }

  window.fbq('init', cleanId);
  initializedPixelId = cleanId;
}

export function trackPixelEvent(
  pixelId: string,
  eventName: 'PageView' | 'ViewContent' | 'AddToCart' | 'InitiateCheckout',
  params?: Record<string, unknown>
): void {
  const cleanId = (pixelId || '').replace(/[^\d]/g, '').trim();
  if (!cleanId) return;
  initMetaPixel(cleanId);
  if (!window.fbq) return;
  if (params) {
    window.fbq('track', eventName, params);
  } else {
    window.fbq('track', eventName);
  }
}
