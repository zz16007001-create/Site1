import type {
  Product,
  ProductColor,
  ProductImage,
  ProductSize,
  StoreSettings,
} from '../types/store';

export const DEFAULT_FOCUS_X = 50;
export const DEFAULT_FOCUS_Y = 65;

export function clampFocus(val: unknown, fallback: number): number {
  const n = Number(val);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(0, Math.min(100, Math.round(n)));
}

export function cleanColorName(name: string | null | undefined): string | null {
  const n = (name || '').trim();
  if (!n || n === 'الأساسي' || n === 'الافتراضي') return null;
  return n;
}

export function normalizeSearchText(val: string | null | undefined): string {
  return (val || '').toLowerCase().replace(/\s+/g, '');
}

export function normalizeEgyptianPhone(raw: string): {
  digits: string;
  valid: boolean;
  whatsappIntl: string | null;
} {
  const ascii = (raw || '')
    .replace(/[\u0660-\u0669]/g, (d) => String(d.charCodeAt(0) - 0x0660))
    .replace(/[\u06F0-\u06F9]/g, (d) => String(d.charCodeAt(0) - 0x06F0));
  let digits = ascii.replace(/[^\d]/g, '');
  if (digits.startsWith('0020')) {
    digits = '0' + digits.slice(4);
  } else if (digits.startsWith('20') && digits.length >= 12) {
    digits = '0' + digits.slice(2);
  }
  const valid = /^01[0125]\d{8}$/.test(digits);
  return {
    digits,
    valid,
    whatsappIntl: valid ? `2${digits}` : null,
  };
}

export function normalizeProductImage(raw: unknown): ProductImage | null {
  if (!raw) return null;
  if (typeof raw === 'string') {
    const trimmed = raw.trim();
    if (!trimmed) return null;
    if (trimmed.startsWith('{')) {
      try {
        const parsed = JSON.parse(trimmed) as Record<string, unknown>;
        return normalizeProductImage(parsed);
      } catch {
        // Fall through as plain URL
      }
    }
    return {
      full: trimmed,
      thumb: trimmed,
      focus_x: DEFAULT_FOCUS_X,
      focus_y: DEFAULT_FOCUS_Y,
    };
  }
  if (typeof raw === 'object') {
    const obj = raw as Record<string, unknown>;
    const full = String(obj.full || obj.url || obj.thumb || '').trim();
    const thumb = String(obj.thumb || obj.full || obj.url || '').trim();
    if (!full && !thumb) return null;
    return {
      full: full || thumb,
      thumb: thumb || full,
      focus_x: clampFocus(obj.focus_x, DEFAULT_FOCUS_X),
      focus_y: clampFocus(obj.focus_y, DEFAULT_FOCUS_Y),
    };
  }
  return null;
}

export function normalizeProductImages(rawList: unknown): ProductImage[] {
  if (!Array.isArray(rawList)) return [];
  const out: ProductImage[] = [];
  for (const item of rawList) {
    const norm = normalizeProductImage(item);
    if (norm) out.push(norm);
  }
  return out;
}

export function isColorSoldOut(color: ProductColor): boolean {
  if (!color.sizes || color.sizes.length === 0) return true;
  return color.sizes.every((s) => s.status === 'sold');
}

export function isProductSoldOut(product: Product): boolean {
  if (!product.colors || product.colors.length === 0) return true;
  return product.colors.every((c) => isColorSoldOut(c));
}

export function getFirstAvailableColor(product: Product): ProductColor | undefined {
  return product.colors.find((c) => !isColorSoldOut(c)) || product.colors[0];
}

export function getFirstAvailableSize(color: ProductColor | undefined): ProductSize | undefined {
  if (!color) return undefined;
  return color.sizes.find((s) => s.status === 'available');
}

export function getProductFirstImageObj(product: Product): ProductImage | null {
  const firstColor = getFirstAvailableColor(product);
  if (firstColor && firstColor.images.length > 0 && firstColor.images[0]) {
    return firstColor.images[0];
  }
  const anyColorWithImage = product.colors.find((c) => c.images.length > 0 && Boolean(c.images[0]));
  return anyColorWithImage?.images[0] || null;
}

export function getProductFirstRealImage(product: Product): string | null {
  return getProductFirstImageObj(product)?.thumb || null;
}

export function getProductMainImageObj(product: Product): ProductImage {
  return (
    getProductFirstImageObj(product) || {
      full: '/assets/aistudio/logo_be4d7522.png',
      thumb: '/assets/aistudio/logo_be4d7522.png',
      focus_x: 50,
      focus_y: 50,
    }
  );
}

export function getProductMainImage(product: Product): string {
  return getProductMainImageObj(product).thumb;
}

export function getDiscountPercent(price: number, oldPrice: number | null): number {
  if (!oldPrice || oldPrice <= price || oldPrice <= 0) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}

/**
 * Automatic sorting everywhere:
 * Available items first (newest first), items with every size sold sink to the end.
 */
export function sortCatalogProducts(products: Product[]): Product[] {
  return [...products].sort((a, b) => {
    const aSold = isProductSoldOut(a);
    const bSold = isProductSoldOut(b);
    if (aSold !== bSold) return aSold ? 1 : -1;
    return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
  });
}

/**
 * Categories that don't normally use shoe sizes (bags, accessories, Chinese gold)
 */
export function categoryUsesSizes(categoryName?: string | null): boolean {
  if (!categoryName) return true;
  const lower = categoryName.trim();
  const nonSizeKeywords = ['شنط', 'شنطة', 'إكسسوار', 'اكسسوار', 'دهب', 'ذهب', 'مجوهرات'];
  return !nonSizeKeywords.some((k) => lower.includes(k));
}

export function formatPrice(amount: number): string {
  return `${Math.round(amount).toLocaleString('en-US')} ج.م`;
}

export const PRODUCT_IMAGE_MAX_DIMENSION = 1000;
export const PRODUCT_IMAGE_THUMB_WIDTH = 360;
export const PRODUCT_IMAGE_JPEG_QUALITY = 0.75;

export interface ImageCompressionStats {
  originalBytes: number;
  compressedBytes: number;
  width: number;
  height: number;
  originalWidth: number;
  originalHeight: number;
  savedPercent: number;
}

export function formatBytesCompact(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes <= 0) return '0 ك.ب';
  if (bytes < 1024 * 1024) {
    return `${Math.max(1, Math.round(bytes / 1024))} ك.ب`;
  }
  return `${(bytes / (1024 * 1024)).toFixed(1)} م.ب`;
}

async function decodeImageForCanvas(
  source: Blob
): Promise<{
  drawable: CanvasImageSource;
  width: number;
  height: number;
  cleanup: () => void;
}> {
  if (typeof createImageBitmap === 'function') {
    try {
      const bitmap = await createImageBitmap(source, {
        imageOrientation: 'from-image',
      });
      return {
        drawable: bitmap,
        width: bitmap.width,
        height: bitmap.height,
        cleanup: () => {
          try {
            bitmap.close();
          } catch {
            // Ignore
          }
        },
      };
    } catch {
      // Fall back to HTMLImageElement for formats/browsers that reject options
    }
  }

  return new Promise((resolve, reject) => {
    const img = new Image();
    const url = URL.createObjectURL(source);
    img.onload = () => {
      resolve({
        drawable: img,
        width: img.naturalWidth || img.width,
        height: img.naturalHeight || img.height,
        cleanup: () => URL.revokeObjectURL(url),
      });
    };
    img.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('Invalid image file'));
    };
    img.src = url;
  });
}

async function renderDecodedToCanvasBlob(
  decoded: {drawable: CanvasImageSource; width: number; height: number},
  originalBytes: number,
  options: {
    maxDimension: number;
    quality: number;
    preserveAlpha: boolean;
    hasAlphaSource: boolean;
    mode: 'longest' | 'width';
  }
): Promise<{blob: Blob; stats: ImageCompressionStats}> {
  const originalWidth = Math.max(1, decoded.width);
  const originalHeight = Math.max(1, decoded.height);
  let width = originalWidth;
  let height = originalHeight;

  if (options.mode === 'width') {
    if (width > options.maxDimension) {
      height = Math.round((height * options.maxDimension) / width);
      width = options.maxDimension;
    }
  } else if (width > options.maxDimension || height > options.maxDimension) {
    if (width >= height) {
      height = Math.round((height * options.maxDimension) / width);
      width = options.maxDimension;
    } else {
      width = Math.round((width * options.maxDimension) / height);
      height = options.maxDimension;
    }
  }

  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, width);
  canvas.height = Math.max(1, height);
  const ctx = canvas.getContext('2d');
  if (!ctx) {
    throw new Error('Canvas context unavailable');
  }

  ctx.imageSmoothingEnabled = true;
  ctx.imageSmoothingQuality = 'high';

  if (!options.hasAlphaSource) {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
  } else {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  }

  ctx.drawImage(decoded.drawable, 0, 0, canvas.width, canvas.height);

function encodeCanvasToBlob(
  canvas: HTMLCanvasElement,
  mime: string,
  quality: number
): Promise<Blob | null> {
  return new Promise((resolve) => {
    try {
      canvas.toBlob((out) => resolve(out), mime, quality);
    } catch {
      resolve(null);
    }
  });
}

async function canvasToOptimalBlob(
  canvas: HTMLCanvasElement,
  quality: number,
  hasAlphaSource: boolean
): Promise<Blob> {
  const webpQuality = hasAlphaSource ? Math.max(quality, 0.85) : quality;
  const webpBlob = await encodeCanvasToBlob(canvas, 'image/webp', webpQuality);
  if (webpBlob && webpBlob.type === 'image/webp') {
    return webpBlob;
  }
  const fallbackMime = hasAlphaSource ? 'image/png' : 'image/jpeg';
  const fallbackBlob = await encodeCanvasToBlob(canvas, fallbackMime, quality);
  if (fallbackBlob) {
    return fallbackBlob;
  }
  throw new Error('Failed to compress image');
}

  const blob = await canvasToOptimalBlob(canvas, options.quality, options.hasAlphaSource);

  const baseBytes = originalBytes || blob.size;
  const compressedBytes = blob.size;
  const savedPercent =
    baseBytes > 0
      ? Math.max(0, Math.round(((baseBytes - compressedBytes) / baseBytes) * 100))
      : 0;

  return {
    blob,
    stats: {
      originalBytes: baseBytes,
      compressedBytes,
      width: canvas.width,
      height: canvas.height,
      originalWidth,
      originalHeight,
      savedPercent,
    },
  };
}

/**
 * Visual Canvas-based client-side image compression.
 * Converts to WebP (default quality 0.75, with JPEG fallback on unsupported browsers)
 * and resizes proportionally so neither dimension exceeds maxDimension (default 1000px).
 */
export async function compressImageToCanvasResult(
  source: Blob,
  options?: {
    maxDimension?: number;
    quality?: number;
    preserveAlpha?: boolean;
    mode?: 'longest' | 'width';
  }
): Promise<{blob: Blob; stats: ImageCompressionStats}> {
  const maxDimension = Math.max(64, options?.maxDimension ?? PRODUCT_IMAGE_MAX_DIMENSION);
  const quality = Math.min(1, Math.max(0.1, options?.quality ?? PRODUCT_IMAGE_JPEG_QUALITY));
  const preserveAlpha = Boolean(options?.preserveAlpha);
  const mode = options?.mode ?? 'longest';
  const hasAlphaSource =
    preserveAlpha && (source.type === 'image/png' || source.type === 'image/webp');

  const decoded = await decodeImageForCanvas(source);
  try {
    return await renderDecodedToCanvasBlob(decoded, source.size || 0, {
      maxDimension,
      quality,
      preserveAlpha,
      hasAlphaSource,
      mode,
    });
  } finally {
    decoded.cleanup();
  }
}

/**
 * Decode image once via decodeImageForCanvas, produce both full (max 1000px, WebP 0.75)
 * and thumb (360px width, WebP 0.75), and clean up in finally.
 */
export async function compressImagePairFromFile(source: Blob): Promise<{
  full: {blob: Blob; stats: ImageCompressionStats};
  thumb: {blob: Blob; stats: ImageCompressionStats};
}> {
  const decoded = await decodeImageForCanvas(source);
  try {
    const originalBytes = source.size || 0;
    const [full, thumb] = await Promise.all([
      renderDecodedToCanvasBlob(decoded, originalBytes, {
        maxDimension: PRODUCT_IMAGE_MAX_DIMENSION,
        quality: PRODUCT_IMAGE_JPEG_QUALITY,
        preserveAlpha: false,
        hasAlphaSource: false,
        mode: 'longest',
      }),
      renderDecodedToCanvasBlob(decoded, originalBytes, {
        maxDimension: PRODUCT_IMAGE_THUMB_WIDTH,
        quality: PRODUCT_IMAGE_JPEG_QUALITY,
        preserveAlpha: false,
        hasAlphaSource: false,
        mode: 'width',
      }),
    ]);
    return {full, thumb};
  } finally {
    decoded.cleanup();
  }
}

/**
 * Client-side image compression preserving original aspect ratio.
 * Defaults to max 1000px and JPEG quality 0.75.
 */
export async function compressImageFile(
  file: File,
  maxDimension = PRODUCT_IMAGE_MAX_DIMENSION,
  quality = PRODUCT_IMAGE_JPEG_QUALITY,
  preserveAlpha = false,
  mode: 'longest' | 'width' = 'longest'
): Promise<Blob> {
  const {blob} = await compressImageToCanvasResult(file, {
    maxDimension,
    quality,
    preserveAlpha,
    mode,
  });
  return blob;
}

export function blobToDataUrl(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error('Failed to read compressed file'));
    reader.readAsDataURL(blob);
  });
}

export async function fileToCompressedDataUrl(
  file: File,
  preserveAlpha = false,
  maxDimension = PRODUCT_IMAGE_MAX_DIMENSION,
  quality = PRODUCT_IMAGE_JPEG_QUALITY,
  mode: 'longest' | 'width' = 'longest'
): Promise<string> {
  const blob = await compressImageFile(file, maxDimension, quality, preserveAlpha, mode);
  return blobToDataUrl(blob);
}

/**
 * Generate both full (max 1000px, JPEG q=0.75) and thumb (500px width, JPEG q=0.75) Blobs
 * from an existing Blob (e.g. extracted from a phone archive ZIP).
 */
export async function compressBlobToPair(blob: Blob): Promise<{fullBlob: Blob; thumbBlob: Blob}> {
  const {full, thumb} = await compressImagePairFromFile(blob);
  return {fullBlob: full.blob, thumbBlob: thumb.blob};
}

/**
 * Probe whether a remote or data image URL actually loads in the browser.
 */
export function verifyImageUrlLoads(url: string, timeoutMs = 6000): Promise<boolean> {
  if (!url) return Promise.resolve(false);
  if (url.startsWith('data:') || url.startsWith('/assets/')) return Promise.resolve(true);
  return new Promise((resolve) => {
    const img = new Image();
    let settled = false;
    const timer = window.setTimeout(() => {
      if (!settled) {
        settled = true;
        resolve(false);
      }
    }, timeoutMs);
    img.onload = () => {
      if (!settled) {
        settled = true;
        window.clearTimeout(timer);
        resolve(true);
      }
    };
    img.onerror = () => {
      if (!settled) {
        settled = true;
        window.clearTimeout(timer);
        resolve(false);
      }
    };
    img.src = url;
  });
}

/**
 * Derive Supabase Storage object path within the "images" bucket from a saved URL.
 */
export function extractImagesBucketPath(url: string | null | undefined): string | null {
  if (!url) return null;
  const clean = url.trim().split('?')[0].split('#')[0];
  if (!clean || clean.startsWith('data:') || clean.startsWith('blob:') || clean.startsWith('/assets/')) {
    return null;
  }

  const markers = [
    '/storage/v1/object/public/images/',
    '/storage/v1/object/sign/images/',
    '/storage/v1/object/authenticated/images/',
    '/storage/v1/render/image/public/images/',
  ];
  for (const marker of markers) {
    const idx = clean.indexOf(marker);
    if (idx !== -1) {
      const pathPart = clean.slice(idx + marker.length).replace(/^\/+/, '');
      try {
        return decodeURIComponent(pathPart) || null;
      } catch {
        return pathPart || null;
      }
    }
  }
  return null;
}

export function collectProductImagePaths(product: Product): string[] {
  const paths = new Set<string>();
  for (const col of product.colors) {
    for (const img of col.images) {
      const fullPath = extractImagesBucketPath(img.full);
      if (fullPath) paths.add(fullPath);
      const thumbPath = extractImagesBucketPath(img.thumb);
      if (thumbPath) paths.add(thumbPath);
    }
  }
  return Array.from(paths);
}

export function getProductAgeDays(listedAt: string): number {
  const ms = new Date(listedAt).getTime();
  if (Number.isNaN(ms)) return 0;
  return Math.max(0, Math.floor((Date.now() - ms) / 86400000));
}

export function isProductExpired(product: Product, expiryDays: number): boolean {
  if (product.is_permanent) return false;
  const threshold = Math.max(1, Number(expiryDays) || 10);
  return getProductAgeDays(product.listed_at || product.created_at) >= threshold;
}

/**
 * Detect Facebook / Messenger / Instagram in-app browsers
 */
export function isInAppBrowser(): boolean {
  if (typeof navigator === 'undefined') return false;
  const ua = navigator.userAgent || '';
  return /FBAN|FBAV|FB_IAB|Messenger|Instagram/i.test(ua);
}

/**
 * Exact Order Message Format (same for WhatsApp and Messenger, single item or cart):
 * طلب رقم #<order_no> | العمار ستور
 *
 * 1) <product name>
 * اللون: <color> (skipped if empty)
 * المقاس: <size> (skipped if empty)
 * الكمية: N (only if qty > 1)
 * السعر: <price> ج (line total when qty > 1)
 *
 * الإجمالي: <total> جنيه
 * الشحن بيتحدد في الشات
 */
export function buildOrderMessage(params: {
  orderNo: number | null;
  settings?: StoreSettings;
  lines: Array<{
    name: string;
    code?: string | null;
    color_name: string | null;
    size_name: string | null;
    qty: number;
    price: number;
  }>;
}): string {
  const {orderNo, lines} = params;
  const sections: string[] = [];

  sections.push(
    orderNo ? `طلب رقم #${orderNo} | العمار ستور` : `طلب جديد | العمار ستور`
  );

  let grandTotal = 0;
  lines.forEach((line, idx) => {
    const qty = Math.max(1, line.qty || 1);
    const lineTotal = qty * line.price;
    grandTotal += lineTotal;

    const cleanColor = cleanColorName(line.color_name);
    const itemLines: string[] = [`${idx + 1}) ${line.name}`];
    if (line.code && line.code.trim()) {
      itemLines.push(`كود: ${line.code.trim()}`);
    }
    if (cleanColor) {
      itemLines.push(`اللون: ${cleanColor}`);
    }
    if (line.size_name && line.size_name.trim()) {
      itemLines.push(`المقاس: ${line.size_name.trim()}`);
    }
    if (qty > 1) {
      itemLines.push(`الكمية: ${qty}`);
      itemLines.push(`السعر: ${Math.round(lineTotal)} ج`);
    } else {
      itemLines.push(`السعر: ${Math.round(line.price)} ج`);
    }
    sections.push(itemLines.join('\n'));
  });

  sections.push(`الإجمالي: ${Math.round(grandTotal)} جنيه\nالشحن بيتحدد في الشات`);

  return sections.join('\n\n');
}

export function getWhatsAppUrl(whatsappNumber: string, text: string): string {
  const cleanDigits = (whatsappNumber || '').replace(/[^\d]/g, '');
  const encoded = encodeURIComponent(text);
  if (!cleanDigits) {
    return `https://wa.me/?text=${encoded}`;
  }
  return `https://wa.me/${cleanDigits}?text=${encoded}`;
}

export function copyTextSync(text: string): boolean {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      void navigator.clipboard.writeText(text).catch(() => {});
    }
  } catch {
    // Ignore and try execCommand fallback
  }
  try {
    const textarea = document.createElement('textarea');
    textarea.value = text;
    textarea.setAttribute('readonly', '');
    textarea.style.position = 'fixed';
    textarea.style.opacity = '0';
    textarea.style.pointerEvents = 'none';
    document.body.appendChild(textarea);
    textarea.select();
    textarea.setSelectionRange(0, text.length);
    const ok = document.execCommand('copy');
    document.body.removeChild(textarea);
    return ok;
  } catch {
    return false;
  }
}

export async function copyTextToClipboard(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    // Fallback below
  }
  return copyTextSync(text);
}

export function openExternalUrl(url: string): void {
  if (!url) return;
  const a = document.createElement('a');
  a.href = url;
  a.target = '_blank';
  a.rel = 'noopener noreferrer';
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
}

export function buildMainSiteLink(): string {
  if (typeof window === 'undefined') return '/';
  return `${window.location.origin}${window.location.pathname}`;
}

export function buildProductDeepLink(productId: string): string {
  if (typeof window === 'undefined') return `/#/p/${productId}`;
  return `${window.location.origin}${window.location.pathname}#/p/${productId}`;
}

export const DEFAULT_CAPTION_TEMPLATE = `✨ {name} من {store_name}

💰 السعر: {price}{discount_line}
{colors_line}{sizes_line}
🛍️ شوفي باقي الكتالوج واطلبي من المتجر:
{link}

الشحن بيتحدد معاكي في الشات 💛`;

export function buildFacebookCaption(
  product: Product,
  settings: StoreSettings
): string {
  const template = settings.caption_template?.trim() || DEFAULT_CAPTION_TEMPLATE;
  const discount = getDiscountPercent(product.price, product.old_price);
  const priceText = `${Math.round(product.price)} ج.م`;
  const oldPriceText =
    product.old_price && product.old_price > product.price
      ? `${Math.round(product.old_price)} ج.م`
      : '';
  const discountLine =
    discount > 0 && oldPriceText
      ? ` (بدلاً من ${oldPriceText} — خصم ${discount}٪ 🔥)`
      : '';

  const availColors = product.colors
    .filter((c) => !isColorSoldOut(c))
    .map((c) => cleanColorName(c.name))
    .filter((name): name is string => Boolean(name));
  const colorsLine =
    availColors.length > 0 ? `🎨 الألوان المتاحة: ${availColors.join(' · ')}\n` : '';

  const availSizesSet = new Set<string>();
  for (const c of product.colors) {
    for (const s of c.sizes) {
      if (s.status === 'available' && s.size) {
        availSizesSet.add(s.size);
      }
    }
  }
  const availSizes = Array.from(availSizesSet);
  const sizesLine =
    availSizes.length > 0 ? `📏 المقاسات المتاحة: ${availSizes.join(' - ')}\n` : '';

  const link = buildMainSiteLink();
  const closingLine = settings.features?.fb_closing_line?.trim();

  let rendered = template
    .replace(/\{name\}/g, product.name)
    .replace(/\{code\}/g, product.code?.trim() || '')
    .replace(/\{store_name\}/g, settings.store_name || 'العمار ستور')
    .replace(/\{price\}/g, priceText)
    .replace(/\{old_price\}/g, oldPriceText)
    .replace(/\{discount\}/g, discount > 0 ? `${discount}٪` : '')
    .replace(/\{discount_line\}/g, discountLine)
    .replace(/\{colors_line\}/g, colorsLine)
    .replace(/\{sizes_line\}/g, sizesLine)
    .replace(/\{colors\}/g, availColors.join(' · '))
    .replace(/\{sizes\}/g, availSizes.join(' - '))
    .replace(/\{description\}/g, product.description || '')
    .replace(/\{link\}/g, link)
    .replace(/\n{3,}/g, '\n\n')
    .trim();

  if (closingLine && !rendered.includes(closingLine)) {
    rendered = `${rendered}\n\n${closingLine}`;
  }
  return rendered;
}

export function describeError(err: unknown): string {
  if (!err) return 'خطأ غير معروف';
  if (typeof err === 'string') return err;
  const e = err as {
    message?: string;
    error_description?: string;
    details?: string;
    hint?: string;
    code?: string;
    statusCode?: string | number;
  };
  const msg = e.message || e.error_description || e.details || '';
  const lower = msg.toLowerCase();
  if (
    lower.includes('row-level security') ||
    lower.includes('violates row-level') ||
    e.code === '42501'
  ) {
    return 'الحساب غير مصرح له بالرفع أو الحفظ (جلسة الأدمن انتهت أو الإيميل غير مضاف في admin_emails). سجّلي خروج ثم دخول من جديد.';
  }
  if (lower.includes('jwt') || lower.includes('not authenticated') || lower.includes('token')) {
    return 'انتهت جلسة تسجيل الدخول. سجّلي خروج ثم دخول من جديد.';
  }
  if (
    lower.includes('failed to fetch') ||
    lower.includes('networkerror') ||
    lower.includes('load failed')
  ) {
    return 'مشكلة في الاتصال بالإنترنت أثناء الرفع أو الحفظ. جرّبي مرة أخرى.';
  }
  if (lower.includes('invalid image file') || lower.includes('failed to compress')) {
    return 'ملف الصورة غير مدعوم أو تالف (جرّبي صورة JPG أو PNG).';
  }
  if (lower.includes('payload too large') || lower.includes('exceeded the maximum')) {
    return 'حجم الصورة كبير جدًا.';
  }
  if (lower.includes('foreign key')) {
    return 'القسم أو النوع المختار غير موجود (ربما اتحذف). اختاري القسم من جديد.';
  }
  if (e.code === 'PGRST204' || lower.includes('schema cache')) {
    const colMatch = msg.match(/Could not find the '([^']+)' column/i);
    return colMatch
      ? `عمود "${colMatch[1]}" غير موجود في قاعدة البيانات — شغّلي كود تحديث الجداول في Supabase SQL Editor.`
      : 'في عمود ناقص في قاعدة البيانات — شغّلي كود تحديث الجداول في Supabase SQL Editor.';
  }
  return msg || e.code?.toString() || 'خطأ غير معروف';
}

export async function uploadWithConcurrency(
  files: File[],
  uploader: (file: File) => Promise<ProductImage>,
  concurrency: number,
  onProgress: (done: number, total: number) => void
): Promise<{
  succeeded: ProductImage[];
  failed: Array<{fileName: string; reason: string}>;
}> {
  const results: Array<
    | {ok: true; image: ProductImage}
    | {ok: false; fileName: string; reason: string}
    | null
  > = new Array(files.length).fill(null);
  let nextIdx = 0;
  let doneCount = 0;

  async function worker() {
    while (nextIdx < files.length) {
      const idx = nextIdx++;
      const file = files[idx];
      try {
        const image = await uploader(file);
        results[idx] = {ok: true, image};
      } catch (err) {
        console.error('upload failed', file.name, err);
        results[idx] = {
          ok: false,
          fileName: file.name || `صورة ${idx + 1}`,
          reason: describeError(err),
        };
      } finally {
        doneCount += 1;
        onProgress(doneCount, files.length);
      }
    }
  }

  const workers = Array.from({length: Math.min(concurrency, files.length)}, () => worker());
  await Promise.all(workers);

  const succeeded: ProductImage[] = [];
  const failed: Array<{fileName: string; reason: string}> = [];
  for (const r of results) {
    if (!r) continue;
    if (r.ok) succeeded.push(r.image);
    else failed.push({fileName: r.fileName, reason: r.reason});
  }
  return {succeeded, failed};
}
