import React, {useEffect, useMemo, useState} from 'react';
import {Link} from 'react-router-dom';
import {
  AlertTriangle,
  ClipboardList,
  Clock,
  FolderKanban,
  HardDrive,
  Image as ImageIcon,
  Lock,
  LogOut,
  Package,
  RefreshCw,
  Settings,
  Store,
} from 'lucide-react';
import {AdminBannersTab} from '../components/admin/AdminBannersTab';
import {AdminCategoriesTab} from '../components/admin/AdminCategoriesTab';
import {AdminExpiredTab} from '../components/admin/AdminExpiredTab';
import {AdminOrdersTab} from '../components/admin/AdminOrdersTab';
import {AdminProductsTab} from '../components/admin/AdminProductsTab';
import {AdminSettingsTab} from '../components/admin/AdminSettingsTab';
import {CrownOrnament} from '../components/BrandElements';
import {useStore} from '../context/StoreContext';
import {isProductExpired} from '../utils/catalogHelpers';

type AdminTab = 'orders' | 'products' | 'expired' | 'categories' | 'banners' | 'settings';

export const AdminPage: React.FC = () => {
  const {
    isDemoMode,
    isAdmin,
    authLoading,
    adminEmail,
    pinIsDefault,
    storageUsageBytes,
    fetchStorageUsageBytes,
    settings,
    products,
    orders,
    fetchOrders,
    signInAdmin,
    signOutAdmin,
  } = useStore();

  const [activeTab, setActiveTab] = useState<AdminTab>('orders');
  const [openChangePinSignal, setOpenChangePinSignal] = useState(0);
  const [refreshingStorage, setRefreshingStorage] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState<string | null>(null);
  const [loggingIn, setLoggingIn] = useState(false);

  useEffect(() => {
    if (isAdmin && !isDemoMode) {
      fetchOrders();
    }
  }, [isAdmin, isDemoMode, fetchOrders]);

  const expiryDays = Math.max(1, Number(settings.expiry_days) || 10);
  const expiredCount = useMemo(
    () => products.filter((p) => isProductExpired(p, expiryDays)).length,
    [products, expiryDays]
  );

  const newOrdersCount = orders.filter((o) => o.status === 'new').length;

  const storageSummary = useMemo(() => {
    const quotaBytes = 1073741824; // 1 GB
    const used = Math.max(0, storageUsageBytes ?? 0);
    const pct = Math.min(100, Math.round((used / quotaBytes) * 100));
    let usedLabel = '0 ك.ب';
    if (used >= 1024 * 1024 * 1024) {
      usedLabel = `${(used / (1024 * 1024 * 1024)).toFixed(2)} ج.ب`;
    } else if (used >= 1024 * 1024) {
      usedLabel = `${(used / (1024 * 1024)).toFixed(1)} م.ب`;
    } else if (used > 0) {
      usedLabel = `${Math.max(1, Math.round(used / 1024))} ك.ب`;
    }
    const barColor =
      pct >= 80 ? 'bg-[#B3261E]' : pct >= 65 ? 'bg-[#D97706]' : 'bg-[#0F4C3A]';
    const textColor =
      pct >= 80 ? 'text-[#B3261E]' : pct >= 65 ? 'text-[#B45309]' : 'text-[#0F4C3A]';
    return {pct, usedLabel, barColor, textColor};
  }, [storageUsageBytes]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError(null);
    setLoggingIn(true);
    try {
      const res = await signInAdmin(email, password);
      if (!res.ok) {
        setLoginError(res.message || 'فشل تسجيل الدخول');
      }
    } finally {
      setLoggingIn(false);
    }
  };

  if (authLoading) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-[#FBF6EA]">
        <p className="text-sm font-bold text-[#0F4C3A]">جاري التحقق من صلاحيات الإدارة...</p>
      </div>
    );
  }

  // Supabase Login Gate
  if (!isAdmin) {
    return (
      <div className="min-h-dvh flex items-center justify-center bg-[#FBF6EA] px-4 py-10">
        <div className="w-full max-w-sm rounded-[28px] bg-white border border-[#E8A91A]/35 p-6 sm:p-8 shadow-xl space-y-5">
          <div className="flex flex-col items-center text-center space-y-2">
            <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#E8A91A] bg-white">
              <img
                src={settings.logo_url || '/assets/aistudio/logo_be4d7522.png'}
                alt={settings.store_name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex items-center gap-1.5">
              <Lock className="w-4 h-4 text-[#0F4C3A]" />
              <h1 className="text-xl font-bold text-[#141413]">إدارة {settings.store_name}</h1>
            </div>
            <p className="text-xs text-[#5B5B5B]">
              الدخول مخصص لحساب الإدارة المسجل في قائمة المصرح لهم فقط.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-3.5">
            <label className="block space-y-1">
              <span className="text-xs font-bold text-[#5B5B5B]">البريد الإلكتروني</span>
              <input
                type="email"
                required
                dir="ltr"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="owner@example.com"
                className="w-full min-h-[46px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm text-left"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-bold text-[#5B5B5B]">كلمة المرور</span>
              <input
                type="password"
                required
                dir="ltr"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                className="w-full min-h-[46px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm text-left"
              />
            </label>

            {loginError && (
              <p className="text-xs font-bold text-[#B3261E] bg-[#B3261E]/10 rounded-xl p-2.5 text-center">
                {loginError}
              </p>
            )}

            <button
              type="submit"
              disabled={loggingIn}
              className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
            >
              {loggingIn ? 'جاري الدخول...' : 'دخول لوحة الإدارة'}
            </button>
          </form>

          <div className="text-center pt-1">
            <Link to="/" className="text-xs font-bold text-[#0F4C3A] hover:underline">
              العودة إلى المتجر
            </Link>
          </div>
        </div>
      </div>
    );
  }

  const tabs: Array<{id: AdminTab; label: string; icon: React.ReactNode; badge?: number}> = [
    {
      id: 'orders',
      label: 'الطلبات',
      icon: <ClipboardList className="w-5 h-5" />,
      badge: newOrdersCount > 0 ? newOrdersCount : undefined,
    },
    {id: 'products', label: 'المنتجات', icon: <Package className="w-5 h-5" />},
    {
      id: 'expired',
      label: 'المنتهية',
      icon: <Clock className="w-5 h-5" />,
      badge: expiredCount > 0 ? expiredCount : undefined,
    },
    {id: 'categories', label: 'الأقسام', icon: <FolderKanban className="w-5 h-5" />},
    {id: 'banners', label: 'الإعلانات', icon: <ImageIcon className="w-5 h-5" />},
    {id: 'settings', label: 'الإعدادات', icon: <Settings className="w-5 h-5" />},
  ];

  return (
    <div className="min-h-dvh bg-[#FBF6EA] text-[#141413] pb-24">
      {/* Admin Top Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-[#E8A91A]/30">
        <div className="max-w-5xl mx-auto px-4 h-14 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <CrownOrnament className="w-5 h-5 shrink-0" />
            <div className="min-w-0">
              <h1 className="text-sm sm:text-base font-bold text-[#141413] truncate">
                لوحة الإدارة · {settings.store_name}
              </h1>
              <p className="text-[11px] text-[#5B5B5B] truncate">
                {isDemoMode ? 'وضع تجريبي (التعديلات مؤقتة في الذاكرة)' : adminEmail}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <Link
              to="/"
              className="min-h-[40px] px-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5"
            >
              <Store className="w-4 h-4" />
              <span>المتجر</span>
            </Link>
            {!isDemoMode && (
              <button
                type="button"
                onClick={signOutAdmin}
                aria-label="تسجيل الخروج"
                className="min-w-[40px] min-h-[40px] rounded-2xl bg-[#B3261E]/10 text-[#B3261E] flex items-center justify-center cursor-pointer"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Active Tab Content */}
      <main className="max-w-5xl mx-auto px-4 py-5 space-y-4">
        {pinIsDefault && (
          <div className="rounded-[22px] bg-[#FEF3C7] border border-[#E8A91A] text-[#141413] p-4 shadow-xs flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <Lock className="w-5 h-5 text-[#B3261E] shrink-0" />
              <p className="text-sm font-bold leading-snug">
                تنبيه أمان: الرقم السري الافتراضي (1234) لسه متفعل — غيّريه دلوقتي
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                setActiveTab('settings');
                setOpenChangePinSignal((n) => n + 1);
              }}
              className="min-h-[40px] px-4 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold hover:bg-[#0A3629] transition-colors cursor-pointer shrink-0"
            >
              غيّريه دلوقتي
            </button>
          </div>
        )}

        {expiredCount > 0 && activeTab !== 'expired' && (
          <div className="rounded-[22px] bg-[#B3261E] text-white p-4 shadow-md flex flex-wrap items-center justify-between gap-3">
            <div className="flex items-center gap-2.5">
              <AlertTriangle className="w-5 h-5 text-[#F6CF5A] shrink-0" />
              <p className="text-sm font-bold leading-snug">
                فيه {expiredCount} موديل عدّى عليهم {expiryDays} يوم
              </p>
            </div>
            <button
              type="button"
              onClick={() => setActiveTab('expired')}
              className="min-h-[40px] px-4 rounded-xl bg-[#F6CF5A] text-[#141413] text-xs font-bold hover:bg-white transition-colors cursor-pointer shrink-0"
            >
              تنظيف الموديلات المنتهية
            </button>
          </div>
        )}

        {/* Storage Usage Progress Bar */}
        {storageUsageBytes !== null && (
          <section
            aria-label="المساحة المستخدمة"
            className="rounded-[22px] bg-white border border-[#E8A91A]/30 px-4 py-3 shadow-xs space-y-2"
          >
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 min-w-0">
                <HardDrive className={`w-4 h-4 shrink-0 ${storageSummary.textColor}`} />
                <span className="text-xs sm:text-sm font-bold text-[#141413] tabular-nums truncate">
                  المساحة المستخدمة {storageSummary.usedLabel} من 1 GB ({storageSummary.pct}%)
                </span>
                {isDemoMode && (
                  <span className="text-[11px] text-[#5B5B5B] hidden sm:inline">· تقديري</span>
                )}
              </div>
              <button
                type="button"
                disabled={refreshingStorage}
                onClick={async () => {
                  setRefreshingStorage(true);
                  try {
                    await fetchStorageUsageBytes();
                  } finally {
                    setRefreshingStorage(false);
                  }
                }}
                aria-label="تحديث قياس المساحة"
                className="min-w-[36px] min-h-[36px] rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 flex items-center justify-center text-[#0F4C3A] cursor-pointer shrink-0"
              >
                <RefreshCw className={`w-3.5 h-3.5 ${refreshingStorage ? 'animate-spin' : ''}`} />
              </button>
            </div>
            <div className="w-full h-2 rounded-full bg-[#FBF6EA] overflow-hidden border border-[#E8A91A]/25">
              <div
                className={`h-full transition-all duration-300 ${storageSummary.barColor}`}
                style={{width: `${Math.max(storageSummary.pct, storageUsageBytes > 0 ? 2 : 0)}%`}}
              />
            </div>
          </section>
        )}

        {activeTab === 'orders' && <AdminOrdersTab />}
        {activeTab === 'products' && <AdminProductsTab />}
        {activeTab === 'expired' && <AdminExpiredTab />}
        {activeTab === 'categories' && <AdminCategoriesTab />}
        {activeTab === 'banners' && <AdminBannersTab />}
        {activeTab === 'settings' && (
          <AdminSettingsTab openChangePinSignal={openChangePinSignal} />
        )}
      </main>

      {/* Bottom 6-Tab Navigation Bar */}
      <nav
        aria-label="أقسام الإدارة"
        className="fixed bottom-3 left-2 right-2 max-w-2xl mx-auto z-40 h-16 rounded-[22px] bg-white/95 backdrop-blur-md border border-[#E8A91A]/40 shadow-xl grid grid-cols-6 items-center px-1"
      >
        {tabs.map((tab) => {
          const active = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              type="button"
              onClick={() => setActiveTab(tab.id)}
              className={`relative min-h-[48px] flex flex-col items-center justify-center gap-0.5 rounded-2xl transition-colors cursor-pointer ${
                active ? 'text-[#0F4C3A] font-bold bg-[#FBF6EA]' : 'text-[#5B5B5B]'
              }`}
            >
              <div className="relative">
                {tab.icon}
                {tab.badge && (
                  <span className="absolute -top-1.5 -left-2 min-w-[16px] h-[16px] px-1 rounded-full bg-[#B3261E] text-white text-[10px] font-bold flex items-center justify-center tabular-nums">
                    {tab.badge}
                  </span>
                )}
              </div>
              <span className="text-[11px] leading-none">{tab.label}</span>
            </button>
          );
        })}
      </nav>
    </div>
  );
};
