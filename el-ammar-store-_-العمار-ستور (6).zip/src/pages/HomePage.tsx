import React, {useEffect, useMemo, useState} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import {
  ArrowLeft,
  CheckCircle2,
  Clock,
  Heart,
  HelpCircle,
  MessageCircle,
  Search,
  ShieldCheck,
  Sparkles,
  Tag,
  X,
} from 'lucide-react';
import {CrownOrnament, EmptyState, ProductCardSkeleton, ResilientImage} from '../components/BrandElements';
import {CategoryIcon} from '../components/CategoryIcon';
import {HeroCarousel} from '../components/HeroCarousel';
import {ProductCard} from '../components/ProductCard';
import {useStore} from '../context/StoreContext';
import type {TrustIconType} from '../types/store';
import {
  formatPrice,
  getProductMainImageObj,
  normalizeSearchText,
  sortCatalogProducts,
} from '../utils/catalogHelpers';

function useCountdown(targetIso: string, enabled: boolean) {
  const [remaining, setRemaining] = useState({days: 0, hours: 0, mins: 0, secs: 0, active: false});

  useEffect(() => {
    if (!enabled || !targetIso) {
      setRemaining({days: 0, hours: 0, mins: 0, secs: 0, active: false});
      return;
    }
    const update = () => {
      const diff = new Date(targetIso).getTime() - Date.now();
      if (Number.isNaN(diff) || diff <= 0) {
        setRemaining({days: 0, hours: 0, mins: 0, secs: 0, active: false});
        return;
      }
      const days = Math.floor(diff / (1000 * 60 * 60 * 24));
      const hours = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const mins = Math.floor((diff / (1000 * 60)) % 60);
      const secs = Math.floor((diff / 1000) % 60);
      setRemaining({days, hours, mins, secs, active: true});
    };
    update();
    const t = window.setInterval(update, 1000);
    return () => window.clearInterval(t);
  }, [targetIso, enabled]);

  return remaining;
}

const TrustBadgeIcon: React.FC<{icon: TrustIconType}> = ({icon}) => {
  const cls = 'w-5 h-5 text-[#0F4C3A] shrink-0';
  switch (icon) {
    case 'shield':
      return <ShieldCheck className={cls} />;
    case 'message':
      return <MessageCircle className={cls} />;
    case 'check':
      return <CheckCircle2 className={cls} />;
    case 'heart':
      return <Heart className={cls} />;
    case 'tag':
      return <Tag className={cls} />;
    default:
      return <Sparkles className={cls} />;
  }
};

export const HomePage: React.FC = () => {
  const {
    categories,
    products,
    banners,
    settings,
    recentlyViewed,
    loading,
    error,
    refreshCatalog,
  } = useStore();

  const [query, setQuery] = useState('');
  const [showHowBanner, setShowHowBanner] = useState(() => {
    try {
      return !window.localStorage.getItem('elamar_how_seen_v1');
    } catch {
      return false;
    }
  });
  const navigate = useNavigate();

  const dismissHowBanner = () => {
    setShowHowBanner(false);
    try {
      window.localStorage.setItem('elamar_how_seen_v1', '1');
    } catch {
      // Ignore storage failures in restricted webviews
    }
  };

  // Top-level categories only on Home circles
  const topCategories = useMemo(
    () =>
      categories
        .filter((c) => !c.parent_id && c.visible)
        .sort((a, b) => a.sort - b.sort),
    [categories]
  );

  const visibleProducts = useMemo(
    () => sortCatalogProducts(products.filter((p) => p.visible)),
    [products]
  );

  const liveSearchResults = useMemo(() => {
    const qNorm = normalizeSearchText(query);
    if (!qNorm) return [];
    return visibleProducts
      .filter((p) => {
        const catName = categories.find((c) => c.id === p.category_id)?.name || '';
        const subName = categories.find((c) => c.id === p.subcategory_id)?.name || '';
        return (
          normalizeSearchText(p.name).includes(qNorm) ||
          normalizeSearchText(p.code).includes(qNorm) ||
          normalizeSearchText(catName).includes(qNorm) ||
          normalizeSearchText(subName).includes(qNorm)
        );
      })
      .slice(0, 6);
  }, [query, visibleProducts, categories]);

  const featuredProducts = useMemo(
    () => visibleProducts.filter((p) => p.featured).slice(0, 8),
    [visibleProducts]
  );

  const latestProducts = useMemo(() => visibleProducts.slice(0, 8), [visibleProducts]);

  const offerProducts = useMemo(
    () => visibleProducts.filter((p) => p.old_price && p.old_price > p.price).slice(0, 8),
    [visibleProducts]
  );

  const recentProducts = useMemo(() => {
    if (!settings.features.recently_viewed.enabled || recentlyViewed.length === 0) return [];
    return recentlyViewed
      .map((id) => visibleProducts.find((p) => p.id === id))
      .filter(Boolean) as typeof visibleProducts;
  }, [settings.features.recently_viewed.enabled, recentlyViewed, visibleProducts]);

  const activeTrustItems = useMemo(
    () => (settings.trust_items || []).filter((item) => item.text?.trim().length > 0),
    [settings.trust_items]
  );

  const countdown = useCountdown(
    settings.features.offers_countdown.end_date,
    settings.features.offers_countdown.enabled
  );

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    navigate(q ? `/catalog?q=${encodeURIComponent(q)}` : '/catalog');
  };

  if (error) {
    return (
      <div className="max-w-6xl mx-auto px-4 py-12">
        <EmptyState
          title="تعذر تحميل المنتجات"
          subtitle="تأكدي من اتصالك بالإنترنت وحاولي مرة تانية."
          actionLabel="إعادة المحاولة"
          onAction={refreshCatalog}
        />
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 sm:py-6 space-y-8 page-enter">
      {showHowBanner && (
        <div className="rounded-[22px] bg-[#FFFDF8] border border-[#E8A91A]/45 px-4 py-2.5 flex items-center justify-between gap-2.5 shadow-xs">
          <Link
            to="/how"
            onClick={dismissHowBanner}
            className="flex-1 min-w-0 flex items-center gap-2 text-xs sm:text-sm font-bold text-[#0F4C3A] hover:underline"
          >
            <HelpCircle className="w-4 h-4 text-[#E8A91A] shrink-0" />
            <span className="truncate">
              أول مرة تطلبي؟ شوفي خطوات الطلب السهلة في 30 ثانية
            </span>
          </Link>
          <button
            type="button"
            onClick={dismissHowBanner}
            aria-label="إخفاء"
            className="min-w-[36px] min-h-[36px] rounded-xl text-[#5B5B5B] hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      )}

      {/* 1. Live Search Bar */}
      <section aria-label="البحث السريع" className="relative z-20">
        <form onSubmit={handleSearchSubmit} className="relative">
          <Search className="w-5 h-5 text-[#5B5B5B] absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="ابحثي بالاسم أو الكود أو القسم (كوتشي، شنطة...)"
            aria-label="ابحثي في الكتالوج"
            className="w-full min-h-[48px] pr-11 pl-11 rounded-[20px] bg-white border border-[#E8A91A]/35 text-sm sm:text-base text-[#141413] placeholder:text-[#5B5B5B] shadow-xs"
          />
          {query && (
            <button
              type="button"
              onClick={() => setQuery('')}
              aria-label="مسح البحث"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center absolute left-1 top-1/2 -translate-y-1/2 text-[#5B5B5B] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </form>

        {query.trim().length > 0 && (
          <div className="absolute left-0 right-0 mt-2 rounded-[22px] bg-white border border-[#E8A91A]/35 shadow-xl overflow-hidden z-30">
            {liveSearchResults.length === 0 ? (
              <div className="p-4 text-center text-sm text-[#5B5B5B]">
                لا توجد نتائج مطابقة لـ «{query}»
              </div>
            ) : (
              <div className="divide-y divide-[#E8A91A]/15">
                {liveSearchResults.map((p) => {
                  const thumbObj = getProductMainImageObj(p);
                  return (
                    <Link
                      key={p.id}
                      to={`/p/${p.id}`}
                      className="flex items-center gap-3 p-3 hover:bg-[#FBF6EA] transition-colors"
                    >
                      <div className="w-11 aspect-[3/4] rounded-xl overflow-hidden bg-[#F7EFE0] shrink-0">
                        <ResilientImage
                          src={thumbObj.thumb}
                          alt={p.name}
                          style={{objectPosition: `${thumbObj.focus_x}% ${thumbObj.focus_y}%`}}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-bold text-[#141413] truncate">{p.name}</p>
                        <div className="flex items-center gap-2 text-xs tabular-nums">
                          <span className="text-[#0F4C3A] font-semibold">
                            {formatPrice(p.price)}
                          </span>
                          {p.code && (
                            <span className="text-[#5B5B5B]">· كود: {p.code}</span>
                          )}
                        </div>
                      </div>
                      <ArrowLeft className="w-4 h-4 text-[#5B5B5B] shrink-0" />
                    </Link>
                  );
                })}
                <button
                  type="button"
                  onClick={handleSearchSubmit}
                  className="w-full min-h-[44px] text-center text-sm font-bold text-[#0F4C3A] bg-[#FBF6EA] hover:bg-[#E8A91A]/20 transition-colors cursor-pointer"
                >
                  عرض كل نتائج «{query}»
                </button>
              </div>
            )}
          </div>
        )}
      </section>

      {/* 2. Circular Top-Level Categories Row + Quick "كيف أطلب؟" Link */}
      <section aria-label="الأقسام">
        <div className="flex items-center justify-between gap-3 mb-3">
          <div className="flex items-center gap-2">
            <CrownOrnament className="w-5 h-5" />
            <h2 className="text-lg sm:text-xl font-bold text-[#141413]">تصفحي حسب القسم</h2>
          </div>
          <Link
            to="/how"
            className="min-h-[40px] px-3.5 rounded-2xl bg-white border border-[#E8A91A]/45 text-xs sm:text-sm font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 hover:bg-[#FBF6EA] whitespace-nowrap shrink-0 shadow-xs"
          >
            <HelpCircle className="w-4 h-4 text-[#E8A91A]" />
            <span>كيف أطلب؟</span>
          </Link>
        </div>

        <div className="flex items-start gap-4 sm:gap-6 overflow-x-auto no-scrollbar py-2 px-1">
          {topCategories.map((cat) => (
            <Link
              key={cat.id}
              to={`/c/${cat.id}`}
              className="group flex flex-col items-center gap-1.5 shrink-0 w-20 sm:w-24 text-center focus-visible:outline-none"
            >
              <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#FBF6EA] border border-[#E8A91A]/40 p-1 flex items-center justify-center shadow-xs transition-transform duration-200 ease-out group-hover:scale-[1.04] group-active:scale-90 overflow-hidden">
                {cat.image_url ? (
                  <ResilientImage
                    src={cat.image_url}
                    alt={cat.name}
                    fallbackLabel={cat.name}
                    className="w-full h-full rounded-full object-cover"
                  />
                ) : (
                  <CategoryIcon
                    name={cat.name}
                    animated
                    className="w-16 h-16 sm:w-[72px] sm:h-[72px] transition-transform duration-200 group-hover:scale-105"
                  />
                )}
              </div>
              <div
                aria-hidden="true"
                className="w-12 sm:w-14 h-2.5 -mt-1.5 rounded-full bg-[#0F4C3A]/15 blur-[4px] transition-transform duration-200 group-hover:scale-95 group-active:scale-90"
              />
              <span className="text-xs sm:text-sm font-bold text-[#141413] leading-tight">
                {cat.name}
              </span>
            </Link>
          ))}

          {/* Virtual "عروض" Category */}
          <Link
            to="/offers"
            className="group flex flex-col items-center gap-1.5 shrink-0 w-20 sm:w-24 text-center focus-visible:outline-none"
          >
            <div className="w-20 h-20 sm:w-24 sm:h-24 rounded-full bg-[#FBF6EA] border border-[#E8A91A]/55 p-1 flex items-center justify-center shadow-xs transition-transform duration-200 ease-out group-hover:scale-[1.04] group-active:scale-90">
              <CategoryIcon
                name="عروض"
                animated
                className="w-16 h-16 sm:w-[72px] sm:h-[72px] transition-transform duration-200 group-hover:scale-105"
              />
            </div>
            <div
              aria-hidden="true"
              className="w-12 sm:w-14 h-2.5 -mt-1.5 rounded-full bg-[#0F4C3A]/15 blur-[4px] transition-transform duration-200 group-hover:scale-95 group-active:scale-90"
            />
            <span className="text-xs sm:text-sm font-bold text-[#B3261E] leading-tight">
              عروض
            </span>
          </Link>
        </div>
      </section>

      {/* 3. New Arrivals ("وصل جديد") — right near the top */}
      <section aria-label="وصل جديد">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CrownOrnament className="w-5 h-5" />
            <h2 className="text-lg sm:text-xl font-bold text-[#141413]">وصل جديد</h2>
          </div>
          <Link
            to="/catalog"
            className="min-h-[44px] inline-flex items-center gap-1 text-sm font-bold text-[#0F4C3A] hover:underline whitespace-nowrap"
          >
            <span>المزيد</span>
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
            {Array.from({length: 4}).map((_, i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
            {latestProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        )}
      </section>

      {/* 4. Marketing Hero Carousel */}
      <HeroCarousel banners={banners} />

      {/* 5. Optional Trust Strip (hidden when empty or disabled) */}
      {settings.features.trust_strip?.enabled && activeTrustItems.length > 0 && (
        <section aria-label="مميزات المتجر">
          <div className="grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
            {activeTrustItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-center sm:justify-start gap-2.5 rounded-2xl bg-white border border-[#E8A91A]/25 px-4 py-3 shadow-xs"
              >
                <div className="w-8 h-8 rounded-full bg-[#FBF6EA] flex items-center justify-center shrink-0">
                  <TrustBadgeIcon icon={item.icon} />
                </div>
                <span className="text-xs sm:text-sm font-bold text-[#141413]">{item.text}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* 6. Welcome Message */}
      {settings.welcome && (
        <section className="flex items-center justify-center text-center px-2">
          <div className="inline-flex items-center gap-2.5 max-w-2xl">
            <CrownOrnament className="w-5 h-5 shrink-0" />
            <p className="text-sm sm:text-base font-semibold text-[#0F4C3A] leading-relaxed">
              {settings.welcome}
            </p>
            <CrownOrnament className="w-5 h-5 shrink-0" />
          </div>
        </section>
      )}

      {/* 7. Featured Products */}
      <section aria-label="منتجات مميزة">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <CrownOrnament className="w-5 h-5" />
            <h2 className="text-lg sm:text-xl font-bold text-[#141413]">منتجات مميزة</h2>
          </div>
          <Link
            to="/catalog"
            className="min-h-[44px] inline-flex items-center gap-1 text-sm font-bold text-[#0F4C3A] hover:underline whitespace-nowrap"
          >
            <span>الكل</span>
            <ArrowLeft className="w-4 h-4" />
          </Link>
        </div>

        {loading ? (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
            {Array.from({length: 4}).map((_, i) => (
              <ProductCardSkeleton key={i} />
            ))}
          </div>
        ) : featuredProducts.length === 0 ? (
          <EmptyState title="لا توجد منتجات مميزة حالياً" />
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
            {featuredProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        )}
      </section>

      {/* 8. Offers & Discounts */}
      {offerProducts.length > 0 && (
        <section aria-label="عروض وخصومات">
          <div className="flex flex-wrap items-center justify-between gap-3 mb-4">
            <div className="flex items-center gap-2">
              <CrownOrnament className="w-5 h-5" />
              <h2 className="text-lg sm:text-xl font-bold text-[#141413]">عروض وخصومات</h2>
            </div>

            {countdown.active && (
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-2xl bg-[#B3261E] text-white text-xs font-bold tabular-nums">
                <Clock className="w-3.5 h-3.5 text-[#F6CF5A]" />
                <span>
                  ينتهي خلال {countdown.days}ي : {String(countdown.hours).padStart(2, '0')}س :{' '}
                  {String(countdown.mins).padStart(2, '0')}د : {String(countdown.secs).padStart(2, '0')}ث
                </span>
              </div>
            )}

            <Link
              to="/offers"
              className="min-h-[44px] inline-flex items-center gap-1 text-sm font-bold text-[#B3261E] hover:underline whitespace-nowrap"
            >
              <span>كل العروض</span>
              <ArrowLeft className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
            {offerProducts.map((p, i) => (
              <ProductCard key={p.id} product={p} index={i} />
            ))}
          </div>
        </section>
      )}

      {/* Optional: Recently Viewed Strip */}
      {recentProducts.length > 0 && (
        <section aria-label="شوفتيها قبل كده">
          <div className="flex items-center gap-2 mb-4">
            <CrownOrnament className="w-5 h-5" />
            <h2 className="text-lg sm:text-xl font-bold text-[#141413]">شوفتيها قبل كده</h2>
          </div>
          <div className="flex gap-3.5 overflow-x-auto no-scrollbar pb-2">
            {recentProducts.map((p, i) => (
              <div key={p.id} className="w-44 sm:w-52 shrink-0">
                <ProductCard product={p} index={i} />
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Optional: Customer Reviews Screenshots Strip */}
      {settings.features.customer_reviews.enabled &&
        settings.features.customer_reviews.items.length > 0 && (
          <section aria-label="آراء عميلاتنا">
            <div className="flex items-center gap-2 mb-4">
              <CrownOrnament className="w-5 h-5" />
              <h2 className="text-lg sm:text-xl font-bold text-[#141413]">آراء عميلاتنا</h2>
            </div>
            <div className="flex gap-4 overflow-x-auto no-scrollbar pb-2">
              {settings.features.customer_reviews.items.map((rev) => (
                <div
                  key={rev.id}
                  className="w-56 sm:w-64 shrink-0 rounded-[22px] bg-white p-2 border border-[#E8A91A]/25 shadow-xs"
                >
                  <ResilientImage
                    src={rev.image_url}
                    alt={rev.caption || 'رأي عميلة'}
                    className="w-full aspect-[3/3.6] object-cover rounded-[16px]"
                  />
                  {rev.caption && (
                    <p className="mt-2 px-1 text-xs font-semibold text-[#5B5B5B] truncate">
                      {rev.caption}
                    </p>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

      {/* View All Products CTA */}
      <div className="flex justify-center pt-2">
        <Link
          to="/catalog"
          className="shine-sweep inline-flex items-center justify-center gap-2.5 min-h-[50px] px-8 py-3 rounded-[22px] bg-[#0F4C3A] text-white font-bold text-base shadow-md hover:bg-[#0A3629] active:scale-[0.98] transition-all"
        >
          <Sparkles className="w-5 h-5 text-[#F6CF5A]" />
          <span>مشاهدة كل المنتجات</span>
        </Link>
      </div>
    </div>
  );
};
