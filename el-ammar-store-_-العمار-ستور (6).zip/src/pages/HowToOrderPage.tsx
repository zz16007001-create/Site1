import React, {useEffect, useState} from 'react';
import {Link} from 'react-router-dom';
import {
  ArrowLeft,
  ArrowRight,
  Check,
  ChevronLeft,
  ClipboardCopy,
  HelpCircle,
  MessageCircle,
  Pause,
  PhoneCall,
  Play,
  Ruler,
  Search,
  ShoppingBag,
  Sparkles,
} from 'lucide-react';
import {CrownOrnament} from '../components/BrandElements';
import {useStore} from '../context/StoreContext';

interface StepItem {
  number: number;
  title: string;
  shortLabel: string;
  description: string;
  tip: string;
}

const STEPS: StepItem[] = [
  {
    number: 1,
    shortLabel: 'اختاري مقاسك',
    title: 'تصفحي أو ابحثي واختاري مقاسك (مقاسي)',
    description:
      'افتحي القسم اللي بتدوري عليه أو اكتبي اسم أو كود الموديل في البحث، وممكن تضغطي على زر «مقاسي» عشان تشوفي الموديلات المتوفرة بمقاسك بس.',
    tip: 'الكتالوج بيحفظ مقاسك المفضل تلقائياً عشان ما تعيديش اختياره كل مرة.',
  },
  {
    number: 2,
    shortLabel: 'شوفي الموديل',
    title: 'افتحي الموديل وشوفي الصور والألوان',
    description:
      'اضغطي على أي موديل يعجبك عشان تشوفي صوره الحقيقية بوضوح، وتقلّبي بين كل الألوان المتاحة له وسعره وكود الموديل.',
    tip: 'لما تضغطي على أي لون، الصور بتتغير فوراً لصور اللون ده.',
  },
  {
    number: 3,
    shortLabel: 'اللون والمقاس',
    title: 'اختاري اللون والمقاس المناسب',
    description:
      'حددي اللون اللي عجبك ثم اختاري المقاس المتاح تحت الصورة. لو الموديل متوفر بمقاس أو لون واحد بس هتلاقيه متحدد جاهز ليكي.',
    tip: 'تقدري كمان تضيفي أكتر من موديل للسلة وتطلبيهم كلهم في رسالة واحدة.',
  },
  {
    number: 4,
    shortLabel: 'اختاري طريقة الطلب',
    title: 'اطلبي واتساب أو ماسنجر أو سيبيلنا رقمك',
    description:
      'اضغطي «اطلبي الآن» واختاري اللي يريحك: واتساب (الأسرع)، أو ماسنجر (بخطوة نسخ ولصق)، أو «اطلبي ونكلمك» لو عايزانا نتصل بيكي.',
    tip: 'مش محتاجة أي حساب أو كلمة سر أو دفع أونلاين عشان تطلبي.',
  },
  {
    number: 5,
    shortLabel: 'التأكيد والشحن',
    title: 'هنأكد التوافر والشحن في الشات',
    description:
      'أول ما يوصّلنا طلبك هنراجع المقاس واللون المتاحين، ونأكد معاكي عنوان التوصيل وميعاد الشحن وسعر المندوب قبل ما نخرّج الأوردر.',
    tip: 'الدفع بيكون عند الاستلام بعد ما تتأكدي من كل تفاصيل طلبك.',
  },
];

const FAQ_ITEMS = [
  {
    q: 'لو مش بعرف أطلب من الماسنجر أعمل إيه؟',
    a: 'الأمر بسيط جداً: لما تختاري ماسنجر، الموقع بينسخ رسالة الطلب تلقائياً (أو دوسي «نسخ الرسالة»). لما يفتح الشات، اضغطي ضغطة مطوّلة جوا خانة الكتابة واختاري «لصق / Paste» وابعتي.',
  },
  {
    q: 'ينفع أطلب من غير واتساب أو ماسنجر؟',
    a: 'أيوة طبعاً! اختاري زر «اطلبي ونكلمك»، اكتبي رقم موبايلك (11 رقم بيبدأ بـ 01) وهنتصل بيكي أو نكلمك واتساب نأكد الطلب.',
  },
  {
    q: 'إيه فائدة كود الموديل اللي مكتوب تحت الصورة؟',
    a: 'كل موديل له كود مميز (زي SH-101) بيتكتب تلقائياً في رسالة الطلب وبيسهل علينا نجهّز طلبك بسرعة من غير أي لخبطة.',
  },
  {
    q: 'هل في دفع أونلاين بالفيزا؟',
    a: 'لا، مفيش أي دفع أونلاين على الموقع. الطلب بيتأكد في الشات أو المكالمة الأول.',
  },
];

const StepVisualMockup: React.FC<{stepNumber: number}> = ({stepNumber}) => {
  switch (stepNumber) {
    case 1:
      return (
        <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-4 space-y-3">
          <div className="flex items-center gap-2 rounded-xl bg-white border border-[#E8A91A]/30 px-3 py-2 text-xs text-[#5B5B5B]">
            <Search className="w-4 h-4 text-[#0F4C3A] shrink-0" />
            <span className="truncate">ابحثي: كوتشي أو SH-101...</span>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-1.5 text-[11px] font-bold text-[#0F4C3A]">
              <Ruler className="w-3.5 h-3.5" />
              <span>مقاسي</span>
            </div>
            <div className="flex flex-wrap gap-1.5 tabular-nums">
              {['الكل', '37', '38', '39', '40'].map((sz) => (
                <span
                  key={sz}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold border ${
                    sz === '38'
                      ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                      : 'bg-white text-[#141413] border-[#E8A91A]/30'
                  }`}
                >
                  {sz}
                </span>
              ))}
            </div>
          </div>
        </div>
      );

    case 2:
      return (
        <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-4 flex items-center gap-4">
          <div className="w-24 aspect-[3/4] rounded-xl bg-white border border-[#E8A91A]/35 flex flex-col items-center justify-center p-2 shrink-0">
            <svg viewBox="0 0 80 60" className="w-16 h-12 text-[#0F4C3A]" fill="none" aria-hidden="true">
              <path
                d="M12 40c6-9 14-14 23-16l8 8c5 5 13 6 23 6 3 0 6 2 6 6v4H10v-4c0-2 1-3 2-4z"
                fill="#0F4C3A"
                fillOpacity="0.14"
                stroke="#0F4C3A"
                strokeWidth="2.5"
                strokeLinejoin="round"
              />
              <path d="M10 48h62" stroke="#E8A91A" strokeWidth="3" strokeLinecap="round" />
            </svg>
            <span className="mt-1 text-[10px] font-bold text-[#5B5B5B] tabular-nums">كود: SH-101</span>
          </div>
          <div className="flex-1 min-w-0 space-y-2">
            <p className="text-xs font-bold text-[#141413]">صور الموديل من كل الزوايا</p>
            <div className="flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-[#141413] border-2 border-[#0F4C3A]" />
              <span className="w-5 h-5 rounded-full bg-[#D9C7AD] border border-black/15" />
              <span className="w-5 h-5 rounded-full bg-[#6E222A] border border-black/15" />
            </div>
            <p className="text-sm font-bold text-[#0F4C3A] tabular-nums">450 ج.م</p>
          </div>
        </div>
      );

    case 3:
      return (
        <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-4 space-y-3">
          <div className="flex items-center justify-between text-xs font-bold">
            <span className="text-[#5B5B5B]">اللون المختار:</span>
            <span className="text-[#0F4C3A]">بيج فاتح</span>
          </div>
          <div className="flex items-center gap-2 tabular-nums">
            {['37', '38', '39', '40'].map((sz) => (
              <span
                key={sz}
                className={`min-w-[40px] h-9 rounded-xl flex items-center justify-center text-xs font-bold border ${
                  sz === '38'
                    ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                    : 'bg-white text-[#141413] border-[#E8A91A]/30'
                }`}
              >
                {sz}
              </span>
            ))}
          </div>
          <div className="h-10 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold flex items-center justify-center gap-1.5">
            <ShoppingBag className="w-4 h-4 text-[#F6CF5A]" />
            <span>اطلبي الآن</span>
          </div>
        </div>
      );

    case 4:
      return (
        <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-4 space-y-2">
          <div className="h-10 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold flex items-center justify-center gap-2">
            <MessageCircle className="w-4 h-4 text-[#F6CF5A]" />
            <span>إرسال عبر واتساب</span>
          </div>
          <div className="h-10 rounded-xl bg-white border border-[#0F4C3A] text-[#0F4C3A] text-xs font-bold flex items-center justify-center gap-2">
            <ClipboardCopy className="w-4 h-4" />
            <span>إرسال عبر ماسنجر</span>
          </div>
          <div className="h-10 rounded-xl bg-[#FFFDF8] border border-[#E8A91A]/45 text-[#141413] text-xs font-bold flex items-center justify-center gap-2">
            <PhoneCall className="w-4 h-4 text-[#0F4C3A]" />
            <span>اطلبي ونكلمك (01xxxxxxxxx)</span>
          </div>
        </div>
      );

    default:
      return (
        <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-4 space-y-2.5 text-center">
          <div className="w-11 h-11 rounded-full bg-[#0F4C3A] text-white flex items-center justify-center mx-auto">
            <Check className="w-5 h-5 text-[#F6CF5A]" />
          </div>
          <p className="text-sm font-bold text-[#0F4C3A] tabular-nums">وصل طلبك رقم #104</p>
          <p className="text-xs text-[#5B5B5B] leading-relaxed">
            بنراجع المقاس واللون وبنأكد معاكي الشحن والعنوان قبل خروج الأوردر.
          </p>
        </div>
      );
  }
};

export const HowToOrderPage: React.FC = () => {
  const {settings} = useStore();
  const [activeIndex, setActiveIndex] = useState(0);
  const [autoPlay, setAutoPlay] = useState(() => {
    if (typeof window === 'undefined' || !window.matchMedia) return false;
    return !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  });

  useEffect(() => {
    if (!autoPlay) return;
    const timer = window.setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % STEPS.length);
    }, 4500);
    return () => window.clearInterval(timer);
  }, [autoPlay]);

  const handleSelectStep = (idx: number) => {
    setAutoPlay(false);
    setActiveIndex(idx);
  };

  const current = STEPS[activeIndex];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-5 sm:py-8 space-y-7 page-enter">
      {/* Header */}
      <div className="space-y-2 text-center sm:text-right">
        <div className="flex items-center justify-between gap-2">
          <Link
            to="/"
            className="min-h-[44px] inline-flex items-center gap-1.5 text-xs sm:text-sm font-bold text-[#0F4C3A] hover:underline"
          >
            <ArrowRight className="w-4 h-4" />
            <span>العودة للرئيسية</span>
          </Link>

          <button
            type="button"
            onClick={() => setAutoPlay((p) => !p)}
            className="min-h-[40px] px-3 rounded-xl bg-white border border-[#E8A91A]/35 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 cursor-pointer"
          >
            {autoPlay ? (
              <>
                <Pause className="w-3.5 h-3.5" />
                <span>إيقاف العرض التلقائي</span>
              </>
            ) : (
              <>
                <Play className="w-3.5 h-3.5" />
                <span>تشغيل تلقائي</span>
              </>
            )}
          </button>
        </div>

        <div className="flex items-center justify-center sm:justify-start gap-2 pt-1">
          <CrownOrnament className="w-5 h-5 shrink-0" />
          <h1 className="text-xl sm:text-2xl font-bold text-[#141413]">
            إزاي تطلبي من {settings.store_name} في 30 ثانية
          </h1>
        </div>
        <p className="text-sm text-[#5B5B5B]">
          5 خطوات سهلة من غير تسجيل حساب ولا دفع أونلاين — اختاري أي خطوة لتفاصيلها.
        </p>
      </div>

      {/* Step Switcher Tabs */}
      <div
        role="tablist"
        aria-label="خطوات الطلب"
        className="grid grid-cols-2 sm:grid-cols-5 gap-2"
      >
        {STEPS.map((step, idx) => {
          const active = idx === activeIndex;
          return (
            <button
              key={step.number}
              role="tab"
              aria-selected={active}
              type="button"
              onClick={() => handleSelectStep(idx)}
              className={`min-h-[48px] px-3 py-2 rounded-2xl border text-right transition-colors cursor-pointer flex items-center gap-2 ${
                active
                  ? 'bg-[#0F4C3A] text-white border-[#0F4C3A] shadow-sm'
                  : 'bg-white text-[#141413] border-[#E8A91A]/30 hover:bg-[#FBF6EA]'
              }`}
            >
              <span
                className={`w-6 h-6 rounded-full text-xs font-bold flex items-center justify-center shrink-0 tabular-nums ${
                  active ? 'bg-[#F6CF5A] text-[#141413]' : 'bg-[#FBF6EA] text-[#0F4C3A]'
                }`}
              >
                {step.number}
              </span>
              <span className="text-xs font-bold truncate">{step.shortLabel}</span>
            </button>
          );
        })}
      </div>

      {/* Active Interactive Step Card */}
      <section className="rounded-[28px] bg-white border border-[#E8A91A]/35 p-5 sm:p-7 shadow-sm space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
          <div className="space-y-3">
            <div className="flex items-center gap-2 text-xs font-bold text-[#0F4C3A] tabular-nums">
              <span>الخطوة {current.number} من {STEPS.length}</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-[#141413] leading-snug">
              {current.title}
            </h2>
            <p className="text-sm text-[#5B5B5B] leading-relaxed">{current.description}</p>
            <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/25 p-3 text-xs font-semibold text-[#0F4C3A]">
              معلومة سريعة: {current.tip}
            </div>
          </div>

          <StepVisualMockup stepNumber={current.number} />
        </div>

        {/* Next / Prev Controls */}
        <div className="flex items-center justify-between gap-3 pt-3 border-t border-[#E8A91A]/20">
          <button
            type="button"
            disabled={activeIndex === 0}
            onClick={() => handleSelectStep(Math.max(0, activeIndex - 1))}
            className="min-h-[48px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 disabled:opacity-40 cursor-pointer"
          >
            <ArrowRight className="w-4 h-4" />
            <span>السابقة</span>
          </button>

          <div className="flex items-center gap-1.5 tabular-nums text-xs font-bold text-[#5B5B5B]">
            <span>{current.number} / {STEPS.length}</span>
          </div>

          {activeIndex < STEPS.length - 1 ? (
            <button
              type="button"
              onClick={() => handleSelectStep(activeIndex + 1)}
              className="min-h-[48px] px-5 rounded-2xl bg-[#0F4C3A] text-white text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] cursor-pointer"
            >
              <span>التالية</span>
              <ArrowLeft className="w-4 h-4" />
            </button>
          ) : (
            <Link
              to="/catalog"
              className="min-h-[48px] px-5 rounded-2xl bg-[#E8A91A] text-[#141413] text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#F6CF5A]"
            >
              <span>ابدئي التصفح</span>
              <ChevronLeft className="w-4 h-4" />
            </Link>
          )}
        </div>
      </section>

      {/* Messenger Copy-Paste Tip Box */}
      <section className="rounded-[24px] bg-[#FFFDF8] border border-[#E8A91A]/40 p-5 space-y-3">
        <div className="flex items-center gap-2">
          <HelpCircle className="w-5 h-5 text-[#0F4C3A] shrink-0" />
          <h2 className="text-base font-bold text-[#141413]">
            طريقة الطلب على ماسنجر في 3 ثواني
          </h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 text-xs font-bold">
          <div className="rounded-2xl bg-white border border-[#E8A91A]/25 p-3 text-[#141413]">
            1. اضغطي «نسخ رسالة الطلب» من نافذة التأكيد
          </div>
          <div className="rounded-2xl bg-white border border-[#E8A91A]/25 p-3 text-[#141413]">
            2. اضغطي «افتحي ماسنجر» هيفتح شات الصفحة
          </div>
          <div className="rounded-2xl bg-white border border-[#E8A91A]/25 p-3 text-[#141413]">
            3. دوسي مطوّلاً في خانة الكتابة ← لصق (Paste) ← إرسال
          </div>
        </div>
      </section>

      {/* Quick FAQ */}
      <section aria-label="أسئلة متكررة" className="space-y-3">
        <h2 className="text-base sm:text-lg font-bold text-[#141413]">أسئلة شائعة</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {FAQ_ITEMS.map((item) => (
            <div
              key={item.q}
              className="rounded-[22px] bg-white border border-[#E8A91A]/25 p-4 space-y-1.5"
            >
              <h3 className="text-sm font-bold text-[#0F4C3A]">{item.q}</h3>
              <p className="text-xs text-[#5B5B5B] leading-relaxed">{item.a}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Primary CTA */}
      <div className="flex justify-center pt-2">
        <Link
          to="/catalog"
          className="shine-sweep min-h-[52px] px-8 py-3 rounded-[22px] bg-[#0F4C3A] text-white font-bold text-base inline-flex items-center justify-center gap-2 shadow-md hover:bg-[#0A3629]"
        >
          <Sparkles className="w-5 h-5 text-[#F6CF5A]" />
          <span>تصفحي المنتجات دلوقتي</span>
        </Link>
      </div>
    </div>
  );
};
