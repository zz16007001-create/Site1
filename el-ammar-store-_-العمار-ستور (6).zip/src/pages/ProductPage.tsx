import React, {useEffect, useMemo, useRef, useState} from 'react';
import {Link, useNavigate, useParams, useSearchParams} from 'react-router-dom';
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  MessageCircle,
  PhoneCall,
  RotateCcw,
  Send,
  ShoppingBag,
  Trash2,
  X,
  ZoomIn,
  ZoomOut,
} from 'lucide-react';
import {PermanentDeleteModal} from '../components/admin/PermanentDeleteModal';
import {EmptyState, ResilientImage} from '../components/BrandElements';
import {OrderConfirmationSheet} from '../components/OrderConfirmationSheet';
import {useStore} from '../context/StoreContext';
import type {OrderChannel, ProductImage} from '../types/store';
import {
  buildOrderMessage,
  cleanColorName,
  copyTextSync,
  formatPrice,
  getDiscountPercent,
  getFirstAvailableColor,
  getWhatsAppUrl,
  isColorSoldOut,
  isProductSoldOut,
  normalizeEgyptianPhone,
} from '../utils/catalogHelpers';
import {trackPixelEvent} from '../utils/metaPixel';

const FALLBACK_PRODUCT_IMAGE: ProductImage = {
  full: '/assets/aistudio/logo_be4d7522.png',
  thumb: '/assets/aistudio/logo_be4d7522.png',
  focus_x: 50,
  focus_y: 50,
};

function clamp(val: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, val));
}

export const ProductPage: React.FC = () => {
  const {id} = useParams<{id: string}>();
  const [searchParams] = useSearchParams();
  const requestedSize = searchParams.get('size')?.trim() || null;
  const navigate = useNavigate();
  const {
    products,
    categories,
    settings,
    loading,
    isAdmin,
    addToCart,
    createOrder,
    showToast,
    recordRecentlyViewed,
  } = useStore();

  const product = useMemo(() => products.find((p) => p.id === id), [products, id]);

  const [selectedColorId, setSelectedColorId] = useState<string | null>(null);
  const [selectedSizeId, setSelectedSizeId] = useState<string | null>(null);
  const [imageIndex, setImageIndex] = useState(0);
  const [deleteModalProductId, setDeleteModalProductId] = useState<string | null>(null);
  const [deletedOnPage, setDeletedOnPage] = useState(false);

  // Highlight state when scrolling to missing color/size
  const [highlightField, setHighlightField] = useState<'color' | 'size' | null>(null);

  // Quick Order ("اطلبي دلوقتي") modal & Confirmation sheet
  const [channelSheetOpen, setChannelSheetOpen] = useState(false);
  const [callbackOpen, setCallbackOpen] = useState(false);
  const [callbackPhone, setCallbackPhone] = useState('');
  const [callbackError, setCallbackError] = useState<string | null>(null);
  const [preparingChannel, setPreparingChannel] = useState<OrderChannel | null>(null);
  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    channel: OrderChannel | null;
    orderNo: number | null;
    message: string;
    destinationUrl: string;
    customerPhone?: string | null;
  }>({
    open: false,
    channel: null,
    orderNo: null,
    message: '',
    destinationUrl: '',
    customerPhone: null,
  });

  // Viewer zoom/pan state (pinch-to-zoom, double-tap, drag pan)
  const [zoomScale, setZoomScale] = useState(1);
  const [pan, setPan] = useState<{x: number; y: number}>({x: 0, y: 0});

  const viewerRef = useRef<HTMLDivElement | null>(null);
  const colorSectionRef = useRef<HTMLDivElement | null>(null);
  const sizeSectionRef = useRef<HTMLDivElement | null>(null);
  const addBtnRef = useRef<HTMLButtonElement | null>(null);

  // Gesture refs
  const touchStartX = useRef<number | null>(null);
  const touchStartY = useRef<number | null>(null);
  const lastTapTimeRef = useRef<number>(0);
  const pinchStartDistRef = useRef<number | null>(null);
  const pinchStartScaleRef = useRef<number>(1);
  const panStartTouchRef = useRef<{x: number; y: number} | null>(null);
  const panStartOffsetRef = useRef<{x: number; y: number}>({x: 0, y: 0});
  const isMouseDraggingRef = useRef(false);
  const mouseStartRef = useRef<{x: number; y: number}>({x: 0, y: 0});

  useEffect(() => {
    window.scrollTo({top: 0, behavior: 'smooth'});
  }, [id]);

  useEffect(() => {
    if (!product) return;
    recordRecentlyViewed(product.id);
    trackPixelEvent(settings.pixel_id, 'ViewContent', {
      content_name: product.name,
      content_ids: [product.id],
      content_type: 'product',
      value: product.price,
      currency: 'EGP',
    });

    let matchedCol = null;
    let matchedSize = null;
    if (requestedSize) {
      for (const c of product.colors) {
        const hit = c.sizes.find(
          (s) => s.status === 'available' && s.size?.trim() === requestedSize
        );
        if (hit) {
          matchedCol = c;
          matchedSize = hit;
          break;
        }
      }
    }

    const defaultCol = matchedCol || getFirstAvailableColor(product);
    setSelectedColorId(defaultCol?.id || null);
    setImageIndex(0);
    setZoomScale(1);
    setPan({x: 0, y: 0});

    if (matchedSize) {
      setSelectedSizeId(matchedSize.id);
    } else if (defaultCol) {
      const avail = defaultCol.sizes.filter((s) => s.status === 'available');
      if (defaultCol.sizes.length === 1 && defaultCol.sizes[0].size === null) {
        setSelectedSizeId(defaultCol.sizes[0].status === 'available' ? defaultCol.sizes[0].id : null);
      } else if (avail.length === 1) {
        setSelectedSizeId(avail[0].id);
      } else {
        setSelectedSizeId(null);
      }
    } else {
      setSelectedSizeId(null);
    }
  }, [product?.id, requestedSize]);

  const resetZoom = () => {
    setZoomScale(1);
    setPan({x: 0, y: 0});
  };

  const clampPanForScale = (nextX: number, nextY: number, scale: number) => {
    const el = viewerRef.current;
    if (!el || scale <= 1) return {x: 0, y: 0};
    const maxX = ((scale - 1) * el.clientWidth) / 2;
    const maxY = ((scale - 1) * el.clientHeight) / 2;
    return {
      x: clamp(nextX, -maxX, maxX),
      y: clamp(nextY, -maxY, maxY),
    };
  };

  if (loading && !product) {
    return (
      <div className="max-w-5xl mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="aspect-[2/3] max-h-[70vh] rounded-[26px] skeleton-box" />
        <div className="space-y-4">
          <div className="h-7 w-2/3 rounded skeleton-box" />
          <div className="h-6 w-1/3 rounded skeleton-box" />
          <div className="h-24 w-full rounded skeleton-box" />
        </div>
      </div>
    );
  }

  if (!product || (!product.visible && !isAdmin)) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-12">
        <EmptyState
          title="الموديل ده خلص أو اتشال"
          subtitle="تقدري تتصفحي باقي الموديلات المتاحة دلوقتي في المتجر."
          actionLabel="الرجوع للرئيسية"
          onAction={() => {
            navigate('/');
          }}
        />
        {deleteModalProductId && (
          <PermanentDeleteModal
            productIds={[deleteModalProductId]}
            onClose={() => {
              setDeleteModalProductId(null);
              if (deletedOnPage) navigate('/admin');
            }}
            onCompleted={() => setDeletedOnPage(true)}
          />
        )}
      </div>
    );
  }

  const category = categories.find((c) => c.id === product.category_id);
  const selectedColor =
    product.colors.find((c) => c.id === selectedColorId) || product.colors[0];
  const images: ProductImage[] =
    selectedColor?.images && selectedColor.images.length > 0
      ? selectedColor.images
      : [FALLBACK_PRODUCT_IMAGE];
  const safeImageIndex = Math.min(imageIndex, images.length - 1);
  const currentImg = images[safeImageIndex];

  const soldOutAll = isProductSoldOut(product);
  const discount = getDiscountPercent(product.price, product.old_price);

  const colorSizes = selectedColor?.sizes || [];
  const hasNamedSizes =
    colorSizes.length > 1 || (colorSizes.length === 1 && colorSizes[0].size !== null);

  const handleSelectColor = (colorId: string) => {
    setSelectedColorId(colorId);
    setImageIndex(0);
    resetZoom();
    const nextCol = product.colors.find((c) => c.id === colorId);
    if (!nextCol) {
      setSelectedSizeId(null);
      return;
    }
    const avail = nextCol.sizes.filter((s) => s.status === 'available');
    if (nextCol.sizes.length === 1 && nextCol.sizes[0].size === null) {
      setSelectedSizeId(nextCol.sizes[0].status === 'available' ? nextCol.sizes[0].id : null);
    } else if (avail.length === 1) {
      setSelectedSizeId(avail[0].id);
    } else {
      setSelectedSizeId(null);
    }
  };

  const triggerHighlight = (field: 'color' | 'size') => {
    setHighlightField(field);
    const targetRef = field === 'color' ? colorSectionRef.current : sizeSectionRef.current;
    targetRef?.scrollIntoView({behavior: 'smooth', block: 'center'});
    window.setTimeout(() => {
      setHighlightField((prev) => (prev === field ? null : prev));
    }, 1800);
  };

  const validateSelection = () => {
    if (soldOutAll || !selectedColor) return null;
    if (isColorSoldOut(selectedColor)) {
      triggerHighlight('color');
      showToast('اختاري اللون المتاح الأول', 'warning');
      return null;
    }

    let chosenSize = colorSizes.find((s) => s.id === selectedSizeId);
    if (!hasNamedSizes && colorSizes.length === 1) {
      chosenSize = colorSizes[0];
    }

    if (!chosenSize) {
      triggerHighlight('size');
      showToast('اختاري المقاس الأول', 'warning');
      return null;
    }
    if (chosenSize.status === 'sold') {
      triggerHighlight('size');
      showToast('هذا المقاس تم بيعه، اختاري مقاساً متاحاً', 'warning');
      return null;
    }

    return {color: selectedColor, size: chosenSize};
  };

  const handleAddToCart = () => {
    const validated = validateSelection();
    if (!validated) return;
    const primaryImg = images[0];

    addToCart(
      {
        product_id: product.id,
        color_id: validated.color.id,
        size_id: validated.size.id,
        name: product.name,
        code: product.code ?? null,
        color_name: cleanColorName(validated.color.name),
        size_name: validated.size.size,
        price: product.price,
        qty: 1,
        image: primaryImg.thumb,
        focus_x: primaryImg.focus_x,
        focus_y: primaryImg.focus_y,
      },
      addBtnRef.current
    );
  };

  const handleOrderNowClick = () => {
    const validated = validateSelection();
    if (!validated) return;
    setCallbackOpen(false);
    setCallbackError(null);
    setChannelSheetOpen(true);
  };

  const handleSelectQuickOrderChannel = async (channel: OrderChannel) => {
    if (preparingChannel) return;
    const validated = validateSelection();
    if (!validated) {
      setChannelSheetOpen(false);
      return;
    }

    let validatedPhone: string | undefined;
    if (channel === 'callback') {
      const parsed = normalizeEgyptianPhone(callbackPhone);
      if (!parsed.valid) {
        setCallbackError('اكتبي رقم موبايل مصري صحيح (11 رقم يبدأ بـ 010 أو 011 أو 012 أو 015)');
        return;
      }
      setCallbackError(null);
      validatedPhone = parsed.digits;
    }

    const whatsappDigits = (settings.whatsapp || '').replace(/[^\d]/g, '');
    const messengerUrl = (settings.messenger_url || '').trim();

    if (channel === 'whatsapp' && !whatsappDigits) {
      showToast('رقم الواتساب غير مضبوط في إعدادات المتجر', 'warning');
      return;
    }
    if (channel === 'messenger' && !messengerUrl) {
      showToast('رابط ماسنجر غير مضبوط في إعدادات المتجر', 'warning');
      return;
    }

    setPreparingChannel(channel);
    try {
      const primaryImg = images[0];
      const cleanedColor = cleanColorName(validated.color.name);
      const linePayload = {
        product_id: product.id,
        color_id: validated.color.id,
        size_id: validated.size.id,
        name: product.name,
        code: product.code ?? null,
        color_name: cleanedColor,
        size_name: validated.size.size,
        price: product.price,
        qty: 1,
        image: primaryImg.thumb,
        focus_x: primaryImg.focus_x,
        focus_y: primaryImg.focus_y,
      };

      const res = await createOrder(channel, [linePayload], validatedPhone);
      if (!res.ok) {
        if (channel === 'callback' && res.errorMessage) {
          setCallbackError(res.errorMessage);
        }
        return;
      }
      const orderNo = res.orderNo;
      const message = buildOrderMessage({
        orderNo,
        lines: [
          {
            name: product.name,
            code: product.code ?? null,
            color_name: cleanedColor,
            size_name: validated.size.size,
            qty: 1,
            price: product.price,
          },
        ],
      });

      if (channel !== 'callback') {
        copyTextSync(message);
      }
      const destinationUrl =
        channel === 'whatsapp'
          ? getWhatsAppUrl(settings.whatsapp, message)
          : channel === 'messenger'
            ? messengerUrl
            : '';

      setChannelSheetOpen(false);
      setCallbackOpen(false);
      setCallbackPhone('');
      setConfirmState({
        open: true,
        channel,
        orderNo,
        message,
        destinationUrl,
        customerPhone: validatedPhone ?? null,
      });
    } finally {
      setPreparingChannel(null);
    }
  };

  // Viewer touch & zoom gesture handlers
  const handleViewerTouchStart = (e: React.TouchEvent) => {
    if (e.touches.length === 2) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      pinchStartDistRef.current = Math.hypot(dx, dy);
      pinchStartScaleRef.current = zoomScale;
      touchStartX.current = null;
      return;
    }

    if (e.touches.length === 1) {
      const t = e.touches[0];
      if (zoomScale > 1) {
        panStartTouchRef.current = {x: t.clientX, y: t.clientY};
        panStartOffsetRef.current = pan;
      } else {
        touchStartX.current = t.clientX;
        touchStartY.current = t.clientY;
      }
    }
  };

  const handleViewerTouchMove = (e: React.TouchEvent) => {
    if (e.touches.length === 2 && pinchStartDistRef.current) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const dist = Math.hypot(dx, dy);
      const nextScale = clamp((dist / pinchStartDistRef.current) * pinchStartScaleRef.current, 1, 3.5);
      setZoomScale(nextScale);
      setPan((prev) => clampPanForScale(prev.x, prev.y, nextScale));
      return;
    }

    if (e.touches.length === 1 && zoomScale > 1 && panStartTouchRef.current) {
      const t = e.touches[0];
      const nextX = panStartOffsetRef.current.x + (t.clientX - panStartTouchRef.current.x);
      const nextY = panStartOffsetRef.current.y + (t.clientY - panStartTouchRef.current.y);
      setPan(clampPanForScale(nextX, nextY, zoomScale));
    }
  };

  const handleViewerTouchEnd = (e: React.TouchEvent) => {
    pinchStartDistRef.current = null;
    panStartTouchRef.current = null;

    if (e.changedTouches.length === 1 && e.touches.length === 0) {
      const t = e.changedTouches[0];
      const movedX = touchStartX.current !== null ? t.clientX - touchStartX.current : 0;
      const movedY = touchStartY.current !== null ? t.clientY - touchStartY.current : 0;

      // Horizontal swipe between images when unzoomed
      if (zoomScale <= 1 && touchStartX.current !== null && images.length > 1) {
        if (Math.abs(movedX) > 40 && Math.abs(movedX) > Math.abs(movedY)) {
          if (movedX > 0) setImageIndex((i) => (i + 1) % images.length);
          else setImageIndex((i) => (i - 1 + images.length) % images.length);
          touchStartX.current = null;
          touchStartY.current = null;
          return;
        }
      }

      // Double-tap detection for zoom toggle (only if finger didn't drag)
      if (Math.abs(movedX) < 12 && Math.abs(movedY) < 12) {
        const now = Date.now();
        if (now - lastTapTimeRef.current < 280) {
          lastTapTimeRef.current = 0;
          if (zoomScale > 1) {
            resetZoom();
          } else {
            setZoomScale(2.4);
          }
        } else {
          lastTapTimeRef.current = now;
        }
      }
    }

    touchStartX.current = null;
    touchStartY.current = null;
  };

  const handleViewerDoubleClick = () => {
    if (zoomScale > 1) resetZoom();
    else setZoomScale(2.4);
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoomScale <= 1) return;
    isMouseDraggingRef.current = true;
    mouseStartRef.current = {x: e.clientX, y: e.clientY};
    panStartOffsetRef.current = pan;
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isMouseDraggingRef.current || zoomScale <= 1) return;
    const nextX = panStartOffsetRef.current.x + (e.clientX - mouseStartRef.current.x);
    const nextY = panStartOffsetRef.current.y + (e.clientY - mouseStartRef.current.y);
    setPan(clampPanForScale(nextX, nextY, zoomScale));
  };

  const handleMouseUp = () => {
    isMouseDraggingRef.current = false;
  };

  const chosenSizeForSheet =
    colorSizes.find((s) => s.id === selectedSizeId) ||
    (!hasNamedSizes && colorSizes.length === 1 ? colorSizes[0] : undefined);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-4 sm:py-8 page-enter">
      {/* Breadcrumb Back Link */}
      <div className="flex items-center justify-between mb-4">
        <Link
          to={category ? `/c/${category.id}` : '/catalog'}
          className="min-h-[44px] inline-flex items-center gap-1.5 text-sm font-bold text-[#0F4C3A] hover:underline"
        >
          <ArrowRight className="w-4 h-4" />
          <span>{category ? category.name : 'كل المنتجات'}</span>
        </Link>

        {isAdmin && (
          <button
            type="button"
            onClick={() => {
              setDeletedOnPage(false);
              setDeleteModalProductId(product.id);
            }}
            className="min-h-[44px] px-3.5 rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/30 text-sm font-bold text-[#B3261E] inline-flex items-center gap-1.5 hover:bg-[#B3261E]/20 cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>حذف نهائي</span>
          </button>
        )}
      </div>

      <div
        className={`grid grid-cols-1 md:grid-cols-12 gap-6 sm:gap-8 items-start ${
          soldOutAll ? 'opacity-75' : ''
        }`}
      >
        {/* Gallery Column — Tall Portrait 2:3 Uncropped Viewer + Pinch/Double-Tap Zoom */}
        <div className="md:col-span-6 space-y-3 md:sticky md:top-20">
          <div
            ref={viewerRef}
            onTouchStart={handleViewerTouchStart}
            onTouchMove={handleViewerTouchMove}
            onTouchEnd={handleViewerTouchEnd}
            onDoubleClick={handleViewerDoubleClick}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className={`relative aspect-[2/3] max-h-[70vh] mx-auto w-full rounded-[26px] overflow-hidden bg-[#FBF6EA] border border-[#E8A91A]/30 shadow-sm flex items-center justify-center select-none ${
              zoomScale > 1 ? 'touch-none cursor-grab active:cursor-grabbing' : 'touch-pan-y cursor-zoom-in'
            }`}
          >
            <div
              style={{
                transform: `translate3d(${pan.x}px, ${pan.y}px, 0) scale(${zoomScale})`,
                transition: pinchStartDistRef.current || isMouseDraggingRef.current ? 'none' : 'transform 160ms ease-out',
              }}
              className="w-full h-full flex items-center justify-center"
            >
              <ResilientImage
                src={currentImg.full}
                alt={product.name}
                fallbackLabel={product.name}
                draggable={false}
                className="w-full h-full object-contain pointer-events-none"
              />
            </div>

            {!soldOutAll && discount > 0 && (
              <span className="animate-soft-pulse absolute top-4 right-4 px-3 py-1 rounded-xl bg-[#B3261E] text-white text-xs font-bold tabular-nums shadow pointer-events-none">
                خصم {discount}٪
              </span>
            )}

            {soldOutAll && (
              <div className="pointer-events-none absolute inset-0 flex items-center justify-center">
                <span className="-rotate-12 bg-[#B3261E] text-white text-base font-bold px-12 py-2 shadow-lg">
                  تم البيع
                </span>
              </div>
            )}

            {/* Zoom Controls */}
            <div className="absolute bottom-3 left-3 flex items-center gap-1.5 z-10">
              {zoomScale > 1 && (
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    resetZoom();
                  }}
                  aria-label="إعادة الحجم الأصلي"
                  className="min-w-[40px] min-h-[40px] rounded-full bg-white/92 text-[#0F4C3A] flex items-center justify-center shadow cursor-pointer"
                >
                  <RotateCcw className="w-4 h-4" />
                </button>
              )}
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  if (zoomScale > 1) {
                    const next = Math.max(1, Number((zoomScale - 0.7).toFixed(1)));
                    setZoomScale(next);
                    if (next === 1) setPan({x: 0, y: 0});
                    else setPan((p) => clampPanForScale(p.x, p.y, next));
                  } else {
                    setZoomScale(2.4);
                  }
                }}
                aria-label={zoomScale > 1 ? 'تصغير الصورة' : 'تكبير الصورة'}
                className="min-w-[40px] min-h-[40px] rounded-full bg-white/92 text-[#141413] flex items-center justify-center shadow cursor-pointer"
              >
                {zoomScale > 1 ? <ZoomOut className="w-4 h-4" /> : <ZoomIn className="w-4 h-4" />}
              </button>
            </div>

            {zoomScale === 1 && (
              <span className="pointer-events-none absolute bottom-3 right-3 px-2.5 py-1 rounded-full bg-white/85 text-[11px] font-semibold text-[#5B5B5B] shadow-xs">
                اضغطي مرتين للتكبير
              </span>
            )}

            {images.length > 1 && zoomScale === 1 && (
              <>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setImageIndex((i) => (i - 1 + images.length) % images.length);
                    resetZoom();
                  }}
                  aria-label="الصورة السابقة"
                  className="absolute right-2.5 top-1/2 -translate-y-1/2 min-w-[40px] min-h-[40px] rounded-full bg-white/85 flex items-center justify-center shadow cursor-pointer"
                >
                  <ChevronRight className="w-5 h-5" />
                </button>
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    setImageIndex((i) => (i + 1) % images.length);
                    resetZoom();
                  }}
                  aria-label="الصورة التالية"
                  className="absolute left-2.5 top-1/2 -translate-y-1/2 min-w-[40px] min-h-[40px] rounded-full bg-white/85 flex items-center justify-center shadow cursor-pointer"
                >
                  <ChevronLeft className="w-5 h-5" />
                </button>
              </>
            )}
          </div>

          {/* 3:4 Portrait Thumbnails */}
          {images.length > 1 && (
            <div className="flex items-center gap-2.5 overflow-x-auto no-scrollbar py-1">
              {images.map((img, idx) => (
                <button
                  key={`${img.thumb}-${idx}`}
                  type="button"
                  onClick={() => {
                    setImageIndex(idx);
                    resetZoom();
                  }}
                  aria-label={`صورة رقم ${idx + 1}`}
                  className={`w-14 aspect-[3/4] rounded-2xl overflow-hidden border-2 shrink-0 cursor-pointer transition-all bg-[#FBF6EA] ${
                    idx === safeImageIndex
                      ? 'border-[#0F4C3A] scale-105 shadow-xs'
                      : 'border-transparent opacity-70 hover:opacity-100'
                  }`}
                >
                  <ResilientImage
                    src={img.thumb}
                    alt=""
                    style={{objectPosition: `${img.focus_x}% ${img.focus_y}%`}}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Purchase Details Column */}
        <div className="md:col-span-6 rounded-[26px] bg-white border border-[#E8A91A]/25 p-5 sm:p-7 shadow-xs space-y-5">
          <div className="space-y-1">
            {(category || product.code) && (
              <div className="flex flex-wrap items-center gap-2 text-xs font-bold">
                {category && <span className="text-[#0F4C3A]">{category.name}</span>}
                {category && product.code && <span aria-hidden="true" className="text-[#5B5B5B]">·</span>}
                {product.code && (
                  <span className="text-[#5B5B5B] tabular-nums">كود الموديل: {product.code}</span>
                )}
              </div>
            )}
            <h1 className="text-xl sm:text-2xl font-bold text-[#141413] leading-snug text-balance">
              {product.name}
            </h1>
          </div>

          {/* Price */}
          <div className="flex items-baseline gap-3 tabular-nums">
            <span className="text-2xl sm:text-3xl font-bold text-[#0F4C3A]">
              {formatPrice(product.price)}
            </span>
            {product.old_price && product.old_price > product.price && (
              <span className="text-base text-[#5B5B5B] line-through">
                {formatPrice(product.old_price)}
              </span>
            )}
          </div>

          {/* Description */}
          {product.description && (
            <p className="text-sm sm:text-base text-[#5B5B5B] leading-relaxed">
              {product.description}
            </p>
          )}

          {/* Color Swatches */}
          {(product.colors.length > 1 ||
            product.colors.some((c) => Boolean(cleanColorName(c.name)))) && (() => {
            const selectedColorIndex = Math.max(
              0,
              product.colors.findIndex((c) => c.id === selectedColor?.id)
            );
            const cleanedSelected = cleanColorName(selectedColor?.name);
            const displayedColorLabel =
              cleanedSelected ??
              (product.colors.length > 1 ? 'لون ' + (selectedColorIndex + 1) : null);

            return (
              <div
                ref={colorSectionRef}
                className={`space-y-2.5 pt-1 transition-all duration-300 ${
                  highlightField === 'color'
                    ? 'ring-2 ring-[#B3261E] rounded-2xl p-2.5 bg-[#B3261E]/5'
                    : ''
                }`}
              >
                {displayedColorLabel && (
                  <div className="flex items-center gap-2 text-sm">
                    <span className="font-bold text-[#141413]">اللون:</span>
                    <span className="text-[#5B5B5B] font-semibold">{displayedColorLabel}</span>
                  </div>
                )}
                <div className="flex flex-wrap items-center gap-2.5">
                  {product.colors.map((c, cIdx) => {
                    const colSold = isColorSoldOut(c);
                    const active = selectedColor?.id === c.id;
                    const label = cleanColorName(c.name) ?? 'لون ' + (cIdx + 1);
                    return (
                      <button
                        key={c.id}
                        type="button"
                        onClick={() => handleSelectColor(c.id)}
                        aria-label={`${label}${colSold ? ' (تم البيع)' : ''}`}
                        className={`relative min-w-[44px] min-h-[44px] px-3 rounded-2xl border-2 flex items-center gap-2 text-xs font-bold transition-all cursor-pointer ${
                          active
                            ? 'border-[#0F4C3A] bg-[#FBF6EA] text-[#0F4C3A]'
                            : 'border-[#E8A91A]/30 bg-white text-[#141413]'
                        } ${colSold ? 'opacity-50 sold-diagonal-line' : ''}`}
                      >
                        {c.hex && (
                          <span
                            className="w-5 h-5 rounded-full border border-black/15 shrink-0"
                            style={{backgroundColor: c.hex}}
                          />
                        )}
                        <span>{label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            );
          })()}

          {/* Size Selector */}
          {hasNamedSizes && (
            <div
              ref={sizeSectionRef}
              className={`space-y-2.5 pt-1 transition-all duration-300 ${
                highlightField === 'size'
                  ? 'ring-2 ring-[#B3261E] rounded-2xl p-2.5 bg-[#B3261E]/5'
                  : ''
              }`}
            >
              <div className="flex items-center justify-between text-sm">
                <span className="font-bold text-[#141413]">اختاري المقاس:</span>
                {selectedSizeId && (
                  <span className="text-xs font-semibold text-[#0F4C3A]">
                    مقاس {colorSizes.find((s) => s.id === selectedSizeId)?.size}
                  </span>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                {colorSizes.map((s) => {
                  const isSold = s.status === 'sold';
                  const isSelected = selectedSizeId === s.id;
                  return (
                    <button
                      key={s.id}
                      type="button"
                      disabled={isSold}
                      onClick={() => {
                        setSelectedSizeId(s.id);
                        setHighlightField(null);
                      }}
                      aria-label={`مقاس ${s.size}${isSold ? ' - تم البيع' : ''}`}
                      className={`min-w-[52px] min-h-[44px] px-3.5 rounded-2xl text-sm font-bold tabular-nums border-2 transition-all ${
                        isSold
                          ? 'opacity-45 bg-[#F4EFE6] border-[#E8A91A]/20 text-[#5B5B5B] cursor-not-allowed sold-diagonal-line'
                          : isSelected
                            ? 'bg-[#0F4C3A] text-white border-[#0F4C3A] shadow-sm cursor-pointer'
                            : 'bg-white text-[#141413] border-[#E8A91A]/35 hover:border-[#0F4C3A] cursor-pointer'
                      }`}
                    >
                      {s.size}
                    </button>
                  );
                })}
              </div>
            </div>
          )}

          {/* Action Buttons */}
          {!soldOutAll ? (
            <div className="space-y-3 pt-2">
              <button
                type="button"
                onClick={handleOrderNowClick}
                className="shine-sweep w-full min-h-[54px] rounded-[20px] bg-[#0F4C3A] text-white font-bold text-base sm:text-lg flex items-center justify-center gap-2 shadow-md hover:bg-[#0A3629] active:scale-[0.98] transition-all cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 text-[#F6CF5A]" />
                <span>اطلبي دلوقتي</span>
              </button>

              <div className="space-y-1.5">
                <button
                  ref={addBtnRef}
                  type="button"
                  onClick={handleAddToCart}
                  className="w-full min-h-[48px] rounded-[20px] bg-white border-2 border-[#0F4C3A] text-[#0F4C3A] font-bold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-[#FBF6EA] active:scale-[0.98] transition-all cursor-pointer"
                >
                  <ShoppingBag className="w-5 h-5" />
                  <span>أضيفي للسلة</span>
                </button>
                <p className="text-center text-xs font-semibold text-[#5B5B5B]">
                  لو هتطلبي أكتر من قطعة
                </p>
              </div>
            </div>
          ) : (
            <div className="rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/25 p-4 text-center">
              <p className="text-sm font-bold text-[#B3261E]">
                تم بيع هذه القطعة بالكامل
              </p>
            </div>
          )}
        </div>
      </div>

      {/* Quick Order Channel Chooser Bottom Sheet ("ابعتي طلبك عبر") */}
      {channelSheetOpen && (
        <div
          className="fixed inset-0 z-[90] flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="ابعتي طلبك عبر"
          onClick={() => setChannelSheetOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full sm:max-w-md rounded-t-[28px] sm:rounded-[28px] bg-white p-5 sm:p-6 shadow-2xl border-t sm:border border-[#E8A91A]/35 space-y-4 page-enter"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-base sm:text-lg font-bold text-[#141413]">
                ابعتي طلبك عبر
              </h3>
              <button
                type="button"
                onClick={() => setChannelSheetOpen(false)}
                aria-label="إغلاق"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-[#FBF6EA] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Selected Item Summary */}
            <div className="flex items-center gap-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-3">
              <div className="w-14 aspect-[3/4] rounded-xl overflow-hidden bg-white shrink-0 border border-[#E8A91A]/25">
                <ResilientImage
                  src={images[0].thumb}
                  alt={product.name}
                  style={{objectPosition: `${images[0].focus_x}% ${images[0].focus_y}%`}}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="flex-1 min-w-0 space-y-0.5">
                <p className="text-sm font-bold text-[#141413] line-clamp-1">{product.name}</p>
                <div className="flex flex-wrap items-center gap-2 text-xs text-[#5B5B5B]">
                  {cleanColorName(selectedColor?.name) && (
                    <span>اللون: {cleanColorName(selectedColor?.name)}</span>
                  )}
                  {cleanColorName(selectedColor?.name) && chosenSizeForSheet?.size && (
                    <span aria-hidden="true">·</span>
                  )}
                  {chosenSizeForSheet?.size && <span>المقاس: {chosenSizeForSheet.size}</span>}
                </div>
                <p className="text-sm font-bold text-[#0F4C3A] tabular-nums">
                  {formatPrice(product.price)}
                </p>
              </div>
            </div>

            <div className="space-y-2.5">
              <button
                type="button"
                disabled={preparingChannel !== null}
                onClick={() => handleSelectQuickOrderChannel('whatsapp')}
                className="w-full min-h-[52px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-[#0A3629] disabled:opacity-60 transition-colors cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 text-[#F6CF5A]" />
                <span>
                  {preparingChannel === 'whatsapp' ? 'جاري تجهيز الطلب...' : 'واتساب'}
                </span>
              </button>

              <button
                type="button"
                disabled={preparingChannel !== null}
                onClick={() => handleSelectQuickOrderChannel('messenger')}
                className="w-full min-h-[52px] rounded-2xl bg-[#E8A91A] text-[#141413] font-bold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-[#F6CF5A] disabled:opacity-60 transition-colors cursor-pointer"
              >
                <Send className="w-5 h-5 text-[#0F4C3A]" />
                <span>
                  {preparingChannel === 'messenger' ? 'جاري تجهيز الطلب...' : 'ماسنجر'}
                </span>
              </button>

              {!callbackOpen ? (
                <button
                  type="button"
                  disabled={preparingChannel !== null}
                  onClick={() => {
                    setCallbackOpen(true);
                    setCallbackError(null);
                  }}
                  className="w-full min-h-[50px] rounded-2xl bg-[#FBF6EA] border border-[#0F4C3A]/35 text-[#0F4C3A] font-bold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-[#F6CF5A]/25 disabled:opacity-60 transition-colors cursor-pointer"
                >
                  <PhoneCall className="w-5 h-5" />
                  <span>اطلبي ونكلمك</span>
                </button>
              ) : (
                <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/45 p-3.5 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0F4C3A]">
                      اكتبي رقم موبايلك وهنتصل بيكي ونكلمك واتساب:
                    </span>
                    <button
                      type="button"
                      onClick={() => setCallbackOpen(false)}
                      className="text-xs font-bold text-[#5B5B5B] cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                  <input
                    type="tel"
                    inputMode="tel"
                    dir="ltr"
                    value={callbackPhone}
                    onChange={(e) => {
                      setCallbackPhone(e.target.value);
                      if (callbackError) setCallbackError(null);
                    }}
                    placeholder="01xxxxxxxxx"
                    aria-label="رقم الموبايل"
                    className="w-full min-h-[46px] px-3.5 rounded-xl bg-white border border-[#E8A91A]/45 text-sm font-bold tabular-nums text-left"
                  />
                  {callbackError && (
                    <p className="text-xs font-bold text-[#B3261E]">{callbackError}</p>
                  )}
                  <button
                    type="button"
                    disabled={preparingChannel !== null}
                    onClick={() => handleSelectQuickOrderChannel('callback')}
                    className="w-full min-h-[48px] rounded-xl bg-[#0F4C3A] text-white text-sm font-bold hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
                  >
                    {preparingChannel === 'callback' ? 'جاري الإرسال...' : 'ابعتي رقمك'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Order Confirmation Sheet with Read-Only Textarea & Real Channel Link */}
      <OrderConfirmationSheet
        open={confirmState.open}
        channel={confirmState.channel}
        orderNo={confirmState.orderNo}
        message={confirmState.message}
        destinationUrl={confirmState.destinationUrl}
        customerPhone={confirmState.customerPhone}
        onClose={() => setConfirmState((s) => ({...s, open: false}))}
      />

      {deleteModalProductId && (
        <PermanentDeleteModal
          productIds={[deleteModalProductId]}
          onClose={() => {
            setDeleteModalProductId(null);
            if (deletedOnPage) navigate('/admin');
          }}
          onCompleted={() => setDeletedOnPage(true)}
        />
      )}
    </div>
  );
};
