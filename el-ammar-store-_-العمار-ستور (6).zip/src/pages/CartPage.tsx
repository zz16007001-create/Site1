import React, {useState} from 'react';
import {Link, useNavigate} from 'react-router-dom';
import {MessageCircle, Minus, PhoneCall, Plus, Send, Trash2} from 'lucide-react';
import {CrownOrnament, EmptyState, ResilientImage} from '../components/BrandElements';
import {OrderConfirmationSheet} from '../components/OrderConfirmationSheet';
import {useStore} from '../context/StoreContext';
import type {OrderChannel} from '../types/store';
import {
  buildOrderMessage,
  cleanColorName,
  copyTextSync,
  DEFAULT_FOCUS_X,
  DEFAULT_FOCUS_Y,
  formatPrice,
  getWhatsAppUrl,
  normalizeEgyptianPhone,
} from '../utils/catalogHelpers';

export const CartPage: React.FC = () => {
  const {
    cart,
    products,
    settings,
    updateCartQty,
    removeFromCart,
    clearCart,
    createOrder,
    showToast,
  } = useStore();
  const navigate = useNavigate();

  const [submitting, setSubmitting] = useState<OrderChannel | null>(null);
  const [confirmClearOpen, setConfirmClearOpen] = useState(false);
  const [callbackOpen, setCallbackOpen] = useState(false);
  const [callbackPhone, setCallbackPhone] = useState('');
  const [callbackError, setCallbackError] = useState<string | null>(null);
  const [confirmState, setConfirmState] = useState<{
    open: boolean;
    channel: OrderChannel | null;
    orderNo: number | null;
    message: string;
    destinationUrl: string;
    customerPhone?: string | null;
  }>({
    open: false,
    channel: null,
    orderNo: null,
    message: '',
    destinationUrl: '',
    customerPhone: null,
  });

  const itemsTotal = cart.reduce((sum, item) => sum + item.price * item.qty, 0);

  const handleCheckout = async (channel: OrderChannel) => {
    if (cart.length === 0 || submitting) return;

    let validatedPhone: string | undefined;
    if (channel === 'callback') {
      const parsed = normalizeEgyptianPhone(callbackPhone);
      if (!parsed.valid) {
        setCallbackError('اكتبي رقم موبايل مصري صحيح (11 رقم يبدأ بـ 010 أو 011 أو 012 أو 015)');
        return;
      }
      setCallbackError(null);
      validatedPhone = parsed.digits;
    }

    const whatsappDigits = (settings.whatsapp || '').replace(/[^\d]/g, '');
    const messengerUrl = (settings.messenger_url || '').trim();

    if (channel === 'whatsapp' && !whatsappDigits) {
      showToast('رقم الواتساب غير مضبوط في إعدادات المتجر', 'warning');
      return;
    }
    if (channel === 'messenger' && !messengerUrl) {
      showToast('رابط ماسنجر غير مضبوط في إعدادات المتجر', 'warning');
      return;
    }

    setSubmitting(channel);
    try {
      const res = await createOrder(channel, undefined, validatedPhone);
      if (!res.ok) {
        if (channel === 'callback' && res.errorMessage) {
          setCallbackError(res.errorMessage);
        }
        return;
      }
      const orderNo = res.orderNo;
      const message = buildOrderMessage({
        orderNo,
        lines: cart.map((c) => {
          const prod = products.find((p) => p.id === c.product_id);
          return {
            name: c.name,
            code: c.code ?? prod?.code ?? null,
            color_name: cleanColorName(c.color_name),
            size_name: c.size_name,
            qty: c.qty,
            price: c.price,
          };
        }),
      });

      if (channel !== 'callback') {
        copyTextSync(message);
      }
      const destinationUrl =
        channel === 'whatsapp'
          ? getWhatsAppUrl(settings.whatsapp, message)
          : channel === 'messenger'
            ? messengerUrl
            : '';

      if (channel === 'callback') {
        setCallbackOpen(false);
        setCallbackPhone('');
      }
      setConfirmState({
        open: true,
        channel,
        orderNo,
        message,
        destinationUrl,
        customerPhone: validatedPhone ?? null,
      });
    } finally {
      setSubmitting(null);
    }
  };

  const resolveItemThumbAndFocus = (line: (typeof cart)[number]) => {
    const prod = products.find((p) => p.id === line.product_id);
    const col = prod?.colors.find((c) => c.id === line.color_id);
    const firstImg = col?.images[0];
    return {
      src: firstImg?.thumb || line.image,
      focusX: line.focus_x ?? firstImg?.focus_x ?? DEFAULT_FOCUS_X,
      focusY: line.focus_y ?? firstImg?.focus_y ?? DEFAULT_FOCUS_Y,
    };
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-6 sm:py-8 space-y-6 page-enter">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <CrownOrnament className="w-6 h-6" />
          <h1 className="text-2xl font-bold text-[#141413]">سلة التسوق</h1>
        </div>
        {cart.length > 0 && (
          confirmClearOpen ? (
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-[#B3261E]">تأكيد الإفراغ؟</span>
              <button
                type="button"
                onClick={() => {
                  clearCart();
                  setConfirmClearOpen(false);
                }}
                className="min-h-[40px] px-3 rounded-xl bg-[#B3261E] text-white text-xs font-bold cursor-pointer"
              >
                نعم
              </button>
              <button
                type="button"
                onClick={() => setConfirmClearOpen(false)}
                className="min-h-[40px] px-3 rounded-xl bg-white border border-[#E8A91A]/35 text-xs font-bold text-[#141413] cursor-pointer"
              >
                لا
              </button>
            </div>
          ) : (
            <button
              type="button"
              onClick={() => setConfirmClearOpen(true)}
              className="min-h-[44px] px-3 text-xs font-bold text-[#B3261E] hover:underline cursor-pointer"
            >
              إفراغ السلة
            </button>
          )
        )}
      </div>

      {cart.length === 0 ? (
        <EmptyState
          title="سلتك فاضية حالياً"
          subtitle="اختاري القطع اللي بتحبيها وأضيفيها للسلة عشان تجهزي طلبك."
          actionLabel="ابدئي التسوق"
          onAction={() => navigate('/catalog')}
        />
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Lines */}
          <div className="lg:col-span-7 space-y-3">
            {cart.map((line) => {
              const thumb = resolveItemThumbAndFocus(line);
              return (
                <div
                  key={line.key}
                  className="flex items-center gap-3.5 rounded-[22px] bg-white border border-[#E8A91A]/25 p-3 shadow-xs"
                >
                  <Link
                    to={`/p/${line.product_id}`}
                    className="w-16 aspect-[3/4] rounded-2xl overflow-hidden bg-[#F7EFE0] shrink-0"
                  >
                    <ResilientImage
                      src={thumb.src}
                      alt={line.name}
                      style={{objectPosition: `${thumb.focusX}% ${thumb.focusY}%`}}
                      className="w-full h-full object-cover"
                    />
                  </Link>

                  <div className="flex-1 min-w-0 space-y-1">
                    <Link
                      to={`/p/${line.product_id}`}
                      className="text-sm font-bold text-[#141413] hover:text-[#0F4C3A] line-clamp-1"
                    >
                      {line.name}
                    </Link>
                    <div className="flex flex-wrap items-center gap-2 text-xs text-[#5B5B5B]">
                      {cleanColorName(line.color_name) && (
                        <span>اللون: {cleanColorName(line.color_name)}</span>
                      )}
                      {cleanColorName(line.color_name) && line.size_name && (
                        <span aria-hidden="true">·</span>
                      )}
                      {line.size_name && <span>المقاس: {line.size_name}</span>}
                    </div>
                    <div className="flex items-center justify-between pt-1">
                      <div className="inline-flex items-center rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30">
                        <button
                          type="button"
                          onClick={() => updateCartQty(line.key, Math.max(1, line.qty - 1))}
                          aria-label="تقليل الكمية"
                          className="min-w-[38px] min-h-[38px] flex items-center justify-center text-[#141413] cursor-pointer"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="px-2 text-sm font-bold tabular-nums">{line.qty}</span>
                        <button
                          type="button"
                          onClick={() => updateCartQty(line.key, line.qty + 1)}
                          aria-label="زيادة الكمية"
                          className="min-w-[38px] min-h-[38px] flex items-center justify-center text-[#141413] cursor-pointer"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="text-left tabular-nums">
                        <p className="text-sm font-bold text-[#0F4C3A]">
                          {formatPrice(line.price * line.qty)}
                        </p>
                        {line.qty > 1 && (
                          <p className="text-[11px] text-[#5B5B5B]">
                            {formatPrice(line.price)} للقطعة
                          </p>
                        )}
                      </div>
                    </div>
                  </div>

                  <button
                    type="button"
                    onClick={() => removeFromCart(line.key)}
                    aria-label="حذف من السلة"
                    className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-[#5B5B5B] hover:text-[#B3261E] hover:bg-[#B3261E]/10 cursor-pointer shrink-0"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>

          {/* Summary & Checkout Buttons (No Customer Form) */}
          <div className="lg:col-span-5 rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 sm:p-6 shadow-xs space-y-4">
            <h2 className="text-lg font-bold text-[#141413]">ملخص الطلب</h2>

            <div className="flex items-center justify-between text-base font-bold pt-2 border-t border-[#E8A91A]/20">
              <span>إجمالي المنتجات</span>
              <span className="text-xl text-[#0F4C3A] tabular-nums">
                {formatPrice(itemsTotal)}
              </span>
            </div>

            <p className="text-xs font-semibold text-[#5B5B5B] bg-[#FBF6EA] rounded-2xl p-3 border border-[#E8A91A]/25">
              الشحن بيتحدد معاكي في الشات — مفيش أي استمارة بيانات دلوقتي، صاحبة المتجر هتتواصل معاكي لبيانات التوصيل.
            </p>

            <div className="space-y-2.5 pt-1">
              <button
                type="button"
                disabled={submitting !== null}
                onClick={() => handleCheckout('whatsapp')}
                className="shine-sweep w-full min-h-[50px] rounded-[20px] bg-[#0F4C3A] text-white font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-md hover:bg-[#0A3629] active:scale-[0.98] disabled:opacity-60 transition-all cursor-pointer"
              >
                <MessageCircle className="w-5 h-5 text-[#F6CF5A]" />
                <span>
                  {submitting === 'whatsapp'
                    ? 'جاري تجهيز الطلب...'
                    : 'إرسال الطلب عبر واتساب'}
                </span>
              </button>

              <button
                type="button"
                disabled={submitting !== null}
                onClick={() => handleCheckout('messenger')}
                className="w-full min-h-[50px] rounded-[20px] bg-[#E8A91A] text-[#141413] font-bold text-sm sm:text-base flex items-center justify-center gap-2 shadow-xs hover:bg-[#F6CF5A] active:scale-[0.98] disabled:opacity-60 transition-all cursor-pointer"
              >
                <Send className="w-5 h-5 text-[#0F4C3A]" />
                <span>
                  {submitting === 'messenger'
                    ? 'جاري تجهيز الطلب...'
                    : 'إرسال الطلب عبر ماسنجر'}
                </span>
              </button>

              {!callbackOpen ? (
                <button
                  type="button"
                  disabled={submitting !== null}
                  onClick={() => {
                    setCallbackOpen(true);
                    setCallbackError(null);
                  }}
                  className="w-full min-h-[48px] rounded-[20px] bg-[#FBF6EA] border border-[#0F4C3A]/35 text-[#0F4C3A] font-bold text-sm sm:text-base flex items-center justify-center gap-2 hover:bg-[#F6CF5A]/25 active:scale-[0.98] disabled:opacity-60 transition-all cursor-pointer"
                >
                  <PhoneCall className="w-5 h-5" />
                  <span>اطلبي ونكلمك</span>
                </button>
              ) : (
                <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/45 p-3.5 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-[#0F4C3A]">
                      اكتبي رقم موبايلك وهنتصل بيكي ونكلمك واتساب:
                    </span>
                    <button
                      type="button"
                      onClick={() => setCallbackOpen(false)}
                      className="text-xs font-bold text-[#5B5B5B] cursor-pointer"
                    >
                      إلغاء
                    </button>
                  </div>
                  <input
                    type="tel"
                    inputMode="tel"
                    dir="ltr"
                    value={callbackPhone}
                    onChange={(e) => {
                      setCallbackPhone(e.target.value);
                      if (callbackError) setCallbackError(null);
                    }}
                    placeholder="01xxxxxxxxx"
                    aria-label="رقم الموبايل"
                    className="w-full min-h-[46px] px-3.5 rounded-xl bg-white border border-[#E8A91A]/45 text-sm font-bold tabular-nums text-left"
                  />
                  {callbackError && (
                    <p className="text-xs font-bold text-[#B3261E]">{callbackError}</p>
                  )}
                  <button
                    type="button"
                    disabled={submitting !== null}
                    onClick={() => handleCheckout('callback')}
                    className="w-full min-h-[48px] rounded-xl bg-[#0F4C3A] text-white text-sm font-bold hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
                  >
                    {submitting === 'callback' ? 'جاري الإرسال...' : 'ابعتي رقمك'}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      <OrderConfirmationSheet
        open={confirmState.open}
        channel={confirmState.channel}
        orderNo={confirmState.orderNo}
        message={confirmState.message}
        destinationUrl={confirmState.destinationUrl}
        customerPhone={confirmState.customerPhone}
        onClose={() => setConfirmState((s) => ({...s, open: false}))}
      />
    </div>
  );
};
