import React, {useEffect, useMemo, useState} from 'react';
import {useLocation, useNavigate, useParams, useSearchParams} from 'react-router-dom';
import {Search, X} from 'lucide-react';
import {CrownOrnament, EmptyState, ProductCardSkeleton} from '../components/BrandElements';
import {CategoryIcon} from '../components/CategoryIcon';
import {ProductCard} from '../components/ProductCard';
import {useStore} from '../context/StoreContext';
import {
  categoryUsesSizes,
  normalizeSearchText,
  sortCatalogProducts,
} from '../utils/catalogHelpers';

const PAGE_SIZE = 24;
const PREFERRED_SIZE_KEY = 'elamar_preferred_size_v1';

function readPreferredSize(): string | null {
  try {
    const val = localStorage.getItem(PREFERRED_SIZE_KEY);
    return val ? val.trim() : null;
  } catch {
    return null;
  }
}

export const CatalogPage: React.FC = () => {
  const {categoryId} = useParams<{categoryId?: string}>();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const {categories, products, loading} = useStore();

  const isOffersRoute = location.pathname === '/offers';
  const initialQuery = searchParams.get('q') || '';
  const [query, setQuery] = useState(initialQuery);
  const [selectedSubId, setSelectedSubId] = useState<string | null>(
    searchParams.get('sub') || null
  );
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const [selectedSize, setSelectedSize] = useState<string | null>(
    searchParams.get('size') || null
  );
  const [savedPreferredSize, setSavedPreferredSize] = useState<string | null>(() =>
    readPreferredSize()
  );

  useEffect(() => {
    setQuery(searchParams.get('q') || '');
    setSelectedSubId(searchParams.get('sub') || null);
    setSelectedSize(searchParams.get('size') || null);
  }, [searchParams, categoryId]);

  useEffect(() => {
    setVisibleCount(PAGE_SIZE);
  }, [categoryId, isOffersRoute, selectedSubId, selectedSize, query]);

  const topCategories = useMemo(
    () =>
      categories
        .filter((c) => !c.parent_id && c.visible)
        .sort((a, b) => a.sort - b.sort),
    [categories]
  );

  const activeCategory = useMemo(() => {
    if (!categoryId) return undefined;
    return categories.find((c) => c.id === categoryId);
  }, [categories, categoryId]);

  // If navigated directly to a subcategory id, treat its parent as the main category
  const effectiveParentId = activeCategory?.parent_id || categoryId;
  const effectiveSubId = activeCategory?.parent_id ? activeCategory.id : selectedSubId;

  const parentForActive = activeCategory?.parent_id
    ? categories.find((c) => c.id === activeCategory.parent_id)
    : undefined;
  const displayCategory = parentForActive || activeCategory;

  const subcategories = useMemo(() => {
    if (!effectiveParentId || isOffersRoute) return [];
    return categories
      .filter((c) => c.parent_id === effectiveParentId && c.visible)
      .sort((a, b) => a.sort - b.sort);
  }, [categories, effectiveParentId, isOffersRoute]);

  const baseCategoryProducts = useMemo(() => {
    return products.filter((p) => {
      if (!p.visible) return false;
      if (isOffersRoute && !(p.old_price && p.old_price > p.price)) return false;
      if (effectiveParentId && p.category_id !== effectiveParentId) return false;
      if (effectiveSubId && p.subcategory_id !== effectiveSubId) return false;
      return true;
    });
  }, [products, isOffersRoute, effectiveParentId, effectiveSubId]);

  const viewUsesSizes = useMemo(() => {
    if (!displayCategory || isOffersRoute) return true;
    return categoryUsesSizes(displayCategory.name);
  }, [displayCategory, isOffersRoute]);

  const availableSizes = useMemo(() => {
    if (!viewUsesSizes) return [];
    const set = new Set<string>();
    for (const p of baseCategoryProducts) {
      for (const c of p.colors) {
        for (const s of c.sizes) {
          if (s.status === 'available' && s.size && s.size.trim()) {
            set.add(s.size.trim());
          }
        }
      }
    }
    return Array.from(set).sort((a, b) => {
      const na = Number(a);
      const nb = Number(b);
      if (Number.isFinite(na) && Number.isFinite(nb)) return na - nb;
      return a.localeCompare(b, 'ar');
    });
  }, [baseCategoryProducts, viewUsesSizes]);

  const activeSizeFilter =
    selectedSize && availableSizes.includes(selectedSize) ? selectedSize : null;

  const filteredProducts = useMemo(() => {
    const qNorm = normalizeSearchText(query);
    const list = baseCategoryProducts.filter((p) => {
      if (activeSizeFilter) {
        const hasSize = p.colors.some((c) =>
          c.sizes.some(
            (s) => s.status === 'available' && s.size?.trim() === activeSizeFilter
          )
        );
        if (!hasSize) return false;
      }
      if (qNorm) {
        const catName = categories.find((c) => c.id === p.category_id)?.name || '';
        const subName = categories.find((c) => c.id === p.subcategory_id)?.name || '';
        const matches =
          normalizeSearchText(p.name).includes(qNorm) ||
          normalizeSearchText(p.code).includes(qNorm) ||
          normalizeSearchText(catName).includes(qNorm) ||
          normalizeSearchText(subName).includes(qNorm) ||
          normalizeSearchText(p.description).includes(qNorm);
        if (!matches) return false;
      }
      return true;
    });
    return sortCatalogProducts(list);
  }, [baseCategoryProducts, activeSizeFilter, query, categories]);

  const handleSelectSize = (size: string | null) => {
    setSelectedSize(size);
    if (size) {
      try {
        localStorage.setItem(PREFERRED_SIZE_KEY, size);
      } catch {
        // Ignore storage errors
      }
      setSavedPreferredSize(size);
    }
    const next = new URLSearchParams(searchParams);
    if (size) next.set('size', size);
    else next.delete('size');
    setSearchParams(next, {replace: true});
  };

  const handleSearchChange = (val: string) => {
    setQuery(val);
    const next = new URLSearchParams(searchParams);
    if (val.trim()) next.set('q', val);
    else next.delete('q');
    setSearchParams(next, {replace: true});
  };

  const handleSelectSubcategory = (subId: string | null) => {
    setSelectedSubId(subId);
    const next = new URLSearchParams(searchParams);
    if (subId) next.set('sub', subId);
    else next.delete('sub');
    setSearchParams(next, {replace: true});
  };

  const pageTitle = isOffersRoute
    ? 'عروض وخصومات'
    : displayCategory
      ? displayCategory.name
      : 'كل المنتجات';

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-5 sm:py-8 space-y-5 page-enter">
      {/* Header + Title */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-2.5">
          {displayCategory ? (
            <div className="w-12 h-12 rounded-full bg-white border border-[#E8A91A]/45 p-1 flex items-center justify-center shrink-0 overflow-hidden shadow-xs">
              {displayCategory.image_url ? (
                <img
                  src={displayCategory.image_url}
                  alt=""
                  className="w-full h-full rounded-full object-cover"
                />
              ) : (
                <CategoryIcon
                  name={displayCategory.name}
                  parentName={parentForActive?.name}
                  className="w-9 h-9"
                />
              )}
            </div>
          ) : isOffersRoute ? (
            <div className="w-12 h-12 rounded-full bg-white border border-[#E8A91A]/45 p-1 flex items-center justify-center shrink-0 shadow-xs">
              <CategoryIcon name="عروض" className="w-9 h-9" />
            </div>
          ) : (
            <CrownOrnament className="w-6 h-6" />
          )}
          <h1 className="text-2xl font-bold text-[#141413]">{pageTitle}</h1>
          <span className="text-xs font-semibold text-[#5B5B5B] tabular-nums">
            ({filteredProducts.length} قطعة)
          </span>
        </div>

        {/* Live Search */}
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-[#5B5B5B] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={query}
            onChange={(e) => handleSearchChange(e.target.value)}
            placeholder="ابحثي بالاسم أو الكود أو القسم..."
            aria-label="ابحثي في المنتجات"
            className="w-full min-h-[44px] pr-10 pl-10 rounded-2xl bg-white border border-[#E8A91A]/35 text-sm text-[#141413] placeholder:text-[#5B5B5B]"
          />
          {query && (
            <button
              type="button"
              onClick={() => handleSearchChange('')}
              aria-label="مسح البحث"
              className="min-w-[40px] min-h-[40px] flex items-center justify-center absolute left-1 top-1/2 -translate-y-1/2 text-[#5B5B5B] cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>
      </div>

      {/* Top-level Category Tabs with Category Icons */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1">
        <button
          type="button"
          onClick={() => navigate('/catalog')}
          className={`min-h-[44px] px-4 py-2 rounded-2xl text-sm font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
            !effectiveParentId && !isOffersRoute
              ? 'bg-[#0F4C3A] text-white shadow-xs'
              : 'bg-white text-[#141413] border border-[#E8A91A]/30 hover:bg-[#FBF6EA]'
          }`}
        >
          الكل
        </button>

        <button
          type="button"
          onClick={() => navigate('/offers')}
          className={`min-h-[44px] px-4 py-2 rounded-2xl text-sm font-bold whitespace-nowrap shrink-0 inline-flex items-center gap-1.5 transition-colors cursor-pointer ${
            isOffersRoute
              ? 'bg-[#B3261E] text-white shadow-xs'
              : 'bg-white text-[#B3261E] border border-[#B3261E]/25 hover:bg-[#B3261E]/5'
          }`}
        >
          <CategoryIcon name="عروض" className="w-6 h-6" />
          <span>عروض</span>
        </button>

        {topCategories.map((cat) => {
          const isActive = effectiveParentId === cat.id;
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => navigate(`/c/${cat.id}`)}
              className={`min-h-[44px] px-4 py-2 rounded-2xl text-sm font-bold whitespace-nowrap shrink-0 inline-flex items-center gap-2 transition-all active:scale-95 cursor-pointer ${
                isActive
                  ? 'bg-[#0F4C3A] text-white shadow-xs'
                  : 'bg-white text-[#141413] border border-[#E8A91A]/30 hover:bg-[#FBF6EA]'
              }`}
            >
              {cat.image_url ? (
                <img
                  src={cat.image_url}
                  alt=""
                  className="w-6 h-6 rounded-full object-cover shrink-0"
                />
              ) : (
                <CategoryIcon name={cat.name} className="w-6 h-6" />
              )}
              <span>{cat.name}</span>
            </button>
          );
        })}
      </div>

      {/* Subcategory Horizontal Filter Chips (Active chip = Gold) */}
      {subcategories.length > 0 && (
        <div
          aria-label="الأنواع الفرعية"
          className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-1"
        >
          <button
            type="button"
            onClick={() => handleSelectSubcategory(null)}
            className={`min-h-[48px] px-4 py-1.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 transition-colors cursor-pointer ${
              !effectiveSubId
                ? 'bg-[#E8A91A] text-[#141413] shadow-xs'
                : 'bg-white text-[#5B5B5B] border border-[#E8A91A]/30 hover:text-[#141413]'
            }`}
          >
            الكل
          </button>

          {subcategories.map((sub) => {
            const activeSub = effectiveSubId === sub.id;
            return (
              <button
                key={sub.id}
                type="button"
                onClick={() => handleSelectSubcategory(sub.id)}
                className={`min-h-[48px] px-3.5 py-1.5 rounded-2xl text-xs sm:text-sm font-bold whitespace-nowrap shrink-0 inline-flex items-center gap-2 transition-colors cursor-pointer ${
                  activeSub
                    ? 'bg-[#E8A91A] text-[#141413] shadow-xs'
                    : 'bg-white text-[#5B5B5B] border border-[#E8A91A]/30 hover:text-[#141413]'
                }`}
              >
                {sub.image_url ? (
                  <img
                    src={sub.image_url}
                    alt=""
                    className="w-8 h-8 rounded-full object-cover shrink-0"
                  />
                ) : (
                  <CategoryIcon
                    name={sub.name}
                    parentName={displayCategory?.name}
                    className="w-8 h-8 shrink-0"
                  />
                )}
                <span>{sub.name}</span>
              </button>
            );
          })}
        </div>
      )}

      {/* My Size ("مقاسي") Filter Row — hidden automatically when category has no sizes */}
      {availableSizes.length > 0 && (
        <div
          aria-label="اختيار المقاس"
          className="rounded-2xl bg-white border border-[#E8A91A]/30 px-3.5 py-2.5 flex flex-wrap items-center gap-2 shadow-xs"
        >
          <span className="text-xs font-bold text-[#0F4C3A] shrink-0">مقاسي:</span>

          {savedPreferredSize &&
            availableSizes.includes(savedPreferredSize) &&
            activeSizeFilter !== savedPreferredSize && (
              <button
                type="button"
                onClick={() => handleSelectSize(savedPreferredSize)}
                className="min-h-[38px] px-3 rounded-xl bg-[#E8A91A] text-[#141413] text-xs font-bold whitespace-nowrap cursor-pointer hover:bg-[#F6CF5A] transition-colors"
              >
                مقاسك {savedPreferredSize}؟
              </button>
            )}

          <button
            type="button"
            onClick={() => handleSelectSize(null)}
            className={`min-h-[38px] px-3 rounded-xl text-xs font-bold whitespace-nowrap cursor-pointer transition-colors ${
              !activeSizeFilter
                ? 'bg-[#0F4C3A] text-white'
                : 'bg-[#FBF6EA] text-[#5B5B5B] hover:text-[#141413]'
            }`}
          >
            كل المقاسات
          </button>

          <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar py-0.5">
            {availableSizes.map((sz) => {
              const active = activeSizeFilter === sz;
              return (
                <button
                  key={sz}
                  type="button"
                  onClick={() => handleSelectSize(active ? null : sz)}
                  className={`min-w-[42px] min-h-[38px] px-2.5 rounded-xl text-xs font-bold tabular-nums border transition-colors shrink-0 cursor-pointer ${
                    active
                      ? 'bg-[#0F4C3A] text-white border-[#0F4C3A] shadow-xs'
                      : 'bg-white text-[#141413] border-[#E8A91A]/35 hover:border-[#0F4C3A]'
                  }`}
                >
                  {sz}
                </button>
              );
            })}
          </div>
        </div>
      )}

      {/* Product Grid */}
      {loading ? (
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
          {Array.from({length: 8}).map((_, i) => (
            <ProductCardSkeleton key={i} />
          ))}
        </div>
      ) : filteredProducts.length === 0 ? (
        <EmptyState
          title="لا توجد منتجات مطابقة"
          subtitle="جربي مسح كلمة البحث أو اختيار نوع أو مقاس آخر."
          actionLabel="عرض كل المنتجات"
          onAction={() => {
            setQuery('');
            setSelectedSubId(null);
            setSelectedSize(null);
            navigate('/catalog');
          }}
        />
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3.5 sm:gap-5">
            {filteredProducts.slice(0, visibleCount).map((p, i) => (
              <ProductCard
                key={p.id}
                product={p}
                index={i}
                selectedSizeFilter={activeSizeFilter}
              />
            ))}
          </div>

          {filteredProducts.length > visibleCount && (
            <div className="flex justify-center pt-2">
              <button
                type="button"
                onClick={() => setVisibleCount((prev) => prev + PAGE_SIZE)}
                className="min-h-[48px] px-8 rounded-2xl bg-white border border-[#E8A91A]/45 text-sm font-bold text-[#0F4C3A] shadow-xs hover:bg-[#FBF6EA] active:scale-[0.98] transition-all cursor-pointer tabular-nums"
              >
                عرض المزيد ({filteredProducts.length - visibleCount} متبقي)
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
