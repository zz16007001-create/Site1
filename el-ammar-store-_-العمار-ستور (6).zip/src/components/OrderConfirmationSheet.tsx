import React, {useEffect, useState} from 'react';
import {Check, CheckCircle2, Copy, ExternalLink, MessageCircle, PhoneCall, Send, X} from 'lucide-react';
import type {OrderChannel} from '../types/store';
import {copyTextSync} from '../utils/catalogHelpers';

interface OrderConfirmationSheetProps {
  open: boolean;
  channel: OrderChannel | null;
  orderNo: number | null;
  message: string;
  destinationUrl: string;
  customerPhone?: string | null;
  onClose: () => void;
  onOpenedChannel?: () => void;
}

export const OrderConfirmationSheet: React.FC<OrderConfirmationSheetProps> = ({
  open,
  channel,
  orderNo,
  message,
  destinationUrl,
  customerPhone,
  onClose,
  onOpenedChannel,
}) => {
  const [copiedNotice, setCopiedNotice] = useState(false);

  useEffect(() => {
    if (!open) {
      setCopiedNotice(false);
      return;
    }
    if (channel !== 'callback' && message) {
      const ok = copyTextSync(message);
      setCopiedNotice(ok);
    }
  }, [open, channel, message]);

  if (!open || !channel) return null;

  const isCallback = channel === 'callback';
  const isMessenger = channel === 'messenger';

  return (
    <div
      className="fixed inset-0 z-[95] flex items-end sm:items-center justify-center bg-black/55 backdrop-blur-xs p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="تأكيد تجهيز الطلب"
      onClick={onClose}
    >
      <div
        className="w-full sm:max-w-md rounded-t-[28px] sm:rounded-[28px] bg-white border-t sm:border border-[#E8A91A]/40 shadow-2xl p-5 sm:p-6 space-y-4 max-h-[92dvh] overflow-y-auto page-enter"
        onClick={(e) => e.stopPropagation()}
      >
        {isCallback ? (
          <>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-2.5">
                <div className="w-11 h-11 rounded-2xl bg-[#0F4C3A]/10 text-[#0F4C3A] flex items-center justify-center shrink-0">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <div className="space-y-0.5">
                  <h2 className="text-lg font-bold text-[#0F4C3A]">
                    {orderNo ? `وصل طلبك رقم #${orderNo} ✅` : 'وصل طلبك ✅'}
                  </h2>
                  <p className="text-xs font-semibold text-[#5B5B5B]">
                    تم تسجيل طلبك في المتجر بنجاح
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-[#FBF6EA] text-[#5B5B5B] shrink-0 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 p-4 space-y-2 text-center">
              <PhoneCall className="w-6 h-6 text-[#0F4C3A] mx-auto" />
              <p className="text-sm sm:text-base font-bold text-[#141413]">
                هنتصل بيكي ونكلمك واتساب نأكد المقاس والشحن
              </p>
              {customerPhone && (
                <p dir="ltr" className="text-sm font-bold text-[#0F4C3A] tabular-nums">
                  {customerPhone}
                </p>
              )}
            </div>

            <button
              type="button"
              onClick={onClose}
              className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white text-base font-bold hover:bg-[#0A3629] transition-colors cursor-pointer"
            >
              تمام، شكراً
            </button>
          </>
        ) : (
          <>
            <div className="flex items-start justify-between gap-3">
              <div className="space-y-1">
                <h2 className="text-lg font-bold text-[#0F4C3A]">
                  {orderNo ? `وصل طلبك رقم #${orderNo} ✅` : 'تم تجهيز طلبك ✅'}
                </h2>
                <p className="text-sm font-semibold text-[#141413]">
                  {isMessenger
                    ? 'امشي على الخطوتين دول لإرسال الطلب في ماسنجر:'
                    : 'ابعتي الرسالة الجاهزة في واتساب وهنأكدلك المقاس والشحن'}
                </p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label="إغلاق"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-[#FBF6EA] text-[#5B5B5B] shrink-0 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {isMessenger && (
              <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/40 p-3 space-y-1.5 text-xs sm:text-sm font-bold text-[#141413]">
                <p>① اضغطي «نسخ الرسالة» الأول</p>
                <p>② اضغطي «افتحي ماسنجر» والصقيها وابعتيها</p>
              </div>
            )}

            <div className="space-y-2">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-[#5B5B5B]">
                  {copiedNotice ? 'تم نسخ نص الطلب — تقدري تلصقيه مباشرة' : 'انسخي نص الطلب'}
                </span>
                <button
                  type="button"
                  onClick={() => {
                    const ok = copyTextSync(message);
                    setCopiedNotice(ok);
                  }}
                  className="min-h-[40px] px-3.5 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/45 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 hover:bg-[#F6CF5A]/30 cursor-pointer"
                >
                  {copiedNotice ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{copiedNotice ? 'تم النسخ ✓' : '① نسخ الرسالة'}</span>
                </button>
              </div>

              <textarea
                readOnly
                rows={7}
                value={message}
                onClick={(e) => e.currentTarget.select()}
                aria-label="نص الطلب الجاهز"
                className="w-full rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 p-3.5 text-xs sm:text-sm text-[#141413] leading-relaxed resize-none focus:outline-none focus:border-[#0F4C3A]"
              />
            </div>

            <div className="space-y-2 pt-1">
              <a
                href={destinationUrl}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => {
                  const ok = copyTextSync(message);
                  setCopiedNotice(ok);
                  onOpenedChannel?.();
                }}
                className={`w-full min-h-[54px] px-5 rounded-2xl text-base font-bold flex items-center justify-center gap-2.5 shadow-lg transition-all active:scale-[0.98] ${
                  isMessenger
                    ? 'bg-[#E8A91A] text-[#141413] hover:bg-[#F6CF5A]'
                    : 'bg-[#0F4C3A] text-white hover:bg-[#0A3629]'
                }`}
              >
                {isMessenger ? (
                  <Send className="w-5 h-5 text-[#0F4C3A]" />
                ) : (
                  <MessageCircle className="w-5 h-5 text-[#F6CF5A]" />
                )}
                <span>{isMessenger ? '② افتحي ماسنجر والصقيها' : 'افتحي واتساب'}</span>
                <ExternalLink className="w-4 h-4 opacity-75" />
              </a>

              <p className="text-center text-xs font-semibold text-[#5B5B5B]">
                وصل طلبك {orderNo ? `#${orderNo}` : ''} — هنكلمك نأكد المقاس والشحن
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
};
