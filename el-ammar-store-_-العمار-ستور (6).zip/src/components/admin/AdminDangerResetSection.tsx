import React, {useEffect, useState} from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Delete,
  KeyRound,
  Lock,
  RefreshCw,
  ShieldAlert,
  Trash2,
  X,
} from 'lucide-react';
import {useStore} from '../../context/StoreContext';
import type {StorageDeleteResult} from '../../types/store';

function formatRemainingLock(lockedUntil: string | null | undefined): string {
  if (!lockedUntil) return '5 دقائق';
  const diffMs = Math.max(0, new Date(lockedUntil).getTime() - Date.now());
  const mins = Math.max(1, Math.ceil(diffMs / 60000));
  return `${mins} دقيقة`;
}

export const AdminDangerResetSection: React.FC<{openChangePinSignal?: number}> = ({
  openChangePinSignal = 0,
}) => {
  const {products, resetAllProducts, changeResetPin, retryDeleteStoragePaths, showToast} =
    useStore();

  // Reset modal state
  const [resetOpen, setResetOpen] = useState(false);
  const [pin, setPin] = useState('');
  const [takeBackup, setTakeBackup] = useState(true);
  const [deleteStorage, setDeleteStorage] = useState(true);
  const [resetStep, setResetStep] = useState<'form' | 'running' | 'done'>('form');
  const [resetError, setResetError] = useState<string | null>(null);
  const [resetResult, setResetResult] = useState<StorageDeleteResult | null>(null);
  const [retryingStorage, setRetryingStorage] = useState(false);

  // Change PIN modal state
  const [changePinOpen, setChangePinOpen] = useState(false);
  const [oldPin, setOldPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [changingPin, setChangingPin] = useState(false);
  const [changePinError, setChangePinError] = useState<string | null>(null);

  const openResetModal = () => {
    setPin('');
    setTakeBackup(true);
    setDeleteStorage(true);
    setResetStep('form');
    setResetError(null);
    setResetResult(null);
    setResetOpen(true);
  };

  const closeResetModal = () => {
    if (resetStep === 'running' || retryingStorage) return;
    setResetOpen(false);
  };

  const handlePadPress = (digit: string) => {
    setResetError(null);
    setPin((prev) => (prev.length >= 4 ? prev : prev + digit));
  };

  const handleResetSubmit = async () => {
    if (pin.length !== 4) {
      setResetError('اكتبي الرقم السري المكون من 4 أرقام');
      return;
    }
    setResetError(null);
    setResetStep('running');
    try {
      const res = await resetAllProducts(pin, takeBackup, deleteStorage);
      if (!res.ok) {
        setResetStep('form');
        setPin('');
        if (res.error === 'locked') {
          setResetError(
            `تم قفل التصفير مؤقتًا لمدة ${formatRemainingLock(res.lockedUntil)} بسبب المحاولات الخاطئة.`
          );
        } else if (res.error === 'invalid_pin') {
          setResetError(
            typeof res.attemptsLeft === 'number'
              ? `الرقم السري غير صحيح — متبقي ${res.attemptsLeft} محاولات`
              : 'الرقم السري غير صحيح'
          );
        } else {
          setResetError('تعذر تنفيذ التصفير. تأكدي من الاتصال وحاولي مرة أخرى.');
        }
        return;
      }

      setResetResult({
        deletedProducts: res.deletedProducts ?? 0,
        deletedImages: res.deletedImages ?? 0,
        pinnedImages: res.pinnedImages ?? 0,
        failedPaths: res.failedPaths ?? [],
      });
      setResetStep('done');
    } catch {
      setResetStep('form');
      setResetError('تعذر تنفيذ التصفير. تأكدي من الاتصال وحاولي مرة أخرى.');
    }
  };

  const handleRetryStorage = async () => {
    if (!resetResult || resetResult.failedPaths.length === 0) return;
    setRetryingStorage(true);
    try {
      const retryRes = await retryDeleteStoragePaths(resetResult.failedPaths);
      setResetResult({
        deletedProducts: resetResult.deletedProducts,
        deletedImages: resetResult.deletedImages + retryRes.deletedImages,
        pinnedImages: resetResult.pinnedImages,
        failedPaths: retryRes.failedPaths,
      });
    } finally {
      setRetryingStorage(false);
    }
  };

  const openChangePinModal = () => {
    setOldPin('');
    setNewPin('');
    setConfirmPin('');
    setChangePinError(null);
    setChangePinOpen(true);
  };

  useEffect(() => {
    if (openChangePinSignal > 0) {
      openChangePinModal();
    }
  }, [openChangePinSignal]);

  const handleChangePinSubmit = async () => {
    setChangePinError(null);
    if (!/^\d{4}$/.test(oldPin)) {
      setChangePinError('اكتبي الرقم السري الحالي المكون من 4 أرقام');
      return;
    }
    if (!/^\d{4}$/.test(newPin)) {
      setChangePinError('الرقم السري الجديد لازم يكون 4 أرقام');
      return;
    }
    if (newPin !== confirmPin) {
      setChangePinError('الرقم السري الجديد وتأكيده مش متطابقين');
      return;
    }
    setChangingPin(true);
    try {
      const res = await changeResetPin(oldPin, newPin);
      if (!res.ok) {
        if (res.error === 'locked') {
          setChangePinError(
            `المحاولات مقفولة مؤقتًا لمدة ${formatRemainingLock(res.lockedUntil)}`
          );
        } else if (res.error === 'invalid_pin') {
          setChangePinError(
            typeof res.attemptsLeft === 'number'
              ? `الرقم السري الحالي غير صحيح — متبقي ${res.attemptsLeft} محاولات`
              : 'الرقم السري الحالي غير صحيح'
          );
        } else {
          setChangePinError('تعذر تغيير الرقم السري');
        }
        return;
      }
      showToast('تم تغيير الرقم السري بنجاح', 'success');
      setChangePinOpen(false);
    } catch {
      setChangePinError('تعذر تغيير الرقم السري');
    } finally {
      setChangingPin(false);
    }
  };

  const formatSummary = (res: StorageDeleteResult) =>
    `تم حذف ${res.deletedProducts} منتج و${res.deletedImages} صورة، و${res.pinnedImages} صورة محفوظة لأنها في نسخة احتياطية`;

  return (
    <section className="rounded-[24px] bg-[#FFF9F8] border border-[#B3261E]/35 p-5 space-y-4">
      <div className="space-y-1">
        <div className="flex items-center gap-2 text-[#B3261E]">
          <ShieldAlert className="w-5 h-5 shrink-0" />
          <h3 className="text-base font-bold">منطقة الخطر</h3>
        </div>
        <p className="text-xs text-[#5B5B5B] leading-relaxed">
          حذف جميع المنتجات لبدء موسم أو كتالوج جديد برقم سري (4 أرقام — الافتراضي 1234). الأقسام والطلبات وإعدادات المتجر لا تتأثر.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={openResetModal}
          className="min-h-[48px] px-4 rounded-2xl bg-[#B3261E] text-white text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#8E1C16] cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span>تصفير كل المنتجات ({products.length})</span>
        </button>

        <button
          type="button"
          onClick={openChangePinModal}
          className="min-h-[48px] px-4 rounded-2xl bg-white border border-[#B3261E]/30 text-[#141413] text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#FBF6EA] cursor-pointer"
        >
          <KeyRound className="w-4 h-4 text-[#0F4C3A]" />
          <span>تغيير الرقم السري</span>
        </button>
      </div>

      {/* RESET ALL PRODUCTS MODAL */}
      {resetOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="تصفير كل المنتجات"
          onClick={closeResetModal}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md max-h-[92vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#B3261E]/30 space-y-4"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
              <div className="flex items-center gap-2 text-[#B3261E]">
                <Lock className="w-5 h-5" />
                <h4 className="text-base font-bold">تصفير كل المنتجات</h4>
              </div>
              {resetStep !== 'running' && !retryingStorage && (
                <button
                  type="button"
                  onClick={closeResetModal}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5 text-[#141413]" />
                </button>
              )}
            </div>

            {resetStep === 'form' && (
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/25 p-3 flex items-start gap-2 text-xs font-bold text-[#B3261E]">
                  <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                  <span>
                    سيتم مسح جميع الموديلات والألوان والمقاسات ({products.length} منتج). سجل الطلبات والأقسام والإعدادات ستبقى كما هي.
                  </span>
                </div>

                {/* Options */}
                <div className="space-y-2.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-3.5">
                  <label className="flex items-center gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={takeBackup}
                      onChange={(e) => setTakeBackup(e.target.checked)}
                      className="w-5 h-5 accent-[#0F4C3A] shrink-0"
                    />
                    <span className="text-xs font-bold text-[#141413]">
                      خد نسخة سريعة قبل التصفير (موصى به)
                    </span>
                  </label>

                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={deleteStorage}
                      onChange={(e) => setDeleteStorage(e.target.checked)}
                      className="w-5 h-5 mt-0.5 accent-[#B3261E] shrink-0"
                    />
                    <span className="text-xs font-bold text-[#141413] leading-relaxed">
                      احذف صور المنتجات من التخزين (الصور المثبتة في النسخ السريعة لن تُحذف)
                    </span>
                  </label>
                </div>

                {/* 4-digit PIN display + keyboard input + touch keypad */}
                <div className="space-y-2.5">
                  <p className="text-xs font-bold text-[#5B5B5B] text-center">
                    أدخلي الرقم السري المكون من 4 أرقام للتأكيد:
                  </p>

                  <div className="flex items-center justify-center gap-3" dir="ltr">
                    {[0, 1, 2, 3].map((idx) => {
                      const filled = idx < pin.length;
                      return (
                        <div
                          key={idx}
                          className={`w-12 h-12 rounded-2xl border-2 flex items-center justify-center text-xl font-bold ${
                            filled
                              ? 'border-[#0F4C3A] bg-[#0F4C3A]/10 text-[#0F4C3A]'
                              : 'border-[#E8A91A]/45 bg-[#FBF6EA] text-[#5B5B5B]'
                          }`}
                        >
                          {filled ? '●' : ''}
                        </div>
                      );
                    })}
                  </div>

                  {/* Hidden/Accessible numeric input for keyboard users */}
                  <input
                    type="password"
                    inputMode="numeric"
                    maxLength={4}
                    value={pin}
                    onChange={(e) => {
                      setResetError(null);
                      setPin(e.target.value.replace(/[^\d]/g, '').slice(0, 4));
                    }}
                    placeholder="أو اكتبي 4 أرقام هنا"
                    aria-label="الرقم السري"
                    className="w-full min-h-[42px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-center text-sm font-bold tracking-widest"
                  />

                  {/* Touch Numeric Keypad (48px targets) */}
                  <div className="grid grid-cols-3 gap-2 max-w-[260px] mx-auto" dir="ltr">
                    {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
                      <button
                        key={digit}
                        type="button"
                        onClick={() => handlePadPress(digit)}
                        className="min-h-[48px] rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-base font-bold text-[#141413] active:scale-95 hover:bg-[#F7EFE0] cursor-pointer"
                      >
                        {digit}
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => setPin('')}
                      className="min-h-[48px] rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold text-[#5B5B5B] active:scale-95 cursor-pointer"
                    >
                      مسح
                    </button>
                    <button
                      type="button"
                      onClick={() => handlePadPress('0')}
                      className="min-h-[48px] rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-base font-bold text-[#141413] active:scale-95 hover:bg-[#F7EFE0] cursor-pointer"
                    >
                      0
                    </button>
                    <button
                      type="button"
                      onClick={() => setPin((prev) => prev.slice(0, -1))}
                      aria-label="رجوع رقم"
                      className="min-h-[48px] rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 flex items-center justify-center text-[#141413] active:scale-95 cursor-pointer"
                    >
                      <Delete className="w-5 h-5" />
                    </button>
                  </div>
                </div>

                {resetError && (
                  <p className="rounded-xl bg-[#B3261E]/10 border border-[#B3261E]/30 p-3 text-xs font-bold text-[#B3261E] text-center">
                    {resetError}
                  </p>
                )}

                <div className="flex gap-2.5 pt-1">
                  <button
                    type="button"
                    disabled={pin.length !== 4}
                    onClick={handleResetSubmit}
                    className="flex-1 min-h-[48px] rounded-2xl bg-[#B3261E] text-white font-bold text-sm hover:bg-[#8E1C16] disabled:opacity-45 cursor-pointer"
                  >
                    تأكيد تصفير كل المنتجات
                  </button>
                  <button
                    type="button"
                    onClick={closeResetModal}
                    className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
                  >
                    إلغاء
                  </button>
                </div>
              </div>
            )}

            {resetStep === 'running' && (
              <div className="py-6 space-y-3 text-center">
                <RefreshCw className="w-8 h-8 text-[#B3261E] animate-spin mx-auto" />
                <p className="text-sm font-bold text-[#141413]">
                  جاري تنفيذ التصفير وحفظ النسخة الاحتياطية...
                </p>
              </div>
            )}

            {resetStep === 'done' && resetResult && (
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#0F4C3A]/10 border border-[#0F4C3A]/25 p-4 flex items-center gap-2.5 text-[#0F4C3A]">
                  <CheckCircle2 className="w-6 h-6 shrink-0" />
                  <p className="text-sm font-bold leading-relaxed">
                    {formatSummary(resetResult)}
                  </p>
                </div>

                {resetResult.failedPaths.length > 0 && (
                  <button
                    type="button"
                    disabled={retryingStorage}
                    onClick={handleRetryStorage}
                    className="w-full min-h-[44px] rounded-xl bg-[#B3261E] text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-4 h-4 ${retryingStorage ? 'animate-spin' : ''}`} />
                    <span>إعادة محاولة حذف الصور المتبقية ({resetResult.failedPaths.length})</span>
                  </button>
                )}

                <button
                  type="button"
                  disabled={retryingStorage}
                  onClick={closeResetModal}
                  className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* CHANGE PIN MODAL */}
      {changePinOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="تغيير الرقم السري"
          onClick={() => !changingPin && setChangePinOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#E8A91A]/35 space-y-4"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
              <div className="flex items-center gap-2 text-[#0F4C3A]">
                <KeyRound className="w-5 h-5" />
                <h4 className="text-base font-bold">تغيير الرقم السري للتصفير</h4>
              </div>
              {!changingPin && (
                <button
                  type="button"
                  onClick={() => setChangePinOpen(false)}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5 text-[#141413]" />
                </button>
              )}
            </div>

            <div className="space-y-3">
              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">
                  الرقم السري الحالي (4 أرقام — الافتراضي 1234)
                </span>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={oldPin}
                  onChange={(e) => setOldPin(e.target.value.replace(/[^\d]/g, '').slice(0, 4))}
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-center text-base font-bold tracking-widest"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">الرقم السري الجديد (4 أرقام)</span>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/[^\d]/g, '').slice(0, 4))}
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-center text-base font-bold tracking-widest"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">تأكيد الرقم السري الجديد</span>
                <input
                  type="password"
                  inputMode="numeric"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/[^\d]/g, '').slice(0, 4))}
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-center text-base font-bold tracking-widest"
                />
              </label>

              {changePinError && (
                <p className="rounded-xl bg-[#B3261E]/10 border border-[#B3261E]/30 p-3 text-xs font-bold text-[#B3261E]">
                  {changePinError}
                </p>
              )}
            </div>

            <div className="flex gap-2.5">
              <button
                type="button"
                disabled={changingPin}
                onClick={handleChangePinSubmit}
                className="flex-1 min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
              >
                {changingPin ? 'جاري التغيير...' : 'حفظ الرقم السري'}
              </button>
              <button
                type="button"
                disabled={changingPin}
                onClick={() => setChangePinOpen(false)}
                className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
