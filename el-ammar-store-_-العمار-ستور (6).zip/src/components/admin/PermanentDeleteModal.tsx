import React, {useMemo, useState} from 'react';
import {AlertTriangle, CheckCircle2, RefreshCw, Trash2, X} from 'lucide-react';
import {useStore} from '../../context/StoreContext';
import type {StorageDeleteResult} from '../../types/store';

interface PermanentDeleteModalProps {
  productIds: string[];
  onClose: () => void;
  onCompleted?: (result: StorageDeleteResult) => void;
}

export const PermanentDeleteModal: React.FC<PermanentDeleteModalProps> = ({
  productIds,
  onClose,
  onCompleted,
}) => {
  const {
    products,
    orders,
    permanentlyDeleteProducts,
    retryDeleteStoragePaths,
    showToast,
  } = useStore();

  const [step, setStep] = useState<'confirm' | 'deleting' | 'done'>('confirm');
  const [progress, setProgress] = useState<{
    stage: 'db' | 'storage';
    done: number;
    total: number;
  } | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [result, setResult] = useState<StorageDeleteResult | null>(null);
  const [retrying, setRetrying] = useState(false);

  const selectedIdsSet = useMemo(() => new Set(productIds), [productIds]);

  const totalImagesCount = useMemo(() => {
    const urls = new Set<string>();
    for (const p of products) {
      if (!selectedIdsSet.has(p.id)) continue;
      for (const c of p.colors) {
        for (const img of c.images) {
          if (img.full) urls.add(img.full);
        }
      }
    }
    return urls.size;
  }, [products, selectedIdsSet]);

  // Count how many selected products appear in undelivered ('new') orders
  const pendingOrderProductCount = useMemo(() => {
    const affectedProducts = new Set<string>();
    for (const o of orders) {
      if (o.status !== 'new') continue;
      for (const item of o.items) {
        if (item.product_id && selectedIdsSet.has(item.product_id)) {
          affectedProducts.add(item.product_id);
        }
      }
    }
    return affectedProducts.size;
  }, [orders, selectedIdsSet]);

  const formatSummary = (res: StorageDeleteResult) =>
    `تم حذف ${res.deletedProducts} منتج و${res.deletedImages} صورة، و${res.pinnedImages} صورة محفوظة لأنها في نسخة احتياطية`;

  const handleConfirm = async () => {
    setErrorMsg(null);
    setStep('deleting');
    try {
      const res = await permanentlyDeleteProducts(productIds, (p) => {
        setProgress(p);
      });
      setResult(res);
      setStep('done');
      showToast(formatSummary(res), res.failedPaths.length > 0 ? 'warning' : 'success');
      onCompleted?.(res);
    } catch {
      setErrorMsg('تعذر إتمام الحذف. تأكدي من الاتصال وحاولي مرة أخرى.');
      setStep('confirm');
    }
  };

  const handleRetryImages = async () => {
    if (!result || result.failedPaths.length === 0) return;
    setRetrying(true);
    try {
      const retryRes = await retryDeleteStoragePaths(result.failedPaths, (p) => {
        setProgress({stage: 'storage', ...p});
      });
      const updated: StorageDeleteResult = {
        deletedProducts: result.deletedProducts,
        deletedImages: result.deletedImages + retryRes.deletedImages,
        pinnedImages: result.pinnedImages,
        failedPaths: retryRes.failedPaths,
      };
      setResult(updated);
      if (retryRes.failedPaths.length === 0) {
        showToast(formatSummary(updated), 'success');
      } else {
        showToast(`بقي ${retryRes.failedPaths.length} صورة تعذر حذفها`, 'warning');
      }
    } finally {
      setRetrying(false);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
      role="dialog"
      aria-modal="true"
      aria-label="تأكيد الحذف النهائي"
      onClick={() => {
        if (step !== 'deleting' && !retrying) onClose();
      }}
    >
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#B3261E]/25 space-y-4"
      >
        <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
          <div className="flex items-center gap-2 text-[#B3261E]">
            <Trash2 className="w-5 h-5" />
            <h3 className="text-base font-bold">
              {step === 'done' ? 'نتيجة الحذف النهائي' : 'تأكيد الحذف النهائي'}
            </h3>
          </div>
          {step !== 'deleting' && !retrying && (
            <button
              type="button"
              onClick={onClose}
              aria-label="إغلاق"
              className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
            >
              <X className="w-5 h-5 text-[#141413]" />
            </button>
          )}
        </div>

        {step === 'confirm' && (
          <>
            <div className="space-y-2.5 text-sm text-[#141413]">
              <p className="font-bold leading-relaxed">
                هل أنتِ متأكدة من حذف{' '}
                <span className="text-[#B3261E] tabular-nums">{productIds.length}</span> منتج نهائيًا؟
              </p>
              <p className="text-xs text-[#5B5B5B] leading-relaxed">
                سيتم حذف الموديلات والألوان والمقاسات وكل صورها ({totalImagesCount} صورة) غير المحفوظة في نسخ احتياطية. الطلبات القديمة ستحتفظ ببياناتها كاملة.
              </p>

              {pendingOrderProductCount > 0 && (
                <div className="rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/35 p-3.5 flex items-start gap-2.5 text-[#B3261E]">
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm font-bold leading-snug">
                    تنبيه: منهم {pendingOrderProductCount} عليه طلبات لسه ما اتسلمتش
                  </p>
                </div>
              )}

              {errorMsg && (
                <p className="text-xs font-bold text-[#B3261E] bg-[#B3261E]/10 rounded-xl p-2.5">
                  {errorMsg}
                </p>
              )}
            </div>

            <div className="flex gap-2.5 pt-1">
              <button
                type="button"
                onClick={handleConfirm}
                className="flex-1 min-h-[48px] rounded-2xl bg-[#B3261E] text-white font-bold text-sm hover:bg-[#8E1C16] cursor-pointer"
              >
                حذف نهائي الآن
              </button>
              <button
                type="button"
                onClick={onClose}
                className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </>
        )}

        {step === 'deleting' && (
          <div className="py-6 space-y-3 text-center">
            <RefreshCw className="w-8 h-8 text-[#0F4C3A] animate-spin mx-auto" />
            <p className="text-sm font-bold text-[#141413]">
              {progress?.stage === 'storage'
                ? `جاري حذف الصور من التخزين (${progress.done} / ${progress.total})...`
                : 'جاري حذف بيانات الموديلات...'}
            </p>
            {progress && progress.total > 0 && (
              <div className="w-full h-2.5 rounded-full bg-[#FBF6EA] overflow-hidden border border-[#E8A91A]/30">
                <div
                  className="h-full bg-[#0F4C3A] transition-all duration-300"
                  style={{
                    width: `${Math.min(100, Math.round((progress.done / progress.total) * 100))}%`,
                  }}
                />
              </div>
            )}
          </div>
        )}

        {step === 'done' && result && (
          <div className="space-y-4">
            <div className="rounded-2xl bg-[#0F4C3A]/10 border border-[#0F4C3A]/25 p-4 flex items-center gap-3 text-[#0F4C3A]">
              <CheckCircle2 className="w-6 h-6 shrink-0" />
              <p className="text-sm font-bold leading-relaxed">{formatSummary(result)}</p>
            </div>

            {result.failedPaths.length > 0 && (
              <div className="rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/30 p-3.5 space-y-2.5">
                <p className="text-xs font-bold text-[#B3261E]">
                  تعذر حذف {result.failedPaths.length} صورة من مساحة التخزين.
                </p>
                <button
                  type="button"
                  disabled={retrying}
                  onClick={handleRetryImages}
                  className="w-full min-h-[44px] rounded-xl bg-[#B3261E] text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 disabled:opacity-60 cursor-pointer"
                >
                  <RefreshCw className={`w-4 h-4 ${retrying ? 'animate-spin' : ''}`} />
                  <span>
                    {retrying ? 'جاري إعادة المحاولة...' : 'إعادة محاولة حذف الصور المتبقية'}
                  </span>
                </button>
              </div>
            )}

            <button
              type="button"
              disabled={retrying}
              onClick={onClose}
              className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm cursor-pointer"
            >
              إغلاق
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
