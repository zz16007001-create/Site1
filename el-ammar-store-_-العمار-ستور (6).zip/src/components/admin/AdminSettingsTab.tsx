import React, {useEffect, useState} from 'react';
import {Camera, Megaphone, Plus, Save, Settings as SettingsIcon, Trash2} from 'lucide-react';
import {ResilientImage} from '../../components/BrandElements';
import {useStore} from '../../context/StoreContext';
import type {StoreSettings, TrustIconType} from '../../types/store';
import {AdminArchiveSection} from './AdminArchiveSection';
import {AdminBackupSection} from './AdminBackupSection';
import {AdminDangerResetSection} from './AdminDangerResetSection';
import {AdminPromoMaterials} from './AdminPromoMaterials';

const TRUST_ICON_OPTIONS: Array<{value: TrustIconType; label: string}> = [
  {value: 'sparkles', label: 'تألق'},
  {value: 'check', label: 'صح'},
  {value: 'message', label: 'محادثة'},
  {value: 'shield', label: 'ثقة'},
  {value: 'heart', label: 'قلب'},
  {value: 'tag', label: 'عرض'},
];

export const AdminSettingsTab: React.FC<{openChangePinSignal?: number}> = ({
  openChangePinSignal = 0,
}) => {
  const {settings, saveSettings, uploadImage, showToast} = useStore();
  const [subTab, setSubTab] = useState<'general' | 'promo'>('general');
  const [form, setForm] = useState<StoreSettings>(settings);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    setForm(settings);
  }, [settings]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await saveSettings({
        ...form,
        whatsapp: form.whatsapp.replace(/[^\d]/g, ''),
        pixel_id: (form.pixel_id || '').replace(/[^\d]/g, ''),
      });
    } catch {
      showToast('تعذر حفظ الإعدادات', 'warning');
    } finally {
      setSaving(false);
    }
  };

  const addTrustItem = () => {
    if ((form.trust_items || []).length >= 4) return;
    setForm({
      ...form,
      trust_items: [
        ...(form.trust_items || []),
        {id: `tr-${Date.now()}`, icon: 'sparkles', text: ''},
      ],
    });
  };

  return (
    <div className="space-y-6">
      {/* Sub-navigation between Store Settings and Promo Materials */}
      <div className="grid grid-cols-2 rounded-2xl bg-white p-1.5 border border-[#E8A91A]/35 shadow-xs">
        <button
          type="button"
          onClick={() => setSubTab('general')}
          className={`min-h-[44px] px-3 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
            subTab === 'general' ? 'bg-[#0F4C3A] text-white shadow-xs' : 'text-[#5B5B5B]'
          }`}
        >
          <SettingsIcon className="w-4 h-4" />
          <span>إعدادات المتجر</span>
        </button>
        <button
          type="button"
          onClick={() => setSubTab('promo')}
          className={`min-h-[44px] px-3 rounded-xl text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-1.5 transition-colors cursor-pointer ${
            subTab === 'promo' ? 'bg-[#0F4C3A] text-white shadow-xs' : 'text-[#5B5B5B]'
          }`}
        >
          <Megaphone className="w-4 h-4" />
          <span>مواد ترويج</span>
        </button>
      </div>

      {subTab === 'promo' ? (
        <AdminPromoMaterials />
      ) : (
        <>
          <form onSubmit={handleSubmit} className="space-y-5">
            {/* Identity & Logo */}
          <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-4">
        <h3 className="text-base font-bold text-[#141413]">هوية المتجر</h3>

        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-[#E8A91A] bg-white shrink-0">
            <ResilientImage
              src={form.logo_url}
              alt={form.store_name}
              className="w-full h-full object-cover"
            />
          </div>
          <label className="min-h-[44px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 cursor-pointer">
            <Camera className="w-4 h-4" />
            <span>تغيير الشعار</span>
            <input
              type="file"
              accept="image/*"
              onChange={async (e) => {
                const f = e.target.files?.[0];
                if (!f) return;
                const url = await uploadImage(f);
                setForm({...form, logo_url: url});
              }}
              className="hidden"
            />
          </label>
        </div>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">اسم المتجر</span>
          <input
            type="text"
            value={form.store_name}
            onChange={(e) => setForm({...form, store_name: e.target.value})}
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">رسالة الترحيب في الرئيسية</span>
          <textarea
            rows={2}
            value={form.welcome}
            onChange={(e) => setForm({...form, welcome: e.target.value})}
            className="w-full p-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">
            السطر الختامي في رسالة الطلب (واتساب/ماسنجر)
          </span>
          <input
            type="text"
            value={form.order_intro}
            onChange={(e) => setForm({...form, order_intro: e.target.value})}
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">مدة بقاء الموديل بالأيام</span>
          <input
            type="number"
            min={1}
            max={365}
            value={form.expiry_days ?? 10}
            onChange={(e) =>
              setForm({
                ...form,
                expiry_days: Math.max(1, parseInt(e.target.value || '10', 10) || 10),
              })
            }
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold tabular-nums"
          />
          <span className="block text-[11px] text-[#5B5B5B]">
            يظهر تنبيه في لوحة الإدارة للموديلات غير الدائمة التي تتجاوز هذه المدة (الافتراضي 10 أيام).
          </span>
        </label>
      </div>

      {/* Contact & Social Links */}
      <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-3.5">
        <h3 className="text-base font-bold text-[#141413]">روابط التواصل و«تابعينا»</h3>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">
            رقم الواتساب (أرقام فقط بالصيغة الدولية، مثل 201000000000)
          </span>
          <input
            type="tel"
            dir="ltr"
            value={form.whatsapp}
            onChange={(e) =>
              setForm({...form, whatsapp: e.target.value.replace(/[^\d]/g, '')})
            }
            placeholder="201000000000"
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold tabular-nums text-left"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">رابط ماسنجر</span>
          <input
            type="url"
            dir="ltr"
            value={form.messenger_url}
            onChange={(e) => setForm({...form, messenger_url: e.target.value})}
            placeholder="https://m.me/yourpage"
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm text-left"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">رابط جروب / قناة واتساب</span>
          <input
            type="url"
            dir="ltr"
            value={form.whatsapp_group_url || ''}
            onChange={(e) => setForm({...form, whatsapp_group_url: e.target.value})}
            placeholder="https://chat.whatsapp.com/..."
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm text-left"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">رابط إنستجرام</span>
          <input
            type="url"
            dir="ltr"
            value={form.instagram_url}
            onChange={(e) => setForm({...form, instagram_url: e.target.value})}
            placeholder="https://instagram.com/yourpage"
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm text-left"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">رابط فيسبوك</span>
          <input
            type="url"
            dir="ltr"
            value={form.facebook_url}
            onChange={(e) => setForm({...form, facebook_url: e.target.value})}
            placeholder="https://facebook.com/yourpage"
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm text-left"
          />
        </label>
      </div>

      {/* Marketing Caption Template & Meta Pixel */}
      <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-4">
        <h3 className="text-base font-bold text-[#141413]">أدوات التسويق والبوستات</h3>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">
            قالب كابشن البوست (المتغيرات: {'{name}'} {'{code}'} {'{price}'} {'{discount_line}'} {'{colors_line}'} {'{sizes_line}'} {'{link}'})
          </span>
          <textarea
            rows={5}
            value={form.caption_template || ''}
            onChange={(e) => setForm({...form, caption_template: e.target.value})}
            className="w-full p-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs sm:text-sm leading-relaxed"
          />
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">
            سطر الدعوة الختامي لبوستات فيسبوك (CTA)
          </span>
          <input
            type="text"
            value={form.features.fb_closing_line ?? 'كل موديلات النهاردة على الموقع 👇'}
            onChange={(e) =>
              setForm({
                ...form,
                features: {
                  ...form.features,
                  fb_closing_line: e.target.value,
                },
              })
            }
            placeholder="كل موديلات النهاردة على الموقع 👇"
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-semibold"
          />
          <span className="block text-[11px] text-[#5B5B5B]">
            يُضاف تلقائيًا في نهاية كابشن فيسبوك عند النسخ من بطاقة المنتج.
          </span>
        </label>

        <label className="block space-y-1">
          <span className="text-xs font-bold text-[#5B5B5B]">
            Meta Pixel ID (اختياري — اتركيه فارغاً لعدم التحميل)
          </span>
          <input
            type="text"
            dir="ltr"
            value={form.pixel_id || ''}
            onChange={(e) =>
              setForm({...form, pixel_id: e.target.value.replace(/[^\d]/g, '')})
            }
            placeholder="123456789012345"
            className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold tabular-nums text-left"
          />
        </label>
      </div>

      {/* Trust Strip Items */}
      <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div>
            <h3 className="text-base font-bold text-[#141413]">شريط الثقة أسفل الكارت الذهبي</h3>
            <p className="text-xs text-[#5B5B5B]">يختفي تلقائياً إذا كانت البنود فارغة</p>
          </div>
          {(form.trust_items || []).length < 4 && (
            <button
              type="button"
              onClick={addTrustItem}
              className="min-h-[38px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/40 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة بند</span>
            </button>
          )}
        </div>

        <div className="space-y-2">
          {(form.trust_items || []).map((item, idx) => (
            <div key={item.id} className="flex items-center gap-2">
              <select
                value={item.icon}
                onChange={(e) => {
                  const next = [...form.trust_items];
                  next[idx] = {...item, icon: e.target.value as TrustIconType};
                  setForm({...form, trust_items: next});
                }}
                className="min-h-[40px] px-2.5 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-bold"
              >
                {TRUST_ICON_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
              <input
                type="text"
                value={item.text}
                onChange={(e) => {
                  const next = [...form.trust_items];
                  next[idx] = {...item, text: e.target.value};
                  setForm({...form, trust_items: next});
                }}
                placeholder="مثال: صور حقيقية على الطبيعة"
                className="flex-1 min-h-[40px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-semibold"
              />
              <button
                type="button"
                onClick={() =>
                  setForm({
                    ...form,
                    trust_items: form.trust_items.filter((t) => t.id !== item.id),
                  })
                }
                aria-label="حذف"
                className="min-w-[40px] min-h-[40px] rounded-xl bg-[#B3261E]/10 text-[#B3261E] flex items-center justify-center cursor-pointer"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Optional Feature Toggles */}
      <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-4">
        <h3 className="text-base font-bold text-[#141413]">تفعيل / تعطيل المزايا التسويقية</h3>

        <div className="space-y-2 pb-3 border-b border-[#E8A91A]/15">
          <label className="flex items-center justify-between gap-3 cursor-pointer">
            <span className="text-sm font-bold text-[#141413]">شريط الإعلانات المتحرك أعلى الموقع</span>
            <input
              type="checkbox"
              checked={form.features.announcement_bar.enabled}
              onChange={(e) =>
                setForm({
                  ...form,
                  features: {
                    ...form.features,
                    announcement_bar: {
                      ...form.features.announcement_bar,
                      enabled: e.target.checked,
                    },
                  },
                })
              }
              className="w-5 h-5 accent-[#0F4C3A]"
            />
          </label>
          {form.features.announcement_bar.enabled && (
            <input
              type="text"
              value={form.features.announcement_bar.text}
              onChange={(e) =>
                setForm({
                  ...form,
                  features: {
                    ...form.features,
                    announcement_bar: {
                      ...form.features.announcement_bar,
                      text: e.target.value,
                    },
                  },
                })
              }
              placeholder="نص شريط الإعلان..."
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-semibold"
            />
          )}
        </div>

        <label className="flex items-center justify-between gap-3 pb-3 border-b border-[#E8A91A]/15 cursor-pointer">
          <span className="text-sm font-bold text-[#141413]">زر الشات العائم (واتساب / ماسنجر)</span>
          <input
            type="checkbox"
            checked={Boolean(form.features.floating_chat?.enabled)}
            onChange={(e) =>
              setForm({
                ...form,
                features: {
                  ...form.features,
                  floating_chat: {enabled: e.target.checked},
                },
              })
            }
            className="w-5 h-5 accent-[#0F4C3A]"
          />
        </label>

        <label className="flex items-center justify-between gap-3 pb-3 border-b border-[#E8A91A]/15 cursor-pointer">
          <span className="text-sm font-bold text-[#141413]">شريط الثقة تحت الكارت الرئيسي</span>
          <input
            type="checkbox"
            checked={Boolean(form.features.trust_strip?.enabled)}
            onChange={(e) =>
              setForm({
                ...form,
                features: {
                  ...form.features,
                  trust_strip: {enabled: e.target.checked},
                },
              })
            }
            className="w-5 h-5 accent-[#0F4C3A]"
          />
        </label>

        <label className="flex items-center justify-between gap-3 pb-3 border-b border-[#E8A91A]/15 cursor-pointer">
          <span className="text-sm font-bold text-[#141413]">كارت «تابعينا» فوق الفوتر</span>
          <input
            type="checkbox"
            checked={Boolean(form.features.follow_us?.enabled)}
            onChange={(e) =>
              setForm({
                ...form,
                features: {
                  ...form.features,
                  follow_us: {enabled: e.target.checked},
                },
              })
            }
            className="w-5 h-5 accent-[#0F4C3A]"
          />
        </label>

        <div className="space-y-2 pb-3 border-b border-[#E8A91A]/15">
          <label className="flex items-center justify-between gap-3 cursor-pointer">
            <span className="text-sm font-bold text-[#141413]">عداد تنازلي لقسم العروض</span>
            <input
              type="checkbox"
              checked={form.features.offers_countdown.enabled}
              onChange={(e) =>
                setForm({
                  ...form,
                  features: {
                    ...form.features,
                    offers_countdown: {
                      ...form.features.offers_countdown,
                      enabled: e.target.checked,
                    },
                  },
                })
              }
              className="w-5 h-5 accent-[#0F4C3A]"
            />
          </label>
          {form.features.offers_countdown.enabled && (
            <input
              type="datetime-local"
              value={form.features.offers_countdown.end_date}
              onChange={(e) =>
                setForm({
                  ...form,
                  features: {
                    ...form.features,
                    offers_countdown: {
                      ...form.features.offers_countdown,
                      end_date: e.target.value,
                    },
                  },
                })
              }
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-bold"
            />
          )}
        </div>

        <label className="flex items-center justify-between gap-3 pb-3 border-b border-[#E8A91A]/15 cursor-pointer">
          <span className="text-sm font-bold text-[#141413]">قسم «شوفتيها قبل كده»</span>
          <input
            type="checkbox"
            checked={form.features.recently_viewed.enabled}
            onChange={(e) =>
              setForm({
                ...form,
                features: {
                  ...form.features,
                  recently_viewed: {enabled: e.target.checked},
                },
              })
            }
            className="w-5 h-5 accent-[#0F4C3A]"
          />
        </label>

        <div className="space-y-3">
          <label className="flex items-center justify-between gap-3 cursor-pointer">
            <span className="text-sm font-bold text-[#141413]">شريط «آراء عميلاتنا» (صور شات)</span>
            <input
              type="checkbox"
              checked={form.features.customer_reviews.enabled}
              onChange={(e) =>
                setForm({
                  ...form,
                  features: {
                    ...form.features,
                    customer_reviews: {
                      ...form.features.customer_reviews,
                      enabled: e.target.checked,
                    },
                  },
                })
              }
              className="w-5 h-5 accent-[#0F4C3A]"
            />
          </label>

          {form.features.customer_reviews.enabled && (
            <div className="flex flex-wrap gap-2.5">
              {form.features.customer_reviews.items.map((item) => (
                <div
                  key={item.id}
                  className="relative w-24 h-28 rounded-2xl overflow-hidden border border-[#E8A91A]/35 bg-[#FBF6EA]"
                >
                  <img
                    src={item.image_url}
                    alt={item.caption || ''}
                    className="w-full h-full object-cover"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setForm({
                        ...form,
                        features: {
                          ...form.features,
                          customer_reviews: {
                            ...form.features.customer_reviews,
                            items: form.features.customer_reviews.items.filter(
                              (r) => r.id !== item.id
                            ),
                          },
                        },
                      })
                    }
                    aria-label="حذف"
                    className="absolute top-1 left-1 w-6 h-6 rounded-full bg-[#B3261E] text-white flex items-center justify-center cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              <label className="w-24 h-28 rounded-2xl border-2 border-dashed border-[#0F4C3A]/40 bg-[#FBF6EA] flex flex-col items-center justify-center text-xs font-bold text-[#0F4C3A] cursor-pointer">
                <Plus className="w-5 h-5 mb-1" />
                <span>إضافة صورة</span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  onChange={async (e) => {
                    const files = Array.from(e.target.files || []);
                    if (files.length === 0) return;
                    const added = [];
                    for (const f of files) {
                      const url = await uploadImage(f);
                      added.push({
                        id: `rev-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`,
                        image_url: url,
                        caption: 'رأي عميلة',
                      });
                    }
                    setForm({
                      ...form,
                      features: {
                        ...form.features,
                        customer_reviews: {
                          ...form.features.customer_reviews,
                          items: [...form.features.customer_reviews.items, ...added],
                        },
                      },
                    });
                  }}
                  className="hidden"
                />
              </label>
            </div>
          )}
        </div>
      </div>

      <button
        type="submit"
        disabled={saving}
        className="w-full min-h-[50px] rounded-[20px] bg-[#0F4C3A] text-white font-bold text-base flex items-center justify-center gap-2 shadow-md hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
      >
        <Save className="w-5 h-5 text-[#F6CF5A]" />
        <span>{saving ? 'جاري الحفظ...' : 'حفظ جميع الإعدادات'}</span>
      </button>
      </form>

      {/* Backups & Phone Archive Section (D1 + D2) */}
      <div className="space-y-4 pt-2 border-t border-[#E8A91A]/25">
        <div className="px-1">
          <h2 className="text-base sm:text-lg font-bold text-[#141413]">النسخ الاحتياطي والأرشيف</h2>
          <p className="text-xs text-[#5B5B5B]">
            احفظي نسخ سريعة على الموقع أو حمّلي أرشيف كامل بالصور على موبايلك لتوفير المساحة.
          </p>
        </div>
        <AdminBackupSection />
        <AdminArchiveSection />
      </div>

      {/* Danger Zone Reset (E) */}
      <AdminDangerResetSection openChangePinSignal={openChangePinSignal} />
        </>
      )}
    </div>
  );
};
