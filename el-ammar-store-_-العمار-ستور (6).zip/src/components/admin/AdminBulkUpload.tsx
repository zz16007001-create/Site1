import React, {useEffect, useMemo, useState} from 'react';
import {
  AlertCircle,
  Camera,
  Check,
  ChevronDown,
  ChevronUp,
  Copy,
  Crosshair,
  Edit3,
  Layers,
  Plus,
  RefreshCw,
  Scissors,
  SlidersHorizontal,
  Trash2,
  Upload,
} from 'lucide-react';
import {useStore} from '../../context/StoreContext';
import type {BulkDraftItem, Category, ProductImage} from '../../types/store';
import {
  categoryUsesSizes,
  describeError,
  formatBytesCompact,
  uploadWithConcurrency,
} from '../../utils/catalogHelpers';
import {ColorPalette} from './ColorPalette';
import {type FocusQueueItem, FocusPointModal} from './FocusPointModal';

const DEFAULT_SHOE_SIZES = ['36', '37', '38', '39', '40', '41', '42'];
const BULK_DRAFTS_STORAGE_KEY = 'elamar_bulk_drafts_v1';
const BULK_DEFAULTS_STORAGE_KEY = 'elamar_bulk_shared_defaults_v1';
const BULK_NAME_SEQ_KEY = 'elamar_bulk_name_seq';

function allocateBulkNameSeq(count: number): number {
  let current = 0;
  try {
    const raw = localStorage.getItem(BULK_NAME_SEQ_KEY);
    const parsed = raw ? Number(raw) : 0;
    if (Number.isFinite(parsed) && parsed > 0) {
      current = Math.floor(parsed);
    }
    localStorage.setItem(BULK_NAME_SEQ_KEY, String(current + Math.max(1, count)));
  } catch {
    // Ignore storage errors
  }
  return current + 1;
}

interface SharedDefaults {
  categoryId: string;
  subcategoryId: string;
  price: string;
  sizes: string[];
  colorName: string;
}

interface AdminBulkUploadProps {
  topCategories: Category[];
  drafts: BulkDraftItem[];
  setDrafts: React.Dispatch<React.SetStateAction<BulkDraftItem[]>>;
  expanded: boolean;
  setExpanded: React.Dispatch<React.SetStateAction<boolean>>;
  onOpenFullEdit: (draft: BulkDraftItem) => void;
}

export function loadSavedBulkDrafts(): BulkDraftItem[] {
  try {
    const raw = localStorage.getItem(BULK_DRAFTS_STORAGE_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export function saveBulkDraftsToStorage(drafts: BulkDraftItem[]): boolean {
  try {
    localStorage.setItem(BULK_DRAFTS_STORAGE_KEY, JSON.stringify(drafts));
    return true;
  } catch {
    return false;
  }
}

function loadSharedDefaults(topCategories: Category[]): SharedDefaults {
  const fallbackCatId = topCategories[0]?.id || '';
  try {
    const raw = localStorage.getItem(BULK_DEFAULTS_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw) as Partial<SharedDefaults>;
      const rawColor = (parsed.colorName || '').trim();
      const rawPrice = String(parsed.price || '').trim();
      return {
        categoryId: parsed.categoryId || fallbackCatId,
        subcategoryId: parsed.subcategoryId || '',
        price: rawPrice === '450' ? '' : rawPrice,
        sizes: Array.isArray(parsed.sizes) && parsed.sizes.length > 0 ? parsed.sizes : ['37', '38', '39', '40'],
        colorName: rawColor === 'الأساسي' || rawColor === 'الافتراضي' ? '' : rawColor,
      };
    }
  } catch {
    // Ignore
  }
  return {
    categoryId: fallbackCatId,
    subcategoryId: '',
    price: '',
    sizes: ['37', '38', '39', '40'],
    colorName: '',
  };
}

export const AdminBulkUpload: React.FC<AdminBulkUploadProps> = ({
  topCategories,
  drafts,
  setDrafts,
  expanded,
  setExpanded,
  onOpenFullEdit,
}) => {
  const {
    categories,
    uploadProductImagePair,
    saveProduct,
    refreshCatalog,
    cleanupDraftImageUrls,
    showToast,
  } = useStore();

  const [uploadMode, setUploadMode] = useState<'per_photo' | 'single_product'>('per_photo');
  const [shared, setShared] = useState<SharedDefaults>(() => loadSharedDefaults(topCategories));

  const [uploading, setUploading] = useState(false);
  const [isDragOver, setIsDragOver] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{done: number; total: number} | null>(null);
  const [batchCompressionStats, setBatchCompressionStats] = useState<{
    count: number;
    originalBytes: number;
    compressedBytes: number;
  } | null>(null);
  const [appendingDraftId, setAppendingDraftId] = useState<string | null>(null);

  const [publishingAll, setPublishingAll] = useState(false);
  const [publishProgress, setPublishProgress] = useState<{done: number; total: number} | null>(null);
  const [publishingSingleId, setPublishingSingleId] = useState<string | null>(null);

  const [confirmClearAll, setConfirmClearAll] = useState(false);
  const [clearingAll, setClearingAll] = useState(false);

  const [focusModal, setFocusModal] = useState<{
    mode: 'batch_post' | 'single_draft';
    draftId?: string;
    items: FocusQueueItem[];
  } | null>(null);

  // Sync fallback categoryId when categories load asynchronously
  useEffect(() => {
    if (!shared.categoryId && topCategories.length > 0) {
      setShared((prev) => ({...prev, categoryId: topCategories[0].id}));
    }
  }, [shared.categoryId, topCategories]);

  // Remember shared defaults in localStorage
  useEffect(() => {
    try {
      localStorage.setItem(BULK_DEFAULTS_STORAGE_KEY, JSON.stringify(shared));
    } catch {
      // Ignore
    }
  }, [shared]);

  const sharedSubcategories = useMemo(
    () =>
      categories
        .filter((c) => c.parent_id === shared.categoryId)
        .sort((a, b) => a.sort - b.sort),
    [categories, shared.categoryId]
  );

  const sharedCategoryName = useMemo(
    () => categories.find((c) => c.id === shared.categoryId)?.name || '',
    [categories, shared.categoryId]
  );
  const sharedUsesSizes = categoryUsesSizes(sharedCategoryName);

  const getBaseLabelForIds = (catId: string, subId: string): string => {
    const sub = subId ? categories.find((c) => c.id === subId) : undefined;
    const cat = catId ? categories.find((c) => c.id === catId) : undefined;
    return sub?.name || cat?.name || 'موديل';
  };

  const processBulkFiles = async (picked: File[]) => {
    const imageFiles = picked.filter(
      (f) => !f.type || f.type.startsWith('image/')
    );
    if (imageFiles.length === 0) {
      showToast('من فضلك اختاري ملفات صور فقط', 'warning');
      return;
    }

    const files = imageFiles.slice(0, 30);
    if (imageFiles.length > 30) {
      showToast('تم تحديد أول 30 صورة كحد أقصى للدفعة الواحدة', 'warning');
    }

    // Inherit values from last draft if present, otherwise shared settings
    const prevDraft = drafts[drafts.length - 1];
    const inheritCatId = prevDraft?.categoryId || shared.categoryId || topCategories[0]?.id || '';
    const inheritSubId = prevDraft ? prevDraft.subcategoryId : shared.subcategoryId;
    const inheritPrice = prevDraft?.price || shared.price || '';
    const inheritOldPrice = prevDraft?.oldPrice || '';
    const inheritSizes =
      prevDraft && prevDraft.sizes.length > 0 ? [...prevDraft.sizes] : [...shared.sizes];
    const rawPrevColor = (prevDraft?.colorName || '').trim();
    const inheritColor =
      rawPrevColor && rawPrevColor !== 'الأساسي' && rawPrevColor !== 'الافتراضي'
        ? rawPrevColor
        : '';
    const inheritColorHex = inheritColor ? prevDraft?.colorHex || undefined : undefined;
    const labelBase = getBaseLabelForIds(inheritCatId, inheritSubId);

    setExpanded(true);
    setUploading(true);
    setUploadProgress({done: 0, total: files.length});
    setBatchCompressionStats(null);

    let origSum = 0;
    let compSum = 0;

    try {
      const {succeeded, failed} = await uploadWithConcurrency(
        files,
        (file) =>
          uploadProductImagePair(file, (stats) => {
            origSum += stats.originalBytes;
            compSum += stats.compressedBytes;
          }),
        2,
        (done, total) => setUploadProgress({done, total})
      );

      if (succeeded.length > 0) {
        setBatchCompressionStats({
          count: succeeded.length,
          originalBytes: origSum,
          compressedBytes: compSum,
        });

        const draftCount = uploadMode === 'single_product' ? 1 : succeeded.length;
        const startSeq = allocateBulkNameSeq(draftCount);
        let createdDrafts: BulkDraftItem[] = [];

        if (uploadMode === 'single_product') {
          createdDrafts = [
            {
              tempId: `draft-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
              name: `${labelBase} ${startSeq}`,
              price: inheritPrice,
              oldPrice: inheritOldPrice,
              categoryId: inheritCatId,
              subcategoryId: inheritSubId,
              colorName: inheritColor,
              colorHex: inheritColorHex,
              sizes: inheritSizes,
              images: succeeded,
              error: null,
            },
          ];
        } else {
          createdDrafts = succeeded.map((img, i) => ({
            tempId: `draft-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
            name: `${labelBase} ${startSeq + i}`,
            price: inheritPrice,
            oldPrice: inheritOldPrice,
            categoryId: inheritCatId,
            subcategoryId: inheritSubId,
            colorName: inheritColor,
            colorHex: inheritColorHex,
            sizes: [...inheritSizes],
            images: [img],
            error: null,
          }));
        }

        setDrafts((prev) => [...prev, ...createdDrafts]);
      }

      if (failed.length > 0) {
        const failedNames = failed.map((f) => f.fileName).join('، ');
        const firstReason = failed[0].reason;
        showToast(
          `تم رفع ${succeeded.length} صورة وفشلت ${failed.length}: [${failedNames}] — ${firstReason}`,
          'warning'
        );
      } else if (succeeded.length > 0) {
        showToast(`تم تجهيز ${succeeded.length} صورة في المسودات بنجاح`, 'success');
      }
    } catch (err) {
      console.error('upload failed', err);
      showToast('تعذر رفع الصور: ' + describeError(err), 'warning');
    } finally {
      setUploading(false);
      setUploadProgress(null);
    }
  };

  const handleBulkFilesSelected = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = Array.from(e.target.files || []);
    e.target.value = '';
    if (picked.length === 0) return;
    await processBulkFiles(picked);
  };

  const handleDropFiles = async (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragOver(false);
    if (uploading) return;
    const dropped = Array.from(e.dataTransfer?.files || []);
    if (dropped.length === 0) return;
    await processBulkFiles(dropped);
  };

  const handleAppendPhotosToDraft = async (
    draftId: string,
    e: React.ChangeEvent<HTMLInputElement>
  ) => {
    const files = Array.from(e.target.files || []).slice(0, 12);
    e.target.value = '';
    if (files.length === 0) return;

    setAppendingDraftId(draftId);
    let origSum = 0;
    let compSum = 0;
    try {
      const {succeeded, failed} = await uploadWithConcurrency(
        files,
        (file) =>
          uploadProductImagePair(file, (stats) => {
            origSum += stats.originalBytes;
            compSum += stats.compressedBytes;
          }),
        2,
        () => {}
      );
      if (succeeded.length > 0) {
        setDrafts((prev) =>
          prev.map((d) =>
            d.tempId === draftId ? {...d, images: [...d.images, ...succeeded], error: null} : d
          )
        );
      }
      if (failed.length > 0) {
        const failedNames = failed.map((f) => f.fileName).join('، ');
        showToast(
          `تم رفع ${succeeded.length} صورة وفشلت ${failed.length}: [${failedNames}] — ${failed[0].reason}`,
          'warning'
        );
      } else if (succeeded.length > 0) {
        const savedPct =
          origSum > 0 ? Math.max(0, Math.round(((origSum - compSum) / origSum) * 100)) : 0;
        showToast(
          savedPct > 0
            ? `تم ضغط وإضافة ${succeeded.length} صورة للمسودة (توفير ${savedPct}%)`
            : `تم ضغط وإضافة ${succeeded.length} صورة للمسودة`,
          'success'
        );
      }
    } catch (err) {
      console.error('upload failed', err);
      showToast('تعذر رفع الصور: ' + describeError(err), 'warning');
    } finally {
      setAppendingDraftId(null);
    }
  };

  const applySharedToAll = () => {
    if (drafts.length === 0) return;
    const baseName = getBaseLabelForIds(shared.categoryId, shared.subcategoryId);
    setDrafts((prev) =>
      prev.map((d, idx) => ({
        ...d,
        categoryId: shared.categoryId,
        subcategoryId: shared.subcategoryId,
        price: shared.price || d.price,
        sizes: [...shared.sizes],
        name: /^\S+(\s+\S+)?\s+\d+$/.test(d.name) ? `${baseName} ${idx + 1}` : d.name,
        error: null,
      }))
    );
    showToast('تم تطبيق الإعدادات المشتركة على كل المسودات', 'success');
  };

  const toggleSharedSize = (sz: string) => {
    setShared((prev) => {
      const exists = prev.sizes.includes(sz);
      return {
        ...prev,
        sizes: exists ? prev.sizes.filter((s) => s !== sz) : [...prev.sizes, sz],
      };
    });
  };

  const toggleDraftSize = (draftId: string, sz: string) => {
    setDrafts((prev) =>
      prev.map((d) => {
        if (d.tempId !== draftId) return d;
        const exists = d.sizes.includes(sz);
        return {
          ...d,
          sizes: exists ? d.sizes.filter((s) => s !== sz) : [...d.sizes, sz],
        };
      })
    );
  };

  const duplicateDraftCard = (draft: BulkDraftItem) => {
    const labelBase = getBaseLabelForIds(draft.categoryId, draft.subcategoryId);
    const nextSeq = allocateBulkNameSeq(1);
    const copy: BulkDraftItem = {
      ...draft,
      tempId: `draft-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: `${labelBase} ${nextSeq}`,
      images: draft.images.map((img) => ({...img})),
      sizes: [...draft.sizes],
      error: null,
    };
    setDrafts((prev) => {
      const idx = prev.findIndex((x) => x.tempId === draft.tempId);
      if (idx === -1) return [...prev, copy];
      const next = [...prev];
      next.splice(idx + 1, 0, copy);
      return next;
    });
  };

  const splitImageToNewDraft = (draftId: string, imgIndex: number) => {
    const target = drafts.find((d) => d.tempId === draftId);
    if (!target || target.images.length <= 1) return;
    const movedImg = target.images[imgIndex];
    if (!movedImg) return;
    const labelBase = getBaseLabelForIds(target.categoryId, target.subcategoryId);
    const nextSeq = allocateBulkNameSeq(1);
    const newDraft: BulkDraftItem = {
      ...target,
      tempId: `draft-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
      name: `${labelBase} ${nextSeq}`,
      code: '',
      images: [{...movedImg}],
      sizes: [...target.sizes],
      error: null,
    };
    setDrafts((prev) => {
      const idx = prev.findIndex((x) => x.tempId === draftId);
      if (idx === -1) return prev;
      const next = [...prev];
      next[idx] = {
        ...next[idx],
        images: next[idx].images.filter((_, i) => i !== imgIndex),
      };
      next.splice(idx + 1, 0, newDraft);
      return next;
    });
    showToast('تم فصل الصورة لموديل جديد', 'success');
  };

  const splitAllImagesToModels = (draft: BulkDraftItem) => {
    if (draft.images.length <= 1) return;
    const labelBase = getBaseLabelForIds(draft.categoryId, draft.subcategoryId);
    const extraImages = draft.images.slice(1);
    const startSeq = allocateBulkNameSeq(extraImages.length);
    const created: BulkDraftItem[] = extraImages.map((img, i) => ({
      ...draft,
      tempId: `draft-${Date.now()}-${i}-${Math.random().toString(36).slice(2, 6)}`,
      name: `${labelBase} ${startSeq + i}`,
      code: '',
      images: [{...img}],
      sizes: [...draft.sizes],
      error: null,
    }));
    setDrafts((prev) => {
      const idx = prev.findIndex((x) => x.tempId === draft.tempId);
      if (idx === -1) return prev;
      const next = [...prev];
      next[idx] = {...next[idx], images: [draft.images[0]]};
      next.splice(idx + 1, 0, ...created);
      return next;
    });
    showToast(`تم فصل ${extraImages.length + 1} موديلات منفصلة`, 'success');
  };

  const removeSingleDraft = async (draft: BulkDraftItem) => {
    // Only delete draft images not shared with another remaining draft card
    const remainingUrls = new Set<string>();
    for (const d of drafts) {
      if (d.tempId === draft.tempId) continue;
      for (const img of d.images) {
        if (img.full) remainingUrls.add(img.full);
        if (img.thumb) remainingUrls.add(img.thumb);
      }
    }
    const candidateUrls: string[] = [];
    for (const img of draft.images) {
      if (img.full && !remainingUrls.has(img.full)) candidateUrls.push(img.full);
      if (img.thumb && !remainingUrls.has(img.thumb)) candidateUrls.push(img.thumb);
    }

    setDrafts((prev) => prev.filter((x) => x.tempId !== draft.tempId));
    if (candidateUrls.length > 0) {
      await cleanupDraftImageUrls(candidateUrls).catch(() => {});
    }
  };

  const handleConfirmClearAll = async () => {
    setClearingAll(true);
    try {
      const allUrls: string[] = [];
      for (const d of drafts) {
        for (const img of d.images) {
          if (img.full) allUrls.push(img.full);
          if (img.thumb) allUrls.push(img.thumb);
        }
      }
      await cleanupDraftImageUrls(allUrls);
      setDrafts([]);
      setConfirmClearAll(false);
      showToast('تم مسح جميع المسودات وتنظيف صورها غير المستخدمة', 'success');
    } catch {
      showToast('تعذر تنظيف بعض ملفات المسودات', 'warning');
    } finally {
      setClearingAll(false);
    }
  };

  const publishOneDraft = async (
    draft: BulkDraftItem,
    options?: {skipRefresh?: boolean}
  ): Promise<void> => {
    const cat = categories.find((c) => c.id === draft.categoryId);
    const usesSizes = categoryUsesSizes(cat?.name);
    const rawPrice = String(draft.price || '').trim();
    const numPrice = Number(rawPrice);

    if (!draft.name.trim()) {
      throw new Error('اكتبي اسم المنتج');
    }
    if (!rawPrice || !Number.isFinite(numPrice) || numPrice <= 0) {
      throw new Error('اكتبي سعر المنتج');
    }

    const numOldPrice =
      draft.oldPrice && Number(draft.oldPrice) > numPrice ? Number(draft.oldPrice) : null;

    const activeSizes = usesSizes
      ? draft.sizes.length > 0
        ? draft.sizes
        : ['37', '38', '39', '40']
      : [];

    await saveProduct({
      name: draft.name.trim(),
      code: draft.code?.trim() || null,
      category_id: draft.categoryId || null,
      subcategory_id: draft.subcategoryId || null,
      description: '',
      price: numPrice,
      old_price: numOldPrice,
      visible: true,
      featured: false,
      is_permanent: false,
      skipRefresh: options?.skipRefresh,
      colors: [
        {
          name:
            draft.colorName?.trim() &&
            draft.colorName.trim() !== 'الأساسي' &&
            draft.colorName.trim() !== 'الافتراضي'
              ? draft.colorName.trim()
              : null,
          hex: draft.colorHex || null,
          images: draft.images,
          sort: 1,
          sizes: usesSizes
            ? activeSizes.map((s) => ({size: s, status: 'available'}))
            : [{size: null, status: 'available'}],
        },
      ],
    });
  };

  const handlePublishSingle = async (draft: BulkDraftItem) => {
    setPublishingSingleId(draft.tempId);
    try {
      await publishOneDraft(draft);
      setDrafts((prev) => prev.filter((x) => x.tempId !== draft.tempId));
      showToast(`تم نشر "${draft.name}"`, 'success');
    } catch (err) {
      const msg = describeError(err);
      setDrafts((prev) =>
        prev.map((x) => (x.tempId === draft.tempId ? {...x, error: msg} : x))
      );
    } finally {
      setPublishingSingleId(null);
    }
  };

  const handlePublishAll = async () => {
    if (drafts.length === 0 || publishingAll) return;

    const invalidPriceIds = new Set(
      drafts
        .filter((d) => {
          const raw = String(d.price || '').trim();
          const n = Number(raw);
          return !raw || !Number.isFinite(n) || n <= 0;
        })
        .map((d) => d.tempId)
    );

    if (invalidPriceIds.size > 0) {
      setDrafts((prev) =>
        prev.map((d) =>
          invalidPriceIds.has(d.tempId) ? {...d, error: 'اكتبي سعر المنتج'} : d
        )
      );
      showToast(`فيه ${invalidPriceIds.size} مسودة من غير سعر`, 'warning');
      return;
    }

    setPublishingAll(true);
    const snapshot = [...drafts];
    setPublishProgress({done: 0, total: snapshot.length});

    let publishedCount = 0;
    let failedCount = 0;

    for (let i = 0; i < snapshot.length; i++) {
      const draft = snapshot[i];
      try {
        await publishOneDraft(draft, {skipRefresh: true});
        publishedCount += 1;
        setDrafts((prev) => prev.filter((x) => x.tempId !== draft.tempId));
      } catch (err) {
        failedCount += 1;
        const msg = describeError(err);
        setDrafts((prev) =>
          prev.map((x) => (x.tempId === draft.tempId ? {...x, error: msg} : x))
        );
      }
      setPublishProgress({done: i + 1, total: snapshot.length});
    }

    if (publishedCount > 0) {
      await refreshCatalog().catch(() => {});
    }

    setPublishingAll(false);
    setPublishProgress(null);
    if (failedCount === 0) {
      showToast(`تم نشر جميع المنتجات (${publishedCount}) بنجاح 🎉`, 'success');
    } else {
      showToast(`تم نشر ${publishedCount} منتج، وبقي ${failedCount} بحاجة للمراجعة`, 'warning');
    }
  };

  const handleSaveFocusModal = (updated: FocusQueueItem[]) => {
    if (!focusModal) return;
    if (focusModal.mode === 'single_draft' && focusModal.draftId) {
      const map = new Map(updated.map((u) => [Number(u.id), u.image]));
      setDrafts((prev) =>
        prev.map((d) =>
          d.tempId === focusModal.draftId
            ? {
                ...d,
                images: d.images.map((img, i) => (map.has(i) ? map.get(i)! : img)),
              }
            : d
        )
      );
    } else {
      const map = new Map(updated.map((u) => [u.id, u.image]));
      setDrafts((prev) =>
        prev.map((d) => ({
          ...d,
          images: d.images.map((img, i) => {
            const k = `${d.tempId}__${i}`;
            return map.has(k) ? map.get(k)! : img;
          }),
        }))
      );
    }
    setFocusModal(null);
  };

  return (
    <div className="space-y-3">
      {/* Persistent Unfinished Drafts Banner */}
      {drafts.length > 0 && (
        <div className="rounded-2xl bg-[#E8A91A]/20 border border-[#E8A91A] p-3.5 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2 text-[#141413]">
            <Layers className="w-5 h-5 text-[#0F4C3A] shrink-0" />
            <span className="text-xs sm:text-sm font-bold">
              عندك {drafts.length} مسودة لسه ماتنشرتش
            </span>
          </div>
          <button
            type="button"
            onClick={() => setExpanded((e) => !e)}
            className="min-h-[38px] px-3.5 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
          >
            <span>{expanded ? 'إخفاء المسودات' : 'فتح المسودات'}</span>
            {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
          </button>
        </div>
      )}

      {/* Upload Workspace Card */}
      {expanded && (
        <div className="rounded-[26px] bg-white border-2 border-[#E8A91A]/60 p-4 sm:p-5 shadow-sm space-y-4">
          {/* Header & Mode Toggle + 60-Photo Picker */}
          <div className="flex flex-col gap-3 pb-3 border-b border-[#E8A91A]/20">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <div>
                <h3 className="text-base font-bold text-[#0F4C3A]">رفع منتجات متعددة بسرعة</h3>
                <p className="text-[11px] text-[#5B5B5B]">
                  اسحبي الصور أو اختاري حتى 30 صورة مرة واحدة، يتم ضغطها تلقائياً (WebP · 1000px / 360px · جودة 0.75) وحفظ المسودات.
                </p>
              </div>
              {drafts.length > 0 && (
                <button
                  type="button"
                  onClick={() => setConfirmClearAll(true)}
                  className="min-h-[38px] px-3 rounded-xl bg-[#B3261E]/10 text-[#B3261E] text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  <span>مسح الكل</span>
                </button>
              )}
            </div>

            {/* Mode Toggle + Drag/Drop Picker */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                e.stopPropagation();
                if (!uploading) setIsDragOver(true);
              }}
              onDragLeave={(e) => {
                e.preventDefault();
                e.stopPropagation();
                setIsDragOver(false);
              }}
              onDrop={handleDropFiles}
              className={`rounded-2xl border-2 border-dashed p-3 transition-colors space-y-2.5 ${
                isDragOver
                  ? 'border-[#0F4C3A] bg-[#0F4C3A]/10'
                  : 'border-[#E8A91A]/45 bg-[#FBF6EA]/50'
              }`}
            >
              <div className="flex flex-col sm:flex-row gap-2.5 items-stretch sm:items-center">
                <div className="grid grid-cols-2 rounded-2xl bg-white p-1 border border-[#E8A91A]/30 shrink-0">
                  <button
                    type="button"
                    onClick={() => setUploadMode('per_photo')}
                    className={`min-h-[40px] px-3 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      uploadMode === 'per_photo'
                        ? 'bg-[#0F4C3A] text-white shadow-xs'
                        : 'text-[#5B5B5B]'
                    }`}
                  >
                    كل صورة = منتج
                  </button>
                  <button
                    type="button"
                    onClick={() => setUploadMode('single_product')}
                    className={`min-h-[40px] px-3 rounded-xl text-xs font-bold transition-colors cursor-pointer ${
                      uploadMode === 'single_product'
                        ? 'bg-[#0F4C3A] text-white shadow-xs'
                        : 'text-[#5B5B5B]'
                    }`}
                  >
                    كل الصور = منتج واحد
                  </button>
                </div>

                <label
                  className={`flex-1 min-h-[46px] px-4 rounded-2xl bg-[#E8A91A] text-[#141413] text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#F6CF5A] cursor-pointer shadow-xs ${
                    uploading ? 'opacity-65 pointer-events-none' : ''
                  }`}
                >
                  <Camera className="w-4 h-4 text-[#0F4C3A]" />
                  <span>
                    {uploading && uploadProgress
                      ? `جاري ضغط WebP (1000px / 360px) ورفعها: ${uploadProgress.done} / ${uploadProgress.total}`
                      : isDragOver
                        ? 'اتركي الصور هنا لبدء الرفع'
                        : 'اختاري أو اسحبي الصور هنا (حتى 30 صورة)'}
                  </span>
                  <input
                    type="file"
                    accept="image/*"
                    multiple
                    disabled={uploading}
                    onChange={handleBulkFilesSelected}
                    className="hidden"
                  />
                </label>
              </div>
            </div>

            {uploading && uploadProgress && (
              <div className="w-full h-2.5 rounded-full bg-[#FBF6EA] overflow-hidden border border-[#E8A91A]/30">
                <div
                  className="h-full bg-[#0F4C3A] transition-all duration-200"
                  style={{
                    width: `${Math.min(
                      100,
                      Math.round((uploadProgress.done / Math.max(1, uploadProgress.total)) * 100)
                    )}%`,
                  }}
                />
              </div>
            )}

            {!uploading && batchCompressionStats && (
              <div className="rounded-xl bg-[#0F4C3A]/8 border border-[#0F4C3A]/20 px-3 py-2 text-[11px] font-bold text-[#0F4C3A] flex flex-wrap items-center justify-between gap-2">
                <span>
                  تم ضغط {batchCompressionStats.count} صورة عبر Canvas (WebP · 1000px / 360px · 0.75)
                </span>
                <span className="tabular-nums">
                  {formatBytesCompact(batchCompressionStats.originalBytes)} ←{' '}
                  {formatBytesCompact(batchCompressionStats.compressedBytes)}
                  {batchCompressionStats.originalBytes > 0
                    ? ` (-${Math.max(
                        0,
                        Math.round(
                          ((batchCompressionStats.originalBytes -
                            batchCompressionStats.compressedBytes) /
                            batchCompressionStats.originalBytes) *
                            100
                        )
                      )}%)`
                    : ''}
                </span>
              </div>
            )}
          </div>

          {/* Sticky Shared Defaults Bar ("الإعدادات المشتركة") */}
          {drafts.length > 0 && (
            <div className="sticky top-[68px] z-20 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/50 p-3.5 shadow-sm space-y-2.5">
              <div className="flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-[#E8A91A]" />
                  <span>الإعدادات المشتركة</span>
                </span>
                <button
                  type="button"
                  onClick={applySharedToAll}
                  className="min-h-[36px] px-3.5 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold hover:bg-[#0A3629] cursor-pointer"
                >
                  تطبيق على الكل
                </button>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                <select
                  value={shared.categoryId}
                  onChange={(e) =>
                    setShared((prev) => ({
                      ...prev,
                      categoryId: e.target.value,
                      subcategoryId: '',
                    }))
                  }
                  className="min-h-[40px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-bold"
                >
                  {topCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>

                <select
                  value={shared.subcategoryId}
                  onChange={(e) =>
                    setShared((prev) => ({...prev, subcategoryId: e.target.value}))
                  }
                  disabled={sharedSubcategories.length === 0}
                  className="min-h-[40px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-bold disabled:opacity-50"
                >
                  <option value="">
                    {sharedSubcategories.length === 0 ? 'بدون نوع فرعي' : 'النوع (اختياري)'}
                  </option>
                  {sharedSubcategories.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>

                <input
                  type="number"
                  inputMode="numeric"
                  value={shared.price}
                  onChange={(e) => setShared((prev) => ({...prev, price: e.target.value}))}
                  placeholder="السعر الافتراضي"
                  className="col-span-2 sm:col-span-1 min-h-[40px] px-3 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-bold tabular-nums"
                />
              </div>

              {sharedUsesSizes && (
                <div className="flex flex-wrap items-center gap-1.5">
                  <span className="text-[11px] font-bold text-[#5B5B5B]">المقاسات الافتراضية:</span>
                  {DEFAULT_SHOE_SIZES.map((sz) => {
                    const active = shared.sizes.includes(sz);
                    return (
                      <button
                        key={sz}
                        type="button"
                        onClick={() => toggleSharedSize(sz)}
                        className={`min-w-[36px] min-h-[34px] px-2 rounded-xl text-xs font-bold tabular-nums border cursor-pointer ${
                          active
                            ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                            : 'bg-white text-[#5B5B5B] border-[#E8A91A]/35'
                        }`}
                      >
                        {sz}
                      </button>
                    );
                  })}
                </div>
              )}
            </div>
          )}

          {/* Draft Cards */}
          {drafts.length > 0 && (
            <div className="space-y-3">
              {drafts.map((d) => {
                const draftCat = categories.find((c) => c.id === d.categoryId);
                const draftSubs = categories
                  .filter((c) => c.parent_id === d.categoryId)
                  .sort((a, b) => a.sort - b.sort);
                const draftUsesSizes = categoryUsesSizes(draftCat?.name);
                const mainImg = d.images[0];

                return (
                  <div
                    key={d.tempId}
                    className={`rounded-2xl border p-3 space-y-2.5 ${
                      d.error
                        ? 'bg-[#FFF5F5] border-[#B3261E]/50'
                        : 'bg-[#FBF6EA]/45 border-[#E8A91A]/35'
                    }`}
                  >
                    <div className="flex items-start gap-3">
                      {/* Thumbnail -> tap to adjust focus point */}
                      <button
                        type="button"
                        onClick={() =>
                          setFocusModal({
                            mode: 'single_draft',
                            draftId: d.tempId,
                            items: d.images.map((img, i) => ({id: String(i), image: img})),
                          })
                        }
                        aria-label="تعديل نقطة التركيز على الصورة"
                        className="relative w-20 aspect-[3/4] rounded-xl overflow-hidden bg-white border border-[#E8A91A]/40 shrink-0 cursor-pointer"
                      >
                        {mainImg && (
                          <img
                            src={mainImg.thumb}
                            alt=""
                            style={{objectPosition: `${mainImg.focus_x}% ${mainImg.focus_y}%`}}
                            className="w-full h-full object-cover"
                          />
                        )}
                        <span className="absolute bottom-1 right-1 w-6 h-6 rounded-full bg-white/90 text-[#0F4C3A] flex items-center justify-center shadow">
                          <Crosshair className="w-3.5 h-3.5" />
                        </span>
                        {d.images.length > 1 && (
                          <span className="absolute top-1 left-1 px-1.5 py-0.5 rounded-full bg-[#0F4C3A] text-white text-[10px] font-bold tabular-nums">
                            {d.images.length}
                          </span>
                        )}
                      </button>

                      {/* Fields */}
                      <div className="flex-1 min-w-0 space-y-2">
                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            value={d.name}
                            onChange={(e) =>
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId ? {...x, name: e.target.value, error: null} : x
                                )
                              )
                            }
                            placeholder="اسم المنتج"
                            className="flex-1 min-w-0 min-h-[40px] px-3 rounded-xl bg-white border border-[#E8A91A]/35 text-xs sm:text-sm font-bold"
                          />
                          <input
                            type="text"
                            value={d.code || ''}
                            onChange={(e) =>
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId ? {...x, code: e.target.value} : x
                                )
                              )
                            }
                            placeholder="كود (اختياري)"
                            className="w-24 sm:w-28 min-h-[40px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-bold tabular-nums"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-1.5">
                          <input
                            type="number"
                            inputMode="numeric"
                            value={d.price}
                            onChange={(e) =>
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId
                                    ? {...x, price: e.target.value, error: null}
                                    : x
                                )
                              )
                            }
                            placeholder="السعر"
                            className="min-h-[38px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-bold tabular-nums"
                          />
                          <input
                            type="number"
                            inputMode="numeric"
                            value={d.oldPrice}
                            onChange={(e) =>
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId ? {...x, oldPrice: e.target.value} : x
                                )
                              )
                            }
                            placeholder="قبل الخصم (اختياري)"
                            className="min-h-[38px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-bold tabular-nums"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-1.5">
                          <select
                            value={d.categoryId}
                            onChange={(e) => {
                              const nextCatId = e.target.value;
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId
                                    ? {...x, categoryId: nextCatId, subcategoryId: ''}
                                    : x
                                )
                              );
                            }}
                            className="min-h-[38px] px-2 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-semibold"
                          >
                            {topCategories.map((c) => (
                              <option key={c.id} value={c.id}>
                                {c.name}
                              </option>
                            ))}
                          </select>

                          <select
                            value={d.subcategoryId}
                            onChange={(e) =>
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId
                                    ? {...x, subcategoryId: e.target.value}
                                    : x
                                )
                              )
                            }
                            disabled={draftSubs.length === 0}
                            className="min-h-[38px] px-2 rounded-xl bg-white border border-[#E8A91A]/30 text-xs font-semibold disabled:opacity-50"
                          >
                            <option value="">{draftSubs.length === 0 ? 'بدون نوع' : 'النوع'}</option>
                            {draftSubs.map((sub) => (
                              <option key={sub.id} value={sub.id}>
                                {sub.name}
                              </option>
                            ))}
                          </select>
                        </div>

                        <div className="pt-1">
                          <span className="text-[11px] font-bold text-[#5B5B5B] block mb-1.5">
                            اللون (اختياري)
                          </span>
                          <ColorPalette
                            compact
                            value={{
                              name:
                                d.colorName?.trim() &&
                                d.colorName.trim() !== 'الأساسي' &&
                                d.colorName.trim() !== 'الافتراضي'
                                  ? d.colorName.trim()
                                  : null,
                              hex: d.colorHex || null,
                            }}
                            onChange={(next) =>
                              setDrafts((prev) =>
                                prev.map((x) =>
                                  x.tempId === d.tempId
                                    ? {
                                        ...x,
                                        colorName: next.name || undefined,
                                        colorHex: next.hex || undefined,
                                      }
                                    : x
                                )
                              )
                            }
                          />
                        </div>
                      </div>
                    </div>

                    {/* Sizes Chips on Draft (only if category uses sizes) */}
                    {draftUsesSizes && (
                      <div className="flex flex-wrap items-center gap-1">
                        {DEFAULT_SHOE_SIZES.map((sz) => {
                          const active = d.sizes.includes(sz);
                          return (
                            <button
                              key={sz}
                              type="button"
                              onClick={() => toggleDraftSize(d.tempId, sz)}
                              className={`min-w-[34px] min-h-[32px] px-2 rounded-lg text-[11px] font-bold tabular-nums border cursor-pointer ${
                                active
                                  ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                                  : 'bg-white text-[#5B5B5B] border-[#E8A91A]/30'
                              }`}
                            >
                              {sz}
                            </button>
                          );
                        })}
                      </div>
                    )}

                    {/* Error Message + Retry */}
                    {d.error && (
                      <div className="flex items-center justify-between gap-2 rounded-xl bg-[#B3261E]/10 px-3 py-2 text-xs font-bold text-[#B3261E]">
                        <span className="inline-flex items-center gap-1">
                          <AlertCircle className="w-4 h-4 shrink-0" />
                          <span>{d.error}</span>
                        </span>
                        <button
                          type="button"
                          onClick={() => handlePublishSingle(d)}
                          className="px-2.5 py-1 rounded-lg bg-[#B3261E] text-white text-[11px] cursor-pointer"
                        >
                          إعادة المحاولة
                        </button>
                      </div>
                    )}

                    {/* Multi-Image Quick Splitter Strip */}
                    {d.images.length > 1 && (
                      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
                        {d.images.map((img, imgIdx) => (
                          <div
                            key={`${d.tempId}-img-${imgIdx}`}
                            className="relative w-12 h-14 rounded-lg overflow-hidden border border-[#E8A91A]/35 bg-white shrink-0"
                          >
                            <img src={img.thumb} alt="" className="w-full h-full object-cover" />
                            {imgIdx > 0 && (
                              <button
                                type="button"
                                onClick={() => splitImageToNewDraft(d.tempId, imgIdx)}
                                title="فصل الصورة لموديل جديد"
                                className="absolute inset-x-0 bottom-0 bg-[#0F4C3A]/90 text-white text-[9px] font-bold py-0.5 text-center cursor-pointer"
                              >
                                موديل جديد
                              </button>
                            )}
                          </div>
                        ))}
                      </div>
                    )}

                    {/* Card Action Row */}
                    <div className="flex flex-wrap items-center gap-1.5 pt-1 border-t border-[#E8A91A]/20">
                      <label className="min-h-[38px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/35 text-[11px] font-bold text-[#0F4C3A] inline-flex items-center gap-1 cursor-pointer">
                        <Plus className="w-3.5 h-3.5" />
                        <span>
                          {appendingDraftId === d.tempId ? 'جاري الرفع...' : '+ صور'}
                        </span>
                        <input
                          type="file"
                          accept="image/*"
                          multiple
                          disabled={appendingDraftId !== null}
                          onChange={(e) => handleAppendPhotosToDraft(d.tempId, e)}
                          className="hidden"
                        />
                      </label>

                      {d.images.length > 1 && (
                        <button
                          type="button"
                          onClick={() => splitAllImagesToModels(d)}
                          className="min-h-[38px] px-2.5 rounded-xl bg-[#FBF6EA] border border-[#0F4C3A]/35 text-[11px] font-bold text-[#0F4C3A] inline-flex items-center gap-1 cursor-pointer"
                        >
                          <Scissors className="w-3.5 h-3.5" />
                          <span>فصل كموديلات ({d.images.length})</span>
                        </button>
                      )}

                      <button
                        type="button"
                        onClick={() => duplicateDraftCard(d)}
                        className="min-h-[38px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/35 text-[11px] font-bold text-[#141413] inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Copy className="w-3.5 h-3.5" />
                        <span>نسخ</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenFullEdit(d)}
                        className="min-h-[38px] px-2.5 rounded-xl bg-white border border-[#E8A91A]/35 text-[11px] font-bold text-[#0F4C3A] inline-flex items-center gap-1 cursor-pointer"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                        <span>تعديل كامل</span>
                      </button>

                      <button
                        type="button"
                        disabled={publishingAll || publishingSingleId === d.tempId}
                        onClick={() => handlePublishSingle(d)}
                        className="min-h-[38px] px-3 rounded-xl bg-[#0F4C3A] text-white text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer disabled:opacity-50"
                      >
                        <Check className="w-3.5 h-3.5 text-[#F6CF5A]" />
                        <span>{publishingSingleId === d.tempId ? 'جاري النشر...' : 'نشر'}</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => removeSingleDraft(d)}
                        className="min-h-[38px] px-2.5 rounded-xl bg-[#B3261E]/10 text-[#B3261E] text-[11px] font-bold inline-flex items-center gap-1 cursor-pointer mr-auto"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                        <span>حذف</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Sticky Bottom Publish All CTA */}
          {drafts.length > 0 && (
            <div className="sticky bottom-3 z-20 pt-2">
              <button
                type="button"
                disabled={publishingAll}
                onClick={handlePublishAll}
                className="w-full min-h-[52px] rounded-2xl bg-[#0F4C3A] text-white text-sm sm:text-base font-bold shadow-xl hover:bg-[#0A3629] disabled:opacity-70 flex items-center justify-center gap-2 cursor-pointer border-2 border-[#E8A91A]/70"
              >
                {publishingAll ? (
                  <>
                    <RefreshCw className="w-5 h-5 animate-spin text-[#F6CF5A]" />
                    <span>
                      جاري النشر ({publishProgress?.done ?? 0} / {publishProgress?.total ?? drafts.length})...
                    </span>
                  </>
                ) : (
                  <>
                    <Upload className="w-5 h-5 text-[#F6CF5A]" />
                    <span>نشر الكل ({drafts.length})</span>
                  </>
                )}
              </button>
            </div>
          )}
        </div>
      )}

      {/* Confirm Clear All Drafts */}
      {confirmClearAll && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => !clearingAll && setConfirmClearAll(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-t-3xl sm:rounded-3xl bg-white p-5 space-y-4 shadow-2xl"
          >
            <h3 className="text-base font-bold text-[#B3261E]">مسح كل المسودات؟</h3>
            <p className="text-xs sm:text-sm text-[#5B5B5B] leading-relaxed">
              سيتم حذف {drafts.length} مسودة وإزالة صورها المرفوعة غير المحفوظة في منتجات أو نسخ احتياطية من مساحة التخزين.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                disabled={clearingAll}
                onClick={handleConfirmClearAll}
                className="flex-1 min-h-[46px] rounded-2xl bg-[#B3261E] text-white text-sm font-bold cursor-pointer disabled:opacity-50"
              >
                {clearingAll ? 'جاري المسح والتنظيف...' : 'نعم، امسحي الكل'}
              </button>
              <button
                type="button"
                disabled={clearingAll}
                onClick={() => setConfirmClearAll(false)}
                className="min-h-[46px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] text-sm font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Optional Skippable Focus Point Modal */}
      {focusModal && (
        <FocusPointModal
          items={focusModal.items}
          onSaveAll={handleSaveFocusModal}
          onCancel={() => setFocusModal(null)}
        />
      )}
    </div>
  );
};
