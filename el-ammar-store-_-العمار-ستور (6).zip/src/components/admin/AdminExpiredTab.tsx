import React, {useEffect, useMemo, useState} from 'react';
import {Archive, CheckSquare, Clock, Infinity as InfinityIcon, RefreshCw, Square, Trash2} from 'lucide-react';
import {EmptyState, ResilientImage} from '../../components/BrandElements';
import {useStore} from '../../context/StoreContext';
import {getProductAgeDays, getProductMainImageObj, isProductExpired} from '../../utils/catalogHelpers';
import {PermanentDeleteModal} from './PermanentDeleteModal';

export const AdminExpiredTab: React.FC = () => {
  const {
    products,
    categories,
    settings,
    renewProduct,
    makeProductPermanent,
    createBackup,
    showToast,
  } = useStore();

  const expiryDays = Math.max(1, Number(settings.expiry_days) || 10);

  const expiredProducts = useMemo(
    () =>
      products
        .filter((p) => isProductExpired(p, expiryDays))
        .sort(
          (a, b) =>
            new Date(a.listed_at || a.created_at).getTime() -
            new Date(b.listed_at || b.created_at).getTime()
        ),
    [products, expiryDays]
  );

  // Select all expired rows by default
  const [selectedIds, setSelectedIds] = useState<string[]>(() =>
    expiredProducts.map((p) => p.id)
  );
  const seenExpiredIdsRef = React.useRef<Set<string>>(
    new Set(expiredProducts.map((p) => p.id))
  );
  const [busyId, setBusyId] = useState<string | null>(null);
  const [deleteModalIds, setDeleteModalIds] = useState<string[] | null>(null);
  const [backupBeforeClean, setBackupBeforeClean] = useState(true);
  const [backingUpAll, setBackingUpAll] = useState(false);

  // Keep existing selections valid and auto-select any newly expired items
  useEffect(() => {
    const expiredSet = new Set(expiredProducts.map((p) => p.id));
    const newlyExpired: string[] = [];
    for (const p of expiredProducts) {
      if (!seenExpiredIdsRef.current.has(p.id)) {
        newlyExpired.push(p.id);
      }
    }
    seenExpiredIdsRef.current = expiredSet;
    setSelectedIds((prev) => {
      const kept = prev.filter((id) => expiredSet.has(id));
      return newlyExpired.length > 0 ? [...kept, ...newlyExpired] : kept;
    });
  }, [expiredProducts]);

  const allSelected =
    expiredProducts.length > 0 && selectedIds.length === expiredProducts.length;

  const toggleAll = () => {
    if (allSelected) {
      setSelectedIds([]);
    } else {
      setSelectedIds(expiredProducts.map((p) => p.id));
    }
  };

  const toggleRow = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  const handleRenew = async (id: string) => {
    setBusyId(id);
    try {
      await renewProduct(id);
    } finally {
      setBusyId(null);
    }
  };

  const handleMakePermanent = async (id: string) => {
    setBusyId(id);
    try {
      await makeProductPermanent(id);
    } finally {
      setBusyId(null);
    }
  };

  const handleOneStepCleanupAll = async () => {
    if (expiredProducts.length === 0) return;
    if (backupBeforeClean) {
      setBackingUpAll(true);
      try {
        await createBackup('قبل تنظيف المنتهية');
      } catch {
        showToast('تعذر أخذ النسخة الاحتياطية — جربي مرة أخرى أو ألغي خيار النسخة', 'warning');
        setBackingUpAll(false);
        return;
      } finally {
        setBackingUpAll(false);
      }
    }
    setDeleteModalIds(expiredProducts.map((p) => p.id));
  };

  if (expiredProducts.length === 0) {
    return (
      <div className="space-y-4">
        <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-4 flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-[#141413]">تنظيف الموديلات المنتهية</h2>
            <p className="text-xs text-[#5B5B5B]">
              المدة الحالية المحددة في الإعدادات: {expiryDays} يوم
            </p>
          </div>
        </div>
        <EmptyState
          title="لا توجد موديلات منتهية حاليًا"
          subtitle={`كل الموديلات غير الدائمة أقل من ${expiryDays} يوم.`}
        />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* 1-Step Cleanup Bar */}
      <div className="rounded-[24px] bg-[#FFFDF8] border-2 border-[#E8A91A]/55 p-4 space-y-3 shadow-xs">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-[#141413]">
              تنظيف سريع للموديلات المنتهية ({expiredProducts.length})
            </h2>
            <p className="text-xs text-[#5B5B5B]">
              تعديل مدة البقاء من الإعدادات (الحالية: {expiryDays} يوم). الصور المثبتة في النسخ الاحتياطية تبقى محفوظة.
            </p>
          </div>
          <button
            type="button"
            disabled={backingUpAll}
            onClick={handleOneStepCleanupAll}
            className="min-h-[46px] px-5 rounded-2xl bg-[#0F4C3A] text-white text-xs sm:text-sm font-bold inline-flex items-center gap-2 hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer shrink-0 shadow-sm"
          >
            {backingUpAll ? (
              <RefreshCw className="w-4 h-4 animate-spin text-[#F6CF5A]" />
            ) : (
              <Trash2 className="w-4 h-4 text-[#F6CF5A]" />
            )}
            <span>
              {backingUpAll
                ? 'جاري حفظ نسخة أمان...'
                : `نضّفي المنتهية (${expiredProducts.length})`}
            </span>
          </button>
        </div>

        <label className="flex items-center gap-2 text-xs font-bold text-[#0F4C3A] cursor-pointer">
          <input
            type="checkbox"
            checked={backupBeforeClean}
            onChange={(e) => setBackupBeforeClean(e.target.checked)}
            className="w-4 h-4 accent-[#0F4C3A]"
          />
          <Archive className="w-3.5 h-3.5 shrink-0" />
          <span>خدي نسخة احتياطية سريعة تلقائياً قبل الحذف (قبل تنظيف المنتهية)</span>
        </label>
      </div>

      {/* Header & Controls */}
      <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-4 space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-[#141413]">
              أو تحكمي في كل موديل على حدة
            </h3>
            <p className="text-xs text-[#5B5B5B]">
              اختاري تجديد الموديل، تثبيته كمنتج دائم، أو حذف المحدد فقط.
            </p>
          </div>

          <button
            type="button"
            onClick={toggleAll}
            className="min-h-[42px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/40 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 cursor-pointer"
          >
            {allSelected ? (
              <>
                <CheckSquare className="w-4 h-4" />
                <span>إلغاء الكل</span>
              </>
            ) : (
              <>
                <Square className="w-4 h-4" />
                <span>تحديد الكل</span>
              </>
            )}
          </button>
        </div>

        <button
          type="button"
          disabled={selectedIds.length === 0 || backingUpAll}
          onClick={() => setDeleteModalIds(selectedIds)}
          className="w-full min-h-[48px] rounded-2xl bg-[#B3261E] text-white font-bold text-sm flex items-center justify-center gap-2 shadow-sm hover:bg-[#8E1C16] disabled:opacity-45 cursor-pointer"
        >
          <Trash2 className="w-4 h-4" />
          <span>حذف المحدد نهائيًا ({selectedIds.length})</span>
        </button>
      </div>

      {/* Expired Products List */}
      <div className="space-y-3">
        {expiredProducts.map((p) => {
          const checked = selectedIds.includes(p.id);
          const catName = categories.find((c) => c.id === p.category_id)?.name || 'بدون قسم';
          const ageDays = getProductAgeDays(p.listed_at || p.created_at);
          const isBusy = busyId === p.id;

          return (
            <div
              key={p.id}
              className={`rounded-[22px] bg-white border p-3.5 shadow-xs space-y-3 transition-colors ${
                checked ? 'border-[#B3261E]/45 bg-[#FFF9F8]' : 'border-[#E8A91A]/25'
              }`}
            >
              <div className="flex items-start gap-3">
                <input
                  type="checkbox"
                  checked={checked}
                  onChange={() => toggleRow(p.id)}
                  aria-label={`تحديد ${p.name}`}
                  className="w-5 h-5 mt-2 accent-[#B3261E] cursor-pointer shrink-0"
                />

                {(() => {
                  const thumbObj = getProductMainImageObj(p);
                  return (
                    <div className="w-14 aspect-[3/4] rounded-2xl overflow-hidden bg-[#F7EFE0] shrink-0">
                      <ResilientImage
                        src={thumbObj.thumb}
                        alt={p.name}
                        style={{objectPosition: `${thumbObj.focus_x}% ${thumbObj.focus_y}%`}}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  );
                })()}

                <div className="flex-1 min-w-0 space-y-1">
                  <div className="flex flex-wrap items-center gap-2 text-xs">
                    <span className="text-[#5B5B5B] font-semibold">{catName}</span>
                    <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full bg-[#B3261E]/10 text-[#B3261E] font-bold tabular-nums">
                      <Clock className="w-3 h-3" />
                      <span>منذ {ageDays} يوم</span>
                    </span>
                  </div>
                  <h3 className="text-sm font-bold text-[#141413] truncate">{p.name}</h3>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#E8A91A]/15">
                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => handleRenew(p.id)}
                  className="min-h-[40px] px-3.5 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] disabled:opacity-50 cursor-pointer"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isBusy ? 'animate-spin' : ''}`} />
                  <span>تجديد</span>
                </button>

                <button
                  type="button"
                  disabled={isBusy}
                  onClick={() => handleMakePermanent(p.id)}
                  className="min-h-[40px] px-3.5 rounded-xl bg-[#E8A91A]/25 text-[#141413] text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#E8A91A]/40 disabled:opacity-50 cursor-pointer"
                >
                  <InfinityIcon className="w-3.5 h-3.5 text-[#0F4C3A]" />
                  <span>جعله دائم</span>
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {deleteModalIds && (
        <PermanentDeleteModal
          productIds={deleteModalIds}
          onClose={() => setDeleteModalIds(null)}
          onCompleted={() => {
            setSelectedIds((prev) => prev.filter((id) => !deleteModalIds.includes(id)));
          }}
        />
      )}
    </div>
  );
};
