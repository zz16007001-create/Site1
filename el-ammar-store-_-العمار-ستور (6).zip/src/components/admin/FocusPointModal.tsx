import React, {useState} from 'react';
import {Check, Crosshair, SkipForward, X} from 'lucide-react';
import type {ProductImage} from '../../types/store';
import {DEFAULT_FOCUS_X, DEFAULT_FOCUS_Y} from '../../utils/catalogHelpers';

export interface FocusQueueItem {
  id: string;
  image: ProductImage;
}

interface FocusPointModalProps {
  items: FocusQueueItem[];
  onSaveAll: (updated: FocusQueueItem[]) => void;
  onCancel: () => void;
}

export const FocusPointModal: React.FC<FocusPointModalProps> = ({
  items,
  onSaveAll,
  onCancel,
}) => {
  const [index, setIndex] = useState(0);
  const [draftItems, setDraftItems] = useState<FocusQueueItem[]>(() =>
    items.map((item) => ({
      ...item,
      image: {...item.image},
    }))
  );

  if (draftItems.length === 0) return null;

  const safeIdx = Math.min(index, draftItems.length - 1);
  const current = draftItems[safeIdx];
  const isLast = safeIdx >= draftItems.length - 1;

  const setFocusFromEvent = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    if (!rect.width || !rect.height) return;
    const x = Math.max(0, Math.min(100, Math.round(((e.clientX - rect.left) / rect.width) * 100)));
    const y = Math.max(0, Math.min(100, Math.round(((e.clientY - rect.top) / rect.height) * 100)));
    setDraftItems((prev) =>
      prev.map((it, i) =>
        i === safeIdx ? {...it, image: {...it.image, focus_x: x, focus_y: y}} : it
      )
    );
  };

  const handleAdvance = (useDefault = false) => {
    let nextList = draftItems;
    if (useDefault) {
      nextList = draftItems.map((it, i) =>
        i === safeIdx
          ? {
              ...it,
              image: {
                ...it.image,
                focus_x: DEFAULT_FOCUS_X,
                focus_y: DEFAULT_FOCUS_Y,
              },
            }
          : it
      );
      setDraftItems(nextList);
    }

    if (isLast) {
      onSaveAll(nextList);
    } else {
      setIndex((i) => i + 1);
    }
  };

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center bg-black/75 backdrop-blur-xs p-3 sm:p-5"
      role="dialog"
      aria-modal="true"
      aria-label="تحديد نقطة التركيز على الصورة"
    >
      <div className="w-full max-w-lg rounded-[28px] bg-white border border-[#E8A91A]/45 shadow-2xl overflow-hidden flex flex-col max-h-[92dvh]">
        {/* Header */}
        <div className="px-4 sm:px-5 py-3.5 bg-[#FBF6EA] border-b border-[#E8A91A]/25 flex items-center justify-between gap-2">
          <div>
            <h3 className="text-sm sm:text-base font-bold text-[#0F4C3A] flex items-center gap-1.5">
              <Crosshair className="w-4 h-4 text-[#E8A91A]" />
              <span>تظبيط مكان ظهور الصورة (اختياري)</span>
            </h3>
            <p className="text-[11px] text-[#5B5B5B]">
              اضغطي على الحذاء أو الشنطة لتظبيط مكان العرض في الكروت ({safeIdx + 1} من {draftItems.length})
            </p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            aria-label="إغلاق"
            className="min-w-[40px] min-h-[40px] rounded-full hover:bg-white flex items-center justify-center text-[#5B5B5B] cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Interactive Image + Mini 3:4 Preview */}
        <div className="p-4 sm:p-5 overflow-y-auto space-y-4 flex-1">
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
            <div
              onClick={setFocusFromEvent}
              className="relative inline-block max-h-[52vh] rounded-2xl overflow-hidden border-2 border-[#E8A91A]/50 bg-[#FBF6EA] cursor-crosshair select-none shadow-sm"
            >
              <img
                src={current.image.full || current.image.thumb}
                alt="اضغطي لتحديد نقطة التركيز"
                className="block max-h-[52vh] w-auto max-w-full object-contain pointer-events-none"
                draggable={false}
              />

              {/* Gold Crosshair Overlay */}
              <div
                aria-hidden="true"
                style={{
                  left: `${current.image.focus_x}%`,
                  top: `${current.image.focus_y}%`,
                }}
                className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none"
              >
                <div className="relative w-10 h-10 rounded-full border-2 border-[#E8A91A] bg-[#E8A91A]/20 shadow-[0_0_0_2px_rgba(255,255,255,0.9)] flex items-center justify-center">
                  <span className="w-2.5 h-2.5 rounded-full bg-[#0F4C3A] border border-white" />
                </div>
              </div>
            </div>

            {/* Live 3:4 Card Crop Preview */}
            <div className="flex sm:flex-col items-center gap-2 shrink-0">
              <div className="w-20 aspect-[3/4] rounded-xl overflow-hidden border-2 border-[#0F4C3A]/30 bg-[#FBF6EA] shadow-xs">
                <img
                  src={current.image.thumb || current.image.full}
                  alt="معاينة الكارت"
                  style={{
                    objectPosition: `${current.image.focus_x}% ${current.image.focus_y}%`,
                  }}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="text-center">
                <p className="text-[11px] font-bold text-[#0F4C3A]">معاينة الكارت 3:4</p>
                <p className="text-[10px] text-[#5B5B5B] tabular-nums">
                  {current.image.focus_x}% × {current.image.focus_y}%
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="px-4 sm:px-5 py-3.5 bg-[#FBF6EA] border-t border-[#E8A91A]/25 flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={() => onSaveAll(draftItems)}
            className="min-h-[44px] px-3.5 rounded-2xl bg-white border border-[#E8A91A]/45 text-xs sm:text-sm font-bold text-[#5B5B5B] hover:text-[#141413] inline-flex items-center justify-center gap-1 cursor-pointer"
          >
            <span>تخطي الكل</span>
          </button>

          {draftItems.length > 1 && (
            <button
              type="button"
              onClick={() => handleAdvance(true)}
              className="min-h-[44px] px-3.5 rounded-2xl bg-white border border-[#E8A91A]/45 text-xs sm:text-sm font-bold text-[#5B5B5B] hover:text-[#141413] inline-flex items-center justify-center gap-1 cursor-pointer"
            >
              <SkipForward className="w-4 h-4" />
              <span>تخطي الصورة</span>
            </button>
          )}

          <button
            type="button"
            onClick={() => handleAdvance(false)}
            className="flex-1 min-h-[44px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-xs sm:text-sm font-bold hover:bg-[#0A3629] inline-flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <Check className="w-4 h-4 text-[#F6CF5A]" />
            <span>{isLast ? 'تم' : 'التالي'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
