import React, {useEffect, useState} from 'react';
import {
  AlertTriangle,
  Archive,
  CheckCircle2,
  Clock,
  Download,
  EyeOff,
  History,
  RefreshCw,
  RotateCcw,
  Save,
  Trash2,
  X,
} from 'lucide-react';
import {useStore} from '../../context/StoreContext';
import type {BackupRecord, Product} from '../../types/store';
import {getProductMainImageObj, verifyImageUrlLoads} from '../../utils/catalogHelpers';

interface RestoreProbeReport {
  totalChecked: number;
  missingProductIds: string[];
  hiddenApplied: boolean;
}

export const AdminBackupSection: React.FC = () => {
  const {
    backups,
    backupsLoading,
    settings,
    saveSettings,
    fetchBackups,
    createBackup,
    deleteBackup,
    restoreBackup,
    bulkUpdateProducts,
    showToast,
  } = useStore();

  const [label, setLabel] = useState('');
  const [creating, setCreating] = useState(false);
  const [retentionDays, setRetentionDays] = useState<number>(
    Math.max(1, settings.backup_retention_days || 7)
  );
  const [savingRetention, setSavingRetention] = useState(false);

  const [restoreConfirmTarget, setRestoreConfirmTarget] = useState<BackupRecord | null>(null);
  const [restoring, setRestoring] = useState(false);
  const [probingImages, setProbingImages] = useState(false);
  const [probeReport, setProbeReport] = useState<RestoreProbeReport | null>(null);
  const [hidingMissing, setHidingMissing] = useState(false);

  const [deleteConfirmTarget, setDeleteConfirmTarget] = useState<BackupRecord | null>(null);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  useEffect(() => {
    void fetchBackups();
  }, [fetchBackups]);

  useEffect(() => {
    setRetentionDays(Math.max(1, settings.backup_retention_days || 7));
  }, [settings.backup_retention_days]);

  const handleSaveRetention = async () => {
    setSavingRetention(true);
    try {
      const safe = Math.max(1, Math.min(365, Math.round(Number(retentionDays) || 7)));
      setRetentionDays(safe);
      await saveSettings({
        ...settings,
        backup_retention_days: safe,
      });
    } catch {
      showToast('تعذر حفظ مدة الاحتفاظ بالنسخ', 'warning');
    } finally {
      setSavingRetention(false);
    }
  };

  const handleCreateBackup = async () => {
    setCreating(true);
    try {
      await createBackup(label.trim());
      setLabel('');
    } catch {
      showToast('تعذر إنشاء النسخة الاحتياطية', 'warning');
    } finally {
      setCreating(false);
    }
  };

  const handleDownloadJson = (bk: BackupRecord) => {
    try {
      const jsonStr = JSON.stringify(
        {
          id: bk.id,
          created_at: bk.created_at,
          label: bk.label,
          counts: bk.counts,
          snapshot: bk.snapshot,
        },
        null,
        2
      );
      const blob = new Blob([jsonStr], {type: 'application/json;charset=utf-8'});
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `elamar-backup-${bk.created_at.slice(0, 10)}.json`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.setTimeout(() => URL.revokeObjectURL(url), 1500);
    } catch {
      showToast('تعذر تنزيل ملف النسخة', 'warning');
    }
  };

  const probeRestoredProducts = async (restoredProducts: Product[]): Promise<RestoreProbeReport> => {
    if (restoredProducts.length === 0) {
      return {totalChecked: 0, missingProductIds: [], hiddenApplied: false};
    }
    const missingIds: string[] = [];
    const queue = [...restoredProducts];
    const concurrency = 5;

    const workers = Array.from({length: Math.min(concurrency, queue.length)}, async () => {
      while (queue.length > 0) {
        const prod = queue.shift();
        if (!prod) continue;
        const imgObj = getProductMainImageObj(prod);
        const testUrl = imgObj.thumb || imgObj.full;
        if (!testUrl || testUrl.startsWith('/assets/aistudio/logo')) {
          missingIds.push(prod.id);
          continue;
        }
        const ok = await verifyImageUrlLoads(testUrl, 5500);
        if (!ok) missingIds.push(prod.id);
      }
    });

    await Promise.all(workers);
    return {
      totalChecked: restoredProducts.length,
      missingProductIds: missingIds,
      hiddenApplied: false,
    };
  };

  const handleConfirmRestore = async () => {
    if (!restoreConfirmTarget) return;
    setRestoring(true);
    setProbeReport(null);
    try {
      const restored = await restoreBackup(restoreConfirmTarget.id);
      setRestoreConfirmTarget(null);
      setProbingImages(true);
      const report = await probeRestoredProducts(restored);
      setProbeReport(report);
    } catch {
      showToast('تعذر استعادة النسخة الاحتياطية', 'warning');
    } finally {
      setRestoring(false);
      setProbingImages(false);
    }
  };

  const handleHideMissingProducts = async () => {
    if (!probeReport || probeReport.missingProductIds.length === 0) return;
    setHidingMissing(true);
    try {
      await bulkUpdateProducts(probeReport.missingProductIds, {type: 'visibility', visible: false});
      setProbeReport((prev) => (prev ? {...prev, hiddenApplied: true} : null));
    } finally {
      setHidingMissing(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deleteConfirmTarget) return;
    setDeletingId(deleteConfirmTarget.id);
    try {
      await deleteBackup(deleteConfirmTarget.id);
      setDeleteConfirmTarget(null);
    } catch {
      showToast('تعذر حذف النسخة الاحتياطية', 'warning');
    } finally {
      setDeletingId(null);
    }
  };

  return (
    <section className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-[#0F4C3A]">
            <History className="w-5 h-5 shrink-0" />
            <h3 className="text-base font-bold text-[#141413]">النسخ الاحتياطية السريعة</h3>
          </div>
          <p className="text-xs text-[#5B5B5B] leading-relaxed">
            تحفظ نسخة كاملة من المنتجات والأقسام والإعلانات والإعدادات (بدون الطلبات أو الأرقام السرية) مع تثبيت صورها في التخزين طوال مدة الاحتفاظ.
          </p>
        </div>
      </div>

      {/* Retention Days Quick Control */}
      <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-3.5 space-y-2">
        <label className="block text-xs font-bold text-[#5B5B5B]">
          مدة الاحتفاظ بالنسخ السريعة (أيام)
        </label>
        <div className="flex items-center gap-2">
          <input
            type="number"
            min={1}
            max={365}
            value={retentionDays}
            onChange={(e) =>
              setRetentionDays(Math.max(1, parseInt(e.target.value || '7', 10) || 7))
            }
            className="w-28 min-h-[44px] px-3 rounded-xl bg-white border border-[#E8A91A]/35 text-sm font-bold tabular-nums text-center"
          />
          <button
            type="button"
            disabled={savingRetention}
            onClick={handleSaveRetention}
            className="min-h-[44px] px-4 rounded-xl bg-white border border-[#0F4C3A]/30 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 hover:bg-[#0F4C3A]/5 disabled:opacity-60 cursor-pointer"
          >
            <Save className="w-4 h-4" />
            <span>{savingRetention ? 'جاري الحفظ...' : 'حفظ المدة'}</span>
          </button>
        </div>
      </div>

      {/* Manual Backup Creator */}
      <div className="flex flex-col sm:flex-row gap-2.5">
        <input
          type="text"
          value={label}
          onChange={(e) => setLabel(e.target.value)}
          placeholder="وصف اختياري (مثل: قبل تعديل الأسعار)"
          className="flex-1 min-h-[46px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs sm:text-sm font-semibold"
        />
        <button
          type="button"
          disabled={creating}
          onClick={handleCreateBackup}
          className="min-h-[46px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#0A3629] disabled:opacity-60 shrink-0 cursor-pointer"
        >
          {creating ? (
            <RefreshCw className="w-4 h-4 animate-spin" />
          ) : (
            <Archive className="w-4 h-4 text-[#F6CF5A]" />
          )}
          <span>{creating ? 'جاري أخذ النسخة...' : 'خد نسخة احتياطية دلوقتي'}</span>
        </button>
      </div>

      {/* Post-restore image health probe */}
      {probingImages && (
        <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 p-3.5 flex items-center gap-2.5 text-xs font-bold text-[#0F4C3A]">
          <RefreshCw className="w-4 h-4 animate-spin shrink-0" />
          <span>جاري فحص سلامة صور المنتجات المستعادة...</span>
        </div>
      )}

      {probeReport && !probingImages && (
        <div
          className={`rounded-2xl border p-3.5 space-y-2.5 ${
            probeReport.missingProductIds.length > 0
              ? 'bg-[#FFF9F8] border-[#B3261E]/35'
              : 'bg-[#0F4C3A]/10 border-[#0F4C3A]/25'
          }`}
        >
          {probeReport.missingProductIds.length === 0 ? (
            <div className="flex items-center gap-2 text-xs sm:text-sm font-bold text-[#0F4C3A]">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>تمت استعادة البيانات وكل صور المنتجات ({probeReport.totalChecked}) شغالة تمام.</span>
            </div>
          ) : (
            <>
              <div className="flex items-start gap-2 text-xs sm:text-sm font-bold text-[#B3261E]">
                <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                <span>
                  تنبيه: {probeReport.missingProductIds.length} منتج صوره مفقودة أو تعذر تحميلها بعد الاستعادة.
                </span>
              </div>
              {!probeReport.hiddenApplied ? (
                <button
                  type="button"
                  disabled={hidingMissing}
                  onClick={handleHideMissingProducts}
                  className="min-h-[44px] px-4 rounded-xl bg-[#B3261E] text-white text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#8E1C16] disabled:opacity-60 cursor-pointer"
                >
                  <EyeOff className="w-4 h-4" />
                  <span>{hidingMissing ? 'جاري الإخفاء...' : 'إخفاء المنتجات دي'}</span>
                </button>
              ) : (
                <p className="text-xs font-bold text-[#0F4C3A]">
                  تم إخفاء المنتجات ذات الصور المفقودة عن الزوار بنجاح.
                </p>
              )}
            </>
          )}
        </div>
      )}

      {/* Backups List */}
      <div className="space-y-2.5">
        {backupsLoading ? (
          <div className="py-4 flex items-center justify-center gap-2 text-xs font-bold text-[#5B5B5B]">
            <RefreshCw className="w-4 h-4 animate-spin text-[#0F4C3A]" />
            <span>جاري تحميل النسخ الاحتياطية...</span>
          </div>
        ) : backups.length === 0 ? (
          <div className="rounded-2xl bg-[#FBF6EA]/70 border border-dashed border-[#E8A91A]/40 p-4 text-center text-xs font-semibold text-[#5B5B5B]">
            لا توجد نسخ احتياطية سريعة محفوظة حاليًا.
          </div>
        ) : (
          backups.map((bk) => {
            const isSafety =
              bk.label.includes('قبل الاستعادة') || bk.label.includes('قبل التصفير');
            const formattedDate = new Date(bk.created_at).toLocaleString('ar-EG', {
              dateStyle: 'medium',
              timeStyle: 'short',
            });
            return (
              <div
                key={bk.id}
                className="rounded-2xl bg-[#FBF6EA]/75 border border-[#E8A91A]/30 p-3.5 space-y-3"
              >
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="space-y-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span
                        className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                          isSafety
                            ? 'bg-[#E8A91A]/25 text-[#141413]'
                            : 'bg-[#0F4C3A]/12 text-[#0F4C3A]'
                        }`}
                      >
                        {bk.label}
                      </span>
                      <span className="inline-flex items-center gap-1 text-[11px] font-semibold text-[#5B5B5B]">
                        <Clock className="w-3.5 h-3.5" />
                        <span>{formattedDate}</span>
                      </span>
                    </div>
                    <p className="text-xs font-bold text-[#141413] tabular-nums">
                      {bk.counts.products} منتج · {bk.counts.categories} قسم · {bk.counts.banners} إعلان
                    </p>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => setRestoreConfirmTarget(bk)}
                    className="min-h-[42px] px-3.5 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5 text-[#F6CF5A]" />
                    <span>استعادة</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDownloadJson(bk)}
                    className="min-h-[42px] px-3.5 rounded-xl bg-white border border-[#E8A91A]/40 text-[#141413] text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#FBF6EA] cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5 text-[#0F4C3A]" />
                    <span>تنزيل كملف JSON</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteConfirmTarget(bk)}
                    className="min-h-[42px] px-3.5 rounded-xl bg-[#B3261E]/10 text-[#B3261E] text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#B3261E]/20 cursor-pointer"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف</span>
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Restore Confirmation Dialog */}
      {restoreConfirmTarget && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="تأكيد استعادة النسخة الاحتياطية"
          onClick={() => !restoring && setRestoreConfirmTarget(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#E8A91A]/35 space-y-4"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
              <div className="flex items-center gap-2 text-[#0F4C3A]">
                <RotateCcw className="w-5 h-5" />
                <h4 className="text-base font-bold">استعادة نسخة «{restoreConfirmTarget.label}»</h4>
              </div>
              {!restoring && (
                <button
                  type="button"
                  onClick={() => setRestoreConfirmTarget(null)}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5 text-[#141413]" />
                </button>
              )}
            </div>

            <div className="space-y-2.5 text-xs sm:text-sm text-[#141413] leading-relaxed">
              <p className="font-bold">
                سيتم استبدال البيانات الحالية بما في هذه النسخة:
              </p>
              <ul className="list-disc list-inside space-y-1 text-xs text-[#5B5B5B]">
                <li>المنتجات والألوان والمقاسات ({restoreConfirmTarget.counts.products} منتج)</li>
                <li>الأقسام الرئيسية والفرعية ({restoreConfirmTarget.counts.categories} قسم)</li>
                <li>إعلانات الرئيسية ({restoreConfirmTarget.counts.banners} إعلان)</li>
                <li>إعدادات المتجر</li>
              </ul>
              <div className="rounded-2xl bg-[#0F4C3A]/10 border border-[#0F4C3A]/20 p-3 text-xs font-bold text-[#0F4C3A]">
                أمان إضافي: سجل الطلبات لن يتأثر، وسيتم أخذ نسخة احتياطية تلقائية بعنوان «قبل الاستعادة» قبل التنفيذ مباشرة.
              </div>
            </div>

            <div className="flex gap-2.5">
              <button
                type="button"
                disabled={restoring}
                onClick={handleConfirmRestore}
                className="flex-1 min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
              >
                {restoring ? 'جاري الاستعادة...' : 'تأكيد الاستعادة الآن'}
              </button>
              <button
                type="button"
                disabled={restoring}
                onClick={() => setRestoreConfirmTarget(null)}
                className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Backup Confirmation Dialog */}
      {deleteConfirmTarget && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="تأكيد حذف النسخة الاحتياطية"
          onClick={() => !deletingId && setDeleteConfirmTarget(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#B3261E]/25 space-y-4"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
              <div className="flex items-center gap-2 text-[#B3261E]">
                <Trash2 className="w-5 h-5" />
                <h4 className="text-base font-bold">حذف النسخة الاحتياطية</h4>
              </div>
              {!deletingId && (
                <button
                  type="button"
                  onClick={() => setDeleteConfirmTarget(null)}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5 text-[#141413]" />
                </button>
              )}
            </div>

            <p className="text-xs sm:text-sm font-semibold text-[#141413] leading-relaxed">
              هل تريدين حذف النسخة «{deleteConfirmTarget.label}»؟ سيتم تنظيف الصور المرتبطة بها فقط إذا لم تعد مستخدمة في المتجر أو في نسخ أخرى.
            </p>

            <div className="flex gap-2.5">
              <button
                type="button"
                disabled={Boolean(deletingId)}
                onClick={handleConfirmDelete}
                className="flex-1 min-h-[48px] rounded-2xl bg-[#B3261E] text-white font-bold text-sm hover:bg-[#8E1C16] disabled:opacity-60 cursor-pointer"
              >
                {deletingId ? 'جاري الحذف...' : 'حذف النسخة'}
              </button>
              <button
                type="button"
                disabled={Boolean(deletingId)}
                onClick={() => setDeleteConfirmTarget(null)}
                className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};
