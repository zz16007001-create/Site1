import React, {useEffect, useMemo, useState} from 'react';
import {Check, Copy, Megaphone, RotateCcw} from 'lucide-react';
import {useStore} from '../../context/StoreContext';
import {buildMainSiteLink, copyTextToClipboard} from '../../utils/catalogHelpers';

interface PromoTemplateDef {
  id: string;
  title: string;
  subtitle: string;
  buildDefault: (storeName: string, siteLink: string, howLink: string, whatsappDisplay: string) => string;
}

const PROMO_TEMPLATES: PromoTemplateDef[] = [
  {
    id: 'intro',
    title: '1. بوست تعريفي بالمتجر',
    subtitle: 'يناسب النشر اليومي أو مشاركة رابط المتجر مع العميلات الجدد.',
    buildDefault: (storeName, siteLink) => `أهلاً بيكم في كتالوج ${storeName} الرسمي 👑✨
دلوقتي كل الموديلات الجديدة متاحة في مكان واحد ومتقسمة بالأقسام والمقاسات المتوفرة لحظياً:
👠 أحذية وكوتشيات وهيلز
👜 شنط عملية وسهرة
💍 دهب صيني وإكسسوارات

ادخلي اختاري موديلك ومقاسك واطلبي في 30 ثانية من اللينك ده 👇
${siteLink}`,
  },
  {
    id: 'how_to_order',
    title: '2. بوست شرح خطوات الطلب (مع رابط /#/how)',
    subtitle: 'بيساعد العميلات اللي مش متعودين على الطلب من الإنترنت.',
    buildDefault: (storeName, siteLink, howLink) => `أول مرة تطلبي من موقع ${storeName}؟ الموضوع أسهل مما تتخيلي 🌸
1️⃣ افتحي الموقع واختاري مقاسك من زر «مقاسي»
2️⃣ اختاري الموديل واللون اللي عاجبك
3️⃣ اطلبي عبر واتساب أو ماسنجر أو سيبيلنا رقمك وهنكلمك نأكد الشحن

شوفي الشرح المصور بالخطوات في 30 ثانية من هنا 👇
${howLink}

وللتصفح المباشر للموديلات:
${siteLink}`,
  },
  {
    id: 'pinned',
    title: '3. بوست مثبّت أعلى صفحة فيسبوك',
    subtitle: 'مثالي للتثبيت في أعلى الصفحة كمرجع دائم لكل الزوار.',
    buildDefault: (storeName, siteLink, howLink, whatsappDisplay) => `📌 مرحباً بكل عميلات ${storeName} الغاليات 💛
عشان تقدري تشوفي كل الموديلات المتاحة يومياً بالأسعار والمقاسات بدون ما تدوري كتير في البوستات، جمعنالك الكتالوج كامل على موقعنا الرسمي:

🛍️ رابط الكتالوج المباشر:
${siteLink}

❓ خطوات الطلب السهلة:
${howLink}
${whatsappDisplay ? `\n💬 لطلبات الواتساب المباشرة: ${whatsappDisplay}\n` : ''}
✨ التحديث يومي والمقاسات المتاحة بتتحدث أول بأول · الشحن والدفع بيتأكد معاكي في الشات قبل خروج الأوردر.`,
  },
  {
    id: 'quick_replies',
    title: '4. ردود سريعة على تعليقات السعر والتفاصيل',
    subtitle: 'رد جاهز للنسخ في كومنتات فيسبوك وإنستجرام لتحويل المتابعة لطلب.',
    buildDefault: (storeName, siteLink) => `أهلاً بكِ يا فندم 🌸 كل موديلات ${storeName} متاحة دلوقتي بالأسعار والمقاسات المتوفرة على الكتالوج من هنا 👇
${siteLink}

ولو حابة نساعدك في اختيار المقاس ابعتيلنا رسالة على الصفحة أو سيبيلنا رقمك من جوا الموديل وهنكلمك فوراً 💛`,
  },
];

export const AdminPromoMaterials: React.FC = () => {
  const {settings, showToast} = useStore();

  const siteLink = useMemo(() => buildMainSiteLink(), []);
  const howLink = useMemo(() => `${siteLink}#/how`, [siteLink]);
  const whatsappDisplay = useMemo(() => {
    const clean = (settings.whatsapp || '').replace(/[^\d]/g, '');
    return clean ? `+${clean}` : '';
  }, [settings.whatsapp]);

  const defaultsMap = useMemo(() => {
    const map: Record<string, string> = {};
    for (const tpl of PROMO_TEMPLATES) {
      map[tpl.id] = tpl.buildDefault(
        settings.store_name || 'العمار ستور',
        siteLink,
        howLink,
        whatsappDisplay
      );
    }
    return map;
  }, [settings.store_name, siteLink, howLink, whatsappDisplay]);

  const [texts, setTexts] = useState<Record<string, string>>(defaultsMap);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    setTexts(defaultsMap);
  }, [defaultsMap]);

  const handleCopy = async (id: string) => {
    const ok = await copyTextToClipboard(texts[id] || '');
    if (ok) {
      setCopiedId(id);
      showToast('تم نسخ النص الترويجي بنجاح ✅', 'success');
      window.setTimeout(() => {
        setCopiedId((cur) => (cur === id ? null : cur));
      }, 2000);
    } else {
      showToast('تعذر النسخ التلقائي، حددي النص وانسخيه يدوياً', 'warning');
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-1.5">
        <div className="flex items-center gap-2 text-[#0F4C3A]">
          <Megaphone className="w-5 h-5 shrink-0" />
          <h3 className="text-base font-bold text-[#141413]">مواد الترويج والبوستات الجاهزة</h3>
        </div>
        <p className="text-xs text-[#5B5B5B] leading-relaxed">
          4 قوالب جاهزة بالروابط الفعلية لمتجرك — تقدري تعدّلي أي جملة فيها وتنسخيها بضغطة واحدة للنشر على فيسبوك أو الرد على التعليقات.
        </p>
      </div>

      <div className="space-y-4">
        {PROMO_TEMPLATES.map((tpl) => {
          const val = texts[tpl.id] ?? defaultsMap[tpl.id] ?? '';
          const isCopied = copiedId === tpl.id;
          return (
            <div
              key={tpl.id}
              className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-3 shadow-xs"
            >
              <div className="flex flex-wrap items-start justify-between gap-2">
                <div>
                  <h4 className="text-sm sm:text-base font-bold text-[#141413]">{tpl.title}</h4>
                  <p className="text-xs text-[#5B5B5B]">{tpl.subtitle}</p>
                </div>
                <span className="text-[11px] font-bold text-[#5B5B5B] tabular-nums">
                  {val.length} حرف
                </span>
              </div>

              <textarea
                rows={6}
                value={val}
                onChange={(e) => setTexts((prev) => ({...prev, [tpl.id]: e.target.value}))}
                className="w-full p-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs sm:text-sm text-[#141413] leading-relaxed"
              />

              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => handleCopy(tpl.id)}
                  className={`min-h-[44px] px-5 rounded-2xl text-xs sm:text-sm font-bold inline-flex items-center gap-2 cursor-pointer transition-colors ${
                    isCopied
                      ? 'bg-[#0F4C3A] text-[#F6CF5A]'
                      : 'bg-[#0F4C3A] text-white hover:bg-[#0A3629]'
                  }`}
                >
                  {isCopied ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                  <span>{isCopied ? 'تم النسخ!' : 'نسخ النص'}</span>
                </button>

                {val !== defaultsMap[tpl.id] && (
                  <button
                    type="button"
                    onClick={() =>
                      setTexts((prev) => ({...prev, [tpl.id]: defaultsMap[tpl.id]}))
                    }
                    className="min-h-[44px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold text-[#5B5B5B] inline-flex items-center gap-1.5 hover:text-[#141413] cursor-pointer"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                    <span>استعادة الافتراضي</span>
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
