import React, {useMemo, useState} from 'react';
import {ArrowDown, ArrowUp, Camera, Eye, EyeOff, Plus, Trash2} from 'lucide-react';
import {CategoryIcon} from '../../components/CategoryIcon';
import {useStore} from '../../context/StoreContext';

export const AdminCategoriesTab: React.FC = () => {
  const {categories, saveCategory, deleteCategory, reorderCategories, uploadImage, showToast} =
    useStore();
  const [newName, setNewName] = useState('');
  const [newImage, setNewImage] = useState<string | null>(null);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState('');
  const [newSubNames, setNewSubNames] = useState<Record<string, string>>({});

  const topCategories = useMemo(
    () =>
      categories
        .filter((c) => !c.parent_id)
        .sort((a, b) => a.sort - b.sort),
    [categories]
  );

  const getSubcategories = (parentId: string) =>
    categories
      .filter((c) => c.parent_id === parentId)
      .sort((a, b) => a.sort - b.sort);

  const handleAddTop = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newName.trim()) return;
    await saveCategory({
      name: newName.trim(),
      image_url: newImage,
      sort: topCategories.length + 1,
      visible: true,
      parent_id: null,
    });
    setNewName('');
    setNewImage(null);
  };

  const handleAddSub = async (parentId: string) => {
    const subName = (newSubNames[parentId] || '').trim();
    if (!subName) return;
    const siblings = getSubcategories(parentId);
    await saveCategory({
      name: subName,
      image_url: null,
      sort: siblings.length + 1,
      visible: true,
      parent_id: parentId,
    });
    setNewSubNames((prev) => ({...prev, [parentId]: ''}));
  };

  const moveInList = async (list: typeof topCategories, idx: number, dir: -1 | 1) => {
    const targetIdx = idx + dir;
    if (targetIdx < 0 || targetIdx >= list.length) return;
    const ids = list.map((c) => c.id);
    const [moved] = ids.splice(idx, 1);
    ids.splice(targetIdx, 0, moved);
    await reorderCategories(ids);
  };

  return (
    <div className="space-y-5">
      {/* Add Top-level Category Form */}
      <form
        onSubmit={handleAddTop}
        className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-4 flex flex-wrap items-center gap-3"
      >
        <label className="w-12 h-12 rounded-full bg-[#FBF6EA] border-2 border-dashed border-[#0F4C3A]/40 flex items-center justify-center p-1 cursor-pointer shrink-0">
          {newImage ? (
            <img src={newImage} alt="" className="w-full h-full object-contain" />
          ) : (
            <Camera className="w-5 h-5 text-[#0F4C3A]" />
          )}
          <input
            type="file"
            accept="image/*"
            onChange={async (e) => {
              const f = e.target.files?.[0];
              if (!f) return;
              try {
                setNewImage(await uploadImage(f, {preserveAlpha: true, maxDimension: 600}));
              } catch {
                showToast('تعذر رفع الصورة', 'warning');
              }
            }}
            className="hidden"
          />
        </label>

        <input
          type="text"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="اسم القسم الرئيسي الجديد..."
          className="flex-1 min-w-[160px] min-h-[44px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold"
        />

        <button
          type="submit"
          className="min-h-[44px] px-5 rounded-2xl bg-[#0F4C3A] text-white text-sm font-bold inline-flex items-center gap-1.5 cursor-pointer"
        >
          <Plus className="w-4 h-4 text-[#F6CF5A]" />
          <span>إضافة قسم</span>
        </button>
      </form>

      {/* Top Categories + Nested Subcategories */}
      <div className="space-y-4">
        {topCategories.map((cat, idx) => {
          const subs = getSubcategories(cat.id);
          return (
            <div
              key={cat.id}
              className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-4 shadow-xs space-y-3"
            >
              {/* Parent Row */}
              <div className="flex items-center gap-3">
                <label className="w-12 h-12 rounded-full bg-[#FBF6EA] border border-[#E8A91A]/45 p-1 shrink-0 cursor-pointer flex items-center justify-center">
                  {cat.image_url ? (
                    <img
                      src={cat.image_url}
                      alt={cat.name}
                      className="w-full h-full object-contain"
                    />
                  ) : (
                    <CategoryIcon name={cat.name} className="w-7 h-7" />
                  )}
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const url = await uploadImage(f, {preserveAlpha: true, maxDimension: 600});
                      await saveCategory({...cat, image_url: url});
                    }}
                    className="hidden"
                  />
                </label>

                <div className="flex-1 min-w-0">
                  {editingId === cat.id ? (
                    <div className="flex gap-2">
                      <input
                        type="text"
                        value={editingName}
                        onChange={(e) => setEditingName(e.target.value)}
                        className="flex-1 min-h-[38px] px-3 rounded-xl bg-[#FBF6EA] text-sm font-bold"
                      />
                      <button
                        type="button"
                        onClick={async () => {
                          if (editingName.trim()) {
                            await saveCategory({...cat, name: editingName.trim()});
                          }
                          setEditingId(null);
                        }}
                        className="px-3 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold cursor-pointer"
                      >
                        حفظ
                      </button>
                    </div>
                  ) : (
                    <div>
                      <button
                        type="button"
                        onClick={() => {
                          setEditingId(cat.id);
                          setEditingName(cat.name);
                        }}
                        className="text-sm sm:text-base font-bold text-[#141413] hover:text-[#0F4C3A] text-right cursor-pointer"
                      >
                        {cat.name}
                      </button>
                      {cat.image_url && (
                        <button
                          type="button"
                          onClick={() => saveCategory({...cat, image_url: null})}
                          className="block text-[11px] text-[#5B5B5B] hover:text-[#B3261E] cursor-pointer"
                        >
                          استخدام الأيقونة الافتراضية
                        </button>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex items-center gap-1 shrink-0">
                  <button
                    type="button"
                    onClick={() => moveInList(topCategories, idx, -1)}
                    disabled={idx === 0}
                    aria-label="تحريك للأعلى"
                    className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowUp className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => moveInList(topCategories, idx, 1)}
                    disabled={idx === topCategories.length - 1}
                    aria-label="تحريك للأسفل"
                    className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center disabled:opacity-30 cursor-pointer"
                  >
                    <ArrowDown className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => saveCategory({...cat, visible: !cat.visible})}
                    aria-label={cat.visible ? 'إخفاء القسم' : 'إظهار القسم'}
                    className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                  >
                    {cat.visible ? (
                      <Eye className="w-4 h-4 text-[#0F4C3A]" />
                    ) : (
                      <EyeOff className="w-4 h-4 text-[#B3261E]" />
                    )}
                  </button>
                  <button
                    type="button"
                    onClick={() => deleteCategory(cat.id)}
                    aria-label="حذف القسم"
                    className="min-w-[38px] min-h-[38px] rounded-xl bg-[#B3261E]/10 text-[#B3261E] flex items-center justify-center cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Subcategories Management */}
              <div className="pr-4 sm:pr-8 pt-2 border-t border-[#E8A91A]/15 space-y-2">
                <p className="text-xs font-bold text-[#5B5B5B]">
                  الأنواع الفرعية داخل {cat.name} ({subs.length})
                </p>

                {subs.length > 0 && (
                  <div className="space-y-1.5">
                    {subs.map((sub, sIdx) => (
                      <div
                        key={sub.id}
                        className="flex items-center justify-between gap-2 rounded-2xl bg-[#FBF6EA]/80 px-3 py-1.5"
                      >
                        {editingId === sub.id ? (
                          <div className="flex gap-2 flex-1">
                            <input
                              type="text"
                              value={editingName}
                              onChange={(e) => setEditingName(e.target.value)}
                              className="flex-1 min-h-[34px] px-2.5 rounded-xl bg-white text-xs font-bold"
                            />
                            <button
                              type="button"
                              onClick={async () => {
                                if (editingName.trim()) {
                                  await saveCategory({...sub, name: editingName.trim()});
                                }
                                setEditingId(null);
                              }}
                              className="px-2.5 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold cursor-pointer"
                            >
                              حفظ
                            </button>
                          </div>
                        ) : (
                          <button
                            type="button"
                            onClick={() => {
                              setEditingId(sub.id);
                              setEditingName(sub.name);
                            }}
                            className={`inline-flex items-center gap-2 text-xs sm:text-sm font-bold text-right cursor-pointer ${
                              sub.visible ? 'text-[#141413]' : 'text-[#5B5B5B] line-through'
                            }`}
                          >
                            {sub.image_url ? (
                              <img
                                src={sub.image_url}
                                alt=""
                                className="w-7 h-7 rounded-full object-cover shrink-0"
                              />
                            ) : (
                              <CategoryIcon
                                name={sub.name}
                                parentName={cat.name}
                                className="w-7 h-7 shrink-0"
                              />
                            )}
                            <span>{sub.name}</span>
                          </button>
                        )}

                        <div className="flex items-center gap-1 shrink-0">
                          <button
                            type="button"
                            onClick={() => moveInList(subs, sIdx, -1)}
                            disabled={sIdx === 0}
                            aria-label="أعلى"
                            className="w-8 h-8 rounded-lg bg-white flex items-center justify-center disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowUp className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => moveInList(subs, sIdx, 1)}
                            disabled={sIdx === subs.length - 1}
                            aria-label="أسفل"
                            className="w-8 h-8 rounded-lg bg-white flex items-center justify-center disabled:opacity-30 cursor-pointer"
                          >
                            <ArrowDown className="w-3.5 h-3.5" />
                          </button>
                          <button
                            type="button"
                            onClick={() => saveCategory({...sub, visible: !sub.visible})}
                            aria-label={sub.visible ? 'إخفاء' : 'إظهار'}
                            className="w-8 h-8 rounded-lg bg-white flex items-center justify-center cursor-pointer"
                          >
                            {sub.visible ? (
                              <Eye className="w-3.5 h-3.5 text-[#0F4C3A]" />
                            ) : (
                              <EyeOff className="w-3.5 h-3.5 text-[#B3261E]" />
                            )}
                          </button>
                          <button
                            type="button"
                            onClick={() => deleteCategory(sub.id)}
                            aria-label="حذف"
                            className="w-8 h-8 rounded-lg bg-[#B3261E]/10 text-[#B3261E] flex items-center justify-center cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                {/* Add Subcategory inline */}
                <div className="flex gap-2 pt-1">
                  <input
                    type="text"
                    value={newSubNames[cat.id] || ''}
                    onChange={(e) =>
                      setNewSubNames((prev) => ({...prev, [cat.id]: e.target.value}))
                    }
                    onKeyDown={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        handleAddSub(cat.id);
                      }
                    }}
                    placeholder={`إضافة نوع فرعي داخل ${cat.name}...`}
                    className="flex-1 min-h-[38px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-semibold"
                  />
                  <button
                    type="button"
                    onClick={() => handleAddSub(cat.id)}
                    className="min-h-[38px] px-3.5 rounded-xl bg-[#E8A91A] text-[#141413] text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>إضافة نوع</span>
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
