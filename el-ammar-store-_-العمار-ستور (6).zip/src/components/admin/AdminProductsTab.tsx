import React, {useMemo, useState} from 'react';
import {
  Camera,
  Check,
  Copy,
  CopyPlus,
  Crosshair,
  Edit3,
  Eye,
  EyeOff,
  Link2,
  MessageSquareText,
  Percent,
  Plus,
  Search,
  Star,
  Trash2,
  X,
} from 'lucide-react';
import {EmptyState, ResilientImage} from '../../components/BrandElements';
import {type ProductDraftInput, useStore} from '../../context/StoreContext';
import type {BulkDraftItem, Product, ProductImage, SizeStatus} from '../../types/store';
import {
  buildFacebookCaption,
  buildProductDeepLink,
  categoryUsesSizes,
  cleanColorName,
  copyTextToClipboard,
  describeError,
  formatBytesCompact,
  formatPrice,
  getProductAgeDays,
  getProductMainImageObj,
  isProductSoldOut,
  normalizeSearchText,
  uploadWithConcurrency,
} from '../../utils/catalogHelpers';
import {type FocusQueueItem, FocusPointModal} from './FocusPointModal';
import {PermanentDeleteModal} from './PermanentDeleteModal';
import {
  AdminBulkUpload,
  loadSavedBulkDrafts,
  saveBulkDraftsToStorage,
} from './AdminBulkUpload';
import {ColorPalette} from './ColorPalette';

const DEFAULT_SHOE_SIZES = ['36', '37', '38', '39', '40', '41', '42'];
const LAST_CAT_KEY = 'elamar_last_admin_cat';
const LAST_SUBCAT_KEY = 'elamar_last_admin_subcat';
const COLOR_NONE_KEY = '__none__';

type PhotoItem = {
  key: string;
  image: ProductImage;
  colorName: string | null;
  colorHex: string | null;
};

type DraftSizeItem = {
  id?: string;
  size: string | null;
  status: SizeStatus;
};

const getColorKey = (colorName: string | null | undefined): string =>
  cleanColorName(colorName) ?? COLOR_NONE_KEY;

let photoKeySeq = 0;
const makePhotoKey = () => `ph-${Date.now()}-${++photoKeySeq}`;

export const AdminProductsTab: React.FC = () => {
  const {
    products,
    categories,
    settings,
    uploadProductImagePair,
    saveProduct,
    duplicateProduct,
    cleanupDraftImageUrls,
    bulkUpdateProducts,
    quickUpdateProductPrices,
    toggleProductSoldAll,
    toggleSizeStatus,
    showToast,
  } = useStore();

  const [filterMode, setFilterMode] = useState<'all' | 'offers' | 'sold' | 'hidden'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [bulkMode, setBulkMode] = useState<'percent' | 'amount'>('percent');
  const [bulkValue, setBulkValue] = useState('');

  const [bulkDrafts, setBulkDrafts] = useState<BulkDraftItem[]>(() => loadSavedBulkDrafts());
  const [bulkExpanded, setBulkExpanded] = useState<boolean>(() => loadSavedBulkDrafts().length > 0);
  const [editingFromBulkId, setEditingFromBulkId] = useState<string | null>(null);

  React.useEffect(() => {
    const saved = saveBulkDraftsToStorage(bulkDrafts);
    if (!saved && bulkDrafts.length > 0) {
      showToast('مساحة حفظ المسودات في المتصفح امتلأت، انشري المسودات الحالية أولًا', 'warning');
    }
  }, [bulkDrafts, showToast]);

  const [priceEdits, setPriceEdits] = useState<Record<string, {price: string; oldPrice: string}>>({});

  const [editingDraft, setEditingDraft] = useState<ProductDraftInput | null>(null);
  const [photos, setPhotos] = useState<PhotoItem[]>([]);
  const [selectedKeys, setSelectedKeys] = useState<string[]>([]);
  const [sizesByColor, setSizesByColor] = useState<Record<string, DraftSizeItem[]>>({});
  const [originalColorIds, setOriginalColorIds] = useState<Record<string, string | undefined>>({});
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const [uploadStepProgress, setUploadStepProgress] = useState<{done: number; total: number} | null>(null);
  const [compressionNotice, setCompressionNotice] = useState<string | null>(null);
  const [focusSession, setFocusSession] = useState<{
    target: 'modal';
    photoKey: string;
    items: FocusQueueItem[];
  } | null>(null);
  const [customSizeInput, setCustomSizeInput] = useState<Record<string, string>>({});
  const [savingForm, setSavingForm] = useState(false);
  const [deleteModalIds, setDeleteModalIds] = useState<string[] | null>(null);

  const topCategories = useMemo(
    () =>
      categories
        .filter((c) => !c.parent_id)
        .sort((a, b) => a.sort - b.sort),
    [categories]
  );

  const selectedCategoryForModal = categories.find(
    (c) => c.id === editingDraft?.category_id
  );
  const modalSubcategories = useMemo(
    () =>
      editingDraft?.category_id
        ? categories
            .filter((c) => c.parent_id === editingDraft.category_id)
            .sort((a, b) => a.sort - b.sort)
        : [],
    [categories, editingDraft?.category_id]
  );
  const modalUsesSizes = categoryUsesSizes(selectedCategoryForModal?.name);

  const visibleColorGroups = useMemo(() => {
    const map = new Map<
      string,
      {
        colorKey: string;
        colorName: string | null;
        colorHex: string | null;
        images: ProductImage[];
      }
    >();
    for (const p of photos) {
      const ck = getColorKey(p.colorName);
      let group = map.get(ck);
      if (!group) {
        const clean = cleanColorName(p.colorName);
        group = {
          colorKey: ck,
          colorName: clean,
          colorHex: clean ? p.colorHex : null,
          images: [],
        };
        map.set(ck, group);
      }
      group.images.push(p.image);
    }
    return Array.from(map.values());
  }, [photos]);

  const getFirstExistingSizesTemplate = (
    currentSizesByColor: Record<string, DraftSizeItem[]>,
    currentPhotos: PhotoItem[],
    excludeKey?: string
  ): DraftSizeItem[] => {
    for (const p of currentPhotos) {
      const ck = getColorKey(p.colorName);
      if (ck === excludeKey) continue;
      const list = currentSizesByColor[ck];
      if (list && list.length > 0 && list.some((s) => s.size !== null)) {
        return list.map((s) => ({size: s.size, status: 'available'}));
      }
    }
    for (const [ck, list] of Object.entries(currentSizesByColor)) {
      if (ck === excludeKey) continue;
      if (list && list.length > 0 && list.some((s) => s.size !== null)) {
        return list.map((s) => ({size: s.size, status: 'available'}));
      }
    }
    return ['37', '38', '39', '40'].map((s) => ({size: s, status: 'available'}));
  };

  const openBulkDraftInFullModal = (draft: BulkDraftItem) => {
    const cat = categories.find((c) => c.id === draft.categoryId);
    const usesSizes = categoryUsesSizes(cat?.name);
    const normalizedColorName = cleanColorName(draft.colorName);
    const normalizedColorHex = normalizedColorName ? draft.colorHex || null : null;
    const colorKey = getColorKey(normalizedColorName);

    setEditingFromBulkId(draft.tempId);
    setCompressionNotice(null);
    setSelectedKeys([]);
    setCustomSizeInput({});
    setOriginalColorIds({});
    setPhotos(
      draft.images.map((img) => ({
        key: makePhotoKey(),
        image: {...img},
        colorName: normalizedColorName,
        colorHex: normalizedColorHex,
      }))
    );
    setSizesByColor({
      [colorKey]: usesSizes
        ? (draft.sizes.length > 0 ? draft.sizes : ['37', '38', '39', '40']).map((sz) => ({
            size: sz,
            status: 'available',
          }))
        : [{size: null, status: 'available'}],
    });
    setEditingDraft({
      name: draft.name,
      code: draft.code || '',
      category_id: draft.categoryId || null,
      subcategory_id: draft.subcategoryId || null,
      description: '',
      price: Math.max(0, Number(draft.price) || 0),
      old_price: draft.oldPrice ? Number(draft.oldPrice) : null,
      visible: true,
      featured: false,
      is_permanent: false,
      colors: [],
    });
  };

  const openNewProductModal = () => {
    setEditingFromBulkId(null);
    setCompressionNotice(null);
    setPhotos([]);
    setSelectedKeys([]);
    setSizesByColor({});
    setOriginalColorIds({});
    setCustomSizeInput({});
    const catId = localStorage.getItem(LAST_CAT_KEY) || topCategories[0]?.id || null;
    const lastSub = localStorage.getItem(LAST_SUBCAT_KEY);
    const validSub = categories.find((c) => c.id === lastSub && c.parent_id === catId);
    setEditingDraft({
      name: '',
      code: '',
      category_id: catId,
      subcategory_id: validSub ? validSub.id : null,
      description: '',
      price: 0,
      old_price: null,
      visible: true,
      featured: false,
      is_permanent: false,
      colors: [],
    });
  };

  const openEditProductModal = (p: Product) => {
    setEditingFromBulkId(null);
    setCompressionNotice(null);
    setSelectedKeys([]);
    setCustomSizeInput({});

    const nextPhotos: PhotoItem[] = [];
    const nextSizesByColor: Record<string, DraftSizeItem[]> = {};
    const nextOrigColorIds: Record<string, string | undefined> = {};
    const resolvedHexByColorKey: Record<string, string | null> = {};

    for (const c of p.colors) {
      const normalizedName = cleanColorName(c.name);
      const ck = getColorKey(normalizedName);

      if (!(ck in nextOrigColorIds)) {
        nextOrigColorIds[ck] = c.id;
        resolvedHexByColorKey[ck] = normalizedName ? c.hex || null : null;
        nextSizesByColor[ck] = c.sizes.map((s) => ({
          id: s.id,
          size: s.size,
          status: s.status,
        }));
      } else {
        // Merge duplicate colorKey into the first block, keeping first block's ID and size IDs/statuses
        const existingSizes = nextSizesByColor[ck];
        const seenSizeKeys = new Set(existingSizes.map((s) => s.size ?? '__null__'));
        for (const s of c.sizes) {
          const sk = s.size ?? '__null__';
          if (!seenSizeKeys.has(sk)) {
            seenSizeKeys.add(sk);
            existingSizes.push({id: s.id, size: s.size, status: s.status});
          }
        }
      }

      const blockHex = resolvedHexByColorKey[ck];
      for (const img of c.images) {
        nextPhotos.push({
          key: makePhotoKey(),
          image: {...img},
          colorName: normalizedName,
          colorHex: blockHex,
        });
      }
    }

    setPhotos(nextPhotos);
    setSizesByColor(nextSizesByColor);
    setOriginalColorIds(nextOrigColorIds);

    setEditingDraft({
      id: p.id,
      name: p.name,
      code: p.code || '',
      category_id: p.category_id,
      subcategory_id: p.subcategory_id ?? null,
      description: p.description,
      price: p.price,
      old_price: p.old_price,
      visible: p.visible,
      featured: p.featured,
      is_permanent: Boolean(p.is_permanent),
      listed_at: p.listed_at,
      colors: [],
    });
  };

  const handleModalCategoryChange = (newCatId: string) => {
    if (!editingDraft) return;
    localStorage.setItem(LAST_CAT_KEY, newCatId);
    const cat = categories.find((c) => c.id === newCatId);
    const usesSizes = categoryUsesSizes(cat?.name);

    setSizesByColor((prev) => {
      const next: Record<string, DraftSizeItem[]> = {};
      for (const [ck, list] of Object.entries(prev)) {
        if (!usesSizes) {
          const existingNull = list.find((s) => s.size === null);
          if (existingNull) {
            next[ck] = [existingNull];
          } else {
            const anyAvail = list.some((s) => s.status === 'available');
            next[ck] = [{size: null, status: anyAvail || list.length === 0 ? 'available' : 'sold'}];
          }
        } else if (list.length === 0 || (list.length === 1 && list[0].size === null)) {
          next[ck] = ['37', '38', '39', '40'].map((sz) => ({size: sz, status: 'available'}));
        } else {
          next[ck] = list;
        }
      }
      return next;
    });

    setEditingDraft({
      ...editingDraft,
      category_id: newCatId || null,
      subcategory_id: null,
    });
  };

  const toggleDraftSize = (colorKey: string, sizeLabel: string) => {
    setSizesByColor((prev) => {
      const current = prev[colorKey] || [];
      const existing = current.find((s) => s.size === sizeLabel);
      if (existing) {
        if (existing.status === 'sold') {
          showToast(
            'المقاس ده مباع — لتعديل حالته استخدمي زر المقاس في بطاقة المنتج',
            'warning'
          );
          return prev;
        }
        return {
          ...prev,
          [colorKey]: current.filter((s) => s.size !== sizeLabel),
        };
      }
      return {
        ...prev,
        [colorKey]: [...current, {size: sizeLabel, status: 'available'}],
      };
    });
  };

  const copySizesToAllColors = (sourceColorKey: string) => {
    setSizesByColor((prev) => {
      const template = prev[sourceColorKey] || [];
      const templateLabels = new Set(
        template.map((s) => s.size).filter((sz): sz is string => Boolean(sz))
      );
      const next: Record<string, DraftSizeItem[]> = {...prev};

      for (const group of visibleColorGroups) {
        const ck = group.colorKey;
        if (ck === sourceColorKey) continue;
        const existing = prev[ck] || [];

        // Keep sold sizes untouched, keep available sizes that exist in template with their IDs, remove only available sizes not in template
        const kept: DraftSizeItem[] = existing.filter(
          (s) => s.status === 'sold' || (s.size !== null && templateLabels.has(s.size))
        );
        const presentLabels = new Set(kept.map((s) => s.size).filter(Boolean));

        for (const tmpl of template) {
          if (tmpl.size && !presentLabels.has(tmpl.size)) {
            kept.push({size: tmpl.size, status: 'available'});
            presentLabels.add(tmpl.size);
          }
        }
        next[ck] = kept;
      }

      return next;
    });
    showToast('تم نسخ المقاسات لباقي الألوان', 'success');
  };

  const handleUploadAllPhotos = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const picked = e.target.files ? Array.from(e.target.files) : [];
    e.target.value = '';
    if (picked.length === 0 || !editingDraft) return;

    const files = picked.slice(0, 30);
    if (picked.length > 30) {
      showToast('تم تحديد أول 30 صورة كحد أقصى في المرة الواحدة', 'warning');
    }

    setUploadingPhotos(true);
    setUploadStepProgress({done: 0, total: files.length});
    setCompressionNotice(null);

    let totalOrigBytes = 0;
    let totalCompBytes = 0;

    try {
      const {succeeded, failed} = await uploadWithConcurrency(
        files,
        (file) =>
          uploadProductImagePair(file, (stats) => {
            totalOrigBytes += stats.originalBytes;
            totalCompBytes += stats.compressedBytes;
          }),
        2,
        (done, total) => setUploadStepProgress({done, total})
      );

      if (succeeded.length > 0) {
        const newItems: PhotoItem[] = succeeded.map((img) => ({
          key: makePhotoKey(),
          image: img,
          colorName: null,
          colorHex: null,
        }));

        setPhotos((prev) => [...prev, ...newItems]);
        setSelectedKeys(newItems.map((item) => item.key));
        setSizesByColor((prev) => {
          if (prev[COLOR_NONE_KEY] && prev[COLOR_NONE_KEY].length > 0) return prev;
          return {
            ...prev,
            [COLOR_NONE_KEY]: modalUsesSizes
              ? getFirstExistingSizesTemplate(prev, photos, COLOR_NONE_KEY)
              : [{size: null, status: 'available'}],
          };
        });

        const savedPct =
          totalOrigBytes > 0
            ? Math.max(0, Math.round(((totalOrigBytes - totalCompBytes) / totalOrigBytes) * 100))
            : 0;
        const summaryText = `ضغط WebP (1000px / 360px · جودة 0.75): ${formatBytesCompact(totalOrigBytes)} ← ${formatBytesCompact(totalCompBytes)}${savedPct > 0 ? ` (-${savedPct}%)` : ''}`;
        setCompressionNotice(summaryText);
      }

      if (failed.length > 0) {
        showToast(
          `تم رفع ${succeeded.length} وفشلت ${failed.length} — ${failed[0].reason}`,
          'warning'
        );
      } else if (succeeded.length > 0) {
        showToast(
          `تم رفع ${succeeded.length} صورة — اختاري اللون لتطبيقه على الصور المحددة`,
          'success'
        );
      }
    } catch (err) {
      console.error('upload failed', err);
      showToast('تعذر رفع الصورة: ' + describeError(err), 'warning');
    } finally {
      setUploadingPhotos(false);
      setUploadStepProgress(null);
    }
  };

  const togglePhotoSelection = (photoKey: string) => {
    setSelectedKeys((prev) =>
      prev.includes(photoKey) ? prev.filter((k) => k !== photoKey) : [...prev, photoKey]
    );
  };

  const applyColorToSelected = (next: {name: string | null; hex: string | null}): boolean => {
    if (selectedKeys.length === 0) {
      showToast('اختاري الصور الأول', 'warning');
      return false;
    }

    const cleanedName = cleanColorName(next.name);
    const nextHex = cleanedName ? next.hex : null;
    const targetKey = getColorKey(cleanedName);
    const selectedSet = new Set(selectedKeys);

    const updatedPhotos = photos.map((p) =>
      selectedSet.has(p.key) ? {...p, colorName: cleanedName, colorHex: nextHex} : p
    );
    setPhotos(updatedPhotos);

    setSizesByColor((prev) => {
      if (prev[targetKey] && prev[targetKey].length > 0) {
        return prev;
      }
      return {
        ...prev,
        [targetKey]: modalUsesSizes
          ? getFirstExistingSizesTemplate(prev, updatedPhotos, targetKey)
          : [{size: null, status: 'available'}],
      };
    });

    setSelectedKeys([]);
    return true;
  };

  const handleSaveFocusSession = (updated: FocusQueueItem[]) => {
    if (!focusSession || updated.length === 0) {
      setFocusSession(null);
      return;
    }
    const map = new Map(updated.map((u) => [u.id, u.image]));
    setPhotos((prev) =>
      prev.map((p) => (map.has(p.key) ? {...p, image: map.get(p.key)!} : p))
    );
    setFocusSession(null);
  };

  const closeModalWithoutSaving = () => {
    if (editingDraft && !editingFromBulkId) {
      const originalProduct = editingDraft.id
        ? products.find((p) => p.id === editingDraft.id)
        : undefined;
      const originalUrls = new Set<string>();
      if (originalProduct) {
        for (const col of originalProduct.colors) {
          for (const img of col.images) {
            if (img.full) originalUrls.add(img.full);
            if (img.thumb) originalUrls.add(img.thumb);
          }
        }
      }
      const newSessionUrls: string[] = [];
      for (const p of photos) {
        if (p.image.full && !originalUrls.has(p.image.full)) newSessionUrls.push(p.image.full);
        if (p.image.thumb && !originalUrls.has(p.image.thumb)) newSessionUrls.push(p.image.thumb);
      }
      if (newSessionUrls.length > 0) {
        void cleanupDraftImageUrls(newSessionUrls).catch(() => {});
      }
    }
    setEditingDraft(null);
    setPhotos([]);
    setSelectedKeys([]);
    setSizesByColor({});
    setOriginalColorIds({});
    setEditingFromBulkId(null);
    setCompressionNotice(null);
    setCustomSizeInput({});
  };

  const handleSaveModal = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingDraft) return;
    if (uploadingPhotos) {
      showToast('استني لحد ما الصور تخلص رفع', 'warning');
      return;
    }
    if (!editingDraft.name.trim()) {
      showToast('اكتبي اسم المنتج الأول', 'warning');
      return;
    }
    if (editingDraft.category_id) {
      localStorage.setItem(LAST_CAT_KEY, editingDraft.category_id);
    }
    if (editingDraft.subcategory_id) {
      localStorage.setItem(LAST_SUBCAT_KEY, editingDraft.subcategory_id);
    }

    const builtColors: ProductDraftInput['colors'] = [];
    if (visibleColorGroups.length > 0) {
      visibleColorGroups.forEach((group, idx) => {
        const rawSizes = sizesByColor[group.colorKey];
        let finalSizes: DraftSizeItem[];
        if (modalUsesSizes) {
          finalSizes =
            rawSizes && rawSizes.length > 0
              ? rawSizes.map((s) => ({
                  ...(s.id ? {id: s.id} : {}),
                  size: s.size,
                  status: s.status,
                }))
              : ['37', '38', '39', '40'].map((sz) => ({size: sz, status: 'available'}));
        } else {
          const existingNull = rawSizes?.find((s) => s.size === null);
          if (existingNull) {
            finalSizes = [
              {
                ...(existingNull.id ? {id: existingNull.id} : {}),
                size: null,
                status: existingNull.status,
              },
            ];
          } else if (rawSizes && rawSizes.length > 0) {
            const allSold = rawSizes.every((s) => s.status === 'sold');
            finalSizes = [{size: null, status: allSold ? 'sold' : 'available'}];
          } else {
            finalSizes = [{size: null, status: 'available'}];
          }
        }

        const existingColorId = originalColorIds[group.colorKey];
        builtColors.push({
          ...(existingColorId ? {id: existingColorId} : {}),
          name: group.colorName,
          hex: group.colorHex,
          images: group.images,
          sort: idx + 1,
          sizes: finalSizes,
        });
      });
    } else {
      const fallbackKey = Object.keys(originalColorIds)[0] || COLOR_NONE_KEY;
      const fallbackColorId = originalColorIds[fallbackKey];
      const rawSizes = sizesByColor[fallbackKey];
      const finalSizes: DraftSizeItem[] = modalUsesSizes
        ? rawSizes && rawSizes.length > 0
          ? rawSizes.map((s) => ({
              ...(s.id ? {id: s.id} : {}),
              size: s.size,
              status: s.status,
            }))
          : ['37', '38', '39', '40'].map((sz) => ({size: sz, status: 'available'}))
        : rawSizes && rawSizes.length > 0
          ? [
              {
                ...(rawSizes[0].id ? {id: rawSizes[0].id} : {}),
                size: null,
                status: rawSizes[0].status,
              },
            ]
          : [{size: null, status: 'available'}];

      builtColors.push({
        ...(fallbackColorId ? {id: fallbackColorId} : {}),
        name: fallbackKey === COLOR_NONE_KEY ? null : fallbackKey,
        hex: null,
        images: [],
        sort: 1,
        sizes: finalSizes,
      });
    }

    const sanitized: ProductDraftInput = {
      ...editingDraft,
      colors: builtColors,
    };

    setSavingForm(true);
    try {
      await saveProduct(sanitized);
      if (editingFromBulkId) {
        setBulkDrafts((prev) => prev.filter((d) => d.tempId !== editingFromBulkId));
        setEditingFromBulkId(null);
      }
      setEditingDraft(null);
      setPhotos([]);
      setSelectedKeys([]);
      setSizesByColor({});
      setOriginalColorIds({});
      setCustomSizeInput({});
      showToast('تم حفظ المنتج بنجاح', 'success');
    } catch (err) {
      console.error('save failed', err);
      showToast('تعذر حفظ المنتج: ' + describeError(err), 'warning');
    } finally {
      setSavingForm(false);
    }
  };

  const filteredProducts = useMemo(() => {
    const qNorm = normalizeSearchText(searchQuery);
    return products.filter((p) => {
      if (filterMode === 'offers' && !(p.old_price && p.old_price > p.price)) return false;
      if (filterMode === 'sold' && !isProductSoldOut(p)) return false;
      if (filterMode === 'hidden' && p.visible) return false;
      if (!qNorm) return true;
      const catName = categories.find((c) => c.id === p.category_id)?.name || '';
      const subName = categories.find((c) => c.id === p.subcategory_id)?.name || '';
      return (
        normalizeSearchText(p.name).includes(qNorm) ||
        normalizeSearchText(p.code).includes(qNorm) ||
        normalizeSearchText(catName).includes(qNorm) ||
        normalizeSearchText(subName).includes(qNorm)
      );
    });
  }, [categories, filterMode, products, searchQuery]);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-5">
      {/* Speed Toolbar */}
      <div className="flex flex-wrap items-center gap-2.5 justify-between">
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={openNewProductModal}
            className="min-h-[44px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] cursor-pointer"
          >
            <Plus className="w-4 h-4 text-[#F6CF5A]" />
            <span>إضافة منتج</span>
          </button>

          <button
            type="button"
            onClick={() => setBulkExpanded((prev) => !prev)}
            className="min-h-[44px] px-4 rounded-2xl bg-[#E8A91A] text-[#141413] text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#F6CF5A] cursor-pointer"
          >
            <Camera className="w-4 h-4 text-[#0F4C3A]" />
            <span>رفع منتجات متعددة</span>
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-[#5B5B5B] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="بحث بالاسم أو الكود..."
            className="w-full min-h-[44px] pr-10 pl-3 rounded-2xl bg-white border border-[#E8A91A]/35 text-sm"
          />
        </div>
      </div>

      {/* Fast Bulk Product Upload Workspace + Persistent Unfinished Drafts Banner */}
      <AdminBulkUpload
        topCategories={topCategories}
        drafts={bulkDrafts}
        setDrafts={setBulkDrafts}
        expanded={bulkExpanded}
        setExpanded={setBulkExpanded}
        onOpenFullEdit={openBulkDraftInFullModal}
      />

      {/* Filter Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
        {(
          [
            {id: 'all', label: `الكل (${products.length})`},
            {
              id: 'offers',
              label: `العروض (${products.filter((p) => p.old_price && p.old_price > p.price).length})`,
            },
            {id: 'sold', label: 'تم بيعه'},
            {id: 'hidden', label: 'مخفي'},
          ] as const
        ).map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setFilterMode(tab.id)}
            className={`min-h-[40px] px-3.5 rounded-2xl text-xs font-bold whitespace-nowrap cursor-pointer ${
              filterMode === tab.id
                ? 'bg-[#0F4C3A] text-white'
                : 'bg-white text-[#141413] border border-[#E8A91A]/30'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Bulk Actions Bar */}
      {selectedIds.length > 0 && (
        <div className="rounded-2xl bg-[#0F4C3A] text-white p-3.5 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold">
            <span>محدد: {selectedIds.length}</span>
            <button
              type="button"
              onClick={() => setSelectedIds([])}
              className="underline text-[#F6CF5A] cursor-pointer"
            >
              إلغاء التحديد
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <select
              value={bulkMode}
              onChange={(e) => setBulkMode(e.target.value as 'percent' | 'amount')}
              className="min-h-[38px] px-2.5 rounded-xl bg-white/15 text-xs font-bold"
            >
              <option value="percent" className="text-black">نسبة %</option>
              <option value="amount" className="text-black">مبلغ ج.م</option>
            </select>
            <input
              type="number"
              value={bulkValue}
              onChange={(e) => setBulkValue(e.target.value)}
              placeholder="+10 أو -15"
              className="w-24 min-h-[38px] px-2.5 rounded-xl bg-white text-[#141413] text-xs font-bold tabular-nums"
            />
            <button
              type="button"
              onClick={() => {
                const n = Number(bulkValue);
                if (!n) return;
                bulkUpdateProducts(
                  selectedIds,
                  bulkMode === 'percent'
                    ? {type: 'price_percent', percent: n}
                    : {type: 'price_amount', amount: n}
                );
                setBulkValue('');
              }}
              className="min-h-[38px] px-3 rounded-xl bg-[#E8A91A] text-[#141413] text-xs font-bold cursor-pointer"
            >
              تعديل السعر
            </button>
            <button
              type="button"
              onClick={() => bulkUpdateProducts(selectedIds, {type: 'visibility', visible: false})}
              className="min-h-[38px] px-3 rounded-xl bg-white/15 text-xs font-bold cursor-pointer"
            >
              إخفاء
            </button>
            <button
              type="button"
              onClick={() => setDeleteModalIds(selectedIds)}
              className="min-h-[38px] px-3 rounded-xl bg-[#B3261E] text-white text-xs font-bold cursor-pointer"
            >
              حذف نهائي
            </button>
          </div>
        </div>
      )}

      {/* Product Rows */}
      {filteredProducts.length === 0 ? (
        <EmptyState title="لا توجد منتجات في هذا التصنيف" />
      ) : (
        <div className="space-y-3">
          {filteredProducts.map((p) => {
            const soldOut = isProductSoldOut(p);
            const checked = selectedIds.includes(p.id);
            const catName = categories.find((c) => c.id === p.category_id)?.name;
            const subName = categories.find((c) => c.id === p.subcategory_id)?.name;
            const editRow = priceEdits[p.id];

            return (
              <div
                key={p.id}
                className={`rounded-[22px] bg-white border border-[#E8A91A]/25 p-3.5 shadow-xs space-y-3 ${
                  !p.visible ? 'opacity-65' : ''
                }`}
              >
                <div className="flex items-start gap-3">
                  <input
                    type="checkbox"
                    checked={checked}
                    onChange={() => toggleSelect(p.id)}
                    aria-label={`تحديد ${p.name}`}
                    className="w-5 h-5 mt-2 accent-[#0F4C3A] cursor-pointer shrink-0"
                  />

                  {(() => {
                    const thumbObj = getProductMainImageObj(p);
                    return (
                      <div className="w-14 aspect-[3/4] rounded-2xl overflow-hidden bg-[#F7EFE0] shrink-0">
                        <ResilientImage
                          src={thumbObj.thumb}
                          alt={p.name}
                          style={{objectPosition: `${thumbObj.focus_x}% ${thumbObj.focus_y}%`}}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    );
                  })()}

                  <div className="flex-1 min-w-0 space-y-1">
                    <div className="flex flex-wrap items-center gap-1.5 text-xs text-[#5B5B5B]">
                      {catName && <span>{catName}</span>}
                      {subName && (
                        <>
                          <span aria-hidden="true">·</span>
                          <span className="font-semibold text-[#0F4C3A]">{subName}</span>
                        </>
                      )}
                      {p.featured && (
                        <span className="inline-flex items-center gap-0.5 text-[#E8A91A] font-bold">
                          <Star className="w-3 h-3 fill-[#E8A91A]" />
                          مميز
                        </span>
                      )}
                      {!p.visible && <span className="text-[#B3261E] font-bold">مخفي</span>}
                      {p.is_permanent ? (
                        <span className="px-2 py-0.5 rounded-full bg-[#0F4C3A]/10 text-[#0F4C3A] font-bold">
                          دائم
                        </span>
                      ) : (
                        <span className="tabular-nums text-[11px]">
                          · منذ {getProductAgeDays(p.listed_at || p.created_at)} يوم
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-sm font-bold text-[#141413] truncate">{p.name}</h3>
                      {p.code && (
                        <span className="text-[11px] font-bold text-[#0F4C3A] bg-[#FBF6EA] px-2 py-0.5 rounded-lg shrink-0 tabular-nums">
                          {p.code}
                        </span>
                      )}
                    </div>

                    {editRow ? (
                      <div className="flex flex-wrap items-center gap-1.5 pt-1">
                        <input
                          type="number"
                          value={editRow.price}
                          onChange={(e) =>
                            setPriceEdits((prev) => ({
                              ...prev,
                              [p.id]: {...editRow, price: e.target.value},
                            }))
                          }
                          placeholder="السعر"
                          className="w-20 px-2 py-1 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/40 text-xs font-bold tabular-nums"
                        />
                        <input
                          type="number"
                          value={editRow.oldPrice}
                          onChange={(e) =>
                            setPriceEdits((prev) => ({
                              ...prev,
                              [p.id]: {...editRow, oldPrice: e.target.value},
                            }))
                          }
                          placeholder="قبل الخصم"
                          className="w-24 px-2 py-1 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/40 text-xs font-bold tabular-nums"
                        />
                        <button
                          type="button"
                          onClick={async () => {
                            await quickUpdateProductPrices(
                              p.id,
                              Math.max(1, Number(editRow.price) || p.price),
                              editRow.oldPrice ? Number(editRow.oldPrice) : null
                            );
                            setPriceEdits((prev) => {
                              const copy = {...prev};
                              delete copy[p.id];
                              return copy;
                            });
                          }}
                          className="min-h-[34px] px-3 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold cursor-pointer"
                        >
                          حفظ
                        </button>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2 tabular-nums">
                        <span className="text-sm font-bold text-[#0F4C3A]">
                          {formatPrice(p.price)}
                        </span>
                        {p.old_price && p.old_price > p.price && (
                          <span className="text-xs text-[#5B5B5B] line-through">
                            {formatPrice(p.old_price)}
                          </span>
                        )}
                        <button
                          type="button"
                          onClick={() =>
                            setPriceEdits((prev) => ({
                              ...prev,
                              [p.id]: {
                                price: String(p.price),
                                oldPrice: p.old_price ? String(p.old_price) : '',
                              },
                            }))
                          }
                          className="text-[11px] font-bold text-[#0F4C3A] underline cursor-pointer"
                        >
                          تعديل السعر
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                {/* Per-size quick toggles */}
                <div className="flex flex-wrap items-center gap-1.5 pt-1">
                  {p.colors.map((c) =>
                    c.sizes.map((s) => (
                      <button
                        key={s.id}
                        type="button"
                        onClick={() =>
                          toggleSizeStatus(s.id, s.status === 'sold' ? 'available' : 'sold')
                        }
                        className={`min-h-[34px] px-2.5 rounded-xl text-[11px] font-bold border transition-colors cursor-pointer ${
                          s.status === 'sold'
                            ? 'bg-[#B3261E]/10 border-[#B3261E]/35 text-[#B3261E] line-through'
                            : 'bg-[#FBF6EA] border-[#E8A91A]/30 text-[#0F4C3A]'
                        }`}
                      >
                        {c.name ? `${c.name} ` : ''}
                        {s.size ? `(${s.size})` : 'القطعة'} ·{' '}
                        {s.status === 'sold' ? 'مباع' : 'متاح'}
                      </button>
                    ))
                  )}
                </div>

                {/* Product Action Row incl. Marketing Copy Caption & Copy Link */}
                <div className="flex flex-wrap items-center gap-2 pt-1 border-t border-[#E8A91A]/15">
                  <button
                    type="button"
                    onClick={async () => {
                      const caption = buildFacebookCaption(p, settings);
                      const ok = await copyTextToClipboard(caption);
                      showToast(
                        ok ? 'تم نسخ كابشن البوست الجاهز للنشر' : 'تعذر النسخ',
                        ok ? 'success' : 'warning'
                      );
                    }}
                    className="min-h-[40px] px-3 rounded-xl bg-[#E8A91A]/20 text-[#141413] text-xs font-bold inline-flex items-center gap-1 cursor-pointer hover:bg-[#E8A91A]/35"
                  >
                    <MessageSquareText className="w-3.5 h-3.5 text-[#0F4C3A]" />
                    <span>نسخ كابشن البوست</span>
                  </button>

                  <button
                    type="button"
                    onClick={async () => {
                      const ok = await copyTextToClipboard(buildProductDeepLink(p.id));
                      showToast(
                        ok ? 'تم نسخ رابط المنتج' : 'تعذر النسخ',
                        ok ? 'success' : 'warning'
                      );
                    }}
                    className="min-h-[40px] px-3 rounded-xl bg-[#FBF6EA] text-[#0F4C3A] text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Link2 className="w-3.5 h-3.5" />
                    <span>نسخ رابط المنتج</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => openEditProductModal(p)}
                    className="min-h-[40px] px-3 rounded-xl bg-[#FBF6EA] text-[#141413] text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    <span>تعديل</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => toggleProductSoldAll(p.id, !soldOut)}
                    className={`min-h-[40px] px-3 rounded-xl text-xs font-bold inline-flex items-center gap-1 cursor-pointer ${
                      soldOut
                        ? 'bg-[#0F4C3A] text-white'
                        : 'bg-[#B3261E]/10 text-[#B3261E]'
                    }`}
                  >
                    <Percent className="w-3.5 h-3.5" />
                    <span>{soldOut ? 'إرجاع متاح' : 'تعليم تم البيع'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => duplicateProduct(p)}
                    className="min-h-[40px] px-3 rounded-xl bg-[#FBF6EA] text-[#0F4C3A] text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    <CopyPlus className="w-3.5 h-3.5" />
                    <span>نسخ منتج</span>
                  </button>

                  <button
                    type="button"
                    onClick={() =>
                      bulkUpdateProducts([p.id], {type: 'visibility', visible: !p.visible})
                    }
                    className="min-h-[40px] px-3 rounded-xl bg-[#FBF6EA] text-[#5B5B5B] text-xs font-bold inline-flex items-center gap-1 cursor-pointer"
                  >
                    {p.visible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
                    <span>{p.visible ? 'إخفاء' : 'إظهار'}</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setDeleteModalIds([p.id])}
                    className="min-h-[40px] px-3 rounded-xl bg-[#B3261E]/10 text-[#B3261E] text-xs font-bold inline-flex items-center gap-1 cursor-pointer mr-auto"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>حذف نهائي</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Compact Product Add/Edit Modal */}
      {editingDraft && (
        <div
          className="fixed inset-0 z-[90] bg-black/55 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleSaveModal}
            className="w-full max-w-2xl max-h-[92dvh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-[#E8A91A]/20">
              <h2 className="text-lg font-bold text-[#141413]">
                {editingDraft.id ? 'تعديل المنتج' : 'إضافة منتج جديد'}
              </h2>
              <button
                type="button"
                onClick={closeModalWithoutSaving}
                aria-label="إغلاق"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-[#FBF6EA] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">اسم المنتج *</span>
                <input
                  type="text"
                  required
                  value={editingDraft.name}
                  onChange={(e) =>
                    setEditingDraft({...editingDraft, name: e.target.value})
                  }
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">كود الموديل (اختياري)</span>
                <input
                  type="text"
                  value={editingDraft.code || ''}
                  onChange={(e) =>
                    setEditingDraft({...editingDraft, code: e.target.value})
                  }
                  placeholder="مثال: SH-104"
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold tabular-nums"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">القسم</span>
                <select
                  value={editingDraft.category_id || ''}
                  onChange={(e) => handleModalCategoryChange(e.target.value)}
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold"
                >
                  {topCategories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </label>

              {/* Second Dropdown: Subcategory ("النوع") */}
              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">النوع (اختياري)</span>
                <select
                  value={editingDraft.subcategory_id || ''}
                  onChange={(e) => {
                    const val = e.target.value || null;
                    if (val) localStorage.setItem(LAST_SUBCAT_KEY, val);
                    setEditingDraft({...editingDraft, subcategory_id: val});
                  }}
                  disabled={modalSubcategories.length === 0}
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold disabled:opacity-50"
                >
                  <option value="">
                    {modalSubcategories.length === 0 ? 'لا توجد أنواع فرعية' : 'بدون نوع محدد'}
                  </option>
                  {modalSubcategories.map((sub) => (
                    <option key={sub.id} value={sub.id}>
                      {sub.name}
                    </option>
                  ))}
                </select>
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">السعر الحالي (ج.م) *</span>
                <input
                  type="number"
                  required
                  min={1}
                  value={editingDraft.price || ''}
                  onChange={(e) =>
                    setEditingDraft({...editingDraft, price: Number(e.target.value)})
                  }
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-bold tabular-nums"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">السعر قبل الخصم (اختياري)</span>
                <input
                  type="number"
                  min={0}
                  value={editingDraft.old_price ?? ''}
                  onChange={(e) =>
                    setEditingDraft({
                      ...editingDraft,
                      old_price: e.target.value ? Number(e.target.value) : null,
                    })
                  }
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-bold tabular-nums"
                />
              </label>
            </div>

            <label className="block space-y-1">
              <span className="text-xs font-bold text-[#5B5B5B]">الوصف</span>
              <textarea
                rows={2}
                value={editingDraft.description}
                onChange={(e) =>
                  setEditingDraft({...editingDraft, description: e.target.value})
                }
                className="w-full p-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm"
              />
            </label>

            <div className="flex flex-wrap gap-4">
              <label className="inline-flex items-center gap-2 text-sm font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={editingDraft.visible}
                  onChange={(e) =>
                    setEditingDraft({...editingDraft, visible: e.target.checked})
                  }
                  className="w-5 h-5 accent-[#0F4C3A]"
                />
                <span>ظاهر للعملاء</span>
              </label>

              <label className="inline-flex items-center gap-2 text-sm font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={editingDraft.featured}
                  onChange={(e) =>
                    setEditingDraft({...editingDraft, featured: e.target.checked})
                  }
                  className="w-5 h-5 accent-[#E8A91A]"
                />
                <span>منتج مميز في الرئيسية</span>
              </label>

              <label className="inline-flex items-center gap-2 text-sm font-bold cursor-pointer">
                <input
                  type="checkbox"
                  checked={Boolean(editingDraft.is_permanent)}
                  onChange={(e) =>
                    setEditingDraft({...editingDraft, is_permanent: e.target.checked})
                  }
                  className="w-5 h-5 accent-[#0F4C3A]"
                />
                <span>منتج دائم (ما يتحذفش بعد المدة)</span>
              </label>
            </div>

            {/* Photos, Colors & Sizes Workspace */}
            <div className="space-y-3 pt-2 border-t border-[#E8A91A]/20">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h3 className="text-sm font-bold text-[#141413]">
                  {modalUsesSizes ? 'الصور والألوان والمقاسات' : 'الصور والألوان'}
                </h3>
                <span className="text-[11px] font-bold text-[#5B5B5B] tabular-nums">
                  {photos.length} صورة · {visibleColorGroups.length}{' '}
                  {visibleColorGroups.length === 1 ? 'مجموعة' : 'مجموعات'}
                </span>
              </div>

              {/* Batch Upload CTA */}
              <label
                className={`w-full min-h-[50px] px-4 rounded-2xl bg-[#E8A91A] text-[#141413] text-sm font-bold flex items-center justify-center gap-2 hover:bg-[#F6CF5A] shadow-xs cursor-pointer transition-opacity ${
                  uploadingPhotos ? 'opacity-70 pointer-events-none' : ''
                }`}
              >
                <Camera className="w-5 h-5 text-[#0F4C3A]" />
                <span>
                  {uploadingPhotos && uploadStepProgress
                    ? `جاري رفع ${uploadStepProgress.done} من ${uploadStepProgress.total}`
                    : 'ارفعي كل الصور مرة واحدة (حتى 30 صورة)'}
                </span>
                <input
                  type="file"
                  accept="image/*"
                  multiple
                  disabled={uploadingPhotos}
                  onChange={handleUploadAllPhotos}
                  className="hidden"
                />
              </label>

              {uploadingPhotos && uploadStepProgress && (
                <div className="w-full h-2.5 rounded-full bg-[#FBF6EA] overflow-hidden border border-[#E8A91A]/30">
                  <div
                    className="h-full bg-[#0F4C3A] transition-all duration-200"
                    style={{
                      width: `${Math.min(
                        100,
                        Math.round(
                          (uploadStepProgress.done / Math.max(1, uploadStepProgress.total)) * 100
                        )
                      )}%`,
                    }}
                  />
                </div>
              )}

              {!uploadingPhotos && compressionNotice && (
                <p className="text-[11px] font-bold text-[#0F4C3A] bg-[#FBF6EA] border border-[#E8A91A]/35 rounded-xl px-3 py-1.5">
                  {compressionNotice}
                </p>
              )}

              {/* Sticky Color Selection Bar */}
              {photos.length > 0 && (
                <div className="sticky top-0 z-20 rounded-2xl bg-white border border-[#E8A91A]/45 p-3 shadow-sm space-y-2.5">
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <p className="text-xs font-bold text-[#0F4C3A]">
                      اختاري الصور اللي لونها واحد، وبعدين دوسي على اللون
                    </p>
                    <span className="px-2.5 py-0.5 rounded-full bg-[#0F4C3A]/10 text-[#0F4C3A] text-[11px] font-bold tabular-nums">
                      {selectedKeys.length} صورة محددة
                    </span>
                  </div>

                  <div className="flex flex-wrap items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setSelectedKeys(photos.map((p) => p.key))}
                      className="min-h-[34px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-[11px] font-bold text-[#141413] cursor-pointer hover:bg-[#E8A91A]/20"
                    >
                      تحديد الكل
                    </button>
                    <button
                      type="button"
                      onClick={() => setSelectedKeys([])}
                      disabled={selectedKeys.length === 0}
                      className="min-h-[34px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-[11px] font-bold text-[#5B5B5B] cursor-pointer disabled:opacity-45"
                    >
                      إلغاء التحديد
                    </button>
                    <button
                      type="button"
                      onClick={() => applyColorToSelected({name: null, hex: null})}
                      className="min-h-[34px] px-3 rounded-xl bg-white border border-[#BDBDBD] text-[11px] font-bold text-[#5B5B5B] cursor-pointer hover:border-[#0F4C3A]"
                    >
                      بدون لون
                    </button>
                  </div>

                  <ColorPalette
                    compact
                    mode="apply"
                    value={{name: null, hex: null}}
                    onChange={(next) => applyColorToSelected(next)}
                  />
                </div>
              )}

              {/* 3:4 Photo Grid */}
              {photos.length > 0 ? (
                <div className="grid grid-cols-3 sm:grid-cols-4 gap-2.5">
                  {photos.map((item, idx) => {
                    const isSelected = selectedKeys.includes(item.key);
                    const isMain = idx === 0;
                    return (
                      <div
                        key={item.key}
                        role="button"
                        tabIndex={0}
                        onClick={() => togglePhotoSelection(item.key)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter' || e.key === ' ') {
                            e.preventDefault();
                            togglePhotoSelection(item.key);
                          }
                        }}
                        aria-pressed={isSelected}
                        className={`relative aspect-[3/4] rounded-2xl overflow-hidden bg-[#F7EFE0] cursor-pointer select-none transition-all ${
                          isSelected
                            ? 'ring-2 ring-[#0F4C3A] border-[3px] border-[#0F4C3A] shadow-md'
                            : 'border border-[#E8A91A]/35 hover:border-[#0F4C3A]/50'
                        }`}
                      >
                        <img
                          src={item.image.thumb}
                          alt=""
                          style={{
                            objectPosition: `${item.image.focus_x}% ${item.image.focus_y}%`,
                          }}
                          className="w-full h-full object-cover"
                        />

                        {/* Selected checkmark badge */}
                        {isSelected && (
                          <span className="absolute top-1.5 left-1/2 -translate-x-1/2 w-6 h-6 rounded-full bg-[#0F4C3A] text-white flex items-center justify-center shadow-md pointer-events-none">
                            <Check className="w-3.5 h-3.5" strokeWidth={3} />
                          </span>
                        )}

                        {/* Delete (X) */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setPhotos((prev) => prev.filter((p) => p.key !== item.key));
                            setSelectedKeys((prev) => prev.filter((k) => k !== item.key));
                          }}
                          aria-label="حذف الصورة"
                          className="absolute top-1.5 left-1.5 w-6 h-6 rounded-full bg-[#B3261E] text-white flex items-center justify-center shadow cursor-pointer"
                        >
                          <X className="w-3.5 h-3.5" />
                        </button>

                        {/* Make Main Photo (Star) */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            if (idx === 0) return;
                            setPhotos((prev) => {
                              const target = prev.find((p) => p.key === item.key);
                              if (!target) return prev;
                              return [target, ...prev.filter((p) => p.key !== item.key)];
                            });
                          }}
                          aria-label="اجعلها الصورة الرئيسية"
                          title="اجعلها الصورة الرئيسية"
                          className={`absolute top-1.5 right-1.5 w-6 h-6 rounded-full flex items-center justify-center shadow cursor-pointer ${
                            isMain
                              ? 'bg-[#E8A91A] text-[#141413]'
                              : 'bg-white/90 text-[#5B5B5B] hover:text-[#E8A91A]'
                          }`}
                        >
                          <Star className={`w-3.5 h-3.5 ${isMain ? 'fill-[#141413]' : ''}`} />
                        </button>

                        {/* Focus Point (Crosshair) */}
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            setFocusSession({
                              target: 'modal',
                              photoKey: item.key,
                              items: [{id: item.key, image: item.image}],
                            });
                          }}
                          aria-label="تعديل نقطة التركيز"
                          className="absolute bottom-1.5 right-1.5 w-6 h-6 rounded-full bg-white/95 text-[#0F4C3A] flex items-center justify-center shadow cursor-pointer"
                        >
                          <Crosshair className="w-3.5 h-3.5" />
                        </button>

                        {/* Bottom-left color indicator dot (18px) + label */}
                        <div className="absolute bottom-1.5 left-1.5 pointer-events-none">
                          {item.colorName ? (
                            <div className="flex flex-col items-center gap-0.5 rounded-lg bg-white/92 backdrop-blur-xs px-1.5 py-1 shadow-xs max-w-[70px]">
                              {item.colorHex ? (
                                <span
                                  style={{backgroundColor: item.colorHex}}
                                  className="w-[18px] h-[18px] rounded-full border border-black/20 shrink-0"
                                />
                              ) : (
                                <span className="w-[18px] h-[18px] rounded-full bg-[#8A8A8A] text-white text-[10px] font-bold flex items-center justify-center shrink-0">
                                  {item.colorName.trim().charAt(0)}
                                </span>
                              )}
                              <span className="text-[10px] leading-none font-bold text-[#141413] truncate max-w-full">
                                {item.colorName}
                              </span>
                            </div>
                          ) : (
                            <span className="inline-block rounded-lg bg-white/92 backdrop-blur-xs px-1.5 py-0.5 text-[10px] font-bold text-[#5B5B5B] shadow-xs">
                              بدون لون
                            </span>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="rounded-2xl border border-dashed border-[#E8A91A]/45 bg-[#FBF6EA]/60 py-6 px-4 text-center text-xs font-semibold text-[#5B5B5B]">
                  ارفعي صور المنتج من الزر بالأعلى، وبعدين حددي صور كل لون واختاري لونه بضغطة واحدة.
                </div>
              )}

              {/* Per-Color Sizes Sections (only for categories using sizes) */}
              {modalUsesSizes && visibleColorGroups.length > 0 && (
                <div className="space-y-3 pt-2">
                  {visibleColorGroups.map((group, gIdx) => {
                    const groupSizes = sizesByColor[group.colorKey] || [];
                    return (
                      <div
                        key={group.colorKey}
                        className="rounded-2xl bg-[#FBF6EA]/75 border border-[#E8A91A]/30 p-3.5 space-y-2.5"
                      >
                        <div className="flex flex-wrap items-center justify-between gap-2">
                          <div className="flex items-center gap-2">
                            {group.colorName ? (
                              group.colorHex ? (
                                <span
                                  style={{backgroundColor: group.colorHex}}
                                  className="w-4 h-4 rounded-full border border-black/20 shrink-0"
                                />
                              ) : (
                                <span className="w-4 h-4 rounded-full bg-[#8A8A8A] text-white text-[9px] font-bold flex items-center justify-center shrink-0">
                                  {group.colorName.trim().charAt(0)}
                                </span>
                              )
                            ) : (
                              <span className="w-4 h-4 rounded-full border border-dashed border-[#8A8A8A] bg-white shrink-0" />
                            )}
                            <span className="text-xs sm:text-sm font-bold text-[#141413]">
                              {group.colorName || 'بدون لون'}
                            </span>
                            <span className="text-[11px] font-semibold text-[#5B5B5B] tabular-nums">
                              ({group.images.length} صورة)
                            </span>
                          </div>

                          {gIdx === 0 && visibleColorGroups.length > 1 && (
                            <button
                              type="button"
                              onClick={() => copySizesToAllColors(group.colorKey)}
                              className="text-[11px] font-bold text-[#0F4C3A] inline-flex items-center gap-1 underline cursor-pointer"
                            >
                              <Copy className="w-3 h-3" />
                              <span>نفس المقاسات للكل</span>
                            </button>
                          )}
                        </div>

                        <div className="flex flex-wrap gap-1.5">
                          {DEFAULT_SHOE_SIZES.map((sz) => {
                            const found = groupSizes.find((s) => s.size === sz);
                            const active = Boolean(found);
                            const isSold = found?.status === 'sold';
                            return (
                              <button
                                key={sz}
                                type="button"
                                onClick={() => toggleDraftSize(group.colorKey, sz)}
                                title={isSold ? 'مباع' : undefined}
                                className={`min-w-[42px] min-h-[38px] px-2.5 rounded-xl text-xs font-bold tabular-nums border cursor-pointer ${
                                  isSold
                                    ? 'bg-[#B3261E]/15 text-[#B3261E] border-[#B3261E]/40'
                                    : active
                                      ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                                      : 'bg-white text-[#5B5B5B] border-[#E8A91A]/30'
                                }`}
                              >
                                {sz}
                                {isSold ? ' · مباع' : ''}
                              </button>
                            );
                          })}
                          {groupSizes
                            .filter((s) => s.size && !DEFAULT_SHOE_SIZES.includes(s.size))
                            .map((s) => {
                              const isSold = s.status === 'sold';
                              return (
                                <button
                                  key={s.size}
                                  type="button"
                                  onClick={() => toggleDraftSize(group.colorKey, s.size!)}
                                  className={`min-w-[42px] min-h-[38px] px-2.5 rounded-xl text-xs font-bold border cursor-pointer ${
                                    isSold
                                      ? 'bg-[#B3261E]/15 text-[#B3261E] border-[#B3261E]/40'
                                      : 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                                  }`}
                                >
                                  {s.size} {isSold ? '· مباع' : '×'}
                                </button>
                              );
                            })}
                        </div>

                        <div className="flex gap-1.5">
                          <input
                            type="text"
                            value={customSizeInput[group.colorKey] || ''}
                            onChange={(e) =>
                              setCustomSizeInput((prev) => ({
                                ...prev,
                                [group.colorKey]: e.target.value,
                              }))
                            }
                            onKeyDown={(e) => {
                              if (e.key === 'Enter') {
                                e.preventDefault();
                                const val = (customSizeInput[group.colorKey] || '').trim();
                                if (!val) return;
                                toggleDraftSize(group.colorKey, val);
                                setCustomSizeInput((prev) => ({...prev, [group.colorKey]: ''}));
                              }
                            }}
                            placeholder="مقاس مخصص (مثل 43 أو M)"
                            className="flex-1 min-h-[38px] px-3 rounded-xl bg-white border border-[#E8A91A]/30 text-xs"
                          />
                          <button
                            type="button"
                            onClick={() => {
                              const val = (customSizeInput[group.colorKey] || '').trim();
                              if (!val) return;
                              toggleDraftSize(group.colorKey, val);
                              setCustomSizeInput((prev) => ({...prev, [group.colorKey]: ''}));
                            }}
                            className="min-h-[38px] px-3 rounded-xl bg-[#E8A91A] text-[#141413] text-xs font-bold cursor-pointer"
                          >
                            إضافة
                          </button>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>

            <div className="flex flex-wrap gap-2.5 pt-2">
              <button
                type="submit"
                disabled={savingForm || uploadingPhotos}
                className="flex-1 min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm hover:bg-[#0A3629] disabled:opacity-60 cursor-pointer"
              >
                {uploadingPhotos
                  ? 'استني لحد ما الصور تخلص رفع...'
                  : savingForm
                    ? 'جاري الحفظ...'
                    : 'حفظ المنتج'}
              </button>
              {editingDraft.id && (
                <button
                  type="button"
                  onClick={() => {
                    const targetId = editingDraft.id!;
                    setEditingDraft(null);
                    setPhotos([]);
                    setSelectedKeys([]);
                    setSizesByColor({});
                    setOriginalColorIds({});
                    setDeleteModalIds([targetId]);
                  }}
                  className="min-h-[48px] px-4 rounded-2xl bg-[#B3261E]/10 text-[#B3261E] font-bold text-sm inline-flex items-center gap-1.5 hover:bg-[#B3261E]/20 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>حذف نهائي</span>
                </button>
              )}
              <button
                type="button"
                onClick={closeModalWithoutSaving}
                className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}

      {deleteModalIds && (
        <PermanentDeleteModal
          productIds={deleteModalIds}
          onClose={() => setDeleteModalIds(null)}
          onCompleted={() => {
            setSelectedIds((prev) => prev.filter((id) => !deleteModalIds.includes(id)));
          }}
        />
      )}

      {focusSession && (
        <FocusPointModal
          items={focusSession.items}
          onSaveAll={handleSaveFocusSession}
          onCancel={() => setFocusSession(null)}
        />
      )}
    </div>
  );
};
