import React, {useEffect, useState} from 'react';
import {Check, Plus} from 'lucide-react';

export interface PaletteColorOption {
  name: string;
  hex: string;
}

export const COLOR_PALETTE: PaletteColorOption[] = [
  {name: 'أسود', hex: '#111111'},
  {name: 'أبيض', hex: '#FFFFFF'},
  {name: 'بيج', hex: '#D9C3A0'},
  {name: 'بني', hex: '#6B4226'},
  {name: 'هافان', hex: '#A9744F'},
  {name: 'لبني', hex: '#F3E9D2'},
  {name: 'رمادي', hex: '#8A8A8A'},
  {name: 'كحلي', hex: '#1F2A44'},
  {name: 'أزرق', hex: '#2F6FDE'},
  {name: 'أخضر', hex: '#2E8B57'},
  {name: 'زيتي', hex: '#6B6B2F'},
  {name: 'أحمر', hex: '#C62828'},
  {name: 'عنابي', hex: '#6D1B2E'},
  {name: 'وردي', hex: '#F2A7C0'},
  {name: 'بنفسجي', hex: '#7B4FA3'},
  {name: 'أصفر', hex: '#F2C230'},
  {name: 'دهبي', hex: '#D4AF37'},
  {name: 'فضي', hex: '#C0C0C0'},
];

const LIGHT_CIRCLE_NAMES = new Set(['أبيض', 'لبني', 'فضي']);
const DARK_CHECK_HEXES = new Set(['#FFFFFF', '#F3E9D2', '#D9C3A0', '#F2C230', '#C0C0C0', '#F2A7C0']);

interface ColorPaletteProps {
  value: {name: string | null; hex: string | null};
  onChange: (next: {name: string | null; hex: string | null}) => boolean | void;
  usedNames?: string[];
  compact?: boolean;
  mode?: 'select' | 'apply';
}

export const ColorPalette: React.FC<ColorPaletteProps> = ({
  value,
  onChange,
  usedNames = [],
  compact = false,
  mode = 'select',
}) => {
  const currentName = (value.name || '').trim();
  const matchesPalette = COLOR_PALETTE.some((c) => c.name === currentName);
  const hasCustomValue = mode === 'select' && Boolean(currentName) && !matchesPalette;

  const [customOpen, setCustomOpen] = useState<boolean>(hasCustomValue);
  const [customDraft, setCustomDraft] = useState<string>('');

  useEffect(() => {
    if (hasCustomValue) {
      setCustomOpen(true);
    }
  }, [hasCustomValue]);

  const usedSet = new Set(usedNames.map((n) => n.trim()).filter(Boolean));

  const handleSelectPaletteColor = (opt: PaletteColorOption) => {
    if (mode === 'apply') {
      setCustomOpen(false);
      onChange({name: opt.name, hex: opt.hex});
      return;
    }
    setCustomOpen(false);
    if (currentName === opt.name) {
      onChange({name: null, hex: null});
    } else {
      onChange({name: opt.name, hex: opt.hex});
    }
  };

  const handleToggleCustom = () => {
    if (mode === 'apply') {
      setCustomOpen((prev) => !prev);
      return;
    }
    if (customOpen) {
      setCustomOpen(false);
      if (hasCustomValue) {
        onChange({name: null, hex: null});
      }
    } else {
      setCustomOpen(true);
      if (matchesPalette) {
        onChange({name: null, hex: null});
      }
    }
  };

  const handleApplyCustom = () => {
    const trimmed = customDraft.trim();
    if (!trimmed) return;
    const result = onChange({name: trimmed, hex: null});
    if (result !== false) {
      setCustomDraft('');
      setCustomOpen(false);
    }
  };

  return (
    <div className="space-y-2">
      <div
        className={
          compact
            ? 'grid grid-cols-6 sm:grid-cols-9 gap-x-1.5 gap-y-2'
            : 'grid grid-cols-5 sm:grid-cols-6 gap-x-2 gap-y-2.5'
        }
      >
        {COLOR_PALETTE.map((opt) => {
          const isSelected = mode === 'select' && currentName === opt.name;
          const isUsedElsewhere = !isSelected && usedSet.has(opt.name);
          const needsGrayBorder = LIGHT_CIRCLE_NAMES.has(opt.name);
          const darkCheck = DARK_CHECK_HEXES.has(opt.hex);

          return (
            <button
              key={opt.name}
              type="button"
              onClick={() => handleSelectPaletteColor(opt)}
              title={opt.name}
              aria-label={`لون ${opt.name}${isSelected ? ' (مختار)' : ''}`}
              aria-pressed={mode === 'select' ? isSelected : undefined}
              className={`flex flex-col items-center gap-0.5 cursor-pointer transition-opacity active:scale-95 ${
                isUsedElsewhere ? 'opacity-40 hover:opacity-75' : 'opacity-100'
              }`}
            >
              <span
                style={{backgroundColor: opt.hex}}
                className={`${compact ? 'w-[30px] h-[30px]' : 'w-10 h-10'} rounded-full flex items-center justify-center transition-all ${
                  isSelected
                    ? 'ring-2 ring-[#0F4C3A] ring-offset-2 border-2 border-[#0F4C3A] scale-105 shadow-xs'
                    : needsGrayBorder
                      ? 'border border-[#BDBDBD]'
                      : 'border border-black/15'
                }`}
              >
                {isSelected && (
                  <Check
                    className={`${compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} ${
                      darkCheck ? 'text-[#141413]' : 'text-white'
                    }`}
                    strokeWidth={3}
                  />
                )}
              </span>
              <span
                className={`text-[10px] leading-tight text-center ${
                  isSelected ? 'font-bold text-[#0F4C3A]' : 'font-semibold text-[#5B5B5B]'
                }`}
              >
                {opt.name}
              </span>
            </button>
          );
        })}

        {/* "لون آخر" button */}
        <button
          type="button"
          onClick={handleToggleCustom}
          aria-pressed={customOpen}
          className="flex flex-col items-center justify-start gap-0.5 cursor-pointer"
        >
          <span
            className={`${compact ? 'w-[30px] h-[30px]' : 'w-10 h-10'} rounded-full border-2 border-dashed flex items-center justify-center transition-colors ${
              customOpen
                ? 'border-[#0F4C3A] bg-[#0F4C3A]/10 text-[#0F4C3A]'
                : 'border-[#E8A91A]/60 bg-white text-[#5B5B5B] hover:border-[#0F4C3A]'
            }`}
          >
            <Plus className={compact ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
          </span>
          <span
            className={`text-[10px] leading-tight text-center whitespace-nowrap ${
              customOpen ? 'font-bold text-[#0F4C3A]' : 'font-semibold text-[#5B5B5B]'
            }`}
          >
            لون آخر
          </span>
        </button>
      </div>

      {customOpen && mode === 'apply' && (
        <div className="flex items-center gap-1.5">
          <input
            type="text"
            value={customDraft}
            onChange={(e) => setCustomDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter') {
                e.preventDefault();
                handleApplyCustom();
              }
            }}
            placeholder="اكتبي اسم اللون..."
            className="flex-1 min-h-[38px] px-3 rounded-xl bg-white border border-[#E8A91A]/40 text-xs font-bold text-[#141413]"
          />
          <button
            type="button"
            onClick={handleApplyCustom}
            disabled={!customDraft.trim()}
            className="min-h-[38px] px-3.5 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold disabled:opacity-45 cursor-pointer"
          >
            تطبيق
          </button>
        </div>
      )}

      {customOpen && mode === 'select' && (
        <input
          type="text"
          value={hasCustomValue || !matchesPalette ? value.name || '' : ''}
          onChange={(e) => {
            const val = e.target.value;
            onChange({name: val ? val : null, hex: null});
          }}
          placeholder="اكتبي اسم اللون (اختياري)..."
          className="w-full min-h-[38px] px-3 rounded-xl bg-white border border-[#E8A91A]/40 text-xs font-bold text-[#141413]"
        />
      )}
    </div>
  );
};
