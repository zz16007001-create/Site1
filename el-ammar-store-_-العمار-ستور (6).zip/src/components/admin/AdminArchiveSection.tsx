import React, {useEffect, useMemo, useRef, useState} from 'react';
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  FileArchive,
  FolderArchive,
  RefreshCw,
  Search,
  Trash2,
  Upload,
  X,
} from 'lucide-react';
import {ResilientImage} from '../../components/BrandElements';
import {useStore} from '../../context/StoreContext';
import type {ArchiveProductEntry, Product, StorageDeleteResult} from '../../types/store';
import {
  buildPhoneArchiveZipParts,
  openArchiveZipFile,
  type PreparedArchivePart,
} from '../../utils/archiveZip';
import {
  DEFAULT_FOCUS_X,
  DEFAULT_FOCUS_Y,
  getProductMainImageObj,
  isProductExpired,
} from '../../utils/catalogHelpers';

type ExportScope = 'all' | 'selected' | 'expired' | 'category';

interface PartWithUrl extends PreparedArchivePart {
  objectUrl: string;
}

interface ConflictPromptState {
  productName: string;
  applyToAll: boolean;
  resolve: (choice: {action: 'replace' | 'skip'; applyToAll: boolean}) => void;
}

export const AdminArchiveSection: React.FC = () => {
  const {
    products,
    categories,
    settings,
    permanentlyDeleteProducts,
    retryDeleteStoragePaths,
    ensureArchiveCategories,
    uploadArchiveImageFromBlob,
    upsertRestoredProduct,
    refreshCatalog,
    showToast,
  } = useStore();

  // Export modal state
  const [exportOpen, setExportOpen] = useState(false);
  const [scope, setScope] = useState<ExportScope>('all');
  const [selectedProductIds, setSelectedProductIds] = useState<string[]>([]);
  const [pickerSearch, setPickerSearch] = useState('');
  const [selectedCategoryId, setSelectedCategoryId] = useState<string>('');
  const [exportStep, setExportStep] = useState<
    'select' | 'building' | 'download' | 'confirm_delete' | 'deleting' | 'deleted'
  >('select');
  const [buildProgress, setBuildProgress] = useState<{
    doneProducts: number;
    totalProducts: number;
    currentPart: number;
  } | null>(null);
  const [preparedParts, setPreparedParts] = useState<PartWithUrl[]>([]);
  const [failedArchiveImages, setFailedArchiveImages] = useState(0);
  const [exportedProductIds, setExportedProductIds] = useState<string[]>([]);
  const [downloadedPartNumbers, setDownloadedPartNumbers] = useState<Set<number>>(new Set());
  const [confirmedAllDownloaded, setConfirmedAllDownloaded] = useState(false);
  const [deleteProgress, setDeleteProgress] = useState<{
    stage: 'db' | 'storage';
    done: number;
    total: number;
  } | null>(null);
  const [deleteResult, setDeleteResult] = useState<StorageDeleteResult | null>(null);
  const [retryingDelete, setRetryingDelete] = useState(false);

  // Restore modal state
  const [restoreOpen, setRestoreOpen] = useState(false);
  const [restoreFiles, setRestoreFiles] = useState<File[]>([]);
  const [restoreStep, setRestoreStep] = useState<'pick' | 'restoring' | 'done'>('pick');
  const [restoreProgress, setRestoreProgress] = useState<{
    currentFileIdx: number;
    totalFiles: number;
    doneProducts: number;
    totalProducts: number;
    currentProductName: string;
  } | null>(null);
  const [restoreReport, setRestoreReport] = useState<{
    restored: number;
    skipped: number;
    failed: number;
  } | null>(null);
  const [conflictPrompt, setConflictPrompt] = useState<ConflictPromptState | null>(null);

  const objectUrlsRef = useRef<string[]>([]);

  const revokeAllUrls = () => {
    for (const url of objectUrlsRef.current) {
      URL.revokeObjectURL(url);
    }
    objectUrlsRef.current = [];
  };

  useEffect(() => {
    return () => {
      revokeAllUrls();
    };
  }, []);

  const topCategories = useMemo(
    () => categories.filter((c) => !c.parent_id).sort((a, b) => a.sort - b.sort),
    [categories]
  );

  const expiredProducts = useMemo(
    () => products.filter((p) => isProductExpired(p, settings.expiry_days || 10)),
    [products, settings.expiry_days]
  );

  useEffect(() => {
    if (!selectedCategoryId && topCategories.length > 0) {
      setSelectedCategoryId(topCategories[0].id);
    }
  }, [selectedCategoryId, topCategories]);

  const filteredPickerProducts = useMemo(() => {
    const q = pickerSearch.trim().toLowerCase();
    if (!q) return products;
    return products.filter((p) => p.name.toLowerCase().includes(q));
  }, [pickerSearch, products]);

  const targetExportProducts: Product[] = useMemo(() => {
    if (scope === 'all') return products;
    if (scope === 'expired') return expiredProducts;
    if (scope === 'category') {
      return products.filter((p) => p.category_id === selectedCategoryId);
    }
    const selSet = new Set(selectedProductIds);
    return products.filter((p) => selSet.has(p.id));
  }, [expiredProducts, products, scope, selectedCategoryId, selectedProductIds]);

  const openExportModal = () => {
    revokeAllUrls();
    setExportStep('select');
    setPreparedParts([]);
    setFailedArchiveImages(0);
    setExportedProductIds([]);
    setDownloadedPartNumbers(new Set());
    setConfirmedAllDownloaded(false);
    setDeleteResult(null);
    setBuildProgress(null);
    setExportOpen(true);
  };

  const closeExportModal = () => {
    if (exportStep === 'building' || exportStep === 'deleting' || retryingDelete) return;
    revokeAllUrls();
    setPreparedParts([]);
    setExportOpen(false);
  };

  const handlePrepareArchive = async () => {
    if (targetExportProducts.length === 0) {
      showToast('اختاري منتج واحد على الأقل للأرشفة', 'warning');
      return;
    }
    revokeAllUrls();
    setExportStep('building');
    setBuildProgress({doneProducts: 0, totalProducts: targetExportProducts.length, currentPart: 1});
    try {
      const built = await buildPhoneArchiveZipParts({
        products: targetExportProducts,
        categories,
        onProgress: (p) => setBuildProgress(p),
      });

      const withUrls: PartWithUrl[] = built.parts.map((part) => {
        const url = URL.createObjectURL(part.blob);
        objectUrlsRef.current.push(url);
        return {...part, objectUrl: url};
      });

      setPreparedParts(withUrls);
      setFailedArchiveImages(built.failedImages);
      setExportedProductIds(targetExportProducts.map((p) => p.id));
      setDownloadedPartNumbers(new Set());
      setConfirmedAllDownloaded(false);
      setExportStep('download');
    } catch {
      showToast('تعذر تجهيز ملف الأرشيف', 'warning');
      setExportStep('select');
    }
  };

  const handleDownloadPart = (part: PartWithUrl) => {
    const a = document.createElement('a');
    a.href = part.objectUrl;
    a.download = part.filename;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setDownloadedPartNumbers((prev) => {
      const next = new Set(prev);
      next.add(part.partNumber);
      return next;
    });
  };

  const handleDeleteExportedProducts = async () => {
    if (exportedProductIds.length === 0) return;
    setExportStep('deleting');
    setDeleteProgress(null);
    try {
      const res = await permanentlyDeleteProducts(exportedProductIds, (p) => {
        setDeleteProgress(p);
      });
      setDeleteResult(res);
      setExportStep('deleted');
    } catch {
      showToast('تعذر حذف المنتجات المؤرشفة', 'warning');
      setExportStep('download');
    }
  };

  const handleRetryArchiveStorageDelete = async () => {
    if (!deleteResult || deleteResult.failedPaths.length === 0) return;
    setRetryingDelete(true);
    try {
      const retryRes = await retryDeleteStoragePaths(deleteResult.failedPaths, (p) => {
        setDeleteProgress({stage: 'storage', ...p});
      });
      setDeleteResult({
        deletedProducts: deleteResult.deletedProducts,
        deletedImages: deleteResult.deletedImages + retryRes.deletedImages,
        pinnedImages: deleteResult.pinnedImages,
        failedPaths: retryRes.failedPaths,
      });
    } finally {
      setRetryingDelete(false);
    }
  };

  const formatDeleteSummary = (res: StorageDeleteResult) =>
    `تم حذف ${res.deletedProducts} منتج و${res.deletedImages} صورة، و${res.pinnedImages} صورة محفوظة لأنها في نسخة احتياطية`;

  // Restore flow
  const openRestoreModal = () => {
    setRestoreFiles([]);
    setRestoreStep('pick');
    setRestoreProgress(null);
    setRestoreReport(null);
    setConflictPrompt(null);
    setRestoreOpen(true);
  };

  const closeRestoreModal = () => {
    if (restoreStep === 'restoring') return;
    setRestoreOpen(false);
  };

  const askConflictAction = (productName: string): Promise<{action: 'replace' | 'skip'; applyToAll: boolean}> => {
    return new Promise((resolve) => {
      setConflictPrompt({
        productName,
        applyToAll: false,
        resolve,
      });
    });
  };

  const handleStartRestore = async () => {
    if (restoreFiles.length === 0) {
      showToast('اختاري ملف أو أكثر بصيغة ZIP أولاً', 'warning');
      return;
    }

    setRestoreStep('restoring');
    const catMap = new Map(categories.map((c) => [c.id, c]));
    const existingIds = new Set(products.map((p) => p.id));

    let restoredCount = 0;
    let skippedCount = 0;
    let failedCount = 0;
    let applyAllChoice: 'replace' | 'skip' | null = null;

    for (let fileIdx = 0; fileIdx < restoreFiles.length; fileIdx++) {
      const file = restoreFiles[fileIdx];
      let reader: Awaited<ReturnType<typeof openArchiveZipFile>> | null = null;
      try {
        reader = await openArchiveZipFile(file);
        const entries: ArchiveProductEntry[] = reader.manifest.products || [];

        for (let prodIdx = 0; prodIdx < entries.length; prodIdx++) {
          const entry = entries[prodIdx];
          setRestoreProgress({
            currentFileIdx: fileIdx + 1,
            totalFiles: restoreFiles.length,
            doneProducts: prodIdx,
            totalProducts: entries.length,
            currentProductName: entry.name,
          });

          try {
            if (existingIds.has(entry.id)) {
              let decision: 'replace' | 'skip';
              if (applyAllChoice) {
                decision = applyAllChoice;
              } else {
                const ans = await askConflictAction(entry.name);
                decision = ans.action;
                if (ans.applyToAll) {
                  applyAllChoice = ans.action;
                }
              }
              if (decision === 'skip') {
                skippedCount += 1;
                continue;
              }
            }

            const resolvedCats = await ensureArchiveCategories({
              categoryId: entry.category_id,
              categoryName: entry.category_name,
              subcategoryId: entry.subcategory_id,
              subcategoryName: entry.subcategory_name,
              catMap,
            });

            const restoredColors = [];
            for (let cIdx = 0; cIdx < (entry.colors || []).length; cIdx++) {
              const col = entry.colors[cIdx];
              const uploadedImgs = [];

              for (let iIdx = 0; iIdx < (col.images || []).length; iIdx++) {
                const imgRef = col.images[iIdx];
                let blob: Blob | null = reader.extractImageBlob(imgRef.path);
                if (!blob) continue;
                try {
                  const uploaded = await uploadArchiveImageFromBlob(
                    blob,
                    imgRef.focus_x ?? DEFAULT_FOCUS_X,
                    imgRef.focus_y ?? DEFAULT_FOCUS_Y
                  );
                  uploadedImgs.push(uploaded);
                } finally {
                  blob = null;
                }
              }

              restoredColors.push({
                id: col.id,
                name: col.name,
                hex: col.hex,
                images: uploadedImgs,
                sort: col.sort ?? cIdx + 1,
                sizes: (col.sizes || []).map((s) => ({
                  id: s.id,
                  size: s.size,
                  status: s.status,
                })),
              });
            }

            await upsertRestoredProduct({
              id: entry.id,
              name: entry.name,
              category_id: resolvedCats.categoryId,
              subcategory_id: resolvedCats.subcategoryId,
              description: entry.description || '',
              price: Number(entry.price) || 0,
              old_price: entry.old_price !== null ? Number(entry.old_price) : null,
              visible: Boolean(entry.visible),
              featured: Boolean(entry.featured),
              is_permanent: Boolean(entry.is_permanent),
              listed_at: entry.listed_at || entry.created_at,
              created_at: entry.created_at,
              colors: restoredColors,
              skipRefresh: true,
            });

            existingIds.add(entry.id);
            restoredCount += 1;
          } catch {
            failedCount += 1;
          }

          setRestoreProgress({
            currentFileIdx: fileIdx + 1,
            totalFiles: restoreFiles.length,
            doneProducts: prodIdx + 1,
            totalProducts: entries.length,
            currentProductName: entry.name,
          });
        }
      } catch {
        failedCount += 1;
        showToast(`تعذر قراءة الملف ${file.name}`, 'warning');
      } finally {
        reader?.release();
      }
    }

    await refreshCatalog();
    setRestoreReport({restored: restoredCount, skipped: skippedCount, failed: failedCount});
    setRestoreStep('done');
  };

  return (
    <section className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-5 space-y-4">
      <div className="space-y-1">
        <div className="flex items-center gap-2 text-[#0F4C3A]">
          <FolderArchive className="w-5 h-5 shrink-0" />
          <h3 className="text-base font-bold text-[#141413]">الأرشيف الكامل على الموبايل (ZIP)</h3>
        </div>
        <p className="text-xs text-[#5B5B5B] leading-relaxed">
          احتفظي بنسخة كاملة بالصور الأصلية على موبايلك لتوفير مساحة الموقع أو إعادة رفع الموديلات في أي وقت.
        </p>
      </div>

      <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/40 p-3 flex items-start gap-2.5 text-xs font-bold text-[#141413]">
        <FileArchive className="w-4 h-4 text-[#E8A91A] shrink-0 mt-0.5" />
        <span>ملف الأرشيف بيتحفظ على موبايلك بس — يُنصح تحفظي نسخة منه على Google Drive</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        <button
          type="button"
          onClick={openExportModal}
          className="min-h-[48px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#0A3629] cursor-pointer"
        >
          <Download className="w-4 h-4 text-[#F6CF5A]" />
          <span>حفظ المنتجات على الموبايل</span>
        </button>

        <button
          type="button"
          onClick={openRestoreModal}
          className="min-h-[48px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#0F4C3A]/35 text-[#0F4C3A] text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#F7EFE0] cursor-pointer"
        >
          <Upload className="w-4 h-4" />
          <span>استعادة من أرشيف</span>
        </button>
      </div>

      {/* EXPORT MODAL */}
      {exportOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="حفظ المنتجات على الموبايل"
          onClick={closeExportModal}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#E8A91A]/35 space-y-4"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
              <div className="flex items-center gap-2 text-[#0F4C3A]">
                <FolderArchive className="w-5 h-5" />
                <h4 className="text-base font-bold">حفظ المنتجات على الموبايل</h4>
              </div>
              {exportStep !== 'building' && exportStep !== 'deleting' && !retryingDelete && (
                <button
                  type="button"
                  onClick={closeExportModal}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5 text-[#141413]" />
                </button>
              )}
            </div>

            {exportStep === 'select' && (
              <div className="space-y-4">
                <div className="space-y-2">
                  <p className="text-xs font-bold text-[#5B5B5B]">اختاري المنتجات المطلوب أرشفتها:</p>
                  <div className="grid grid-cols-2 gap-2">
                    {(
                      [
                        {id: 'all', label: `كل المنتجات (${products.length})`},
                        {id: 'expired', label: `قائمة المنتهية (${expiredProducts.length})`},
                        {id: 'category', label: 'قسم واحد'},
                        {id: 'selected', label: `تحديد منتجات (${selectedProductIds.length})`},
                      ] as Array<{id: ExportScope; label: string}>
                    ).map((opt) => (
                      <button
                        key={opt.id}
                        type="button"
                        onClick={() => setScope(opt.id)}
                        className={`min-h-[44px] px-3 rounded-2xl border text-xs font-bold cursor-pointer transition-colors ${
                          scope === opt.id
                            ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                            : 'bg-[#FBF6EA] text-[#141413] border-[#E8A91A]/35'
                        }`}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </div>

                {scope === 'category' && (
                  <label className="block space-y-1">
                    <span className="text-xs font-bold text-[#5B5B5B]">اختاري القسم:</span>
                    <select
                      value={selectedCategoryId}
                      onChange={(e) => setSelectedCategoryId(e.target.value)}
                      className="w-full min-h-[44px] px-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-bold"
                    >
                      {topCategories.map((c) => (
                        <option key={c.id} value={c.id}>
                          {c.name}
                        </option>
                      ))}
                    </select>
                  </label>
                )}

                {scope === 'selected' && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="relative flex-1">
                        <Search className="w-4 h-4 text-[#5B5B5B] absolute right-3 top-1/2 -translate-y-1/2" />
                        <input
                          type="text"
                          value={pickerSearch}
                          onChange={(e) => setPickerSearch(e.target.value)}
                          placeholder="ابحثي باسم المنتج..."
                          className="w-full min-h-[40px] pr-9 pl-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-semibold"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={() => {
                          if (selectedProductIds.length === products.length) {
                            setSelectedProductIds([]);
                          } else {
                            setSelectedProductIds(products.map((p) => p.id));
                          }
                        }}
                        className="min-h-[40px] px-3 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold text-[#0F4C3A] cursor-pointer"
                      >
                        {selectedProductIds.length === products.length ? 'إلغاء' : 'الكل'}
                      </button>
                    </div>

                    <div className="max-h-56 overflow-y-auto space-y-1.5 border border-[#E8A91A]/25 rounded-2xl p-2 bg-[#FBF6EA]/50">
                      {filteredPickerProducts.map((p) => {
                        const checked = selectedProductIds.includes(p.id);
                        const thumb = getProductMainImageObj(p);
                        return (
                          <label
                            key={p.id}
                            className="flex items-center gap-2.5 p-2 rounded-xl bg-white border border-[#E8A91A]/20 cursor-pointer"
                          >
                            <input
                              type="checkbox"
                              checked={checked}
                              onChange={() =>
                                setSelectedProductIds((prev) =>
                                  checked ? prev.filter((x) => x !== p.id) : [...prev, p.id]
                                )
                              }
                              className="w-4 h-4 accent-[#0F4C3A]"
                            />
                            <div className="w-10 h-12 rounded-lg overflow-hidden bg-[#F7EFE0] shrink-0">
                              <ResilientImage
                                src={thumb.thumb}
                                alt={p.name}
                                style={{objectPosition: `${thumb.focus_x}% ${thumb.focus_y}%`}}
                                className="w-full h-full object-cover"
                              />
                            </div>
                            <span className="text-xs font-bold text-[#141413] truncate">
                              {p.name}
                            </span>
                          </label>
                        );
                      })}
                    </div>
                  </div>
                )}

                <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 p-3 text-xs text-[#5B5B5B] leading-relaxed">
                  سيتم تقسيم الأرشيف تلقائيًا إلى ملفات صغيرة (بحد أقصى 40 منتج أو 58 ميجا للملف) بالصور الأصلية الكاملة لسهولة التحميل على الموبايل.
                </div>

                <button
                  type="button"
                  disabled={targetExportProducts.length === 0}
                  onClick={handlePrepareArchive}
                  className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm hover:bg-[#0A3629] disabled:opacity-50 cursor-pointer"
                >
                  تجهيز الأرشيف ({targetExportProducts.length} منتج)
                </button>
              </div>
            )}

            {exportStep === 'building' && (
              <div className="py-6 space-y-3 text-center">
                <RefreshCw className="w-8 h-8 text-[#0F4C3A] animate-spin mx-auto" />
                <p className="text-sm font-bold text-[#141413]">
                  جاري تجهيز الأرشيف ({buildProgress?.doneProducts || 0} /{' '}
                  {buildProgress?.totalProducts || 0}) — الجزء {buildProgress?.currentPart || 1}
                </p>
                {buildProgress && buildProgress.totalProducts > 0 && (
                  <div className="w-full h-2.5 rounded-full bg-[#FBF6EA] overflow-hidden border border-[#E8A91A]/30">
                    <div
                      className="h-full bg-[#0F4C3A] transition-all duration-200"
                      style={{
                        width: `${Math.min(
                          100,
                          Math.round(
                            (buildProgress.doneProducts / buildProgress.totalProducts) * 100
                          )
                        )}%`,
                      }}
                    />
                  </div>
                )}
              </div>
            )}

            {exportStep === 'download' && (
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#0F4C3A]/10 border border-[#0F4C3A]/25 p-3.5 text-xs font-bold text-[#0F4C3A]">
                  تم تجهيز {preparedParts.length} ملف أرشيف لـ {exportedProductIds.length} منتج. نزّلي كل الأجزاء على موبايلك الآن.
                </div>

                {failedArchiveImages > 0 && (
                  <p className="rounded-xl bg-[#E8A91A]/20 p-2.5 text-xs font-bold text-[#141413]">
                    ملاحظة: تعذر سحب {failedArchiveImages} صورة أثناء التجهيز.
                  </p>
                )}

                <div className="space-y-2">
                  {preparedParts.map((part) => {
                    const downloaded = downloadedPartNumbers.has(part.partNumber);
                    const mb = (part.sizeBytes / (1024 * 1024)).toFixed(1);
                    return (
                      <div
                        key={part.partNumber}
                        className={`rounded-2xl border p-3 flex items-center justify-between gap-2 ${
                          downloaded
                            ? 'bg-[#0F4C3A]/8 border-[#0F4C3A]/35'
                            : 'bg-[#FBF6EA] border-[#E8A91A]/35'
                        }`}
                      >
                        <div className="min-w-0">
                          <p className="text-xs font-bold text-[#141413]">
                            الجزء {part.partNumber} من {preparedParts.length}
                          </p>
                          <p className="text-[11px] text-[#5B5B5B] tabular-nums">
                            {part.productCount} منتج · {part.imageCount} صورة · {mb} MB
                          </p>
                        </div>

                        <button
                          type="button"
                          onClick={() => handleDownloadPart(part)}
                          className={`min-h-[42px] px-3.5 rounded-xl text-xs font-bold inline-flex items-center gap-1.5 shrink-0 cursor-pointer ${
                            downloaded
                              ? 'bg-white border border-[#0F4C3A] text-[#0F4C3A]'
                              : 'bg-[#0F4C3A] text-white'
                          }`}
                        >
                          {downloaded ? (
                            <CheckCircle2 className="w-4 h-4" />
                          ) : (
                            <Download className="w-4 h-4 text-[#F6CF5A]" />
                          )}
                          <span>
                            {downloaded
                              ? `اتحمّل (${part.partNumber}/${preparedParts.length})`
                              : `نزّل الجزء ${part.partNumber} من ${preparedParts.length}`}
                          </span>
                        </button>
                      </div>
                    );
                  })}
                </div>

                <div className="rounded-2xl bg-[#FFF9F8] border border-[#B3261E]/30 p-3.5 space-y-3">
                  <label className="flex items-start gap-2.5 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={confirmedAllDownloaded}
                      onChange={(e) => setConfirmedAllDownloaded(e.target.checked)}
                      className="w-5 h-5 mt-0.5 accent-[#B3261E] shrink-0"
                    />
                    <span className="text-xs font-bold text-[#141413]">
                      اتأكدت إن كل الأجزاء اتحملت على موبايلي أو Google Drive بنجاح
                    </span>
                  </label>

                  <button
                    type="button"
                    disabled={!confirmedAllDownloaded}
                    onClick={() => setExportStep('confirm_delete')}
                    className="w-full min-h-[46px] rounded-xl bg-[#B3261E] text-white text-xs sm:text-sm font-bold inline-flex items-center justify-center gap-2 hover:bg-[#8E1C16] disabled:opacity-45 cursor-pointer"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>احذف المنتجات دي من الموقع لتوفير المساحة</span>
                  </button>
                </div>
              </div>
            )}

            {exportStep === 'confirm_delete' && (
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/30 p-4 flex items-start gap-2.5 text-[#B3261E]">
                  <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
                  <p className="text-xs sm:text-sm font-bold leading-relaxed">
                    هل أنتِ متأكدة من حذف {exportedProductIds.length} منتج من الموقع بعد تنزيل الأرشيف؟ الصور المثبتة في نسخ احتياطية سريعة ستبقى محفوظة.
                  </p>
                </div>

                <div className="flex gap-2.5">
                  <button
                    type="button"
                    onClick={handleDeleteExportedProducts}
                    className="flex-1 min-h-[48px] rounded-2xl bg-[#B3261E] text-white font-bold text-sm hover:bg-[#8E1C16] cursor-pointer"
                  >
                    نعم، احذف لتوفير المساحة
                  </button>
                  <button
                    type="button"
                    onClick={() => setExportStep('download')}
                    className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
                  >
                    رجوع
                  </button>
                </div>
              </div>
            )}

            {exportStep === 'deleting' && (
              <div className="py-6 space-y-3 text-center">
                <RefreshCw className="w-8 h-8 text-[#0F4C3A] animate-spin mx-auto" />
                <p className="text-sm font-bold text-[#141413]">
                  {deleteProgress?.stage === 'storage'
                    ? `جاري حذف الصور من التخزين (${deleteProgress.done} / ${deleteProgress.total})...`
                    : 'جاري حذف المنتجات المؤرشفة...'}
                </p>
              </div>
            )}

            {exportStep === 'deleted' && deleteResult && (
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#0F4C3A]/10 border border-[#0F4C3A]/25 p-4 flex items-center gap-2.5 text-[#0F4C3A]">
                  <CheckCircle2 className="w-6 h-6 shrink-0" />
                  <p className="text-sm font-bold leading-relaxed">
                    {formatDeleteSummary(deleteResult)}
                  </p>
                </div>

                {deleteResult.failedPaths.length > 0 && (
                  <button
                    type="button"
                    disabled={retryingDelete}
                    onClick={handleRetryArchiveStorageDelete}
                    className="w-full min-h-[44px] rounded-xl bg-[#B3261E] text-white text-xs font-bold inline-flex items-center justify-center gap-1.5 cursor-pointer"
                  >
                    <RefreshCw className={`w-4 h-4 ${retryingDelete ? 'animate-spin' : ''}`} />
                    <span>إعادة محاولة حذف الصور المتبقية ({deleteResult.failedPaths.length})</span>
                  </button>
                )}

                <button
                  type="button"
                  disabled={retryingDelete}
                  onClick={closeExportModal}
                  className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm cursor-pointer"
                >
                  إغلاق
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* RESTORE MODAL */}
      {restoreOpen && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          aria-label="استعادة من أرشيف"
          onClick={closeRestoreModal}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-lg max-h-[90vh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 shadow-2xl border border-[#E8A91A]/35 space-y-4"
          >
            <div className="flex items-center justify-between gap-2 pb-2 border-b border-[#E8A91A]/20">
              <div className="flex items-center gap-2 text-[#0F4C3A]">
                <Upload className="w-5 h-5" />
                <h4 className="text-base font-bold">استعادة من أرشيف الموبايل</h4>
              </div>
              {restoreStep !== 'restoring' && (
                <button
                  type="button"
                  onClick={closeRestoreModal}
                  aria-label="إغلاق"
                  className="min-w-[40px] min-h-[40px] rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-5 h-5 text-[#141413]" />
                </button>
              )}
            </div>

            {restoreStep === 'pick' && (
              <div className="space-y-4">
                <p className="text-xs text-[#5B5B5B] leading-relaxed">
                  اختاري ملف أو أكثر من أجزاء الأرشيف (ZIP). سيتم رفع الصور الأصلية وتوليد الصور المصغرة تلقائيًا وربط الأقسام والفرعيات.
                </p>

                <label className="w-full min-h-[96px] rounded-2xl border-2 border-dashed border-[#0F4C3A]/40 bg-[#FBF6EA] flex flex-col items-center justify-center gap-1.5 p-4 text-center cursor-pointer">
                  <FileArchive className="w-6 h-6 text-[#0F4C3A]" />
                  <span className="text-xs sm:text-sm font-bold text-[#0F4C3A]">
                    اختاري ملفات الأرشيف (.zip)
                  </span>
                  <span className="text-[11px] text-[#5B5B5B]">
                    تقدري تختاري جزء واحد أو عدة أجزاء مع بعض
                  </span>
                  <input
                    type="file"
                    accept=".zip,application/zip"
                    multiple
                    onChange={(e) => {
                      const list = Array.from(e.target.files || []);
                      setRestoreFiles(list);
                    }}
                    className="hidden"
                  />
                </label>

                {restoreFiles.length > 0 && (
                  <div className="space-y-1.5">
                    {restoreFiles.map((f, idx) => (
                      <div
                        key={`${f.name}-${idx}`}
                        className="rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 px-3 py-2 flex items-center justify-between text-xs font-bold text-[#141413]"
                      >
                        <span className="truncate">{f.name}</span>
                        <span className="text-[#5B5B5B] shrink-0 tabular-nums">
                          {(f.size / (1024 * 1024)).toFixed(1)} MB
                        </span>
                      </div>
                    ))}
                  </div>
                )}

                <button
                  type="button"
                  disabled={restoreFiles.length === 0}
                  onClick={handleStartRestore}
                  className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm hover:bg-[#0A3629] disabled:opacity-50 cursor-pointer"
                >
                  بدء الاستعادة ({restoreFiles.length} ملف)
                </button>
              </div>
            )}

            {restoreStep === 'restoring' && (
              <div className="space-y-4">
                <div className="py-3 space-y-2.5 text-center">
                  <RefreshCw className="w-8 h-8 text-[#0F4C3A] animate-spin mx-auto" />
                  <p className="text-sm font-bold text-[#141413]">
                    ملف {restoreProgress?.currentFileIdx || 1} من {restoreProgress?.totalFiles || 1}{' '}
                    — منتج {restoreProgress?.doneProducts || 0} من{' '}
                    {restoreProgress?.totalProducts || 0}
                  </p>
                  {restoreProgress?.currentProductName && (
                    <p className="text-xs text-[#5B5B5B] truncate">
                      {restoreProgress.currentProductName}
                    </p>
                  )}
                  {restoreProgress && restoreProgress.totalProducts > 0 && (
                    <div className="w-full h-2.5 rounded-full bg-[#FBF6EA] overflow-hidden border border-[#E8A91A]/30">
                      <div
                        className="h-full bg-[#0F4C3A] transition-all duration-200"
                        style={{
                          width: `${Math.min(
                            100,
                            Math.round(
                              (restoreProgress.doneProducts / restoreProgress.totalProducts) * 100
                            )
                          )}%`,
                        }}
                      />
                    </div>
                  )}
                </div>

                {conflictPrompt && (
                  <div className="rounded-2xl bg-[#FFF9F8] border-2 border-[#E8A91A] p-4 space-y-3">
                    <p className="text-xs sm:text-sm font-bold text-[#141413]">
                      المنتج «{conflictPrompt.productName}» موجود بالفعل في الموقع:
                    </p>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={conflictPrompt.applyToAll}
                        onChange={(e) =>
                          setConflictPrompt((prev) =>
                            prev ? {...prev, applyToAll: e.target.checked} : null
                          )
                        }
                        className="w-4 h-4 accent-[#0F4C3A]"
                      />
                      <span className="text-xs font-semibold text-[#5B5B5B]">
                        تطبيق نفس الاختيار على كل المنتجات المتكررة
                      </span>
                    </label>
                    <div className="flex gap-2">
                      <button
                        type="button"
                        onClick={() => {
                          const {resolve, applyToAll} = conflictPrompt;
                          setConflictPrompt(null);
                          resolve({action: 'replace', applyToAll});
                        }}
                        className="flex-1 min-h-[44px] rounded-xl bg-[#0F4C3A] text-white text-xs font-bold cursor-pointer"
                      >
                        استبدال
                      </button>
                      <button
                        type="button"
                        onClick={() => {
                          const {resolve, applyToAll} = conflictPrompt;
                          setConflictPrompt(null);
                          resolve({action: 'skip', applyToAll});
                        }}
                        className="flex-1 min-h-[44px] rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/40 text-[#141413] text-xs font-bold cursor-pointer"
                      >
                        تخطي
                      </button>
                    </div>
                  </div>
                )}
              </div>
            )}

            {restoreStep === 'done' && restoreReport && (
              <div className="space-y-4">
                <div className="rounded-2xl bg-[#0F4C3A]/10 border border-[#0F4C3A]/25 p-4 flex items-center gap-2.5 text-[#0F4C3A]">
                  <CheckCircle2 className="w-6 h-6 shrink-0" />
                  <p className="text-sm font-bold leading-relaxed">
                    تمت استعادة {restoreReport.restored} منتج، وتخطي {restoreReport.skipped}، وفشل{' '}
                    {restoreReport.failed}.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={closeRestoreModal}
                  className="w-full min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm cursor-pointer"
                >
                  تم
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
