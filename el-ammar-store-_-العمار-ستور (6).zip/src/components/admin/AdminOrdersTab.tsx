import React, {useEffect, useMemo, useState} from 'react';
import {
  AlertTriangle,
  BarChart3,
  Check,
  MessageCircle,
  PhoneCall,
  RefreshCw,
  RotateCcw,
  Search,
  Trash2,
  X,
} from 'lucide-react';
import {EmptyState, ResilientImage} from '../../components/BrandElements';
import {useStore} from '../../context/StoreContext';
import type {OrderStatus} from '../../types/store';
import {
  cleanColorName,
  formatPrice,
  getWhatsAppUrl,
  normalizeEgyptianPhone,
  openExternalUrl,
} from '../../utils/catalogHelpers';

export const AdminOrdersTab: React.FC = () => {
  const {
    orders,
    ordersLoading,
    fetchOrders,
    markOrderDelivered,
    markOrderCancelled,
    markOrderUndo,
    deleteOrder,
    deleteAllCancelledOrders,
    isDemoMode,
  } = useStore();

  const [statusFilter, setStatusFilter] = useState<'all' | OrderStatus>('all');
  const [searchNo, setSearchNo] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [confirmDeleteOrderId, setConfirmDeleteOrderId] = useState<string | null>(null);
  const [confirmDeleteAllCancelled, setConfirmDeleteAllCancelled] = useState(false);
  const [deletingAllCancelled, setDeletingAllCancelled] = useState(false);

  useEffect(() => {
    if (!isDemoMode) {
      fetchOrders();
    }
  }, [isDemoMode, fetchOrders]);

  // Count how many active ('new') orders request each (product_id, color_id, size_id)
  const conflictCounts = useMemo(() => {
    const map = new Map<string, number>();
    for (const o of orders) {
      if (o.status !== 'new') continue;
      const seenInOrder = new Set<string>();
      for (const item of o.items) {
        if (!item.product_id || !item.color_id || !item.size_id) continue;
        const key = `${item.product_id}__${item.color_id}__${item.size_id}`;
        if (!seenInOrder.has(key)) {
          seenInOrder.add(key);
          map.set(key, (map.get(key) || 0) + 1);
        }
      }
    }
    return map;
  }, [orders]);

  const cancelledOrdersCount = useMemo(
    () => orders.filter((o) => o.status === 'cancelled').length,
    [orders]
  );

  const orderStats = useMemo(() => {
    const startOfToday = new Date();
    startOfToday.setHours(0, 0, 0, 0);
    const todayMs = startOfToday.getTime();
    const sevenDaysMs = Date.now() - 7 * 86400000;

    let todayCount = 0;
    let weekCount = 0;
    const modelCounts = new Map<string, number>();
    const sizeCounts = new Map<string, number>();

    for (const o of orders) {
      if (o.status === 'cancelled') continue;
      const t = new Date(o.created_at).getTime();
      if (!Number.isNaN(t)) {
        if (t >= todayMs) todayCount += 1;
        if (t >= sevenDaysMs) weekCount += 1;
      }
      for (const item of o.items) {
        const qty = Math.max(1, Number(item.qty) || 1);
        const name = (item.name_snapshot || '').trim();
        if (name) {
          modelCounts.set(name, (modelCounts.get(name) || 0) + qty);
        }
        const sz = (item.size_snapshot || '').trim();
        if (sz) {
          sizeCounts.set(sz, (sizeCounts.get(sz) || 0) + qty);
        }
      }
    }

    const topModels = Array.from(modelCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);
    const topSizes = Array.from(sizeCounts.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5);

    return {todayCount, weekCount, topModels, topSizes};
  }, [orders]);

  const filtered = useMemo(() => {
    const q = searchNo.trim().replace(/^#/, '');
    return orders.filter((o) => {
      // "الكل" must NEVER list cancelled orders; only "ملغي" shows them
      if (statusFilter === 'all' && o.status === 'cancelled') return false;
      if (statusFilter !== 'all' && o.status !== statusFilter) return false;
      if (q) {
        const matchesNo = String(o.order_no).includes(q);
        const matchesPhone = Boolean(o.customer_phone && o.customer_phone.includes(q));
        if (!matchesNo && !matchesPhone) return false;
      }
      return true;
    });
  }, [orders, statusFilter, searchNo]);

  const runAction = async (orderId: string, fn: () => Promise<void>) => {
    setBusyId(orderId);
    try {
      await fn();
    } finally {
      setBusyId(null);
    }
  };

  const orderToConfirmDelete = useMemo(
    () => orders.find((o) => o.id === confirmDeleteOrderId) || null,
    [orders, confirmDeleteOrderId]
  );

  return (
    <div className="space-y-4">
      {/* Lightweight Orders Summary Report */}
      {orders.length > 0 && (
        <section
          aria-label="ملخص الطلبات"
          className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-4 space-y-3 shadow-xs"
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <div className="flex items-center gap-2 text-[#0F4C3A]">
              <BarChart3 className="w-4 h-4 shrink-0" />
              <h2 className="text-sm font-bold text-[#141413]">ملخص الطلبات</h2>
            </div>
            <div className="flex items-center gap-3 text-xs font-bold tabular-nums">
              <span className="text-[#0F4C3A]">النهاردة: {orderStats.todayCount}</span>
              <span aria-hidden="true" className="text-[#E8A91A]">·</span>
              <span className="text-[#141413]">آخر 7 أيام: {orderStats.weekCount}</span>
            </div>
          </div>

          {(orderStats.topModels.length > 0 || orderStats.topSizes.length > 0) && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-2 border-t border-[#E8A91A]/15 text-xs">
              {orderStats.topModels.length > 0 && (
                <div className="space-y-1">
                  <p className="font-bold text-[#5B5B5B]">أكثر 5 موديلات طلبًا</p>
                  <div className="space-y-1">
                    {orderStats.topModels.map(([name, qty]) => (
                      <div key={name} className="flex items-center justify-between gap-2">
                        <span className="font-semibold text-[#141413] truncate">{name}</span>
                        <span className="font-bold text-[#0F4C3A] tabular-nums shrink-0">
                          {qty} قطعة
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {orderStats.topSizes.length > 0 && (
                <div className="space-y-1">
                  <p className="font-bold text-[#5B5B5B]">أكثر 5 مقاسات طلبًا</p>
                  <div className="flex flex-wrap gap-2 tabular-nums">
                    {orderStats.topSizes.map(([sz, qty]) => (
                      <span
                        key={sz}
                        className="px-2.5 py-1 rounded-xl bg-[#FBF6EA] border border-[#E8A91A]/30 font-bold text-[#141413]"
                      >
                        مقاس {sz} ({qty})
                      </span>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </section>
      )}

      {/* Top Controls */}
      <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
        <div className="relative flex-1 max-w-xs">
          <Search className="w-4 h-4 text-[#5B5B5B] absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="search"
            value={searchNo}
            onChange={(e) => setSearchNo(e.target.value)}
            placeholder="بحث برقم الطلب أو رقم الموبايل..."
            className="w-full min-h-[44px] pr-10 pl-4 rounded-2xl bg-white border border-[#E8A91A]/35 text-sm"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {(
            [
              {id: 'all', label: 'الكل'},
              {id: 'new', label: 'جديد'},
              {id: 'delivered', label: 'تم التسليم'},
              {
                id: 'cancelled',
                label: cancelledOrdersCount > 0 ? `ملغي (${cancelledOrdersCount})` : 'ملغي',
              },
            ] as const
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setStatusFilter(tab.id)}
              className={`min-h-[40px] px-3.5 rounded-2xl text-xs font-bold whitespace-nowrap cursor-pointer ${
                statusFilter === tab.id
                  ? 'bg-[#0F4C3A] text-white'
                  : 'bg-white text-[#141413] border border-[#E8A91A]/30'
              }`}
            >
              {tab.label}
            </button>
          ))}

          {!isDemoMode && (
            <button
              type="button"
              onClick={fetchOrders}
              aria-label="تحديث الطلبات"
              className="min-w-[40px] min-h-[40px] rounded-2xl bg-white border border-[#E8A91A]/30 flex items-center justify-center cursor-pointer"
            >
              <RefreshCw className={`w-4 h-4 ${ordersLoading ? 'animate-spin' : ''}`} />
            </button>
          )}
        </div>
      </div>

      {/* Delete All Cancelled Bar inside "ملغي" tab */}
      {statusFilter === 'cancelled' && cancelledOrdersCount > 0 && (
        <div className="rounded-2xl bg-[#B3261E]/10 border border-[#B3261E]/30 p-3 flex flex-wrap items-center justify-between gap-2">
          <p className="text-xs sm:text-sm font-bold text-[#B3261E] tabular-nums">
            إجمالي الطلبات الملغية: {cancelledOrdersCount} طلب
          </p>
          <button
            type="button"
            onClick={() => setConfirmDeleteAllCancelled(true)}
            className="min-h-[42px] px-4 rounded-xl bg-[#B3261E] text-white text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#8E1C16] cursor-pointer"
          >
            <Trash2 className="w-4 h-4" />
            <span>حذف كل الملغي</span>
          </button>
        </div>
      )}

      {/* Orders List */}
      {filtered.length === 0 ? (
        <EmptyState
          title="لا توجد طلبات مطابقة"
          subtitle={
            statusFilter === 'all'
              ? 'الطلبات الجديدة والتي تم تسليمها تظهر هنا (الملغية في تبويب ملغي).'
              : 'الطلبات التي يرسلها العملاء عبر واتساب أو ماسنجر تظهر هنا.'
          }
        />
      ) : (
        <div className="space-y-4">
          {filtered.map((order) => {
            const total = order.items.reduce(
              (sum, i) => sum + i.price_snapshot * i.qty,
              0
            );
            const statusText =
              order.status === 'new'
                ? 'طلب جديد (في انتظار التأكيد)'
                : order.status === 'delivered'
                  ? 'تم التسليم والدفع'
                  : 'ملغي';
            const statusColor =
              order.status === 'new'
                ? 'text-[#0F4C3A]'
                : order.status === 'delivered'
                  ? 'text-[#141413]'
                  : 'text-[#B3261E]';

            return (
              <div
                key={order.id}
                className="rounded-[24px] bg-white border border-[#E8A91A]/30 p-4 sm:p-5 shadow-xs space-y-4"
              >
                <div className="flex flex-wrap items-center justify-between gap-2 pb-3 border-b border-[#E8A91A]/15">
                  <div className="space-y-0.5">
                    <div className="flex items-center gap-2 text-base font-bold text-[#141413] tabular-nums">
                      <span>طلب #{order.order_no}</span>
                      <span aria-hidden="true">·</span>
                      <span
                        className={`text-xs font-bold ${
                          order.channel === 'callback' ? 'text-[#0F4C3A]' : 'text-[#5B5B5B]'
                        }`}
                      >
                        {order.channel === 'whatsapp'
                          ? 'واتساب'
                          : order.channel === 'messenger'
                            ? 'ماسنجر'
                            : 'طلب مكالمة'}
                      </span>
                    </div>
                    <p className={`text-xs font-bold ${statusColor}`}>{statusText}</p>
                  </div>

                  <div className="text-left tabular-nums">
                    <p className="text-base font-bold text-[#0F4C3A]">{formatPrice(total)}</p>
                    <p className="text-[11px] text-[#5B5B5B]">
                      {new Date(order.created_at).toLocaleString('ar-EG', {
                        month: 'short',
                        day: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                </div>

                {order.customer_phone && (() => {
                  const parsedPhone = normalizeEgyptianPhone(order.customer_phone);
                  const itemNames = order.items
                    .map((i) => `${i.name_snapshot}${i.size_snapshot ? ` (مقاس ${i.size_snapshot})` : ''}`)
                    .join('، ');
                  const waText = `أهلاً بكِ يا فندم 🌸 بخصوص طلبك رقم #${order.order_no} من العمار ستور (${itemNames}) — حابين نأكد معاكي التوافر وعنوان الشحن.`;
                  const waNumber = parsedPhone.whatsappIntl || order.customer_phone;
                  return (
                    <div className="rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/40 p-3 flex flex-wrap items-center justify-between gap-2.5">
                      <div className="flex items-center gap-2">
                        <PhoneCall className="w-4 h-4 text-[#0F4C3A] shrink-0" />
                        <span className="text-xs font-bold text-[#5B5B5B]">موبايل العميلة:</span>
                        <span dir="ltr" className="text-sm font-bold text-[#141413] tabular-nums">
                          {order.customer_phone}
                        </span>
                      </div>
                      <div className="flex flex-wrap items-center gap-2">
                        <a
                          href={`tel:${order.customer_phone}`}
                          className="min-h-[38px] px-3 rounded-xl bg-white border border-[#0F4C3A]/35 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 hover:bg-[#0F4C3A]/5"
                        >
                          <PhoneCall className="w-3.5 h-3.5" />
                          <span>اتصال</span>
                        </a>
                        <button
                          type="button"
                          onClick={() => openExternalUrl(getWhatsAppUrl(waNumber, waText))}
                          className="min-h-[38px] px-3 rounded-xl bg-[#0F4C3A] text-white text-xs font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] cursor-pointer"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-[#F6CF5A]" />
                          <span>واتساب للعميلة</span>
                        </button>
                      </div>
                    </div>
                  );
                })()}

                {/* Items */}
                <div className="space-y-2.5">
                  {order.items.map((item) => {
                    const key =
                      item.product_id && item.color_id && item.size_id
                        ? `${item.product_id}__${item.color_id}__${item.size_id}`
                        : null;
                    const hasConflict =
                      Boolean(key) && order.status === 'new' && (conflictCounts.get(key!) || 0) > 1;
                    return (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 rounded-2xl bg-[#FBF6EA]/70 p-2.5"
                      >
                        <div className="w-14 h-14 rounded-xl overflow-hidden bg-white border border-[#E8A91A]/20 shrink-0">
                          <ResilientImage
                            src={item.thumbnail_url || undefined}
                            alt={item.name_snapshot}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0 space-y-1">
                          <p className="text-sm font-bold text-[#141413] truncate">
                            {item.name_snapshot}
                          </p>
                          <div className="flex flex-wrap items-center gap-2 text-xs text-[#5B5B5B] tabular-nums">
                            {cleanColorName(item.color_snapshot) && (
                              <span>اللون: {cleanColorName(item.color_snapshot)}</span>
                            )}
                            {item.size_snapshot && <span>المقاس: {item.size_snapshot}</span>}
                            <span>
                              {item.qty} × {formatPrice(item.price_snapshot)}
                            </span>
                          </div>
                          {hasConflict && (
                            <div className="inline-flex items-center gap-1 text-xs font-bold text-[#B3261E] bg-[#B3261E]/10 px-2.5 py-1 rounded-lg">
                              <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                              <span>القطعة دي مطلوبة في طلب تاني</span>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Actions */}
                <div className="flex flex-wrap gap-2 pt-1">
                  {order.status === 'new' && (
                    <>
                      <button
                        type="button"
                        disabled={busyId === order.id}
                        onClick={() => runAction(order.id, () => markOrderDelivered(order.id))}
                        className="min-h-[44px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] disabled:opacity-50 cursor-pointer"
                      >
                        <Check className="w-4 h-4 text-[#F6CF5A]" />
                        <span>تم التسليم والدفع (تم البيع)</span>
                      </button>
                      <button
                        type="button"
                        disabled={busyId === order.id}
                        onClick={() => runAction(order.id, () => markOrderCancelled(order.id))}
                        className="min-h-[44px] px-4 rounded-2xl bg-white border border-[#B3261E]/35 text-[#B3261E] text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#B3261E]/5 disabled:opacity-50 cursor-pointer"
                      >
                        <X className="w-4 h-4" />
                        <span>إلغاء</span>
                      </button>
                    </>
                  )}

                  {order.status === 'delivered' && (
                    <button
                      type="button"
                      disabled={busyId === order.id}
                      onClick={() => runAction(order.id, () => markOrderUndo(order.id))}
                      className="min-h-[44px] px-4 rounded-2xl bg-[#E8A91A] text-[#141413] text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#F6CF5A] disabled:opacity-50 cursor-pointer"
                    >
                      <RotateCcw className="w-4 h-4" />
                      <span>تراجع وإرجاع للمتاح</span>
                    </button>
                  )}

                  {order.status === 'cancelled' && (
                    <>
                      <button
                        type="button"
                        disabled={busyId === order.id}
                        onClick={() => runAction(order.id, () => markOrderUndo(order.id))}
                        className="min-h-[44px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#0A3629] disabled:opacity-50 cursor-pointer"
                      >
                        <RotateCcw className="w-4 h-4 text-[#F6CF5A]" />
                        <span>إعادة فتح الطلب</span>
                      </button>
                      <button
                        type="button"
                        disabled={busyId === order.id}
                        onClick={() => setConfirmDeleteOrderId(order.id)}
                        className="min-h-[44px] px-4 rounded-2xl bg-[#B3261E]/10 text-[#B3261E] text-xs sm:text-sm font-bold inline-flex items-center gap-1.5 hover:bg-[#B3261E]/20 disabled:opacity-50 cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                        <span>حذف نهائي</span>
                      </button>
                    </>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Confirm Single Cancelled Order Permanent Delete */}
      {orderToConfirmDelete && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => setConfirmDeleteOrderId(null)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-t-3xl sm:rounded-3xl bg-white p-5 space-y-4 shadow-2xl"
          >
            <h3 className="text-base font-bold text-[#B3261E]">
              تأكيد حذف الطلب #{orderToConfirmDelete.order_no}
            </h3>
            <p className="text-xs sm:text-sm text-[#5B5B5B] leading-relaxed">
              هل أنتِ متأكدة من الحذف النهائي للطلب #{orderToConfirmDelete.order_no}؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                disabled={busyId === orderToConfirmDelete.id}
                onClick={async () => {
                  const id = orderToConfirmDelete.id;
                  await runAction(id, () => deleteOrder(id));
                  setConfirmDeleteOrderId(null);
                }}
                className="flex-1 min-h-[46px] rounded-2xl bg-[#B3261E] text-white text-sm font-bold cursor-pointer"
              >
                حذف نهائي
              </button>
              <button
                type="button"
                onClick={() => setConfirmDeleteOrderId(null)}
                className="min-h-[46px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] text-sm font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Confirm Delete All Cancelled Orders */}
      {confirmDeleteAllCancelled && (
        <div
          className="fixed inset-0 z-[100] bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4"
          role="dialog"
          aria-modal="true"
          onClick={() => !deletingAllCancelled && setConfirmDeleteAllCancelled(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-sm rounded-t-3xl sm:rounded-3xl bg-white p-5 space-y-4 shadow-2xl"
          >
            <h3 className="text-base font-bold text-[#B3261E]">حذف جميع الطلبات الملغية</h3>
            <p className="text-xs sm:text-sm text-[#5B5B5B] leading-relaxed">
              هل أنتِ متأكدة من حذف جميع الطلبات الملغية ({cancelledOrdersCount} طلب) نهائيًا؟ لا يمكن التراجع عن هذا الإجراء.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                disabled={deletingAllCancelled}
                onClick={async () => {
                  setDeletingAllCancelled(true);
                  try {
                    await deleteAllCancelledOrders();
                    setConfirmDeleteAllCancelled(false);
                  } finally {
                    setDeletingAllCancelled(false);
                  }
                }}
                className="flex-1 min-h-[46px] rounded-2xl bg-[#B3261E] text-white text-sm font-bold cursor-pointer disabled:opacity-50"
              >
                {deletingAllCancelled ? 'جاري الحذف...' : `حذف الكل (${cancelledOrdersCount})`}
              </button>
              <button
                type="button"
                disabled={deletingAllCancelled}
                onClick={() => setConfirmDeleteAllCancelled(false)}
                className="min-h-[46px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] text-sm font-bold cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
