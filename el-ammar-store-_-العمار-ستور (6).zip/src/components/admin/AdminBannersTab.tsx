import React, {useMemo, useState} from 'react';
import {ArrowDown, ArrowUp, Camera, Edit3, Eye, EyeOff, Plus, Trash2, X} from 'lucide-react';
import {ResilientImage} from '../../components/BrandElements';
import {HeroCarousel} from '../../components/HeroCarousel';
import {useStore} from '../../context/StoreContext';
import type {Banner, BannerType} from '../../types/store';

const SLIDE_TYPES: Array<{value: BannerType; label: string; hint: string}> = [
  {value: 'offer', label: 'عرض', hint: 'خصم مع صورة واحدة وإمكانية إضافة عداد تنازلي بتاريخ حقيقي'},
  {value: 'new_arrivals', label: 'وصل جديد (تلقائي)', hint: 'يعرض أحدث 3 منتجات متاحة تلقائياً بصور متداخلة'},
  {value: 'biggest_discount', label: 'أقوى خصم (تلقائي)', hint: 'يعرض أكثر 3 منتجات عليها خصم تلقائياً بصور متداخلة'},
  {value: 'featured_product', label: 'منتج مميز', hint: 'يعرض المنتجات المميزة (حتى 3 منتجات) أو منتجاً واحداً تختارينه'},
  {value: 'message', label: 'رسالة حرة', hint: 'صورة واحدة ونص مخصص مع زر توجيه لأي صفحة'},
];

export const AdminBannersTab: React.FC = () => {
  const {banners, categories, products, saveBanner, deleteBanner, reorderBanners, uploadImage} =
    useStore();

  const [editing, setEditing] = useState<Partial<Banner> | null>(null);

  const sorted = useMemo(() => [...banners].sort((a, b) => a.sort - b.sort), [banners]);
  const topCategories = useMemo(
    () => categories.filter((c) => !c.parent_id).sort((a, b) => a.sort - b.sort),
    [categories]
  );

  const move = async (idx: number, dir: -1 | 1) => {
    const target = idx + dir;
    if (target < 0 || target >= sorted.length) return;
    const ids = sorted.map((b) => b.id);
    const [m] = ids.splice(idx, 1);
    ids.splice(target, 0, m);
    await reorderBanners(ids);
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editing) return;
    const type = editing.type || 'message';
    const fallbackTitle =
      type === 'new_arrivals'
        ? 'وصل حديثاً'
        : type === 'biggest_discount'
          ? 'أقوى خصم الآن'
          : '';
    const finalTitle = (editing.title || fallbackTitle).trim();
    if (!finalTitle) return;

    await saveBanner({
      ...editing,
      type,
      title: finalTitle,
      subtitle: editing.subtitle || '',
      btn_text: editing.btn_text || 'تسوقي الآن',
      link: editing.link || '/catalog',
      product_id: editing.product_id || null,
      category_id: editing.category_id || null,
      ends_at: editing.ends_at ? new Date(editing.ends_at).toISOString() : null,
      active: editing.active ?? true,
      sort: editing.sort ?? sorted.length + 1,
    });
    setEditing(null);
  };

  const toDatetimeLocalValue = (iso?: string | null): string => {
    if (!iso) return '';
    const d = new Date(iso);
    if (Number.isNaN(d.getTime())) return '';
    const pad = (n: number) => String(n).padStart(2, '0');
    return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
  };

  const previewBannerObject: Banner | null = editing
    ? {
        id: editing.id || 'preview',
        type: editing.type || 'message',
        title: editing.title || '',
        subtitle: editing.subtitle || '',
        btn_text: editing.btn_text || 'تسوقي الآن',
        link: editing.link || '/catalog',
        image_url: editing.image_url || null,
        product_id: editing.product_id || null,
        category_id: editing.category_id || null,
        ends_at: editing.ends_at || null,
        active: true,
        sort: 1,
      }
    : null;

  return (
    <div className="space-y-5">
      <div className="flex justify-between items-center gap-2">
        <p className="text-xs font-semibold text-[#5B5B5B]">
          شرائح الكارت الذهبي التسويقي (5 أنواع ذكية وتلقائية)
        </p>
        <button
          type="button"
          onClick={() =>
            setEditing({
              type: 'offer',
              title: '',
              subtitle: '',
              btn_text: 'شوفي العروض',
              link: '/offers',
              image_url: null,
              product_id: null,
              category_id: null,
              ends_at: null,
              active: true,
            })
          }
          className="min-h-[44px] px-4 rounded-2xl bg-[#0F4C3A] text-white text-sm font-bold inline-flex items-center gap-1.5 cursor-pointer shrink-0"
        >
          <Plus className="w-4 h-4 text-[#F6CF5A]" />
          <span>إضافة شريحة</span>
        </button>
      </div>

      <div className="space-y-3">
        {sorted.map((b, idx) => {
          const typeLabel = SLIDE_TYPES.find((t) => t.value === b.type)?.label || 'رسالة';
          return (
            <div
              key={b.id}
              className="rounded-[22px] bg-white border border-[#E8A91A]/25 p-3.5 flex items-center gap-3.5 shadow-xs"
            >
              <div className="w-16 h-16 rounded-2xl overflow-hidden bg-[#F6CF5A]/30 shrink-0">
                <ResilientImage
                  src={b.image_url || undefined}
                  alt={b.title}
                  fallbackLabel={typeLabel}
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 min-w-0 space-y-0.5">
                <div className="flex items-center gap-2 text-[11px] font-bold text-[#0F4C3A]">
                  <span>{typeLabel}</span>
                  {b.ends_at && (
                    <span className="text-[#B3261E]">· ينتهي {new Date(b.ends_at).toLocaleDateString('ar-EG')}</span>
                  )}
                </div>
                <h3 className="text-sm font-bold text-[#141413] truncate">{b.title}</h3>
                <p className="text-xs text-[#5B5B5B] truncate">{b.subtitle}</p>
              </div>

              <div className="flex items-center gap-1 shrink-0">
                <button
                  type="button"
                  onClick={() => move(idx, -1)}
                  disabled={idx === 0}
                  aria-label="تحريك للأعلى"
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center disabled:opacity-30 cursor-pointer"
                >
                  <ArrowUp className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => move(idx, 1)}
                  disabled={idx === sorted.length - 1}
                  aria-label="تحريك للأسفل"
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center disabled:opacity-30 cursor-pointer"
                >
                  <ArrowDown className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => setEditing(b)}
                  aria-label="تعديل"
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <Edit3 className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() => saveBanner({...b, active: !b.active})}
                  aria-label={b.active ? 'إخفاء' : 'تفعيل'}
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  {b.active ? (
                    <Eye className="w-4 h-4 text-[#0F4C3A]" />
                  ) : (
                    <EyeOff className="w-4 h-4 text-[#B3261E]" />
                  )}
                </button>
                <button
                  type="button"
                  onClick={() => deleteBanner(b.id)}
                  aria-label="حذف"
                  className="min-w-[38px] min-h-[38px] rounded-xl bg-[#B3261E]/10 text-[#B3261E] flex items-center justify-center cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Add/Edit Banner Modal with Live Preview */}
      {editing && (
        <div
          className="fixed inset-0 z-[90] bg-black/55 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 overflow-y-auto"
          role="dialog"
          aria-modal="true"
        >
          <form
            onSubmit={handleSave}
            className="w-full max-w-2xl max-h-[94dvh] overflow-y-auto rounded-t-3xl sm:rounded-3xl bg-white p-5 sm:p-6 space-y-4 shadow-2xl"
          >
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-bold text-[#141413]">
                {editing.id ? 'تعديل الشريحة' : 'شريحة إعلانية جديدة'}
              </h3>
              <button
                type="button"
                onClick={() => setEditing(null)}
                aria-label="إغلاق"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-[#FBF6EA] cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Live Hero Preview */}
            {previewBannerObject && (
              <div className="space-y-1.5">
                <p className="text-xs font-bold text-[#0F4C3A]">معاينة حية للشكل النهائي:</p>
                <div className="scale-[0.94] origin-top">
                  <HeroCarousel banners={[]} previewSlide={previewBannerObject} />
                </div>
              </div>
            )}

            {/* Slide Type Selector */}
            <div className="space-y-1.5">
              <span className="text-xs font-bold text-[#5B5B5B]">نوع الشريحة</span>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {SLIDE_TYPES.map((st) => (
                  <button
                    key={st.value}
                    type="button"
                    onClick={() =>
                      setEditing({
                        ...editing,
                        type: st.value,
                        link:
                          st.value === 'offer' || st.value === 'biggest_discount'
                            ? '/offers'
                            : st.value === 'new_arrivals'
                              ? '/catalog'
                              : editing.link || '/catalog',
                      })
                    }
                    className={`min-h-[42px] px-3 py-2 rounded-2xl text-xs font-bold text-right border transition-colors cursor-pointer ${
                      (editing.type || 'message') === st.value
                        ? 'bg-[#0F4C3A] text-white border-[#0F4C3A]'
                        : 'bg-[#FBF6EA] text-[#141413] border-[#E8A91A]/35'
                    }`}
                  >
                    {st.label}
                  </button>
                ))}
              </div>
              <p className="text-[11px] text-[#5B5B5B]">
                {SLIDE_TYPES.find((t) => t.value === (editing.type || 'message'))?.hint}
              </p>
            </div>

            {/* Product Picker for featured_product or offer */}
            {(editing.type === 'featured_product' || editing.type === 'offer') && (
              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">
                  {editing.type === 'featured_product'
                    ? 'اختاري منتجاً محدداً (أو اتركيه فارغاً لعرض حتى 3 منتجات مميزة تلقائياً)'
                    : 'ربط الشريحة بمنتج لحساب نسبة الخصم (اختياري)'}
                </span>
                <select
                  value={editing.product_id || ''}
                  onChange={(e) => {
                    const pid = e.target.value || null;
                    const chosen = products.find((p) => p.id === pid);
                    setEditing({
                      ...editing,
                      product_id: pid,
                      link: pid ? `/p/${pid}` : editing.link,
                      title: !editing.title && chosen ? chosen.name : editing.title,
                    });
                  }}
                  className="w-full min-h-[44px] px-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold"
                >
                  <option value="">
                    {editing.type === 'featured_product'
                      ? 'تلقائي (أحدث 3 منتجات مميزة)...'
                      : 'اختاري منتجاً...'}
                  </option>
                  {products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({Math.round(p.price)} ج.م)
                    </option>
                  ))}
                </select>
              </label>
            )}

            {/* Real End Date for offer slides */}
            {editing.type === 'offer' && (
              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">
                  تاريخ انتهاء العرض للعداد التنازلي (اتركيه فارغاً لإخفاء العداد)
                </span>
                <input
                  type="datetime-local"
                  value={toDatetimeLocalValue(editing.ends_at)}
                  onChange={(e) =>
                    setEditing({
                      ...editing,
                      ends_at: e.target.value ? new Date(e.target.value).toISOString() : null,
                    })
                  }
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-xs font-bold"
                />
              </label>
            )}

            {/* Image Upload */}
            {editing.type !== 'new_arrivals' && (
              <div className="flex items-center gap-3">
                <div className="w-16 h-16 rounded-2xl overflow-hidden bg-[#FBF6EA] border border-[#E8A91A]/35 shrink-0">
                  <ResilientImage
                    src={editing.image_url || undefined}
                    alt=""
                    className="w-full h-full object-cover"
                  />
                </div>
                <label className="min-h-[44px] px-4 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/40 text-xs font-bold text-[#0F4C3A] inline-flex items-center gap-1.5 cursor-pointer">
                  <Camera className="w-4 h-4" />
                  <span>رفع صورة مخصصة</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (!f) return;
                      const url = await uploadImage(f);
                      setEditing({...editing, image_url: url});
                    }}
                    className="hidden"
                  />
                </label>
                {editing.image_url && (
                  <button
                    type="button"
                    onClick={() => setEditing({...editing, image_url: null})}
                    className="text-xs font-bold text-[#B3261E] cursor-pointer"
                  >
                    إزالة
                  </button>
                )}
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">العنوان الرئيسي</span>
                <input
                  type="text"
                  value={editing.title || ''}
                  onChange={(e) => setEditing({...editing, title: e.target.value})}
                  placeholder="عنوان الشريحة..."
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold"
                />
              </label>

              <label className="block space-y-1">
                <span className="text-xs font-bold text-[#5B5B5B]">نص الزر</span>
                <input
                  type="text"
                  value={editing.btn_text || ''}
                  onChange={(e) => setEditing({...editing, btn_text: e.target.value})}
                  className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm font-bold"
                />
              </label>
            </div>

            <label className="block space-y-1">
              <span className="text-xs font-bold text-[#5B5B5B]">النص الفرعي</span>
              <input
                type="text"
                value={editing.subtitle || ''}
                onChange={(e) => setEditing({...editing, subtitle: e.target.value})}
                className="w-full min-h-[44px] px-3.5 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-sm"
              />
            </label>

            <label className="block space-y-1">
              <span className="text-xs font-bold text-[#5B5B5B]">وجهة الزر</span>
              <select
                value={editing.link || '/catalog'}
                onChange={(e) => {
                  const val = e.target.value;
                  const catMatch = val.startsWith('/c/') ? val.replace('/c/', '') : null;
                  const prodMatch = val.startsWith('/p/') ? val.replace('/p/', '') : null;
                  setEditing({
                    ...editing,
                    link: val,
                    category_id: catMatch,
                    product_id: prodMatch || editing.product_id || null,
                  });
                }}
                className="w-full min-h-[44px] px-3 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/30 text-xs font-bold"
              >
                <option value="/catalog">كل المنتجات</option>
                <option value="/offers">العروض والخصومات</option>
                {topCategories.map((c) => (
                  <option key={c.id} value={`/c/${c.id}`}>
                    قسم: {c.name}
                  </option>
                ))}
                {products.slice(0, 25).map((p) => (
                  <option key={p.id} value={`/p/${p.id}`}>
                    منتج: {p.name}
                  </option>
                ))}
              </select>
            </label>

            <div className="flex gap-2.5 pt-2">
              <button
                type="submit"
                className="flex-1 min-h-[48px] rounded-2xl bg-[#0F4C3A] text-white font-bold text-sm cursor-pointer"
              >
                حفظ الشريحة
              </button>
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="min-h-[48px] px-5 rounded-2xl bg-[#FBF6EA] text-[#141413] font-bold text-sm cursor-pointer"
              >
                إلغاء
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
