import React, {useEffect, useState} from 'react';
import {Link, useLocation, useNavigate} from 'react-router-dom';
import {
  Home,
  LayoutGrid,
  MessageCircle,
  Search,
  Send,
  ShoppingBag,
  Users,
  X,
} from 'lucide-react';
import {useStore} from '../context/StoreContext';
import {
  copyTextToClipboard,
  getWhatsAppUrl,
  openExternalUrl,
} from '../utils/catalogHelpers';
import {trackPixelEvent} from '../utils/metaPixel';
import {CrownOrnament, PWAInstallButton, SplashIntro} from './BrandElements';

export const Layout: React.FC<{children: React.ReactNode}> = ({children}) => {
  const {settings, cart, isDemoMode, cartBounceKey, cartIconRef, showToast} =
    useStore();
  const location = useLocation();
  const navigate = useNavigate();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [chatOpen, setChatOpen] = useState(false);
  const [stickyBarDismissed, setStickyBarDismissed] = useState(false);

  const cartCount = cart.reduce((sum, item) => sum + item.qty, 0);
  const isHome = location.pathname === '/';
  const showAnnouncement =
    settings.features.announcement_bar.enabled &&
    settings.features.announcement_bar.text.trim().length > 0;

  const isCartOrAdmin =
    location.pathname === '/cart' || location.pathname.startsWith('/admin');
  const showStickyCartBar = !isCartOrAdmin && cartCount > 0 && !stickyBarDismissed;

  useEffect(() => {
    setStickyBarDismissed(false);
  }, [cartCount, location.pathname]);

  // Optional Meta Pixel PageView tracking (only loads when pixel_id is filled)
  useEffect(() => {
    if (settings.pixel_id?.trim()) {
      trackPixelEvent(settings.pixel_id, 'PageView');
    }
  }, [settings.pixel_id, location.pathname, location.search]);

  const handleQuickSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = searchQuery.trim();
    setSearchOpen(false);
    navigate(q ? `/catalog?q=${encodeURIComponent(q)}` : '/catalog');
  };

  const hasFollowLinks =
    Boolean(settings.facebook_url?.trim()) ||
    Boolean(settings.instagram_url?.trim()) ||
    Boolean(settings.whatsapp_group_url?.trim());

  const greetingText = `أهلاً ${settings.store_name || 'العمار ستور'}، حابة أستفسر عن المنتجات المتاحة حالياً 🌸`;

  const cartPiecesLabel =
    cartCount === 1
      ? 'في السلة 1 قطعة'
      : cartCount <= 10
        ? `في السلة ${cartCount} قطع`
        : `في السلة ${cartCount} قطعة`;

  const handleContinueShopping = () => {
    if (location.pathname.startsWith('/p/')) {
      navigate('/catalog');
    } else {
      setStickyBarDismissed(true);
    }
  };

  return (
    <div
      className={`min-h-dvh flex flex-col bg-[#FBF6EA] text-[#141413] ${
        showStickyCartBar ? 'pb-36 md:pb-20' : 'pb-20 md:pb-0'
      }`}
    >
      <SplashIntro logoUrl={settings.logo_url} storeName={settings.store_name} />

      {/* Optional Announcement Bar (<= 32px height) */}
      {showAnnouncement && (
        <div className="w-full bg-[#0F4C3A] text-[#FBF6EA] text-xs font-semibold h-8 flex items-center overflow-hidden border-b border-[#E8A91A]/30">
          <div className="w-full overflow-hidden whitespace-nowrap">
            <span className="animate-marquee-rtl px-6">
              {settings.features.announcement_bar.text}
            </span>
          </div>
        </div>
      )}

      {/* Sticky Compact Top Header */}
      <header className="sticky top-0 z-40 h-14 bg-[#FBF6EA]/92 backdrop-blur-md border-b border-[#E8A91A]/25">
        <div className="max-w-6xl mx-auto h-full px-3 sm:px-6 flex items-center justify-between gap-4">
          <Link
            to="/"
            className="flex items-center gap-2.5 shrink-0 rounded-full focus-visible:outline-none"
          >
            <div className="relative w-11 h-11 rounded-full overflow-hidden border-[1.5px] border-[#E8A91A] bg-white shadow-xs logo-shine shrink-0">
              <img
                src={settings.logo_url || '/assets/aistudio/logo_be4d7522.png'}
                alt={settings.store_name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex flex-col leading-tight">
              <span className="text-base sm:text-lg font-bold text-[#141413] whitespace-nowrap">
                {settings.store_name}
              </span>
              {isDemoMode && (
                <span className="text-[11px] font-semibold text-[#0F4C3A] whitespace-nowrap">
                  وضع تجريبي
                </span>
              )}
            </div>
          </Link>

          <nav className="hidden md:flex items-center gap-6 text-sm font-semibold text-[#5B5B5B]">
            <Link
              to="/"
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                isHome
                  ? 'text-[#0F4C3A] border-[#E8A91A]'
                  : 'border-transparent hover:text-[#141413]'
              }`}
            >
              الرئيسية
            </Link>
            <Link
              to="/catalog"
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                location.pathname.startsWith('/catalog') || location.pathname.startsWith('/c/')
                  ? 'text-[#0F4C3A] border-[#E8A91A]'
                  : 'border-transparent hover:text-[#141413]'
              }`}
            >
              كل المنتجات
            </Link>
            <Link
              to="/offers"
              className={`whitespace-nowrap shrink-0 py-1 border-b-2 transition-colors ${
                location.pathname === '/offers'
                  ? 'text-[#0F4C3A] border-[#E8A91A]'
                  : 'border-transparent hover:text-[#141413]'
              }`}
            >
              العروض
            </Link>
          </nav>

          <div className="flex items-center gap-1 shrink-0">
            <button
              type="button"
              onClick={() => setSearchOpen((v) => !v)}
              aria-label="ابحثي في المنتجات"
              className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full text-[#141413] hover:bg-white/80 transition-colors cursor-pointer"
            >
              {searchOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
            </button>

            <Link
              ref={cartIconRef}
              to="/cart"
              aria-label="سلة التسوق"
              className="relative min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full bg-[#0F4C3A] text-white hover:bg-[#0A3629] transition-colors"
            >
              <ShoppingBag className="w-5 h-5" />
              {cartCount > 0 && (
                <span
                  key={cartBounceKey}
                  className="animate-badge-bounce absolute -top-1 -left-1 min-w-[20px] h-[20px] px-1 rounded-full bg-[#E8A91A] text-[#141413] text-[11px] font-bold flex items-center justify-center border border-[#FBF6EA] tabular-nums"
                >
                  {cartCount}
                </span>
              )}
            </Link>
          </div>
        </div>

        {searchOpen && (
          <div className="border-t border-[#E8A91A]/25 bg-[#FBF6EA] px-4 py-3 shadow-md">
            <form onSubmit={handleQuickSearch} className="max-w-2xl mx-auto flex gap-2">
              <input
                type="search"
                autoFocus
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="ابحثي عن حذاء، شنطة، دهب صيني..."
                className="flex-1 min-h-[44px] px-4 rounded-2xl bg-white border border-[#E8A91A]/40 text-sm text-[#141413] placeholder:text-[#5B5B5B]"
              />
              <button
                type="submit"
                className="min-h-[44px] px-5 rounded-2xl bg-[#0F4C3A] text-white text-sm font-semibold whitespace-nowrap shrink-0 cursor-pointer"
              >
                بحث
              </button>
            </form>
          </div>
        )}
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Optional "تابعينا" Card near Footer */}
      {settings.features.follow_us?.enabled && hasFollowLinks && (
        <section className="max-w-6xl mx-auto w-full px-4 sm:px-6 mt-12">
          <div className="rounded-[26px] bg-gradient-to-br from-[#0F4C3A] to-[#0A3629] text-white p-6 sm:p-8 shadow-md border border-[#E8A91A]/40 flex flex-col md:flex-row items-center justify-between gap-5">
            <div className="text-center md:text-right space-y-1.5">
              <div className="inline-flex items-center gap-2">
                <CrownOrnament className="w-5 h-5" />
                <h2 className="text-xl font-bold text-[#F6CF5A]">تابعينا</h2>
              </div>
              <p className="text-sm text-white/85">
                شوفي أحدث الموديلات والوصول الجديد لحظة بلحظة على صفحاتنا وجروب الواتساب
              </p>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2.5">
              {settings.facebook_url && (
                <a
                  href={settings.facebook_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-5 rounded-2xl bg-white text-[#141413] text-sm font-bold inline-flex items-center gap-2 hover:bg-[#F6CF5A] transition-colors"
                >
                  <span>صفحة فيسبوك</span>
                </a>
              )}
              {settings.instagram_url && (
                <a
                  href={settings.instagram_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-5 rounded-2xl bg-white text-[#141413] text-sm font-bold inline-flex items-center gap-2 hover:bg-[#F6CF5A] transition-colors"
                >
                  <span>إنستجرام</span>
                </a>
              )}
              {settings.whatsapp_group_url && (
                <a
                  href={settings.whatsapp_group_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-5 rounded-2xl bg-[#E8A91A] text-[#141413] text-sm font-bold inline-flex items-center gap-2 hover:bg-[#F6CF5A] transition-colors"
                >
                  <Users className="w-4 h-4 text-[#0F4C3A]" />
                  <span>جروب / قناة واتساب</span>
                </a>
              )}
            </div>
          </div>
        </section>
      )}

      {/* Footer */}
      <footer className="mt-12 border-t border-[#E8A91A]/25 bg-white/80">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full overflow-hidden border border-[#E8A91A] bg-white shrink-0">
                <img
                  src={settings.logo_url || '/assets/aistudio/logo_be4d7522.png'}
                  alt={settings.store_name}
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="font-bold text-base text-[#141413]">{settings.store_name}</p>
                <p className="text-xs text-[#5B5B5B]">أحذية حريمي · شنط · دهب صيني · إكسسوارات</p>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-center gap-2.5">
              {settings.whatsapp && (
                <a
                  href={`https://wa.me/${settings.whatsapp.replace(/[^\d]/g, '')}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-4 py-2 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold text-[#0F4C3A] hover:bg-[#E8A91A]/15 flex items-center gap-1.5 transition-colors"
                >
                  <span>واتساب</span>
                </a>
              )}
              {settings.messenger_url && (
                <a
                  href={settings.messenger_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-4 py-2 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold text-[#0F4C3A] hover:bg-[#E8A91A]/15 flex items-center gap-1.5 transition-colors"
                >
                  <span>ماسنجر</span>
                </a>
              )}
              {settings.instagram_url && (
                <a
                  href={settings.instagram_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-4 py-2 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold text-[#0F4C3A] hover:bg-[#E8A91A]/15 flex items-center gap-1.5 transition-colors"
                >
                  <span>إنستجرام</span>
                </a>
              )}
              {settings.facebook_url && (
                <a
                  href={settings.facebook_url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="min-h-[44px] px-4 py-2 rounded-2xl bg-[#FBF6EA] border border-[#E8A91A]/35 text-sm font-semibold text-[#0F4C3A] hover:bg-[#E8A91A]/15 flex items-center gap-1.5 transition-colors"
                >
                  <span>فيسبوك</span>
                </a>
              )}
              <PWAInstallButton />
            </div>
          </div>

          <div className="mt-8 pt-6 border-t border-[#E8A91A]/15 flex flex-col sm:flex-row items-center justify-between gap-2 text-xs text-[#5B5B5B]">
            <p>© {new Date().getFullYear()} {settings.store_name} · جميع الحقوق محفوظة</p>
            <div className="flex items-center gap-3">
              <span>الشحن بيتحدد معاكي في الشات</span>
              <span aria-hidden="true">·</span>
              <Link
                to="/admin"
                className="text-xs text-[#5B5B5B]/80 hover:text-[#0F4C3A] hover:underline transition-colors py-1 px-1 whitespace-nowrap shrink-0"
              >
                الإدارة
              </Link>
            </div>
          </div>
        </div>
      </footer>

      {/* Optional Floating Round Chat Button */}
      {settings.features.floating_chat?.enabled && (
        <div
          className={`fixed ${
            showStickyCartBar ? 'bottom-[142px] md:bottom-20' : 'bottom-20 md:bottom-6'
          } left-4 z-40 flex flex-col items-end gap-2 transition-all duration-200`}
        >
          {chatOpen && (
            <div className="w-64 rounded-3xl bg-white border border-[#E8A91A]/45 shadow-2xl p-4 space-y-2.5 page-enter">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold text-[#141413]">تواصلي معنا مباشرة</p>
                <button
                  type="button"
                  onClick={() => setChatOpen(false)}
                  aria-label="إغلاق"
                  className="w-7 h-7 rounded-full hover:bg-[#FBF6EA] flex items-center justify-center cursor-pointer"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
              <button
                type="button"
                onClick={() => {
                  setChatOpen(false);
                  openExternalUrl(getWhatsAppUrl(settings.whatsapp, greetingText));
                }}
                className="w-full min-h-[44px] rounded-2xl bg-[#0F4C3A] text-white text-xs font-bold flex items-center justify-center gap-2 hover:bg-[#0A3629] cursor-pointer"
              >
                <MessageCircle className="w-4 h-4 text-[#F6CF5A]" />
                <span>محادثة واتساب</span>
              </button>
              <button
                type="button"
                onClick={async () => {
                  setChatOpen(false);
                  await copyTextToClipboard(greetingText);
                  showToast('تم نسخ رسالة الترحيب، الصقيها في ماسنجر', 'success');
                  window.setTimeout(() => {
                    openExternalUrl(settings.messenger_url || settings.facebook_url);
                  }, 300);
                }}
                className="w-full min-h-[44px] rounded-2xl bg-[#E8A91A] text-[#141413] text-xs font-bold flex items-center justify-center gap-2 hover:bg-[#F6CF5A] cursor-pointer"
              >
                <Send className="w-4 h-4 text-[#0F4C3A]" />
                <span>محادثة ماسنجر</span>
              </button>
            </div>
          )}

          <button
            type="button"
            onClick={() => setChatOpen((v) => !v)}
            aria-label="تواصلي معنا عبر الشات"
            className="w-13 h-13 rounded-full bg-[#0F4C3A] text-[#F6CF5A] border-2 border-[#E8A91A] shadow-xl flex items-center justify-center hover:scale-105 active:scale-95 transition-transform cursor-pointer"
          >
            {chatOpen ? <X className="w-6 h-6" /> : <MessageCircle className="w-6 h-6" />}
          </button>
        </div>
      )}

      {/* Sticky Cart Bar above Mobile Bottom Nav */}
      {showStickyCartBar && (
        <div
          role="region"
          aria-label="ملخص السلة"
          className="fixed bottom-[74px] md:bottom-4 left-3 right-3 md:left-auto md:right-6 z-40 md:w-auto md:min-w-[360px]"
        >
          <div className="rounded-2xl bg-[#0F4C3A] text-white border border-[#E8A91A]/55 shadow-xl px-3 py-2 flex items-center justify-between gap-2">
            <div className="flex items-center gap-2 min-w-0">
              <div className="w-8 h-8 rounded-xl bg-[#E8A91A] text-[#141413] flex items-center justify-center shrink-0">
                <ShoppingBag className="w-4 h-4" />
              </div>
              <span className="text-xs sm:text-sm font-bold truncate tabular-nums">
                {cartPiecesLabel}
              </span>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                type="button"
                onClick={handleContinueShopping}
                className="min-h-[38px] px-2.5 rounded-xl bg-white/12 hover:bg-white/20 text-white text-xs font-semibold whitespace-nowrap cursor-pointer transition-colors"
              >
                كمّلي تسوق
              </button>
              <Link
                to="/cart"
                className="min-h-[38px] px-3 rounded-xl bg-[#E8A91A] hover:bg-[#F6CF5A] text-[#141413] text-xs font-bold inline-flex items-center justify-center whitespace-nowrap transition-colors"
              >
                إتمام الطلب
              </Link>
            </div>
          </div>
        </div>
      )}

      {/* Floating Mobile Bottom Navigation Bar */}
      <nav
        aria-label="التنقل السريع"
        className="md:hidden fixed bottom-3 left-3 right-3 z-40 h-14 rounded-[22px] bg-white/95 backdrop-blur-md border border-[#E8A91A]/35 shadow-lg grid grid-cols-3 items-center px-1"
      >
        <Link
          to="/"
          className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 rounded-2xl transition-colors ${
            isHome ? 'text-[#0F4C3A] font-bold' : 'text-[#5B5B5B]'
          }`}
        >
          <Home className="w-5 h-5" />
          <span className="text-[11px] leading-none">الرئيسية</span>
        </Link>

        <Link
          to="/catalog"
          className={`min-h-[44px] flex flex-col items-center justify-center gap-0.5 rounded-2xl transition-colors ${
            location.pathname.startsWith('/catalog') ||
            location.pathname.startsWith('/c/') ||
            location.pathname === '/offers'
              ? 'text-[#0F4C3A] font-bold'
              : 'text-[#5B5B5B]'
          }`}
        >
          <LayoutGrid className="w-5 h-5" />
          <span className="text-[11px] leading-none">المنتجات</span>
        </Link>

        <Link
          to="/cart"
          className={`relative min-h-[44px] flex flex-col items-center justify-center gap-0.5 rounded-2xl transition-colors ${
            location.pathname === '/cart' ? 'text-[#0F4C3A] font-bold' : 'text-[#5B5B5B]'
          }`}
        >
          <div className="relative">
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1.5 -left-2 min-w-[16px] h-[16px] px-1 rounded-full bg-[#E8A91A] text-[#141413] text-[10px] font-bold flex items-center justify-center tabular-nums">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[11px] leading-none">السلة</span>
        </Link>
      </nav>
    </div>
  );
};
