import React, {useEffect, useState} from 'react';
import {CheckCircle2, Download, Share, ShoppingBag, Smartphone, Sparkles, X} from 'lucide-react';
import {useStore} from '../context/StoreContext';
import {usePWAInstall} from '../hooks/usePWAInstall';

export const CrownOrnament: React.FC<{className?: string}> = ({className = 'w-5 h-5'}) => (
  <svg
    viewBox="0 0 28 22"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    aria-hidden="true"
  >
    <path
      d="M3 17.5L1.5 7.5L8.2 11.8L14 4L19.8 11.8L26.5 7.5L25 17.5H3Z"
      fill="#F6CF5A"
      stroke="#0F4C3A"
      strokeWidth="1.6"
      strokeLinejoin="round"
    />
    <rect x="3" y="18.5" width="22" height="2.4" rx="1.2" fill="#0F4C3A" />
    <circle cx="1.5" cy="5.5" r="1.4" fill="#0F4C3A" />
    <circle cx="14" cy="2.2" r="1.6" fill="#E8A91A" stroke="#0F4C3A" strokeWidth="1" />
    <circle cx="26.5" cy="5.5" r="1.4" fill="#0F4C3A" />
  </svg>
);

interface ResilientImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallbackLabel?: string;
}

export const ResilientImage: React.FC<ResilientImageProps> = ({
  src,
  alt,
  className = '',
  fallbackLabel,
  ...rest
}) => {
  const [failed, setFailed] = useState(false);

  useEffect(() => {
    setFailed(false);
  }, [src]);

  if (!src || failed) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-[#FBF6EA] to-[#EFE5CE] text-[#0F4C3A] p-3 text-center ${className}`}
        role="img"
        aria-label={alt || fallbackLabel || 'صورة المنتج'}
      >
        <ShoppingBag className="w-8 h-8 opacity-45 mb-1.5" />
        {fallbackLabel && (
          <span className="text-xs font-semibold text-[#5B5B5B] line-clamp-2">{fallbackLabel}</span>
        )}
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt || ''}
      referrerPolicy="no-referrer"
      onError={() => setFailed(true)}
      className={className}
      {...rest}
    />
  );
};

export const SplashIntro: React.FC<{logoUrl: string; storeName: string}> = ({
  logoUrl,
  storeName,
}) => {
  const [visible, setVisible] = useState(() => {
    if (typeof window === 'undefined') return false;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return false;
    return !sessionStorage.getItem('elamar_splash_seen');
  });
  const [fading, setFading] = useState(false);

  useEffect(() => {
    if (!visible) return;
    sessionStorage.setItem('elamar_splash_seen', '1');
    const t1 = window.setTimeout(() => setFading(true), 360);
    const t2 = window.setTimeout(() => setVisible(false), 560);
    return () => {
      window.clearTimeout(t1);
      window.clearTimeout(t2);
    };
  }, [visible]);

  if (!visible) return null;

  return (
    <div
      className={`fixed inset-0 z-[100] flex flex-col items-center justify-center bg-[#FBF6EA] transition-opacity duration-300 ${
        fading ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
      aria-hidden="true"
    >
      <div className="relative flex items-center justify-center w-36 h-36 splash-logo-in">
        <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 130 130">
          <circle
            cx="65"
            cy="65"
            r="60"
            fill="none"
            stroke="#E8A91A"
            strokeWidth="3.5"
            strokeLinecap="round"
            className="splash-ring-draw"
          />
        </svg>
        <div className="relative w-28 h-28 rounded-full overflow-hidden bg-white shadow-lg splash-sweep-once border border-[#E8A91A]/40">
          <img
            src={logoUrl || '/assets/aistudio/logo_be4d7522.png'}
            alt={storeName}
            className="w-full h-full object-cover"
          />
        </div>
      </div>
      <p className="mt-4 text-lg font-bold text-[#0F4C3A] tracking-tight">{storeName}</p>
    </div>
  );
};

export const ToastBanner: React.FC = () => {
  const {toast, cart} = useStore();
  if (!toast) return null;

  const toneBg =
    toast.tone === 'success'
      ? 'bg-[#0F4C3A] text-white'
      : toast.tone === 'warning'
        ? 'bg-[#B3261E] text-white'
        : 'bg-[#141413] text-[#FBF6EA]';

  const bottomOffset =
    cart.length > 0 ? 'bottom-[142px] md:bottom-20' : 'bottom-20 md:bottom-6';

  return (
    <div
      role="status"
      aria-live="polite"
      className={`fixed ${bottomOffset} left-1/2 -translate-x-1/2 z-[90] px-4 w-full max-w-sm pointer-events-none transition-all duration-200`}
    >
      <div
        className={`flex items-center justify-center gap-2 rounded-2xl px-4 py-3 text-sm font-semibold shadow-xl ${toneBg} page-enter`}
      >
        <CheckCircle2 className="w-4 h-4 shrink-0" />
        <span className="text-center">{toast.message}</span>
      </div>
    </div>
  );
};

export const FlyToCartOverlay: React.FC = () => {
  const {flyAnim, cartIconRef} = useStore();
  const [flying, setFlying] = useState(false);

  useEffect(() => {
    if (!flyAnim) {
      setFlying(false);
      return;
    }
    const raf = requestAnimationFrame(() => setFlying(true));
    return () => cancelAnimationFrame(raf);
  }, [flyAnim]);

  if (!flyAnim) return null;

  const targetRect = cartIconRef.current?.getBoundingClientRect();
  const toX = targetRect ? targetRect.left + targetRect.width / 2 : flyAnim.fromX;
  const toY = targetRect ? targetRect.top + targetRect.height / 2 : 28;
  const dx = toX - flyAnim.fromX;
  const dy = toY - flyAnim.fromY;

  return (
    <div
      aria-hidden="true"
      className="fixed z-[95] pointer-events-none w-14 h-14 -ml-7 -mt-7 rounded-2xl overflow-hidden shadow-lg border-2 border-[#E8A91A] bg-white"
      style={{
        left: flyAnim.fromX,
        top: flyAnim.fromY,
        transform: flying
          ? `translate3d(${dx}px, ${dy}px, 0) scale(0.3)`
          : 'translate3d(0, 0, 0) scale(1)',
        opacity: flying ? 0.15 : 1,
        transition: 'transform 0.55s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.55s ease-out',
      }}
    >
      <img src={flyAnim.image} alt="" className="w-full h-full object-cover" />
    </div>
  );
};

export const PWAInstallButton: React.FC<{className?: string}> = ({className = ''}) => {
  const {isInstallable, isIOS, install} = usePWAInstall();
  const [showIOSGuide, setShowIOSGuide] = useState(false);

  if (!isInstallable && !isIOS) return null;

  return (
    <>
      <button
        type="button"
        onClick={() => {
          if (isInstallable) {
            install();
          } else {
            setShowIOSGuide(true);
          }
        }}
        className={`inline-flex items-center justify-center gap-2 min-h-[44px] px-4 py-2 rounded-2xl bg-[#0F4C3A] text-white text-sm font-semibold hover:bg-[#0A3629] active:scale-[0.97] transition-all cursor-pointer ${className}`}
      >
        <Download className="w-4 h-4 text-[#F6CF5A]" />
        <span>ثبّتي التطبيق</span>
      </button>

      {showIOSGuide && (
        <div
          className="fixed inset-0 z-[95] flex items-end sm:items-center justify-center bg-black/50 backdrop-blur-xs p-4"
          role="dialog"
          aria-modal="true"
          aria-label="تثبيت التطبيق على آيفون"
        >
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl border border-[#E8A91A]/30">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 text-[#0F4C3A] font-bold text-base">
                <Smartphone className="w-5 h-5 text-[#E8A91A]" />
                <span>ثبّتي التطبيق على جهازك</span>
              </div>
              <button
                type="button"
                onClick={() => setShowIOSGuide(false)}
                aria-label="إغلاق"
                className="min-w-[44px] min-h-[44px] flex items-center justify-center rounded-full hover:bg-[#FBF6EA]"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <ol className="space-y-3 text-sm text-[#141413] leading-relaxed">
              <li className="flex items-start gap-2.5">
                <span className="w-6 h-6 rounded-full bg-[#FBF6EA] text-[#0F4C3A] font-bold flex items-center justify-center shrink-0">
                  1
                </span>
                <span>
                  اضغطي على زر <strong className="text-[#0F4C3A]">مشاركة</strong>{' '}
                  <Share className="inline w-4 h-4 mx-0.5 text-[#0F4C3A]" /> في شريط متصفح سفاري بالأسفل.
                </span>
              </li>
              <li className="flex items-start gap-2.5">
                <span className="w-6 h-6 rounded-full bg-[#FBF6EA] text-[#0F4C3A] font-bold flex items-center justify-center shrink-0">
                  2
                </span>
                <span>
                  اختاري <strong className="text-[#0F4C3A]">إضافة إلى الشاشة الرئيسية</strong>.
                </span>
              </li>
            </ol>
            <button
              type="button"
              onClick={() => setShowIOSGuide(false)}
              className="mt-5 w-full min-h-[44px] rounded-2xl bg-[#E8A91A] text-[#141413] font-bold text-sm hover:bg-[#F6CF5A] transition-colors cursor-pointer"
            >
              فهمت
            </button>
          </div>
        </div>
      )}
    </>
  );
};

export const ProductCardSkeleton: React.FC = () => (
  <div className="rounded-[22px] bg-white p-2.5 border border-[#E8A91A]/20">
    <div className="aspect-[3/4] w-full rounded-[16px] skeleton-box" />
    <div className="pt-3 px-1 space-y-2">
      <div className="h-3 w-16 rounded skeleton-box" />
      <div className="h-4 w-4/5 rounded skeleton-box" />
      <div className="h-4 w-24 rounded skeleton-box" />
    </div>
  </div>
);

export const EmptyState: React.FC<{
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
}> = ({title, subtitle, actionLabel, onAction}) => (
  <div className="flex flex-col items-center justify-center text-center py-12 px-6 rounded-[24px] bg-white border border-[#E8A91A]/25">
    <div className="w-14 h-14 rounded-full bg-[#FBF6EA] flex items-center justify-center text-[#0F4C3A] mb-3 border border-[#E8A91A]/30">
      <Sparkles className="w-6 h-6 text-[#E8A91A]" />
    </div>
    <h3 className="text-base font-bold text-[#141413]">{title}</h3>
    {subtitle && <p className="mt-1.5 text-sm text-[#5B5B5B] max-w-xs">{subtitle}</p>}
    {actionLabel && onAction && (
      <button
        type="button"
        onClick={onAction}
        className="mt-4 min-h-[44px] px-5 py-2.5 rounded-2xl bg-[#0F4C3A] text-white text-sm font-semibold hover:bg-[#0A3629] transition-colors cursor-pointer"
      >
        {actionLabel}
      </button>
    )}
  </div>
);
