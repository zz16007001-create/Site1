import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {useNavigate} from 'react-router-dom';
import {ArrowLeft, ChevronLeft, ChevronRight, Clock} from 'lucide-react';
import {useStore} from '../context/StoreContext';
import type {Banner, Product} from '../types/store';
import {
  DEFAULT_FOCUS_X,
  DEFAULT_FOCUS_Y,
  getDiscountPercent,
  getProductFirstImageObj,
  isProductSoldOut,
  openExternalUrl,
} from '../utils/catalogHelpers';

interface StackPhoto {
  src: string;
  alt: string;
  productId: string | null;
  focusX: number;
  focusY: number;
}

interface ResolvedHeroSlide {
  id: string;
  badgeText: string;
  badgeTone: 'emerald' | 'sale';
  title: string;
  price: number | null;
  oldPrice: number | null;
  pricePrefix?: string;
  btnText: string;
  link: string;
  endsAt?: string | null;
  photos: StackPhoto[];
}

const HERO_SPARKLES = [
  {top: '14%', right: '8%', size: 11, delay: '60ms', tone: '#0F4C3A'},
  {top: '20%', right: '42%', size: 9, delay: '140ms', tone: '#FFFDF4'},
  {top: '74%', right: '45%', size: 12, delay: '210ms', tone: '#0F4C3A'},
  {top: '82%', right: '10%', size: 9, delay: '280ms', tone: '#FFFDF4'},
  {top: '16%', left: '12%', size: 11, delay: '180ms', tone: '#F6CF5A'},
  {top: '48%', left: '6%', size: 9, delay: '340ms', tone: '#FFFDF4'},
  {top: '80%', left: '22%', size: 10, delay: '410ms', tone: '#0F4C3A'},
];

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(() =>
    typeof window !== 'undefined'
      ? window.matchMedia('(prefers-reduced-motion: reduce)').matches
      : false
  );

  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)');
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  return reduced;
}

function useCountUpPrice(
  target: number | null,
  active: boolean,
  reducedMotion: boolean
): number | null {
  const [display, setDisplay] = useState<number | null>(target);

  useEffect(() => {
    if (target === null) {
      setDisplay(null);
      return;
    }
    if (reducedMotion || !active) {
      setDisplay(target);
      return;
    }

    const startVal = Math.max(0, Math.round(target * 0.45));
    const duration = 600;
    let rafId = 0;
    const startTime = performance.now();

    const step = (now: number) => {
      const elapsed = now - startTime;
      const t = Math.min(1, elapsed / duration);
      const eased = 1 - Math.pow(1 - t, 3);
      setDisplay(Math.round(startVal + (target - startVal) * eased));
      if (t < 1) {
        rafId = requestAnimationFrame(step);
      }
    };

    rafId = requestAnimationFrame(step);
    return () => cancelAnimationFrame(rafId);
  }, [target, active, reducedMotion]);

  return display;
}

function useSlideCountdown(endsAt?: string | null) {
  const [state, setState] = useState<{
    active: boolean;
    days: number;
    hours: number;
    mins: number;
  }>({active: false, days: 0, hours: 0, mins: 0});

  useEffect(() => {
    if (!endsAt) {
      setState({active: false, days: 0, hours: 0, mins: 0});
      return;
    }
    const tick = () => {
      const diff = new Date(endsAt).getTime() - Date.now();
      if (Number.isNaN(diff) || diff <= 0) {
        setState({active: false, days: 0, hours: 0, mins: 0});
        return;
      }
      setState({
        active: true,
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        mins: Math.floor((diff / (1000 * 60)) % 60),
      });
    };
    tick();
    const id = window.setInterval(tick, 30000);
    return () => window.clearInterval(id);
  }, [endsAt]);

  return state;
}

function toStackPhotos(products: Product[], maxCount = 3): StackPhoto[] {
  const out: StackPhoto[] = [];
  for (const p of products) {
    const imgObj = getProductFirstImageObj(p);
    if (imgObj) {
      out.push({
        src: imgObj.thumb,
        alt: p.name,
        productId: p.id,
        focusX: imgObj.focus_x,
        focusY: imgObj.focus_y,
      });
      if (out.length >= maxCount) break;
    }
  }
  return out;
}

export function resolveHeroSlide(
  banner: Banner,
  visibleProducts: Product[]
): ResolvedHeroSlide | null {
  const available = visibleProducts.filter((p) => !isProductSoldOut(p));
  const pool = available.length > 0 ? available : visibleProducts;

  if (banner.type === 'new_arrivals') {
    const latest = [...pool]
      .filter((p) => Boolean(getProductFirstImageObj(p)))
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
      .slice(0, 3);
    const photos = toStackPhotos(latest, 3);
    if (photos.length === 0) return null;
    const minPrice = Math.min(...latest.map((p) => p.price));
    return {
      id: banner.id,
      badgeText: 'وصل جديد',
      badgeTone: 'emerald',
      title: banner.title || 'وصل حديثًا',
      price: minPrice,
      oldPrice: null,
      pricePrefix: 'ابتداءً من',
      btnText: banner.btn_text || 'شوفي الجديد',
      link: banner.link || '/catalog',
      photos,
    };
  }

  if (banner.type === 'biggest_discount') {
    const discounted = pool
      .filter((p) => p.old_price && p.old_price > p.price && Boolean(getProductFirstImageObj(p)))
      .sort(
        (a, b) =>
          getDiscountPercent(b.price, b.old_price) - getDiscountPercent(a.price, a.old_price)
      )
      .slice(0, 3);
    const photos = toStackPhotos(discounted, 3);
    if (photos.length === 0) return null;
    const maxPct = Math.max(...discounted.map((p) => getDiscountPercent(p.price, p.old_price)));
    const lowestPriced = [...discounted].sort((a, b) => a.price - b.price)[0];
    return {
      id: banner.id,
      badgeText: `-${maxPct}%`,
      badgeTone: 'sale',
      title: banner.title || 'أقوى خصم',
      price: lowestPriced.price,
      oldPrice: lowestPriced.old_price,
      pricePrefix: discounted.length > 1 ? 'ابتداءً من' : undefined,
      btnText: banner.btn_text || 'شوفي العروض',
      link: banner.link || '/offers',
      photos,
    };
  }

  if (banner.type === 'featured_product') {
    if (banner.product_id) {
      const prod = visibleProducts.find((p) => p.id === banner.product_id);
      if (!prod) return null;
      const prodImg = getProductFirstImageObj(prod);
      const singlePhoto = banner.image_url || prodImg?.thumb;
      if (!singlePhoto) return null;
      const pct = getDiscountPercent(prod.price, prod.old_price);
      return {
        id: banner.id,
        badgeText: pct > 0 ? `-${pct}%` : 'منتج مميز',
        badgeTone: pct > 0 ? 'sale' : 'emerald',
        title: banner.title || prod.name,
        price: prod.price,
        oldPrice: prod.old_price,
        btnText: banner.btn_text || 'شوفيها دلوقتي',
        link: `/p/${prod.id}`,
        photos: [
          {
            src: singlePhoto,
            alt: prod.name,
            productId: prod.id,
            focusX: banner.image_url ? 50 : prodImg?.focus_x ?? DEFAULT_FOCUS_X,
            focusY: banner.image_url ? 50 : prodImg?.focus_y ?? DEFAULT_FOCUS_Y,
          },
        ],
      };
    }

    const featured = pool
      .filter((p) => p.featured && Boolean(getProductFirstImageObj(p)))
      .slice(0, 3);
    const photos = toStackPhotos(featured, 3);
    if (photos.length === 0) return null;
    const minPrice = Math.min(...featured.map((p) => p.price));
    const minItem = featured.find((p) => p.price === minPrice) || featured[0];
    return {
      id: banner.id,
      badgeText: 'منتج مميز',
      badgeTone: 'emerald',
      title: banner.title || 'اختيارات العمار المميزة',
      price: minPrice,
      oldPrice: featured.length === 1 ? minItem.old_price : null,
      pricePrefix: featured.length > 1 ? 'ابتداءً من' : undefined,
      btnText: banner.btn_text || 'شوفيها دلوقتي',
      link: banner.link || '/catalog',
      photos,
    };
  }

  const linkedProd = banner.product_id
    ? visibleProducts.find((p) => p.id === banner.product_id)
    : undefined;
  const linkedImg = linkedProd ? getProductFirstImageObj(linkedProd) : null;
  const photoSrc = banner.image_url || linkedImg?.thumb || null;
  if (!photoSrc) return null;

  const pct = linkedProd ? getDiscountPercent(linkedProd.price, linkedProd.old_price) : 0;
  const targetLink = banner.category_id
    ? `/c/${banner.category_id}`
    : banner.link || (banner.type === 'offer' ? '/offers' : '/catalog');

  return {
    id: banner.id,
    badgeText: pct > 0 ? `-${pct}%` : banner.type === 'offer' ? 'عرض خاص' : 'العمار ستور',
    badgeTone: pct > 0 || banner.type === 'offer' ? 'sale' : 'emerald',
    title: banner.title || linkedProd?.name || 'عروض العمار ستور',
    price: linkedProd ? linkedProd.price : null,
    oldPrice: linkedProd ? linkedProd.old_price : null,
    btnText: banner.btn_text || (banner.type === 'offer' ? 'شوفي العروض' : 'تسوقي الآن'),
    link: targetLink,
    endsAt: banner.type === 'offer' ? banner.ends_at : null,
    photos: [
      {
        src: photoSrc,
        alt: banner.title || linkedProd?.name || 'العمار ستور',
        productId: linkedProd?.id || null,
        focusX: banner.image_url ? 50 : linkedImg?.focus_x ?? DEFAULT_FOCUS_X,
        focusY: banner.image_url ? 50 : linkedImg?.focus_y ?? DEFAULT_FOCUS_Y,
      },
    ],
  };
}

const PhotoStackCard: React.FC<{
  photo: StackPhoto;
  styleClass: string;
  rotationDeg: number;
  staggerMs: number;
  isFirstSlide: boolean;
  onSelect: () => void;
}> = ({photo, styleClass, rotationDeg, staggerMs, isFirstSlide, onSelect}) => {
  const [loaded, setLoaded] = useState(false);

  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        onSelect();
      }}
      aria-label={photo.alt}
      style={
        {
          '--photo-rot': `${rotationDeg}deg`,
          '--stagger': `${staggerMs}ms`,
        } as React.CSSProperties
      }
      className={`hero-photo-item relative rounded-[16px] border-4 border-white bg-white shadow-[0_10px_24px_rgba(15,76,58,0.22)] overflow-hidden transition-transform duration-200 hover:scale-[1.04] active:scale-[0.98] cursor-pointer focus-visible:ring-2 focus-visible:ring-[#0F4C3A] ${styleClass}`}
    >
      {!loaded && <div className="absolute inset-0 skeleton-box" aria-hidden="true" />}
      <img
        src={photo.src}
        alt={photo.alt}
        width={300}
        height={380}
        loading={isFirstSlide ? 'eager' : 'lazy'}
        fetchPriority={isFirstSlide ? 'high' : 'low'}
        decoding={isFirstSlide ? 'sync' : 'async'}
        referrerPolicy="no-referrer"
        onLoad={() => setLoaded(true)}
        onError={() => setLoaded(true)}
        style={{objectPosition: `${photo.focusX}% ${photo.focusY}%`}}
        className={`w-full h-full object-cover transition-opacity duration-300 ${
          loaded ? 'opacity-100' : 'opacity-0'
        }`}
      />
    </button>
  );
};

const HeroSlideCard: React.FC<{
  slide: ResolvedHeroSlide;
  slideIndex: number;
  totalSlides: number;
  isActive: boolean;
  reducedMotion: boolean;
  parallaxRef: (el: HTMLDivElement | null) => void;
  onSelectSegment: (idx: number) => void;
  onNavigate: (link: string) => void;
}> = ({
  slide,
  slideIndex,
  totalSlides,
  isActive,
  reducedMotion,
  parallaxRef,
  onSelectSegment,
  onNavigate,
}) => {
  const animatedPrice = useCountUpPrice(slide.price, isActive, reducedMotion);
  const countdown = useSlideCountdown(slide.endsAt);

  // Stack geometry: front photo is largest (last rendered = highest z-index)
  const photoConfigs = useMemo(() => {
    const count = slide.photos.length;
    if (count === 1) {
      return [
        {
          photo: slide.photos[0],
          rot: 0,
          stagger: 0,
          cls: 'w-[122px] h-[156px] sm:w-[148px] sm:h-[186px] z-20',
        },
      ];
    }
    if (count === 2) {
      return [
        {
          photo: slide.photos[1],
          rot: -8,
          stagger: 0,
          cls: 'w-[90px] h-[116px] sm:w-[112px] sm:h-[144px] -translate-x-5 translate-y-1.5 z-10',
        },
        {
          photo: slide.photos[0],
          rot: 6,
          stagger: 120,
          cls: 'w-[106px] h-[136px] sm:w-[132px] sm:h-[168px] translate-x-4 z-20',
        },
      ];
    }
    // 3 photos: back (-8deg), mid (+8deg), front largest (0deg)
    return [
      {
        photo: slide.photos[2],
        rot: -8,
        stagger: 0,
        cls: 'w-[80px] h-[104px] sm:w-[100px] sm:h-[128px] -translate-x-8 translate-y-2 z-10',
      },
      {
        photo: slide.photos[1],
        rot: 8,
        stagger: 120,
        cls: 'w-[86px] h-[112px] sm:w-[108px] sm:h-[138px] translate-x-8 translate-y-1 z-20',
      },
      {
        photo: slide.photos[0],
        rot: 0,
        stagger: 240,
        cls: 'w-[102px] h-[134px] sm:w-[128px] sm:h-[164px] z-30',
      },
    ];
  }, [slide.photos]);

  return (
    <article
      className={`hero-card-shine relative rounded-[28px] overflow-hidden bg-gradient-to-br from-[#E8A91A] via-[#F0BC34] to-[#F6CF5A] border border-[#C98D0B]/45 ring-1 ring-inset ring-white/35 shadow-md h-[280px] sm:h-[300px] lg:h-[320px] flex flex-col justify-between select-none ${
        isActive ? 'hero-slide-active' : ''
      }`}
    >
      {/* Top-left deep-emerald quarter-circle carrying faint concentric ring pattern echoing the logo */}
      <svg
        viewBox="0 0 220 220"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        aria-hidden="true"
        className="pointer-events-none absolute top-0 left-0 w-44 h-44 sm:w-56 sm:h-56 lg:w-64 lg:h-64"
      >
        <path d="M0 0 H220 A220 220 0 0 1 0 220 Z" fill="#0F4C3A" />
        <circle cx="0" cy="0" r="188" stroke="#F6CF5A" strokeOpacity="0.22" strokeWidth="1.5" />
        <circle cx="0" cy="0" r="152" stroke="#F6CF5A" strokeOpacity="0.16" strokeWidth="1.25" />
        <circle cx="0" cy="0" r="114" stroke="#F6CF5A" strokeOpacity="0.2" strokeWidth="1.5" />
        <circle cx="0" cy="0" r="76" stroke="#F6CF5A" strokeOpacity="0.14" strokeWidth="1.25" />
      </svg>

      {/* 7 tiny sparkle shapes twinkling once when slide becomes active */}
      <div aria-hidden="true" className="pointer-events-none absolute inset-0 overflow-hidden">
        {HERO_SPARKLES.map((sp, i) => (
          <svg
            key={i}
            viewBox="0 0 16 16"
            fill="none"
            style={
              {
                top: sp.top,
                right: sp.right,
                left: sp.left,
                width: sp.size,
                height: sp.size,
                '--twinkle-delay': sp.delay,
              } as React.CSSProperties
            }
            className="hero-sparkle-twinkle absolute opacity-70"
          >
            <path
              d="M8 0.5L9.8 6.2L15.5 8L9.8 9.8L8 15.5L6.2 9.8L0.5 8L6.2 6.2L8 0.5Z"
              fill={sp.tone}
            />
          </svg>
        ))}
      </div>

      {/* Story-style segmented progress bar at top of card (current position only, no timers) */}
      <div
        className="relative z-20 pt-3 px-4 sm:px-6 flex items-center gap-1.5"
        role="tablist"
        aria-label="شرائح العرض"
      >
        {Array.from({length: totalSlides}).map((_, i) => (
          <button
            key={i}
            type="button"
            role="tab"
            aria-selected={i === slideIndex}
            aria-label={`الشريحة ${i + 1}`}
            onClick={() => onSelectSegment(i)}
            className="flex-1 py-1.5 cursor-pointer focus-visible:outline-none"
          >
            <span
              className={`block h-[3px] w-full rounded-full transition-colors duration-200 ${
                i === slideIndex ? 'bg-[#0F4C3A]' : 'bg-[#141413]/22'
              }`}
            />
          </button>
        ))}
      </div>

      {/* Main Split Content (RTL Start = Text & CTA, RTL End = Stacked Product Photos) */}
      <div className="relative z-10 flex-1 grid grid-cols-12 items-center gap-2 px-4 sm:px-7 pb-4 pt-1 min-h-0">
        {/* Right Half (RTL start): Badge, Title (max 2 lines), Price line, ONE emerald button */}
        <div className="col-span-6 sm:col-span-7 flex flex-col items-start justify-center text-right gap-2 min-w-0">
          <div className="flex flex-wrap items-center gap-1.5">
            <span
              className={`hero-badge-pop inline-flex items-center px-3 py-1 rounded-full text-[11px] sm:text-xs font-bold whitespace-nowrap shadow-xs ${
                slide.badgeTone === 'sale'
                  ? 'bg-[#B3261E] text-white'
                  : 'bg-[#0F4C3A] text-[#FBF6EA]'
              }`}
            >
              {slide.badgeText}
            </span>

            {countdown.active && (
              <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full bg-[#0F4C3A] text-[#FBF6EA] text-[10px] sm:text-xs font-bold tabular-nums whitespace-nowrap">
                <Clock className="w-3 h-3 text-[#F6CF5A]" />
                <span>
                  {countdown.days > 0 ? `${countdown.days}ي ` : ''}
                  {String(countdown.hours).padStart(2, '0')}:
                  {String(countdown.mins).padStart(2, '0')}
                </span>
              </span>
            )}
          </div>

          <h1 className="text-lg sm:text-2xl lg:text-[28px] font-bold text-[#141413] leading-snug line-clamp-2 text-balance">
            {slide.title}
          </h1>

          {animatedPrice !== null && (
            <div className="flex flex-wrap items-baseline gap-1.5 sm:gap-2 tabular-nums">
              <span className="text-sm sm:text-lg font-extrabold text-[#141413]">
                {slide.pricePrefix ? `${slide.pricePrefix} ` : ''}
                {animatedPrice.toLocaleString('en-US')} ج
              </span>
              {slide.oldPrice && slide.oldPrice > (slide.price ?? 0) && (
                <span className="text-xs sm:text-sm font-semibold text-[#141413]/70 line-through">
                  {Math.round(slide.oldPrice).toLocaleString('en-US')} ج
                </span>
              )}
            </div>
          )}

          <div className="pt-1">
            <button
              type="button"
              onClick={() => onNavigate(slide.link)}
              className="hero-btn-shine inline-flex items-center justify-center gap-1.5 min-h-[42px] px-4 sm:px-6 py-2 rounded-2xl bg-[#0F4C3A] text-[#FBF6EA] text-xs sm:text-sm font-bold shadow-md hover:bg-[#0A3629] active:scale-[0.97] transition-all cursor-pointer whitespace-nowrap"
            >
              <span>{slide.btnText}</span>
              <ArrowLeft className="w-4 h-4 text-[#F6CF5A]" />
            </button>
          </div>
        </div>

        {/* Left Half (RTL end): Scroll-parallax + idle-float stack of up to 3 real product photos */}
        <div className="col-span-6 sm:col-span-5 flex items-center justify-center h-full">
          <div ref={parallaxRef} className="will-change-transform flex items-center justify-center">
            <div className="hero-stack-idle-float relative flex items-center justify-center w-[150px] h-[170px] sm:w-[210px] sm:h-[210px]">
              {photoConfigs.map((cfg, idx) => (
                <div key={`${slide.id}-p-${idx}`} className="absolute flex items-center justify-center">
                  <PhotoStackCard
                    photo={cfg.photo}
                    styleClass={cfg.cls}
                    rotationDeg={cfg.rot}
                    staggerMs={cfg.stagger}
                    isFirstSlide={slideIndex === 0}
                    onSelect={() =>
                      onNavigate(cfg.photo.productId ? `/p/${cfg.photo.productId}` : slide.link)
                    }
                  />
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </article>
  );
};

export const HeroCarousel: React.FC<{
  banners: Banner[];
  previewSlide?: Banner | null;
}> = ({banners, previewSlide}) => {
  const {products} = useStore();
  const navigate = useNavigate();
  const reducedMotion = usePrefersReducedMotion();

  const visibleProducts = useMemo(() => products.filter((p) => p.visible), [products]);

  const slides = useMemo<ResolvedHeroSlide[]>(() => {
    if (previewSlide) {
      const single = resolveHeroSlide(previewSlide, visibleProducts);
      if (single) return [single];
      return [];
    }

    const activeBanners = banners.filter((b) => b.active).sort((a, b) => a.sort - b.sort);

    if (activeBanners.length > 0) {
      return activeBanners
        .map((b) => resolveHeroSlide(b, visibleProducts))
        .filter((s): s is ResolvedHeroSlide => Boolean(s && s.photos.length > 0))
        .slice(0, 3);
    }

    // Fallback: auto-synthesize the 3 core slides from visible catalog products
    const synth: Banner[] = [
      {
        id: 'auto-new',
        type: 'new_arrivals',
        image_url: null,
        title: 'وصل حديثًا',
        subtitle: '',
        btn_text: 'شوفي الجديد',
        link: '/catalog',
        product_id: null,
        category_id: null,
        ends_at: null,
        active: true,
        sort: 1,
      },
      {
        id: 'auto-discount',
        type: 'biggest_discount',
        image_url: null,
        title: 'أقوى خصم',
        subtitle: '',
        btn_text: 'شوفي العروض',
        link: '/offers',
        product_id: null,
        category_id: null,
        ends_at: null,
        active: true,
        sort: 2,
      },
      {
        id: 'auto-featured',
        type: 'featured_product',
        image_url: null,
        title: 'اختيارات العمار المميزة',
        subtitle: '',
        btn_text: 'شوفيها دلوقتي',
        link: '/catalog',
        product_id: null,
        category_id: null,
        ends_at: null,
        active: true,
        sort: 3,
      },
    ];

    return synth
      .map((b) => resolveHeroSlide(b, visibleProducts))
      .filter((s): s is ResolvedHeroSlide => Boolean(s && s.photos.length > 0))
      .slice(0, 3);
  }, [banners, previewSlide, visibleProducts]);

  const [activeIndex, setActiveIndex] = useState(0);
  const [hovered, setHovered] = useState(false);
  const [isDesktop, setIsDesktop] = useState(() =>
    typeof window !== 'undefined' ? window.matchMedia('(min-width: 1024px)').matches : false
  );

  const sectionRef = useRef<HTMLElement | null>(null);
  const trackRef = useRef<HTMLDivElement | null>(null);
  const slideRefs = useRef<Array<HTMLDivElement | null>>([]);
  const parallaxRefs = useRef<Array<HTMLDivElement | null>>([]);

  const safeActive = slides.length > 0 ? Math.min(activeIndex, slides.length - 1) : 0;

  // Track 1024px+ desktop media query (auto-rotate 6s ONLY on 1024px+ screens)
  useEffect(() => {
    const mq = window.matchMedia('(min-width: 1024px)');
    const onChange = () => setIsDesktop(mq.matches);
    mq.addEventListener('change', onChange);
    return () => mq.removeEventListener('change', onChange);
  }, []);

  // Preload first slide's photos with high priority in document <head>
  useEffect(() => {
    if (previewSlide || slides.length === 0) return;
    const firstPhotos = slides[0].photos.map((p) => p.src);
    const links: HTMLLinkElement[] = [];

    for (const href of firstPhotos) {
      if (!href || href.startsWith('data:')) continue;
      const linkEl = document.createElement('link');
      linkEl.rel = 'preload';
      linkEl.as = 'image';
      linkEl.href = href;
      linkEl.setAttribute('fetchpriority', 'high');
      document.head.appendChild(linkEl);
      links.push(linkEl);
    }

    return () => {
      for (const el of links) {
        el.remove();
      }
    };
  }, [previewSlide, slides]);

  // Light scroll parallax on photo stacks (requestAnimationFrame, throttled, disabled on reduced motion)
  useEffect(() => {
    if (reducedMotion || previewSlide || slides.length === 0) {
      for (const el of parallaxRefs.current) {
        if (el) el.style.transform = '';
      }
      return;
    }

    let rafPending = false;
    const updateParallax = () => {
      rafPending = false;
      const host = sectionRef.current;
      if (!host) return;
      const rect = host.getBoundingClientRect();
      const progress = Math.max(-1, Math.min(1, -rect.top / 420));
      const shiftY = Math.round(progress * 10 * 10) / 10;
      for (const el of parallaxRefs.current) {
        if (el) {
          el.style.transform = `translate3d(0, ${shiftY}px, 0)`;
        }
      }
    };

    const onScroll = () => {
      if (!rafPending) {
        rafPending = true;
        requestAnimationFrame(updateParallax);
      }
    };

    window.addEventListener('scroll', onScroll, {passive: true});
    return () => window.removeEventListener('scroll', onScroll);
  }, [reducedMotion, previewSlide, slides.length]);

  // Detect active slide via center proximity during CSS scroll-snap (RTL-safe across browsers)
  const scrollRafRef = useRef(false);
  const handleTrackScroll = useCallback(() => {
    if (scrollRafRef.current) return;
    scrollRafRef.current = true;
    requestAnimationFrame(() => {
      scrollRafRef.current = false;
      const track = trackRef.current;
      if (!track || slides.length <= 1) return;
      const trackRect = track.getBoundingClientRect();
      const centerX = trackRect.left + trackRect.width / 2;

      let closestIdx = 0;
      let minDist = Infinity;
      for (let i = 0; i < slides.length; i++) {
        const el = slideRefs.current[i];
        if (!el) continue;
        const r = el.getBoundingClientRect();
        const slideCenter = r.left + r.width / 2;
        const dist = Math.abs(slideCenter - centerX);
        if (dist < minDist) {
          minDist = dist;
          closestIdx = i;
        }
      }
      setActiveIndex(closestIdx);
    });
  }, [slides.length]);

  const scrollToSlide = useCallback(
    (idx: number) => {
      const target = slideRefs.current[idx];
      if (!target) return;
      setActiveIndex(idx);
      target.scrollIntoView({
        behavior: reducedMotion ? 'auto' : 'smooth',
        inline: 'start',
        block: 'nearest',
      });
    },
    [reducedMotion]
  );

  // Auto-rotate every 6s ONLY on 1024px+ screens, pause on hover
  useEffect(() => {
    if (!isDesktop || hovered || previewSlide || slides.length <= 1 || reducedMotion) return;
    const timer = window.setInterval(() => {
      const next = (safeActive + 1) % slides.length;
      scrollToSlide(next);
    }, 6000);
    return () => window.clearInterval(timer);
  }, [isDesktop, hovered, previewSlide, slides.length, safeActive, scrollToSlide, reducedMotion]);

  const handleNavigate = (link: string) => {
    if (previewSlide) return;
    if (!link) return navigate('/catalog');
    if (link.startsWith('http')) {
      openExternalUrl(link);
      return;
    }
    navigate(link.startsWith('/') ? link : `/${link}`);
  };

  if (slides.length === 0) return null;

  const hasMultiple = slides.length > 1 && !previewSlide;

  return (
    <section
      ref={sectionRef}
      aria-label="العروض الرئيسية"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative"
    >
      <div
        ref={trackRef}
        onScroll={handleTrackScroll}
        className={
          hasMultiple
            ? '-mx-4 px-4 sm:-mx-6 sm:px-6 lg:mx-0 lg:px-0 flex gap-3 overflow-x-auto no-scrollbar snap-x snap-mandatory scroll-px-4 sm:scroll-px-6 lg:scroll-px-0'
            : 'w-full'
        }
      >
        {slides.map((slide, idx) => (
          <div
            key={slide.id}
            ref={(el) => {
              slideRefs.current[idx] = el;
            }}
            className={
              hasMultiple
                ? 'w-[calc(100%-26px)] sm:w-[calc(100%-38px)] lg:w-full shrink-0 snap-start'
                : 'w-full'
            }
          >
            <HeroSlideCard
              slide={slide}
              slideIndex={idx}
              totalSlides={slides.length}
              isActive={idx === safeActive}
              reducedMotion={reducedMotion}
              parallaxRef={(el) => {
                parallaxRefs.current[idx] = el;
              }}
              onSelectSegment={scrollToSlide}
              onNavigate={handleNavigate}
            />
          </div>
        ))}
      </div>

      {/* Desktop-only subtle prev/next buttons (1024px+) */}
      {hasMultiple && (
        <>
          <button
            type="button"
            onClick={() => scrollToSlide((safeActive - 1 + slides.length) % slides.length)}
            aria-label="الشريحة السابقة"
            className="hidden lg:flex absolute top-1/2 -translate-y-1/2 right-3 z-30 w-9 h-9 rounded-full bg-white/85 hover:bg-white text-[#141413] shadow-md items-center justify-center transition-colors cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
          <button
            type="button"
            onClick={() => scrollToSlide((safeActive + 1) % slides.length)}
            aria-label="الشريحة التالية"
            className="hidden lg:flex absolute top-1/2 -translate-y-1/2 left-3 z-30 w-9 h-9 rounded-full bg-white/85 hover:bg-white text-[#141413] shadow-md items-center justify-center transition-colors cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
        </>
      )}
    </section>
  );
};
