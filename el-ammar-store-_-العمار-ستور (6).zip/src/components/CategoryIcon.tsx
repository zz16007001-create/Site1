import React, {useEffect, useState} from 'react';

interface CategoryIconProps {
  name: string;
  parentName?: string | null;
  active?: boolean;
  animated?: boolean;
  className?: string;
}

interface CategoryIconSpec {
  url: string;
  fallbackUrl?: string;
  fallbackEmoji: string;
}

export const SUBCATEGORY_ICON_URLS = {
  kotshi: '/assets/subcategories/sub-kotshi.png',
  sabo: '/assets/subcategories/sub-sabo.png',
  slipper: '/assets/subcategories/sub-slipper.png',
  heels: '/assets/subcategories/sub-heels.png',
  shoes: '/assets/subcategories/sub-shoes.png',
  bagBack: '/assets/subcategories/sub-bag-back.png',
  bagShoulder: '/assets/subcategories/sub-bag-shoulder.png',
  bagCross: '/assets/subcategories/sub-bag-cross.png',
  goldRing: '/assets/subcategories/sub-gold-ring.png',
  goldNecklace: '/assets/subcategories/sub-gold-necklace.png',
  goldBracelet: '/assets/subcategories/sub-gold-bracelet.png',
  goldEarring: '/assets/subcategories/sub-gold-earring.png',
} as const;

export const BUNDLED_CATEGORY_ICON_URLS = {
  heels: '/assets/aistudio/icon-heels_1d6561e8.png',
  bag: '/assets/aistudio/icon-bag_7550e240.png',
  gold: '/assets/aistudio/icon-gold-necklace_71ce0238.png',
  accessories: '/assets/aistudio/icon-accessories_9c198dc5.png',
} as const;

export const CATEGORY_3D_EMOJI_URLS = {
  shoes:
    'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/High-heeled%20shoe/3D/high-heeled_shoe_3d.png',
  bags:
    'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Handbag/3D/handbag_3d.png',
  gold:
    'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Ring/3D/ring_3d.png',
  accessories:
    'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Ribbon/3D/ribbon_3d.png',
  offers:
    'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Label/3D/label_3d.png',
  default:
    'https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/Sparkles/3D/sparkles_3d.png',
} as const;

function normalizeArabic(s?: string | null): string {
  return (s || '')
    .replace(/[\u064B-\u065F\u0670]/g, '')
    .replace(/[أإآ]/g, 'ا')
    .replace(/ة/g, 'ه')
    .replace(/ى/g, 'ي')
    .replace(/\s+/g, ' ')
    .trim()
    .toLowerCase();
}

function matchSubcategorySpec(rawName?: string | null): CategoryIconSpec | null {
  const normalized = normalizeArabic(rawName);
  if (!normalized) return null;

  if (normalized.includes('كوتشي') || normalized.includes('كوتش')) {
    return {url: SUBCATEGORY_ICON_URLS.kotshi, fallbackEmoji: '👟'};
  }
  if (normalized.includes('صابو') || normalized.includes('سابو')) {
    return {url: SUBCATEGORY_ICON_URLS.sabo, fallbackEmoji: '🥿'};
  }
  if (normalized.includes('سليبر') || normalized.includes('شبشب')) {
    return {url: SUBCATEGORY_ICON_URLS.slipper, fallbackEmoji: '🩴'};
  }
  if (normalized.includes('هيلز') || normalized.includes('كعب')) {
    return {url: SUBCATEGORY_ICON_URLS.heels, fallbackEmoji: '👠'};
  }
  if (normalized.includes('شوز')) {
    return {url: SUBCATEGORY_ICON_URLS.shoes, fallbackEmoji: '🥿'};
  }
  if (normalized.includes('باك')) {
    return {url: SUBCATEGORY_ICON_URLS.bagBack, fallbackEmoji: '🎒'};
  }
  if (normalized.includes('شولدر')) {
    return {url: SUBCATEGORY_ICON_URLS.bagShoulder, fallbackEmoji: '👜'};
  }
  if (normalized.includes('كروس')) {
    return {url: SUBCATEGORY_ICON_URLS.bagCross, fallbackEmoji: '👜'};
  }
  if (normalized.includes('خاتم')) {
    return {url: SUBCATEGORY_ICON_URLS.goldRing, fallbackEmoji: '💍'};
  }
  if (normalized.includes('سلسل')) {
    return {url: SUBCATEGORY_ICON_URLS.goldNecklace, fallbackEmoji: '📿'};
  }
  if (normalized.includes('اسور')) {
    return {url: SUBCATEGORY_ICON_URLS.goldBracelet, fallbackEmoji: '⭕'};
  }
  if (normalized.includes('حلق')) {
    return {url: SUBCATEGORY_ICON_URLS.goldEarring, fallbackEmoji: '✨'};
  }

  return null;
}

function matchCategorySpec(rawName?: string | null): CategoryIconSpec | null {
  const normalized = (rawName || '').trim();
  if (!normalized) return null;

  // Offers / عروض -> Fluent 3D Label / Price tag
  if (normalized.includes('عرض') || normalized.includes('عروض') || normalized.includes('خصم')) {
    return {
      url: CATEGORY_3D_EMOJI_URLS.offers,
      fallbackEmoji: '🏷️',
    };
  }

  // Shoes / أحذية حريمي -> Bundled heels PNG (with Fluent fallback)
  if (
    normalized.includes('أحذي') ||
    normalized.includes('احذي') ||
    normalized.includes('حذاء') ||
    normalized.includes('شوز') ||
    normalized.includes('هيلز')
  ) {
    return {
      url: BUNDLED_CATEGORY_ICON_URLS.heels,
      fallbackUrl: CATEGORY_3D_EMOJI_URLS.shoes,
      fallbackEmoji: '👠',
    };
  }

  // Bags / شنطة -> Bundled bag PNG (with Fluent fallback)
  if (normalized.includes('شنط')) {
    return {
      url: BUNDLED_CATEGORY_ICON_URLS.bag,
      fallbackUrl: CATEGORY_3D_EMOJI_URLS.bags,
      fallbackEmoji: '👜',
    };
  }

  // Chinese Gold / دهب صيني -> Bundled gold necklace PNG (with Fluent fallback)
  if (normalized.includes('دهب') || normalized.includes('ذهب') || normalized.includes('مجوهرات')) {
    return {
      url: BUNDLED_CATEGORY_ICON_URLS.gold,
      fallbackUrl: CATEGORY_3D_EMOJI_URLS.gold,
      fallbackEmoji: '📿',
    };
  }

  // Accessories / إكسسوارات -> Bundled hair clip + sunglasses PNG (with Fluent fallback)
  if (normalized.includes('إكسسوار') || normalized.includes('اكسسوار')) {
    return {
      url: BUNDLED_CATEGORY_ICON_URLS.accessories,
      fallbackUrl: CATEGORY_3D_EMOJI_URLS.accessories,
      fallbackEmoji: '🎀',
    };
  }

  return null;
}

function resolveCategoryIconSpec(name: string, parentName?: string | null): CategoryIconSpec {
  const subDirect = matchSubcategorySpec(name);
  if (subDirect) return subDirect;

  const direct = matchCategorySpec(name);
  if (direct) return direct;

  const fromParent = matchCategorySpec(parentName);
  if (fromParent) return fromParent;

  return {
    url: CATEGORY_3D_EMOJI_URLS.default,
    fallbackEmoji: '✨',
  };
}

/**
 * Bundled transparent 3D category PNGs (heels, bag, gold necklace, accessories)
 * with Fluent Emoji 3D label for "عروض" and native emoji fallback + soft drop shadow.
 * Subcategories automatically inherit their parent category's icon via parentName.
 */
export const CategoryIcon: React.FC<CategoryIconProps> = ({
  name,
  parentName,
  animated = false,
  className = 'w-10 h-10',
}) => {
  const spec = resolveCategoryIconSpec(name, parentName);
  const [srcStage, setSrcStage] = useState<'primary' | 'fallback' | 'emoji'>('primary');

  useEffect(() => {
    setSrcStage('primary');
  }, [spec.url, spec.fallbackUrl]);

  const activeUrl =
    srcStage === 'primary'
      ? spec.url
      : srcStage === 'fallback'
        ? spec.fallbackUrl || null
        : null;

  if (!activeUrl || srcStage === 'emoji') {
    return (
      <span
        aria-hidden="true"
        className={`inline-flex items-center justify-center leading-none select-none drop-shadow-[0_4px_8px_rgba(15,76,58,0.22)] transition-transform duration-200 ${
          animated ? 'category-3d-float' : ''
        } ${className}`}
        style={{fontSize: 'clamp(1.25rem, 60%, 3.25rem)'}}
      >
        {spec.fallbackEmoji}
      </span>
    );
  }

  return (
    <img
      src={activeUrl}
      alt=""
      aria-hidden="true"
      loading="lazy"
      decoding="async"
      referrerPolicy="no-referrer"
      onError={() => {
        if (srcStage === 'primary' && spec.fallbackUrl) {
          setSrcStage('fallback');
        } else {
          setSrcStage('emoji');
        }
      }}
      className={`object-contain select-none pointer-events-none drop-shadow-[0_6px_10px_rgba(15,76,58,0.22)] transition-transform duration-200 ${
        animated ? 'category-3d-float' : ''
      } ${className}`}
    />
  );
};
