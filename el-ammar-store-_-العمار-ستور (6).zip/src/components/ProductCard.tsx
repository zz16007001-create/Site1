import React, {useEffect, useRef, useState} from 'react';
import {Link} from 'react-router-dom';
import {useStore} from '../context/StoreContext';
import type {Product} from '../types/store';
import {
  formatPrice,
  getDiscountPercent,
  getProductMainImageObj,
  isProductSoldOut,
} from '../utils/catalogHelpers';
import {ResilientImage} from './BrandElements';

const PASTEL_BACKGROUNDS = [
  'bg-[#F7EFE0]',
  'bg-[#EDF4F1]',
  'bg-[#FBF3DF]',
  'bg-[#F4EFE8]',
];

export const ProductCard: React.FC<{
  product: Product;
  index?: number;
  selectedSizeFilter?: string | null;
}> = ({product, index = 0, selectedSizeFilter = null}) => {
  const {categories} = useStore();
  const [revealed, setRevealed] = useState(false);
  const cardRef = useRef<HTMLDivElement | null>(null);

  const soldOut = isProductSoldOut(product);
  const discount = getDiscountPercent(product.price, product.old_price);
  const mainImageObj = getProductMainImageObj(product);
  const categoryName = categories.find((c) => c.id === product.category_id)?.name;
  const pastelClass = PASTEL_BACKGROUNDS[index % PASTEL_BACKGROUNDS.length];
  const productUrl = selectedSizeFilter
    ? `/p/${product.id}?size=${encodeURIComponent(selectedSizeFilter)}`
    : `/p/${product.id}`;

  useEffect(() => {
    const el = cardRef.current;
    if (!el) return;
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      setRevealed(true);
      return;
    }
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting) {
          setRevealed(true);
          observer.disconnect();
        }
      },
      {threshold: 0.08}
    );
    observer.observe(el);
    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={cardRef}
      style={{
        transitionDelay: `${Math.min(index, 5) * 45}ms`,
      }}
      className={`group relative rounded-[22px] bg-white border border-[#E8A91A]/25 p-2.5 shadow-xs transition-all duration-300 hover:-translate-y-0.5 hover:shadow-md ${
        revealed ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-4'
      } ${soldOut ? 'opacity-55' : ''}`}
    >
      {/* Portrait 3:4 Product Thumbnail */}
      <Link
        to={productUrl}
        className={`relative block aspect-[3/4] w-full rounded-[16px] overflow-hidden ${pastelClass}`}
      >
        <ResilientImage
          src={mainImageObj.thumb}
          alt={product.name}
          fallbackLabel={product.name}
          loading="lazy"
          decoding="async"
          style={{
            objectPosition: `${mainImageObj.focus_x}% ${mainImageObj.focus_y}%`,
          }}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-[1.03]"
        />

        {/* Discount tag (single clean label, no badge spam) */}
        {!soldOut && discount > 0 && (
          <span className="animate-soft-pulse absolute top-2.5 right-2.5 px-2.5 py-0.5 rounded-lg bg-[#B3261E] text-white text-xs font-bold tabular-nums shadow-xs">
            خصم {discount}٪
          </span>
        )}

        {/* Sold-out red diagonal ribbon */}
        {soldOut && (
          <div className="pointer-events-none absolute inset-0 flex items-center justify-center overflow-hidden">
            <span className="-rotate-12 bg-[#B3261E] text-white text-xs sm:text-sm font-bold px-8 py-1.5 shadow-md tracking-wide">
              تم البيع
            </span>
          </div>
        )}
      </Link>

      {/* Clean Unboxed Metadata & Price */}
      <Link to={productUrl} className="block pt-2.5 px-1 pb-1 space-y-1">
        {(categoryName || product.code) && (
          <div className="flex items-center justify-between gap-2 text-[11px] font-semibold text-[#5B5B5B]">
            <span className="truncate">{categoryName || ''}</span>
            {product.code && (
              <span className="shrink-0 tabular-nums text-[#0F4C3A]">كود: {product.code}</span>
            )}
          </div>
        )}
        <h3 className="text-sm sm:text-[15px] font-bold text-[#141413] leading-snug line-clamp-2 min-h-[2.5rem]">
          {product.name}
        </h3>
        <div className="flex items-baseline justify-between gap-2 pt-0.5 tabular-nums">
          <div className="flex items-baseline gap-2">
            <span className="text-[15px] sm:text-base font-bold text-[#0F4C3A]">
              {formatPrice(product.price)}
            </span>
            {product.old_price && product.old_price > product.price && (
              <span className="text-xs text-[#5B5B5B] line-through">
                {formatPrice(product.old_price)}
              </span>
            )}
          </div>
          {!soldOut && selectedSizeFilter && (
            <span className="text-[11px] font-bold text-[#0F4C3A]">
              متاح مقاس {selectedSizeFilter}
            </span>
          )}
        </div>
      </Link>
    </div>
  );
};
