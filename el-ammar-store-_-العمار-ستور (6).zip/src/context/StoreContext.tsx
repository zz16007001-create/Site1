import React, {createContext, useCallback, useContext, useEffect, useMemo, useRef, useState} from 'react';
import {
  DEMO_BANNERS,
  DEMO_CATEGORIES,
  DEMO_ORDERS,
  DEMO_PRODUCTS,
  DEMO_SETTINGS,
} from '../data/demoData';
import {isSupabaseConfigured, supabase} from '../lib/supabase';
import type {
  BackupRecord,
  BackupSnapshot,
  Banner,
  CartItem,
  Category,
  Order,
  OrderChannel,
  Product,
  ProductColor,
  ProductImage,
  ProductSize,
  SizeStatus,
  StorageDeleteResult,
  StoreSettings,
} from '../types/store';
import {
  blobToDataUrl,
  clampFocus,
  compressBlobToPair,
  compressImageFile,
  compressImagePairFromFile,
  DEFAULT_FOCUS_X,
  DEFAULT_FOCUS_Y,
  extractImagesBucketPath,
  fileToCompressedDataUrl,
  getProductMainImage,
  type ImageCompressionStats,
  normalizeProductImages,
} from '../utils/catalogHelpers';
import {trackPixelEvent} from '../utils/metaPixel';

interface ToastState {
  id: number;
  message: string;
  tone: 'info' | 'success' | 'warning';
}

interface FlyCartAnim {
  id: number;
  image: string;
  fromX: number;
  fromY: number;
}

export interface ProductDraftInput {
  id?: string;
  name: string;
  code?: string | null;
  category_id: string | null;
  subcategory_id: string | null;
  description: string;
  price: number;
  old_price: number | null;
  visible: boolean;
  featured: boolean;
  is_permanent?: boolean;
  listed_at?: string;
  skipRefresh?: boolean;
  colors: Array<{
    id?: string;
    name: string | null;
    hex: string | null;
    images: ProductImage[];
    sort: number;
    sizes: Array<{
      id?: string;
      size: string | null;
      status: SizeStatus;
    }>;
  }>;
}

interface StoreContextValue {
  isDemoMode: boolean;
  loading: boolean;
  error: string | null;
  categories: Category[];
  products: Product[];
  banners: Banner[];
  settings: StoreSettings;
  orders: Order[];
  ordersLoading: boolean;
  backups: BackupRecord[];
  backupsLoading: boolean;
  cart: CartItem[];
  recentlyViewed: string[];
  toast: ToastState | null;
  cartBounceKey: number;
  flyAnim: FlyCartAnim | null;
  cartIconRef: React.RefObject<HTMLAnchorElement | null>;
  // Auth & Security
  adminEmail: string | null;
  isAdmin: boolean;
  authLoading: boolean;
  pinIsDefault: boolean;
  storageUsageBytes: number | null;
  checkIsDefaultPin: () => Promise<boolean>;
  fetchStorageUsageBytes: () => Promise<number | null>;
  signInAdmin: (email: string, password: string) => Promise<{ok: boolean; message?: string}>;
  signOutAdmin: () => Promise<void>;
  // Storefront actions
  refreshCatalog: () => Promise<Product[]>;
  showToast: (message: string, tone?: 'info' | 'success' | 'warning') => void;
  addToCart: (item: Omit<CartItem, 'key'>, originEl?: HTMLElement | null) => void;
  updateCartQty: (key: string, qty: number) => void;
  removeFromCart: (key: string) => void;
  clearCart: () => void;
  recordRecentlyViewed: (productId: string) => void;
  createOrder: (
    channel: OrderChannel,
    overrideLines?: Array<Omit<CartItem, 'key'>>,
    customerPhone?: string
  ) => Promise<{orderNo: number | null; ok: boolean; errorMessage?: string}>;
  // Admin actions
  fetchOrders: () => Promise<void>;
  uploadImage: (file: File, options?: {preserveAlpha?: boolean; maxDimension?: number}) => Promise<string>;
  uploadProductImagePair: (
    file: File,
    onCompressed?: (stats: ImageCompressionStats) => void
  ) => Promise<ProductImage>;
  uploadArchiveImageFromBlob: (blob: Blob, focusX?: number, focusY?: number) => Promise<ProductImage>;
  saveProduct: (draft: ProductDraftInput) => Promise<Product>;
  upsertRestoredProduct: (
    draft: ProductDraftInput & {id: string; created_at?: string; skipRefresh?: boolean}
  ) => Promise<void>;
  ensureArchiveCategories: (params: {
    categoryId: string | null;
    categoryName: string | null;
    subcategoryId: string | null;
    subcategoryName: string | null;
    catMap: Map<string, Category>;
  }) => Promise<{categoryId: string | null; subcategoryId: string | null}>;
  duplicateProduct: (product: Product) => Promise<void>;
  deleteProducts: (ids: string[]) => Promise<void>;
  renewProduct: (productId: string) => Promise<void>;
  makeProductPermanent: (productId: string) => Promise<void>;
  permanentlyDeleteProducts: (
    ids: string[],
    onProgress?: (progress: {stage: 'db' | 'storage'; done: number; total: number}) => void
  ) => Promise<StorageDeleteResult>;
  retryDeleteStoragePaths: (
    paths: string[],
    onProgress?: (progress: {done: number; total: number}) => void
  ) => Promise<{deletedImages: number; failedPaths: string[]}>;
  cleanupDraftImageUrls: (urls: string[]) => Promise<void>;
  bulkUpdateProducts: (
    ids: string[],
    action: {type: 'visibility'; visible: boolean} | {type: 'price_percent'; percent: number} | {type: 'price_amount'; amount: number}
  ) => Promise<void>;
  quickUpdateProductPrices: (productId: string, price: number, oldPrice: number | null) => Promise<void>;
  toggleProductSoldAll: (productId: string, makeSold: boolean) => Promise<void>;
  toggleSizeStatus: (sizeId: string, status: SizeStatus) => Promise<void>;
  saveCategory: (cat: Partial<Category> & {name: string}) => Promise<void>;
  deleteCategory: (id: string) => Promise<void>;
  reorderCategories: (orderedIds: string[]) => Promise<void>;
  saveBanner: (ban: Partial<Banner> & {title: string}) => Promise<void>;
  deleteBanner: (id: string) => Promise<void>;
  reorderBanners: (orderedIds: string[]) => Promise<void>;
  saveSettings: (next: StoreSettings) => Promise<void>;
  markOrderDelivered: (orderId: string) => Promise<void>;
  markOrderCancelled: (orderId: string) => Promise<void>;
  markOrderUndo: (orderId: string) => Promise<void>;
  deleteOrder: (orderId: string) => Promise<void>;
  deleteAllCancelledOrders: () => Promise<number>;
  // Backups & PIN Reset
  fetchBackups: () => Promise<void>;
  createBackup: (label?: string) => Promise<BackupRecord | null>;
  deleteBackup: (backupId: string) => Promise<void>;
  restoreBackup: (backupId: string) => Promise<Product[]>;
  resetAllProducts: (
    pin: string,
    takeBackup: boolean,
    deleteStorage: boolean
  ) => Promise<{
    ok: boolean;
    error?: 'locked' | 'invalid_pin' | 'unknown';
    attemptsLeft?: number;
    lockedUntil?: string | null;
    deletedProducts?: number;
    deletedImages?: number;
    pinnedImages?: number;
    failedPaths?: string[];
  }>;
  changeResetPin: (
    oldPin: string,
    newPin: string
  ) => Promise<{
    ok: boolean;
    error?: 'locked' | 'invalid_pin' | 'invalid_new_pin' | 'unknown';
    attemptsLeft?: number;
    lockedUntil?: string | null;
  }>;
}

const StoreContext = createContext<StoreContextValue | null>(null);

const CART_STORAGE_KEY = 'elamar_cart_v1';
const RECENT_STORAGE_KEY = 'elamar_recent_v1';
const DEMO_BACKUPS_STORAGE_KEY = 'elamar_demo_backups_v1';
const DEMO_PIN_STORAGE_KEY = 'elamar_demo_pin_state_v1';

function readJsonStorage<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function hashDemoPin(pin: string): string {
  // Deterministic non-plaintext salted digest for Demo Mode only (live mode uses server-side pgcrypto bcrypt)
  let h = 2166136261;
  const salted = `elamar-demo-pin::${pin}`;
  for (let i = 0; i < salted.length; i++) {
    h ^= salted.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return `fnv_${(h >>> 0).toString(16)}`;
}

export const StoreProvider: React.FC<{children: React.ReactNode}> = ({children}) => {
  const isDemoMode = !isSupabaseConfigured || !supabase;

  const [loading, setLoading] = useState(!isDemoMode);
  const [error, setError] = useState<string | null>(null);

  const [categories, setCategories] = useState<Category[]>(() => (isDemoMode ? DEMO_CATEGORIES : []));
  const [products, setProducts] = useState<Product[]>(() => (isDemoMode ? DEMO_PRODUCTS : []));
  const [banners, setBanners] = useState<Banner[]>(() => (isDemoMode ? DEMO_BANNERS : []));
  const [settings, setSettings] = useState<StoreSettings>(DEMO_SETTINGS);
  const [orders, setOrders] = useState<Order[]>(() => (isDemoMode ? DEMO_ORDERS : []));
  const [ordersLoading, setOrdersLoading] = useState(false);
  const [backups, setBackups] = useState<BackupRecord[]>(() =>
    isDemoMode ? readJsonStorage<BackupRecord[]>(DEMO_BACKUPS_STORAGE_KEY, []) : []
  );
  const [backupsLoading, setBackupsLoading] = useState(false);

  const [cart, setCart] = useState<CartItem[]>(() => readJsonStorage<CartItem[]>(CART_STORAGE_KEY, []));
  const [recentlyViewed, setRecentlyViewed] = useState<string[]>(() =>
    readJsonStorage<string[]>(RECENT_STORAGE_KEY, [])
  );

  const [toast, setToast] = useState<ToastState | null>(null);
  const [cartBounceKey, setCartBounceKey] = useState(0);
  const [flyAnim, setFlyAnim] = useState<FlyCartAnim | null>(null);
  const cartIconRef = useRef<HTMLAnchorElement | null>(null);

  const [adminEmail, setAdminEmail] = useState<string | null>(isDemoMode ? 'demo-owner@elamar.store' : null);
  const [isAdmin, setIsAdmin] = useState<boolean>(isDemoMode);
  const [authLoading, setAuthLoading] = useState<boolean>(!isDemoMode);
  const [pinIsDefault, setPinIsDefault] = useState<boolean>(() => {
    if (!isDemoMode) return false;
    const saved = readJsonStorage<{pinHash?: string}>(DEMO_PIN_STORAGE_KEY, {});
    return !saved.pinHash || saved.pinHash === hashDemoPin('1234');
  });
  const [storageUsageBytes, setStorageUsageBytes] = useState<number | null>(null);

  const toastTimerRef = useRef<number | null>(null);
  const hasLoadedCatalogRef = useRef<boolean>(isDemoMode);
  const productsRef = useRef<Product[]>(products);
  productsRef.current = products;
  const isAdminRef = useRef<boolean>(isAdmin);
  isAdminRef.current = isAdmin;
  const prevIsAdminRef = useRef<boolean>(isAdmin);
  const catalogStateRef = useRef({categories, products, banners, settings, backups});
  catalogStateRef.current = {categories, products, banners, settings, backups};

  const showToast = useCallback((message: string, tone: 'info' | 'success' | 'warning' = 'info') => {
    if (toastTimerRef.current) window.clearTimeout(toastTimerRef.current);
    setToast({id: Date.now(), message, tone});
    toastTimerRef.current = window.setTimeout(
      () => {
        setToast(null);
      },
      tone === 'warning' ? 6000 : 3200
    );
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cart));
    } catch {
      // Ignore storage quota errors
    }
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem(RECENT_STORAGE_KEY, JSON.stringify(recentlyViewed));
    } catch {
      // Ignore
    }
  }, [recentlyViewed]);

  useEffect(() => {
    if (!isDemoMode) return;
    try {
      localStorage.setItem(DEMO_BACKUPS_STORAGE_KEY, JSON.stringify(backups));
    } catch {
      // Ignore storage quota errors in demo mode
    }
  }, [backups, isDemoMode]);

  const refreshCatalog = useCallback(async (): Promise<Product[]> => {
    if (isDemoMode || !supabase) {
      setLoading(false);
      return productsRef.current;
    }
    const client = supabase;
    if (!hasLoadedCatalogRef.current) {
      setLoading(true);
    }
    setError(null);

    const fetchAllPages = async <T,>(
      buildPageQuery: (from: number, to: number) => PromiseLike<{data: T[] | null; error: unknown}>,
      pageSize = 1000
    ): Promise<T[]> => {
      const all: T[] = [];
      let from = 0;
      while (true) {
        const to = from + pageSize - 1;
        const {data, error: qErr} = await buildPageQuery(from, to);
        if (qErr) throw qErr;
        const batch = data || [];
        all.push(...batch);
        if (batch.length < pageSize) break;
        from += pageSize;
      }
      return all;
    };

    try {
      const [catRes, banRes, setRes] = await Promise.all([
        client
          .from('categories')
          .select('id,name,image_url,sort,visible,parent_id')
          .order('sort', {ascending: true}),
        client
          .from('banners')
          .select('id,image_url,title,subtitle,btn_text,link,active,sort,type,product_id,category_id,ends_at')
          .order('sort', {ascending: true}),
        client
          .from('settings')
          .select(
            'id,store_name,logo_url,whatsapp,messenger_url,instagram_url,facebook_url,whatsapp_group_url,welcome,order_intro,trust_items,pixel_id,expiry_days,backup_retention_days,caption_template,features'
          )
          .eq('id', 1)
          .maybeSingle(),
      ]);

      if (catRes.error) throw catRes.error;
      if (banRes.error) throw banRes.error;

      const effectiveExpiryDays = Math.max(
        1,
        Number(setRes.data?.expiry_days) || DEMO_SETTINGS.expiry_days
      );
      const cutoffIso = new Date(Date.now() - effectiveExpiryDays * 86400000).toISOString();
      const applyPublicExpiryFilter = !isAdminRef.current;

      const queryProductsPages = async (includeCode: boolean) => {
        return fetchAllPages<Record<string, unknown>>(async (from, to) => {
          const base = includeCode
            ? client
                .from('products')
                .select(
                  'id,name,code,category_id,subcategory_id,description,price,old_price,visible,featured,is_permanent,listed_at,created_at'
                )
            : client
                .from('products')
                .select(
                  'id,name,category_id,subcategory_id,description,price,old_price,visible,featured,is_permanent,listed_at,created_at'
                );
          let q = base
            .order('created_at', {ascending: false})
            .order('id', {ascending: true});
          if (applyPublicExpiryFilter) {
            q = q.or(`is_permanent.eq.true,listed_at.gte.${cutoffIso}`);
          }
          const res = await q.range(from, to);
          return {
            data: res.data as unknown as Record<string, unknown>[] | null,
            error: res.error,
          };
        });
      };

      let rawProducts: Record<string, unknown>[];
      try {
        rawProducts = await queryProductsPages(true);
      } catch (prodErr) {
        const msg = String((prodErr as {message?: string})?.message || '').toLowerCase();
        const code = (prodErr as {code?: string})?.code;
        if (code === '42703' || msg.includes('code')) {
          rawProducts = await queryProductsPages(false);
        } else {
          throw prodErr;
        }
      }

      const [rawColors, rawSizes] = await Promise.all([
        fetchAllPages<Record<string, unknown>>((from, to) =>
          client
            .from('product_colors')
            .select('id,product_id,name,hex,images,sort')
            .order('sort', {ascending: true})
            .order('id', {ascending: true})
            .range(from, to)
        ),
        fetchAllPages<Record<string, unknown>>((from, to) =>
          client
            .from('product_sizes')
            .select('id,color_id,size,status,sold_at')
            .order('id', {ascending: true})
            .range(from, to)
        ),
      ]);

      const sizeMap = new Map<string, ProductSize[]>();
      for (const s of rawSizes) {
        const cid = String(s.color_id);
        const arr = sizeMap.get(cid) || [];
        arr.push({
          id: String(s.id),
          color_id: cid,
          size: (s.size as string | null) ?? null,
          status: (s.status as SizeStatus) || 'available',
          sold_at: (s.sold_at as string | null) ?? null,
        });
        sizeMap.set(cid, arr);
      }

      const colorMap = new Map<string, ProductColor[]>();
      for (const c of rawColors) {
        const pid = String(c.product_id);
        const cid = String(c.id);
        const arr = colorMap.get(pid) || [];
        arr.push({
          id: cid,
          product_id: pid,
          name: (c.name as string | null) ?? null,
          hex: (c.hex as string | null) ?? null,
          images: normalizeProductImages(c.images),
          sort: Number(c.sort ?? 0),
          sizes: sizeMap.get(cid) || [],
        });
        colorMap.set(pid, arr);
      }

      const assembledProducts: Product[] = rawProducts.map((p) => {
        const pid = String(p.id);
        return {
          id: pid,
          name: String(p.name || ''),
          code: (p.code as string | null) ?? null,
          category_id: (p.category_id as string | null) ?? null,
          subcategory_id: (p.subcategory_id as string | null) ?? null,
          description: String(p.description || ''),
          price: Number(p.price),
          old_price: p.old_price !== null && p.old_price !== undefined ? Number(p.old_price) : null,
          visible: Boolean(p.visible),
          featured: Boolean(p.featured),
          is_permanent: Boolean(p.is_permanent),
          listed_at: String(p.listed_at || p.created_at),
          created_at: String(p.created_at),
          colors: colorMap.get(pid) || [],
        };
      });

      const normalizedCategories: Category[] = (catRes.data || []).map((c) => ({
        id: c.id,
        name: c.name,
        image_url: c.image_url ?? null,
        sort: c.sort ?? 0,
        visible: Boolean(c.visible),
        parent_id: c.parent_id ?? null,
      }));

      const normalizedBanners: Banner[] = (banRes.data || []).map((b) => ({
        id: b.id,
        image_url: b.image_url ?? null,
        title: b.title || '',
        subtitle: b.subtitle || '',
        btn_text: b.btn_text || 'تسوقي الآن',
        link: b.link || '/catalog',
        active: Boolean(b.active),
        sort: b.sort ?? 0,
        type: b.type || 'message',
        product_id: b.product_id ?? null,
        category_id: b.category_id ?? null,
        ends_at: b.ends_at ?? null,
      }));

      setCategories(normalizedCategories);
      setProducts(assembledProducts);
      setBanners(normalizedBanners);
      if (setRes.data) {
        setSettings({
          ...DEMO_SETTINGS,
          ...setRes.data,
          expiry_days: effectiveExpiryDays,
          backup_retention_days: Math.max(
            1,
            Number(setRes.data.backup_retention_days) || DEMO_SETTINGS.backup_retention_days
          ),
          trust_items: Array.isArray(setRes.data.trust_items)
            ? setRes.data.trust_items
            : DEMO_SETTINGS.trust_items,
          pixel_id: setRes.data.pixel_id ?? '',
          whatsapp_group_url: setRes.data.whatsapp_group_url ?? '',
          caption_template: setRes.data.caption_template || DEMO_SETTINGS.caption_template,
          features: {
            ...DEMO_SETTINGS.features,
            ...(setRes.data.features || {}),
          },
        });
      }
      hasLoadedCatalogRef.current = true;
      return assembledProducts;
    } catch (err) {
      setError(err instanceof Error ? err.message : 'تعذر تحميل بيانات المتجر');
      return productsRef.current;
    } finally {
      setLoading(false);
    }
  }, [isDemoMode]);

  useEffect(() => {
    refreshCatalog();
  }, [refreshCatalog]);

  // Silently prune cart & recentlyViewed if products are deleted or hidden
  useEffect(() => {
    if (!hasLoadedCatalogRef.current || loading || error) return;

    const visibleProductIds = new Set<string>();
    const visibleSizeIds = new Set<string>();
    for (const p of products) {
      if (!p.visible) continue;
      visibleProductIds.add(p.id);
      for (const c of p.colors) {
        for (const s of c.sizes) {
          visibleSizeIds.add(s.id);
        }
      }
    }

    const nextCart = cart.filter(
      (item) => visibleProductIds.has(item.product_id) && visibleSizeIds.has(item.size_id)
    );
    const nextRecent = recentlyViewed.filter((id) => visibleProductIds.has(id));

    const cartShrank = nextCart.length !== cart.length;
    const recentShrank = nextRecent.length !== recentlyViewed.length;

    if (cartShrank) setCart(nextCart);
    if (recentShrank) setRecentlyViewed(nextRecent);

    if (cartShrank) {
      showToast('بعض القطع خلصت واتشالت', 'info');
    }
  }, [products, loading, error, cart, recentlyViewed, showToast]);

  useEffect(() => {
    const client = supabase;
    if (isDemoMode || !client) {
      setAuthLoading(false);
      return;
    }

    let cancelled = false;
    const checkSession = async (showLoader: boolean) => {
      if (showLoader) setAuthLoading(true);
      try {
        const {data, error: sessionErr} = await client.auth.getSession();
        if (sessionErr && isAdminRef.current) {
          console.warn('getSession transient error while admin active:', sessionErr);
          if (!cancelled) setAuthLoading(false);
          return;
        }
        const email = data.session?.user?.email || null;
        if (!email) {
          if (!cancelled) {
            setAdminEmail(null);
            setIsAdmin(false);
            setAuthLoading(false);
          }
          return;
        }

        const {data: allowed, error: rpcErr} = await client.rpc('is_current_user_admin');
        if (rpcErr) {
          if (isAdminRef.current) {
            console.warn('is_current_user_admin transient error, keeping active admin session:', rpcErr);
            if (!cancelled) setAuthLoading(false);
            return;
          }
          await new Promise((r) => window.setTimeout(r, 2000));
          if (cancelled) return;
          const {data: retryAllowed, error: retryErr} = await client.rpc('is_current_user_admin');
          if (!cancelled) {
            setAdminEmail(email);
            setIsAdmin(retryErr ? false : Boolean(retryAllowed));
            setAuthLoading(false);
          }
          return;
        }

        if (!cancelled) {
          setAdminEmail(email);
          setIsAdmin(Boolean(allowed));
          setAuthLoading(false);
        }
      } catch (err) {
        if (isAdminRef.current) {
          console.warn('checkSession error while admin active, keeping session:', err);
          if (!cancelled) setAuthLoading(false);
        } else if (!cancelled) {
          setIsAdmin(false);
          setAuthLoading(false);
        }
      }
    };

    void checkSession(true);
    const {data: sub} = client.auth.onAuthStateChange((event) => {
      if (
        event === 'SIGNED_OUT' ||
        event === 'USER_UPDATED' ||
        event === 'INITIAL_SESSION' ||
        (event === 'SIGNED_IN' && !isAdminRef.current)
      ) {
        void checkSession(false);
      }
    });
    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
  }, [isDemoMode]);

  const checkIsDefaultPin = useCallback(async (): Promise<boolean> => {
    if (isDemoMode || !supabase) {
      const saved = readJsonStorage<{pinHash?: string}>(DEMO_PIN_STORAGE_KEY, {});
      const isDef = !saved.pinHash || saved.pinHash === hashDemoPin('1234');
      setPinIsDefault(isDef);
      return isDef;
    }
    try {
      const {data, error: rpcErr} = await supabase.rpc('is_default_reset_pin');
      if (rpcErr) {
        return false;
      }
      const isDef = Boolean(data);
      setPinIsDefault(isDef);
      return isDef;
    } catch {
      return false;
    }
  }, [isDemoMode]);

  const fetchStorageUsageBytes = useCallback(async (): Promise<number | null> => {
    if (isDemoMode || !supabase) {
      try {
        const estimated = new Blob([
          JSON.stringify({
            products: productsRef.current,
            backups: catalogStateRef.current.backups,
          }),
        ]).size;
        setStorageUsageBytes(estimated);
        return estimated;
      } catch {
        return null;
      }
    }
    try {
      const {data, error: rpcErr} = await supabase.rpc('get_storage_usage_bytes');
      if (rpcErr) {
        return null;
      }
      const bytes = Math.max(0, Number(data) || 0);
      setStorageUsageBytes(bytes);
      return bytes;
    } catch {
      return null;
    }
  }, [isDemoMode]);

  useEffect(() => {
    const wasAdmin = prevIsAdminRef.current;
    prevIsAdminRef.current = isAdmin;
    if (isAdmin) {
      if (!isDemoMode && !wasAdmin) {
        void refreshCatalog();
      }
      void checkIsDefaultPin();
      void fetchStorageUsageBytes();
    } else if (!isDemoMode && wasAdmin) {
      setPinIsDefault(false);
      setStorageUsageBytes(null);
    }
  }, [checkIsDefaultPin, fetchStorageUsageBytes, isAdmin, isDemoMode, refreshCatalog]);

  const signInAdmin = useCallback(
    async (email: string, password: string) => {
      if (isDemoMode || !supabase) {
        setAdminEmail(email || 'demo-owner@elamar.store');
        setIsAdmin(true);
        return {ok: true};
      }
      const {error: authErr} = await supabase.auth.signInWithPassword({email: email.trim(), password});
      if (authErr) {
        return {ok: false, message: 'بيانات الدخول غير صحيحة'};
      }
      const {data: allowed} = await supabase.rpc('is_current_user_admin');
      if (!allowed) {
        await supabase.auth.signOut();
        return {ok: false, message: 'هذا الحساب غير مصرح له بإدارة المتجر'};
      }
      setAdminEmail(email.trim());
      setIsAdmin(true);
      await refreshCatalog();
      return {ok: true};
    },
    [isDemoMode, refreshCatalog]
  );

  const signOutAdmin = useCallback(async () => {
    if (isDemoMode || !supabase) {
      showToast('تم تسجيل الخروج (الوضع التجريبي)');
      return;
    }
    await supabase.auth.signOut();
    setAdminEmail(null);
    setIsAdmin(false);
    await refreshCatalog();
  }, [isDemoMode, refreshCatalog, showToast]);

  const addToCart = useCallback(
    (item: Omit<CartItem, 'key'>, originEl?: HTMLElement | null) => {
      const key = `${item.product_id}__${item.color_id}__${item.size_id}`;
      setCart((prev) => {
        const existing = prev.find((l) => l.key === key);
        if (existing) {
          return prev.map((l) => (l.key === key ? {...l, qty: l.qty + item.qty} : l));
        }
        return [...prev, {...item, key}];
      });

      trackPixelEvent(settings.pixel_id, 'AddToCart', {
        content_name: item.name,
        content_ids: [item.product_id],
        content_type: 'product',
        value: item.price * item.qty,
        currency: 'EGP',
      });

      if (originEl) {
        const rect = originEl.getBoundingClientRect();
        setFlyAnim({
          id: Date.now(),
          image: item.image,
          fromX: rect.left + rect.width / 2,
          fromY: rect.top + rect.height / 2,
        });
        window.setTimeout(() => setFlyAnim(null), 650);
      }
      window.setTimeout(() => setCartBounceKey((k) => k + 1), originEl ? 380 : 0);
      showToast('تمت الإضافة إلى السلة', 'success');
    },
    [settings.pixel_id, showToast]
  );

  const updateCartQty = useCallback((key: string, qty: number) => {
    setCart((prev) =>
      prev.map((l) => (l.key === key ? {...l, qty: Math.max(1, qty)} : l))
    );
  }, []);

  const removeFromCart = useCallback((key: string) => {
    setCart((prev) => prev.filter((l) => l.key !== key));
  }, []);

  const clearCart = useCallback(() => {
    setCart([]);
  }, []);

  const recordRecentlyViewed = useCallback((productId: string) => {
    setRecentlyViewed((prev) => {
      const filtered = prev.filter((id) => id !== productId);
      return [productId, ...filtered].slice(0, 10);
    });
  }, []);

  const createOrder = useCallback(
    async (
      channel: OrderChannel,
      overrideLines?: Array<Omit<CartItem, 'key'>>,
      customerPhone?: string
    ): Promise<{orderNo: number | null; ok: boolean; errorMessage?: string}> => {
      const targetLines = overrideLines && overrideLines.length > 0 ? overrideLines : cart;
      if (targetLines.length === 0) return {orderNo: null, ok: false};

      const totalVal = targetLines.reduce((sum, l) => sum + l.price * l.qty, 0);
      trackPixelEvent(settings.pixel_id, 'InitiateCheckout', {
        content_ids: targetLines.map((l) => l.product_id),
        num_items: targetLines.reduce((sum, l) => sum + l.qty, 0),
        value: totalVal,
        currency: 'EGP',
      });

      const normalizedPhone = customerPhone?.trim() || null;

      if (isDemoMode || !supabase) {
        const nextNo = orders.reduce((max, o) => Math.max(max, o.order_no), 1000) + 1;
        const newOrderId = `ord-${Date.now()}`;
        const newOrder: Order = {
          id: newOrderId,
          order_no: nextNo,
          created_at: new Date().toISOString(),
          status: 'new',
          channel,
          customer_phone: normalizedPhone,
          items: targetLines.map((line, idx) => ({
            id: `oi-${Date.now()}-${idx}`,
            order_id: newOrderId,
            product_id: line.product_id,
            color_id: line.color_id,
            size_id: line.size_id,
            name_snapshot: line.name,
            color_snapshot: line.color_name,
            size_snapshot: line.size_name,
            price_snapshot: line.price,
            qty: line.qty,
            thumbnail_url: line.image,
          })),
        };
        setOrders((prev) => [newOrder, ...prev]);
        return {orderNo: nextNo, ok: true};
      }

      try {
        const payload = targetLines.map((line) => ({
          product_id: line.product_id,
          color_id: line.color_id,
          size_id: line.size_id,
          qty: line.qty,
        }));

        const {data, error: rpcErr} = await supabase.rpc('create_order', {
          items: payload,
          channel,
          p_phone: normalizedPhone,
        });

        if (rpcErr) {
          const msg = String(rpcErr.message || '');
          const isMissingV2 =
            rpcErr.code === 'PGRST202' ||
            rpcErr.code === '23514' ||
            msg.includes('Could not find the function') ||
            msg.includes('orders_channel_check');
          if (isMissingV2) {
            if (channel === 'callback') {
              const warning = 'يلزم تشغيل ملف التحديث migration_v2.sql لتفعيل طلب المكالمة';
              showToast(warning, 'warning');
              return {orderNo: null, ok: false, errorMessage: warning};
            }
            const fallbackRes = await supabase.rpc('create_order', {
              items: payload,
              channel,
            });
            if (!fallbackRes.error && fallbackRes.data) {
              return {orderNo: fallbackRes.data.order_no ?? null, ok: true};
            }
          }
          if (msg.includes('Duplicate order submitted too quickly')) {
            const dupMsg = 'بعتّي الطلب ده من ثواني — لو محتاجة تعديل تواصلي معانا في الشات';
            showToast(dupMsg, 'warning');
            return {orderNo: null, ok: false, errorMessage: dupMsg};
          }
          return {orderNo: null, ok: false};
        }

        if (!data) return {orderNo: null, ok: false};
        return {orderNo: data.order_no ?? null, ok: true};
      } catch {
        return {orderNo: null, ok: false};
      }
    },
    [cart, isDemoMode, orders, settings.pixel_id, showToast]
  );

  // ============================================================================
  // ADMIN OPERATIONS
  // ============================================================================

  const fetchOrders = useCallback(async () => {
    if (isDemoMode || !supabase) return;
    setOrdersLoading(true);
    try {
      const {data: ordData, error: ordErr} = await supabase
        .from('orders')
        .select('*, order_items(*)')
        .order('created_at', {ascending: false});
      if (ordErr) throw ordErr;
      const mapped: Order[] = (ordData || []).map((o) => ({
        id: o.id,
        order_no: o.order_no,
        created_at: o.created_at,
        status: o.status,
        channel: o.channel,
        customer_phone: o.customer_phone ?? null,
        items: (o.order_items || []).map((item: Record<string, unknown>) => {
          const prod = productsRef.current.find((p) => p.id === item.product_id);
          const col = prod?.colors.find((c) => c.id === item.color_id);
          const thumb = col?.images[0]?.thumb || (prod ? getProductMainImage(prod) : null);
          return {
            id: String(item.id),
            order_id: String(item.order_id),
            product_id: (item.product_id as string) || null,
            color_id: (item.color_id as string) || null,
            size_id: (item.size_id as string) || null,
            name_snapshot: String(item.name_snapshot),
            color_snapshot: (item.color_snapshot as string) || null,
            size_snapshot: (item.size_snapshot as string) || null,
            price_snapshot: Number(item.price_snapshot),
            qty: Number(item.qty),
            thumbnail_url: thumb,
          };
        }),
      }));
      setOrders(mapped);
    } catch {
      showToast('تعذر تحميل الطلبات', 'warning');
    } finally {
      setOrdersLoading(false);
    }
  }, [isDemoMode, showToast]);

  const uploadImage = useCallback(
    async (
      file: File,
      options?: {preserveAlpha?: boolean; maxDimension?: number}
    ): Promise<string> => {
      const preserveAlpha = Boolean(options?.preserveAlpha);
      const maxDimension = options?.maxDimension ?? 1000;
      if (isDemoMode || !supabase) {
        return fileToCompressedDataUrl(file, preserveAlpha, maxDimension);
      }
      const compressed = await compressImageFile(file, maxDimension, 0.75, preserveAlpha);
      const isWebp = compressed.type === 'image/webp';
      const ext = isWebp ? 'webp' : 'jpg';
      const filePath = `uploads/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const {error: upErr} = await supabase.storage
        .from('images')
        .upload(filePath, compressed, {
          contentType: isWebp ? 'image/webp' : 'image/jpeg',
          cacheControl: '31536000',
          upsert: false,
        });
      if (upErr) throw upErr;
      const {data} = supabase.storage.from('images').getPublicUrl(filePath);
      return data.publicUrl;
    },
    [isDemoMode]
  );

  const uploadStorageWithRetry = async (
    filePath: string,
    fileBody: Blob
  ): Promise<{error: unknown}> => {
    if (!supabase) return {error: new Error('Supabase client unavailable')};
    const isNetworkErr = (err: unknown): boolean => {
      const msg = String(
        (err as {message?: string})?.message || err || ''
      ).toLowerCase();
      return (
        msg.includes('failed to fetch') ||
        msg.includes('load failed') ||
        msg.includes('networkerror')
      );
    };

    const mimeType = fileBody.type || 'image/webp';
    for (let attempt = 0; attempt <= 2; attempt++) {
      try {
        const {error: upErr} = await supabase.storage
          .from('images')
          .upload(filePath, fileBody, {
            contentType: mimeType,
            cacheControl: '31536000',
            upsert: false,
          });
        if (!upErr) return {error: null};
        if (attempt < 2 && isNetworkErr(upErr)) {
          await new Promise((r) => window.setTimeout(r, 1000));
          continue;
        }
        return {error: upErr};
      } catch (err) {
        if (attempt < 2 && isNetworkErr(err)) {
          await new Promise((r) => window.setTimeout(r, 1000));
          continue;
        }
        return {error: err};
      }
    }
    return {error: new Error('Upload retry exhausted')};
  };

  const uploadProductImagePair = useCallback(
    async (
      file: File,
      onCompressed?: (stats: ImageCompressionStats) => void
    ): Promise<ProductImage> => {
      const {full: fullResCompressed, thumb: thumbResCompressed} =
        await compressImagePairFromFile(file);

      onCompressed?.(fullResCompressed.stats);

      if (isDemoMode || !supabase) {
        const [full, thumb] = await Promise.all([
          blobToDataUrl(fullResCompressed.blob),
          blobToDataUrl(thumbResCompressed.blob),
        ]);
        return {
          full,
          thumb,
          focus_x: DEFAULT_FOCUS_X,
          focus_y: DEFAULT_FOCUS_Y,
        };
      }

      const fullBlob = fullResCompressed.blob;
      const thumbBlob = thumbResCompressed.blob;

      const base = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const fullExt = fullBlob.type === 'image/webp' ? 'webp' : 'jpg';
      const thumbExt = thumbBlob.type === 'image/webp' ? 'webp' : 'jpg';
      const fullPath = `products/${base}-full.${fullExt}`;
      const thumbPath = `products/${base}-thumb.${thumbExt}`;

      const [fullRes, thumbRes] = await Promise.all([
        uploadStorageWithRetry(fullPath, fullBlob),
        uploadStorageWithRetry(thumbPath, thumbBlob),
      ]);

      if (fullRes.error) {
        if (!thumbRes.error) {
          await supabase.storage.from('images').remove([thumbPath]).catch(() => {});
        }
        throw fullRes.error;
      }
      if (thumbRes.error) {
        await supabase.storage.from('images').remove([fullPath]).catch(() => {});
        throw thumbRes.error;
      }

      const fullUrl = supabase.storage.from('images').getPublicUrl(fullPath).data.publicUrl;
      const thumbUrl = supabase.storage.from('images').getPublicUrl(thumbPath).data.publicUrl;

      return {
        full: fullUrl,
        thumb: thumbUrl,
        focus_x: DEFAULT_FOCUS_X,
        focus_y: DEFAULT_FOCUS_Y,
      };
    },
    [isDemoMode]
  );

  const uploadArchiveImageFromBlob = useCallback(
    async (
      blob: Blob,
      focusX = DEFAULT_FOCUS_X,
      focusY = DEFAULT_FOCUS_Y
    ): Promise<ProductImage> => {
      if (isDemoMode || !supabase) {
        const isSvg = blob.type.includes('svg');
        if (isSvg) {
          const dataUrl = await blobToDataUrl(blob);
          return {full: dataUrl, thumb: dataUrl, focus_x: focusX, focus_y: focusY};
        }
        const {fullBlob, thumbBlob} = await compressBlobToPair(blob);
        const [full, thumb] = await Promise.all([
          blobToDataUrl(fullBlob),
          blobToDataUrl(thumbBlob),
        ]);
        return {full, thumb, focus_x: focusX, focus_y: focusY};
      }

      const {fullBlob, thumbBlob} = await compressBlobToPair(blob);
      const base = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
      const fullExt = fullBlob.type === 'image/webp' ? 'webp' : 'jpg';
      const thumbExt = thumbBlob.type === 'image/webp' ? 'webp' : 'jpg';
      const fullPath = `products/${base}-full.${fullExt}`;
      const thumbPath = `products/${base}-thumb.${thumbExt}`;

      const [fullRes, thumbRes] = await Promise.all([
        uploadStorageWithRetry(fullPath, fullBlob),
        uploadStorageWithRetry(thumbPath, thumbBlob),
      ]);

      if (fullRes.error) {
        if (!thumbRes.error) {
          await supabase.storage.from('images').remove([thumbPath]).catch(() => {});
        }
        throw fullRes.error;
      }
      if (thumbRes.error) {
        await supabase.storage.from('images').remove([fullPath]).catch(() => {});
        throw thumbRes.error;
      }

      const fullUrl = supabase.storage.from('images').getPublicUrl(fullPath).data.publicUrl;
      const thumbUrl = supabase.storage.from('images').getPublicUrl(thumbPath).data.publicUrl;

      return {
        full: fullUrl,
        thumb: thumbUrl,
        focus_x: clampFocus(focusX, DEFAULT_FOCUS_X),
        focus_y: clampFocus(focusY, DEFAULT_FOCUS_Y),
      };
    },
    [isDemoMode]
  );

  const saveProduct = useCallback(
    async (draft: ProductDraftInput): Promise<Product> => {
      if (isDemoMode || !supabase) {
        const prodId = draft.id || `prod-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`;
        const existing = products.find((p) => p.id === prodId);
        const createdAt = existing?.created_at || new Date().toISOString();
        const listedAt = draft.listed_at || existing?.listed_at || createdAt;
        const isPermanent = draft.is_permanent ?? existing?.is_permanent ?? false;
        const assembled: Product = {
          id: prodId,
          name: draft.name,
          code: draft.code?.trim() || null,
          category_id: draft.category_id,
          subcategory_id: draft.subcategory_id ?? null,
          description: draft.description,
          price: draft.price,
          old_price: draft.old_price,
          visible: draft.visible,
          featured: draft.featured,
          is_permanent: isPermanent,
          listed_at: listedAt,
          created_at: createdAt,
          colors: draft.colors.map((c, idx) => {
            const cid = c.id || `col-${Date.now()}-${idx}`;
            return {
              id: cid,
              product_id: prodId,
              name: c.name,
              hex: c.hex,
              images: c.images,
              sort: c.sort ?? idx + 1,
              sizes: c.sizes.map((s, sIdx) => ({
                id: s.id || `sz-${Date.now()}-${idx}-${sIdx}`,
                color_id: cid,
                size: s.size,
                status: s.status,
              })),
            };
          }),
        };
        setProducts((prev) =>
          existing ? prev.map((p) => (p.id === prodId ? assembled : p)) : [assembled, ...prev]
        );
        return assembled;
      }

      const isNewProduct = !draft.id;
      const previousProduct = draft.id
        ? productsRef.current.find((p) => p.id === draft.id)
        : undefined;
      const prevSizeMap = new Map<string, ProductSize>();
      if (previousProduct) {
        for (const oldCol of previousProduct.colors) {
          for (const oldSz of oldCol.sizes) {
            prevSizeMap.set(oldSz.id, oldSz);
          }
        }
      }

      const OPTIONAL_PRODUCT_COLUMNS = new Set([
        'is_permanent',
        'listed_at',
        'subcategory_id',
        'code',
      ]);
      const getMissingOptionalProductColumn = (err: unknown): string | null => {
        if (!err || typeof err !== 'object') return null;
        const e = err as {code?: string; message?: string};
        const msg = e.message || '';
        if (e.code === 'PGRST204' || msg.includes('schema cache')) {
          const match = msg.match(/Could not find the '([^']+)' column/i);
          if (match && OPTIONAL_PRODUCT_COLUMNS.has(match[1])) {
            return match[1];
          }
        }
        return null;
      };

      const nowIso = new Date().toISOString();
      let prodId = draft.id;
      let createdAt = previousProduct?.created_at || nowIso;
      let listedAt = draft.listed_at || previousProduct?.listed_at || nowIso;

      if (prodId) {
        const updatePayload: Record<string, unknown> = {
          name: draft.name,
          code: draft.code?.trim() || null,
          category_id: draft.category_id,
          subcategory_id: draft.subcategory_id ?? null,
          description: draft.description,
          price: draft.price,
          old_price: draft.old_price,
          visible: draft.visible,
          featured: draft.featured,
          is_permanent: Boolean(draft.is_permanent),
        };
        if (draft.listed_at) {
          updatePayload.listed_at = draft.listed_at;
        }
        for (let attempt = 0; attempt < 5; attempt++) {
          const {error: updErr} = await supabase
            .from('products')
            .update(updatePayload)
            .eq('id', prodId);
          if (!updErr) break;
          const missingCol = getMissingOptionalProductColumn(updErr);
          if (missingCol && missingCol in updatePayload) {
            console.warn(`Column "${missingCol}" missing in products table; retrying update without it.`, updErr);
            delete updatePayload[missingCol];
            continue;
          }
          throw updErr;
        }
      } else {
        const insertPayload: Record<string, unknown> = {
          name: draft.name,
          code: draft.code?.trim() || null,
          category_id: draft.category_id,
          subcategory_id: draft.subcategory_id ?? null,
          description: draft.description,
          price: draft.price,
          old_price: draft.old_price,
          visible: draft.visible,
          featured: draft.featured,
          is_permanent: Boolean(draft.is_permanent),
          listed_at: draft.listed_at || nowIso,
        };
        let insProd: {id: string; created_at?: string; listed_at?: string} | null = null;
        for (let attempt = 0; attempt < 5; attempt++) {
          const {data, error: insErr} = await supabase
            .from('products')
            .insert(insertPayload)
            .select()
            .single();
          if (!insErr && data) {
            insProd = data;
            break;
          }
          const missingCol = getMissingOptionalProductColumn(insErr);
          if (missingCol && missingCol in insertPayload) {
            console.warn(`Column "${missingCol}" missing in products table; retrying insert without it.`, insErr);
            delete insertPayload[missingCol];
            continue;
          }
          throw insErr || new Error('تعذر إنشاء المنتج');
        }
        if (!insProd) throw new Error('تعذر إنشاء المنتج');
        prodId = insProd.id;
        createdAt = insProd.created_at || nowIso;
        listedAt = insProd.listed_at || createdAt;
      }

      const savedColors: ProductColor[] = [];
      try {
        const keepColorIds = draft.colors.map((c) => c.id).filter(Boolean) as string[];
        if (draft.id) {
          const {data: existingColors, error: fetchColErr} = await supabase
            .from('product_colors')
            .select('id')
            .eq('product_id', prodId);
          if (fetchColErr) throw fetchColErr;
          const toDelete = (existingColors || [])
            .map((ec) => ec.id)
            .filter((cid) => !keepColorIds.includes(cid));
          if (toDelete.length > 0) {
            const {error: delColErr} = await supabase
              .from('product_colors')
              .delete()
              .in('id', toDelete);
            if (delColErr) throw delColErr;
          }
        }

        for (let i = 0; i < draft.colors.length; i++) {
          const c = draft.colors[i];
          const sortOrder = c.sort ?? i + 1;
          let colorId = c.id;
          if (colorId) {
            const {error: colUpdErr} = await supabase
              .from('product_colors')
              .update({name: c.name, hex: c.hex, images: c.images, sort: sortOrder})
              .eq('id', colorId);
            if (colUpdErr) throw colUpdErr;
          } else {
            const {data: insCol, error: colInsErr} = await supabase
              .from('product_colors')
              .insert({
                product_id: prodId,
                name: c.name,
                hex: c.hex,
                images: c.images,
                sort: sortOrder,
              })
              .select()
              .single();
            if (colInsErr || !insCol) throw colInsErr || new Error('تعذر حفظ اللون');
            colorId = insCol.id;
          }

          const keepSizeIds = c.sizes.map((s) => s.id).filter(Boolean) as string[];
          if (c.id) {
            const {data: existingSizes, error: fetchSzErr} = await supabase
              .from('product_sizes')
              .select('id')
              .eq('color_id', colorId);
            if (fetchSzErr) throw fetchSzErr;
            const szDelete = (existingSizes || [])
              .map((es) => es.id)
              .filter((sid) => !keepSizeIds.includes(sid));
            if (szDelete.length > 0) {
              const {error: delSzErr} = await supabase
                .from('product_sizes')
                .delete()
                .in('id', szDelete);
              if (delSzErr) throw delSzErr;
            }
          }

          const savedSizes: ProductSize[] = [];
          const newSizesPayload: Array<{
            color_id: string;
            size: string | null;
            status: SizeStatus;
            sold_at: string | null;
          }> = [];

          for (const s of c.sizes) {
            if (s.id) {
              const prevSz = prevSizeMap.get(s.id);
              let nextSoldAt: string | null = prevSz?.sold_at ?? null;
              if (s.status === 'sold') {
                if (!prevSz || prevSz.status !== 'sold') {
                  nextSoldAt = new Date().toISOString();
                }
              } else {
                nextSoldAt = null;
              }
              const {error: szUpdErr} = await supabase
                .from('product_sizes')
                .update({
                  size: s.size,
                  status: s.status,
                  sold_at: nextSoldAt,
                })
                .eq('id', s.id);
              if (szUpdErr) throw szUpdErr;
              savedSizes.push({
                id: s.id,
                color_id: colorId!,
                size: s.size,
                status: s.status,
                sold_at: nextSoldAt,
              });
            } else {
              newSizesPayload.push({
                color_id: colorId!,
                size: s.size,
                status: s.status,
                sold_at: s.status === 'sold' ? new Date().toISOString() : null,
              });
            }
          }

          if (newSizesPayload.length > 0) {
            const {data: insSizes, error: szInsErr} = await supabase
              .from('product_sizes')
              .insert(newSizesPayload)
              .select();
            if (szInsErr) throw szInsErr;
            for (const row of insSizes || []) {
              savedSizes.push({
                id: row.id,
                color_id: row.color_id,
                size: row.size,
                status: row.status,
                sold_at: row.sold_at,
              });
            }
          }

          savedColors.push({
            id: colorId!,
            product_id: prodId!,
            name: c.name,
            hex: c.hex,
            images: c.images,
            sort: sortOrder,
            sizes: savedSizes,
          });
        }
      } catch (err) {
        if (isNewProduct && prodId) {
          await supabase.from('products').delete().eq('id', prodId).then(() => {}, () => {});
        }
        throw err;
      }

      if (draft.id && previousProduct) {
        const keptOrProtected = new Set<string>();
        const markProtected = (url: string | null | undefined) => {
          const p = extractImagesBucketPath(url);
          if (p) keptOrProtected.add(p);
        };
        markProtected(settings.logo_url);
        for (const cat of categories) markProtected(cat.image_url);
        for (const ban of banners) markProtected(ban.image_url);
        for (const rev of settings.features.customer_reviews?.items || []) markProtected(rev.image_url);
        for (const other of productsRef.current) {
          if (other.id === prodId) continue;
          for (const c of other.colors) {
            for (const img of c.images) {
              markProtected(img.full);
              markProtected(img.thumb);
            }
          }
        }
        for (const c of draft.colors) {
          for (const img of c.images) {
            markProtected(img.full);
            markProtected(img.thumb);
          }
        }

        const orphanedPaths: string[] = [];
        for (const oldCol of previousProduct.colors) {
          for (const oldImg of oldCol.images) {
            const pFull = extractImagesBucketPath(oldImg.full);
            if (pFull && !keptOrProtected.has(pFull)) orphanedPaths.push(pFull);
            const pThumb = extractImagesBucketPath(oldImg.thumb);
            if (pThumb && !keptOrProtected.has(pThumb)) orphanedPaths.push(pThumb);
          }
        }
        if (orphanedPaths.length > 0) {
          // Respect Image Pinning Rule: keep any path referenced by backups or other records
          const {data: inUseArr} = await supabase.rpc('image_paths_in_use');
          const pinnedSet = new Set<string>(Array.isArray(inUseArr) ? inUseArr : []);
          const safeToRemove = Array.from(new Set(orphanedPaths)).filter((p) => !pinnedSet.has(p));
          if (safeToRemove.length > 0) {
            await supabase.storage.from('images').remove(safeToRemove).catch(() => {});
          }
        }
      }

      const assembledSaved: Product = {
        id: prodId!,
        name: draft.name,
        code: draft.code?.trim() || null,
        category_id: draft.category_id,
        subcategory_id: draft.subcategory_id ?? null,
        description: draft.description,
        price: draft.price,
        old_price: draft.old_price,
        visible: draft.visible,
        featured: draft.featured,
        is_permanent: Boolean(draft.is_permanent),
        listed_at: listedAt,
        created_at: createdAt,
        colors: savedColors,
      };

      if (draft.skipRefresh) {
        setProducts((prev) =>
          draft.id ? prev.map((p) => (p.id === prodId ? assembledSaved : p)) : [assembledSaved, ...prev]
        );
        return assembledSaved;
      }

      const latestProducts = await refreshCatalog();
      const updated = latestProducts.find((p) => p.id === prodId);
      return updated || assembledSaved;
    },
    [banners, categories, isDemoMode, refreshCatalog, settings]
  );

  const ensureArchiveCategories = useCallback(
    async (params: {
      categoryId: string | null;
      categoryName: string | null;
      subcategoryId: string | null;
      subcategoryName: string | null;
      catMap: Map<string, Category>;
    }): Promise<{categoryId: string | null; subcategoryId: string | null}> => {
      const {categoryId, categoryName, subcategoryId, subcategoryName, catMap} = params;
      let resolvedCatId: string | null = null;
      const allCats = Array.from(catMap.values());

      if (categoryId && catMap.has(categoryId) && !catMap.get(categoryId)?.parent_id) {
        resolvedCatId = categoryId;
      } else if (categoryName) {
        const byName = allCats.find(
          (c) => !c.parent_id && c.name.trim() === categoryName.trim()
        );
        if (byName) {
          resolvedCatId = byName.id;
        } else {
          const newId =
            categoryId && /^[0-9a-f-]{36}$/i.test(categoryId)
              ? categoryId
              : isDemoMode
                ? `cat-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`
                : crypto.randomUUID();
          const newCat: Category = {
            id: newId,
            name: categoryName.trim(),
            image_url: null,
            sort: allCats.filter((c) => !c.parent_id).length + 1,
            visible: true,
            parent_id: null,
          };
          if (!isDemoMode && supabase) {
            await supabase.from('categories').upsert(newCat);
          } else {
            setCategories((prev) => [...prev, newCat]);
          }
          catMap.set(newCat.id, newCat);
          resolvedCatId = newCat.id;
        }
      }

      let resolvedSubId: string | null = null;
      if (resolvedCatId) {
        if (
          subcategoryId &&
          catMap.has(subcategoryId) &&
          catMap.get(subcategoryId)?.parent_id === resolvedCatId
        ) {
          resolvedSubId = subcategoryId;
        } else if (subcategoryName) {
          const bySubName = Array.from(catMap.values()).find(
            (c) => c.parent_id === resolvedCatId && c.name.trim() === subcategoryName.trim()
          );
          if (bySubName) {
            resolvedSubId = bySubName.id;
          } else {
            const newSubId =
              subcategoryId && /^[0-9a-f-]{36}$/i.test(subcategoryId)
                ? subcategoryId
                : isDemoMode
                  ? `sub-${Date.now()}-${Math.random().toString(36).slice(2, 5)}`
                  : crypto.randomUUID();
            const newSub: Category = {
              id: newSubId,
              name: subcategoryName.trim(),
              image_url: null,
              sort: Array.from(catMap.values()).filter((c) => c.parent_id === resolvedCatId).length + 1,
              visible: true,
              parent_id: resolvedCatId,
            };
            if (!isDemoMode && supabase) {
              await supabase.from('categories').upsert(newSub);
            } else {
              setCategories((prev) => [...prev, newSub]);
            }
            catMap.set(newSub.id, newSub);
            resolvedSubId = newSub.id;
          }
        }
      }

      return {categoryId: resolvedCatId, subcategoryId: resolvedSubId};
    },
    [isDemoMode]
  );

  const upsertRestoredProduct = useCallback(
    async (draft: ProductDraftInput & {id: string; created_at?: string; skipRefresh?: boolean}) => {
      if (isDemoMode || !supabase) {
        const restored: Product = {
          id: draft.id,
          name: draft.name,
          code: draft.code?.trim() || null,
          category_id: draft.category_id,
          subcategory_id: draft.subcategory_id ?? null,
          description: draft.description || '',
          price: draft.price,
          old_price: draft.old_price ?? null,
          visible: draft.visible,
          featured: draft.featured,
          is_permanent: Boolean(draft.is_permanent),
          listed_at: draft.listed_at || draft.created_at || new Date().toISOString(),
          created_at: draft.created_at || new Date().toISOString(),
          colors: draft.colors.map((c, idx) => {
            const cid = c.id || `col-${Date.now()}-${idx}`;
            return {
              id: cid,
              product_id: draft.id,
              name: c.name,
              hex: c.hex,
              images: c.images,
              sort: c.sort ?? idx + 1,
              sizes: c.sizes.map((s, sIdx) => ({
                id: s.id || `sz-${Date.now()}-${idx}-${sIdx}`,
                color_id: cid,
                size: s.size,
                status: s.status,
              })),
            };
          }),
        };
        setProducts((prev) => {
          const exists = prev.some((p) => p.id === draft.id);
          return exists ? prev.map((p) => (p.id === draft.id ? restored : p)) : [restored, ...prev];
        });
        return;
      }

      const upsertPayload: Record<string, unknown> = {
        id: draft.id,
        name: draft.name,
        code: draft.code?.trim() || null,
        category_id: draft.category_id,
        subcategory_id: draft.subcategory_id ?? null,
        description: draft.description || '',
        price: draft.price,
        old_price: draft.old_price ?? null,
        visible: draft.visible,
        featured: draft.featured,
        is_permanent: Boolean(draft.is_permanent),
        listed_at: draft.listed_at || draft.created_at || new Date().toISOString(),
        created_at: draft.created_at || new Date().toISOString(),
      };
      const {error: prodErr} = await supabase.from('products').upsert(upsertPayload);
      if (prodErr) {
        const msg = String(prodErr.message || '');
        if ((prodErr.code === 'PGRST204' || msg.includes('schema cache')) && msg.includes("'code'")) {
          delete upsertPayload.code;
          const {error: retryErr} = await supabase.from('products').upsert(upsertPayload);
          if (retryErr) throw retryErr;
        } else {
          throw prodErr;
        }
      }

      const keepColorIds: string[] = [];
      for (let i = 0; i < draft.colors.length; i++) {
        const c = draft.colors[i];
        const colorId = c.id || crypto.randomUUID();
        keepColorIds.push(colorId);

        const {error: colErr} = await supabase.from('product_colors').upsert({
          id: colorId,
          product_id: draft.id,
          name: c.name,
          hex: c.hex,
          images: c.images,
          sort: c.sort ?? i + 1,
        });
        if (colErr) throw colErr;

        const keepSizeIds: string[] = [];
        for (const s of c.sizes) {
          const sizeId = s.id || crypto.randomUUID();
          keepSizeIds.push(sizeId);
          const {error: szErr} = await supabase.from('product_sizes').upsert({
            id: sizeId,
            color_id: colorId,
            size: s.size,
            status: s.status,
            sold_at: s.status === 'sold' ? new Date().toISOString() : null,
          });
          if (szErr) throw szErr;
        }

        const {data: existingSizes} = await supabase
          .from('product_sizes')
          .select('id')
          .eq('color_id', colorId);
        const delSizes = (existingSizes || [])
          .map((x) => x.id)
          .filter((sid) => !keepSizeIds.includes(sid));
        if (delSizes.length > 0) {
          await supabase.from('product_sizes').delete().in('id', delSizes);
        }
      }

      const {data: existingColors} = await supabase
        .from('product_colors')
        .select('id')
        .eq('product_id', draft.id);
      const delColors = (existingColors || [])
        .map((x) => x.id)
        .filter((cid) => !keepColorIds.includes(cid));
      if (delColors.length > 0) {
        await supabase.from('product_colors').delete().in('id', delColors);
      }

      if (!draft.skipRefresh) {
        await refreshCatalog();
      }
    },
    [isDemoMode, refreshCatalog]
  );

  const duplicateProduct = useCallback(
    async (product: Product) => {
      await saveProduct({
        name: `${product.name} (نسخة)`,
        code: product.code ? `${product.code}-2` : null,
        category_id: product.category_id,
        subcategory_id: product.subcategory_id,
        description: product.description,
        price: product.price,
        old_price: product.old_price,
        visible: product.visible,
        featured: false,
        is_permanent: false,
        colors: product.colors.map((c) => ({
          name: c.name,
          hex: c.hex,
          images: [...c.images],
          sort: c.sort,
          sizes: c.sizes.map((s) => ({
            size: s.size,
            status: 'available',
          })),
        })),
      });
      showToast('تم نسخ المنتج بنجاح', 'success');
    },
    [saveProduct, showToast]
  );

  const retryDeleteStoragePaths = useCallback(
    async (
      paths: string[],
      onProgress?: (progress: {done: number; total: number}) => void
    ): Promise<{deletedImages: number; failedPaths: string[]}> => {
      const uniquePaths = Array.from(new Set(paths.filter(Boolean)));
      if (uniquePaths.length === 0 || isDemoMode || !supabase) {
        return {deletedImages: uniquePaths.length, failedPaths: []};
      }
      const BATCH_SIZE = 20;
      let deletedImages = 0;
      const failedPaths: string[] = [];

      for (let i = 0; i < uniquePaths.length; i += BATCH_SIZE) {
        const batch = uniquePaths.slice(i, i + BATCH_SIZE);
        try {
          const {error: remErr} = await supabase.storage.from('images').remove(batch);
          if (remErr) {
            failedPaths.push(...batch);
          } else {
            deletedImages += batch.length;
          }
        } catch {
          failedPaths.push(...batch);
        }
        onProgress?.({
          done: Math.min(i + batch.length, uniquePaths.length),
          total: uniquePaths.length,
        });
      }

      return {deletedImages, failedPaths};
    },
    [isDemoMode]
  );

  const computeDemoPathsInUse = useCallback(
    (excludeProductIds?: Set<string>, excludeBackupIds?: Set<string>): Set<string> => {
      const snap = catalogStateRef.current;
      const used = new Set<string>();
      const addUrl = (u: string | null | undefined) => {
        if (!u || u.startsWith('/assets/')) return;
        used.add(u);
      };
      addUrl(snap.settings.logo_url);
      for (const c of snap.categories) addUrl(c.image_url);
      for (const b of snap.banners) addUrl(b.image_url);
      for (const r of snap.settings.features.customer_reviews?.items || []) addUrl(r.image_url);
      for (const p of snap.products) {
        if (excludeProductIds?.has(p.id)) continue;
        for (const col of p.colors) {
          for (const img of col.images) {
            addUrl(img.full);
            if (img.thumb && img.thumb !== img.full) addUrl(img.thumb);
          }
        }
      }
      for (const bk of snap.backups) {
        if (excludeBackupIds?.has(bk.id)) continue;
        for (const pPath of bk.image_paths || []) {
          if (pPath) used.add(pPath);
        }
      }
      return used;
    },
    []
  );

  const deleteStoragePathsWithPinning = useCallback(
    async (
      candidatePaths: string[],
      onProgress?: (progress: {done: number; total: number}) => void
    ): Promise<{deletedImages: number; pinnedImages: number; failedPaths: string[]}> => {
      const uniqueCandidates = Array.from(new Set(candidatePaths.filter(Boolean)));
      if (uniqueCandidates.length === 0) {
        return {deletedImages: 0, pinnedImages: 0, failedPaths: []};
      }
      if (isDemoMode || !supabase) {
        const inUse = computeDemoPathsInUse();
        let pinnedImages = 0;
        let deletedImages = 0;
        for (const path of uniqueCandidates) {
          if (inUse.has(path)) pinnedImages += 1;
          else deletedImages += 1;
        }
        return {deletedImages, pinnedImages, failedPaths: []};
      }

      const {data: inUseData, error: inUseErr} = await supabase.rpc('image_paths_in_use');
      if (inUseErr) {
        // Safer default: if we cannot check pinning, do not delete blindly
        return {deletedImages: 0, pinnedImages: 0, failedPaths: uniqueCandidates};
      }
      const inUseSet = new Set<string>(Array.isArray(inUseData) ? inUseData : []);
      const toDelete: string[] = [];
      let pinnedImages = 0;
      for (const p of uniqueCandidates) {
        if (inUseSet.has(p)) {
          pinnedImages += 1;
        } else {
          toDelete.push(p);
        }
      }

      if (toDelete.length === 0) {
        return {deletedImages: 0, pinnedImages, failedPaths: []};
      }
      const res = await retryDeleteStoragePaths(toDelete, onProgress);
      return {
        deletedImages: res.deletedImages,
        pinnedImages,
        failedPaths: res.failedPaths,
      };
    },
    [computeDemoPathsInUse, isDemoMode, retryDeleteStoragePaths]
  );

  const cleanupDraftImageUrls = useCallback(
    async (urls: string[]) => {
      if (isDemoMode || !supabase || urls.length === 0) return;
      const paths = urls
        .map((u) => extractImagesBucketPath(u))
        .filter((p): p is string => Boolean(p));
      if (paths.length === 0) return;
      await deleteStoragePathsWithPinning(paths);
    },
    [deleteStoragePathsWithPinning, isDemoMode]
  );

  const permanentlyDeleteProducts = useCallback(
    async (
      ids: string[],
      onProgress?: (progress: {stage: 'db' | 'storage'; done: number; total: number}) => void
    ): Promise<StorageDeleteResult> => {
      const targetIds = Array.from(new Set(ids.filter(Boolean)));
      if (targetIds.length === 0) {
        return {deletedProducts: 0, deletedImages: 0, pinnedImages: 0, failedPaths: []};
      }
      const idsSet = new Set(targetIds);
      const targetProducts = products.filter((p) => idsSet.has(p.id));

      onProgress?.({stage: 'db', done: 0, total: targetIds.length});

      if (isDemoMode || !supabase) {
        const candidateKeys = new Set<string>();
        for (const prod of targetProducts) {
          for (const col of prod.colors) {
            for (const img of col.images) {
              if (img.full && !img.full.startsWith('/assets/')) candidateKeys.add(img.full);
              if (img.thumb && img.thumb !== img.full && !img.thumb.startsWith('/assets/')) {
                candidateKeys.add(img.thumb);
              }
            }
          }
        }
        const inUseAfterDelete = computeDemoPathsInUse(idsSet);
        let deletedImages = 0;
        let pinnedImages = 0;
        for (const k of candidateKeys) {
          if (inUseAfterDelete.has(k)) pinnedImages += 1;
          else deletedImages += 1;
        }

        setProducts((prev) => prev.filter((p) => !idsSet.has(p.id)));
        setOrders((prev) =>
          prev.map((o) => ({
            ...o,
            items: o.items.map((item) =>
              item.product_id && idsSet.has(item.product_id)
                ? {...item, product_id: null, color_id: null, size_id: null}
                : item
            ),
          }))
        );
        onProgress?.({stage: 'db', done: targetIds.length, total: targetIds.length});
        return {
          deletedProducts: targetProducts.length,
          deletedImages,
          pinnedImages,
          failedPaths: [],
        };
      }

      const candidatePaths = new Set<string>();
      for (const prod of targetProducts) {
        for (const col of prod.colors) {
          for (const img of col.images) {
            const fullPath = extractImagesBucketPath(img.full);
            if (fullPath) candidatePaths.add(fullPath);
            const thumbPath = extractImagesBucketPath(img.thumb);
            if (thumbPath) candidatePaths.add(thumbPath);
          }
        }
      }

      const {error: delErr} = await supabase.from('products').delete().in('id', targetIds);
      if (delErr) throw delErr;
      onProgress?.({stage: 'db', done: targetIds.length, total: targetIds.length});

      let deletedImages = 0;
      let pinnedImages = 0;
      let failedPaths: string[] = [];
      const candidateList = Array.from(candidatePaths);
      if (candidateList.length > 0) {
        onProgress?.({stage: 'storage', done: 0, total: candidateList.length});
        const storageRes = await deleteStoragePathsWithPinning(candidateList, ({done, total}) => {
          onProgress?.({stage: 'storage', done, total});
        });
        deletedImages = storageRes.deletedImages;
        pinnedImages = storageRes.pinnedImages;
        failedPaths = storageRes.failedPaths;
      }

      await refreshCatalog();
      return {
        deletedProducts: targetProducts.length,
        deletedImages,
        pinnedImages,
        failedPaths,
      };
    },
    [
      computeDemoPathsInUse,
      deleteStoragePathsWithPinning,
      isDemoMode,
      products,
      refreshCatalog,
    ]
  );

  const deleteProducts = useCallback(
    async (ids: string[]) => {
      if (ids.length === 0) return;
      const res = await permanentlyDeleteProducts(ids);
      showToast(
        `تم حذف ${res.deletedProducts} منتج و${res.deletedImages} صورة، و${res.pinnedImages} صورة محفوظة لأنها في نسخة احتياطية`,
        'success'
      );
    },
    [permanentlyDeleteProducts, showToast]
  );

  const renewProduct = useCallback(
    async (productId: string) => {
      const nowIso = new Date().toISOString();
      if (isDemoMode || !supabase) {
        setProducts((prev) =>
          prev.map((p) => (p.id === productId ? {...p, listed_at: nowIso} : p))
        );
        showToast('تم تجديد مدة الموديل', 'success');
        return;
      }
      const {error: updErr} = await supabase
        .from('products')
        .update({listed_at: nowIso})
        .eq('id', productId);
      if (updErr) throw updErr;
      await refreshCatalog();
      showToast('تم تجديد مدة الموديل', 'success');
    },
    [isDemoMode, refreshCatalog, showToast]
  );

  const makeProductPermanent = useCallback(
    async (productId: string) => {
      if (isDemoMode || !supabase) {
        setProducts((prev) =>
          prev.map((p) => (p.id === productId ? {...p, is_permanent: true} : p))
        );
        showToast('تم تعيين الموديل كمنتج دائم', 'success');
        return;
      }
      const {error: updErr} = await supabase
        .from('products')
        .update({is_permanent: true})
        .eq('id', productId);
      if (updErr) throw updErr;
      await refreshCatalog();
      showToast('تم تعيين الموديل كمنتج دائم', 'success');
    },
    [isDemoMode, refreshCatalog, showToast]
  );

  const bulkUpdateProducts = useCallback(
    async (
      ids: string[],
      action:
        | {type: 'visibility'; visible: boolean}
        | {type: 'price_percent'; percent: number}
        | {type: 'price_amount'; amount: number}
    ) => {
      if (ids.length === 0) return;
      if (isDemoMode || !supabase) {
        setProducts((prev) =>
          prev.map((p) => {
            if (!ids.includes(p.id)) return p;
            if (action.type === 'visibility') {
              return {...p, visible: action.visible};
            }
            if (action.type === 'price_percent') {
              const nextPrice = Math.max(1, Math.round(p.price * (1 + action.percent / 100)));
              return {...p, price: nextPrice};
            }
            const nextPrice = Math.max(1, Math.round(p.price + action.amount));
            return {...p, price: nextPrice};
          })
        );
        showToast('تم تطبيق التعديل الجماعي', 'success');
        return;
      }

      if (action.type === 'visibility') {
        await supabase.from('products').update({visible: action.visible}).in('id', ids);
      } else {
        const targets = products.filter((p) => ids.includes(p.id));
        for (const p of targets) {
          const nextPrice =
            action.type === 'price_percent'
              ? Math.max(1, Math.round(p.price * (1 + action.percent / 100)))
              : Math.max(1, Math.round(p.price + action.amount));
          await supabase.from('products').update({price: nextPrice}).eq('id', p.id);
        }
      }
      await refreshCatalog();
      showToast('تم تطبيق التعديل الجماعي', 'success');
    },
    [isDemoMode, products, refreshCatalog, showToast]
  );

  const quickUpdateProductPrices = useCallback(
    async (productId: string, price: number, oldPrice: number | null) => {
      if (isDemoMode || !supabase) {
        setProducts((prev) =>
          prev.map((p) => (p.id === productId ? {...p, price, old_price: oldPrice} : p))
        );
        showToast('تم تحديث السعر', 'success');
        return;
      }
      const {error: updErr} = await supabase
        .from('products')
        .update({price, old_price: oldPrice})
        .eq('id', productId);
      if (updErr) throw updErr;
      await refreshCatalog();
      showToast('تم تحديث السعر', 'success');
    },
    [isDemoMode, refreshCatalog, showToast]
  );

  const toggleProductSoldAll = useCallback(
    async (productId: string, makeSold: boolean) => {
      const nextStatus: SizeStatus = makeSold ? 'sold' : 'available';
      if (isDemoMode || !supabase) {
        setProducts((prev) =>
          prev.map((p) =>
            p.id !== productId
              ? p
              : {
                  ...p,
                  colors: p.colors.map((c) => ({
                    ...c,
                    sizes: c.sizes.map((s) => ({
                      ...s,
                      status: nextStatus,
                      sold_at: makeSold ? new Date().toISOString() : null,
                    })),
                  })),
                }
          )
        );
        showToast(makeSold ? 'تم تعليم المنتج كمُباع' : 'تمت إعادة المنتج للمتاح', 'success');
        return;
      }

      const target = products.find((p) => p.id === productId);
      const sizeIds = target?.colors.flatMap((c) => c.sizes.map((s) => s.id)) || [];
      if (sizeIds.length > 0) {
        await supabase
          .from('product_sizes')
          .update({status: nextStatus, sold_at: makeSold ? new Date().toISOString() : null})
          .in('id', sizeIds);
      }
      await refreshCatalog();
      showToast(makeSold ? 'تم تعليم المنتج كمُباع' : 'تمت إعادة المنتج للمتاح', 'success');
    },
    [isDemoMode, products, refreshCatalog, showToast]
  );

  const toggleSizeStatus = useCallback(
    async (sizeId: string, status: SizeStatus) => {
      if (isDemoMode || !supabase) {
        setProducts((prev) =>
          prev.map((p) => ({
            ...p,
            colors: p.colors.map((c) => ({
              ...c,
              sizes: c.sizes.map((s) =>
                s.id === sizeId
                  ? {...s, status, sold_at: status === 'sold' ? new Date().toISOString() : null}
                  : s
              ),
            })),
          }))
        );
        return;
      }
      await supabase
        .from('product_sizes')
        .update({status, sold_at: status === 'sold' ? new Date().toISOString() : null})
        .eq('id', sizeId);
      await refreshCatalog();
    },
    [isDemoMode, refreshCatalog]
  );

  const saveCategory = useCallback(
    async (cat: Partial<Category> & {name: string}) => {
      if (isDemoMode || !supabase) {
        if (cat.id) {
          setCategories((prev) =>
            prev.map((c) => (c.id === cat.id ? {...c, ...cat} : c))
          );
        } else {
          const newCat: Category = {
            id: `cat-${Date.now()}`,
            name: cat.name,
            image_url: cat.image_url ?? null,
            sort: cat.sort ?? categories.length + 1,
            visible: cat.visible ?? true,
            parent_id: cat.parent_id ?? null,
          };
          setCategories((prev) => [...prev, newCat]);
        }
        showToast('تم حفظ القسم', 'success');
        return;
      }
      if (cat.id) {
        await supabase
          .from('categories')
          .update({
            name: cat.name,
            image_url: cat.image_url,
            sort: cat.sort,
            visible: cat.visible,
            parent_id: cat.parent_id ?? null,
          })
          .eq('id', cat.id);
      } else {
        await supabase.from('categories').insert({
          name: cat.name,
          image_url: cat.image_url ?? null,
          sort: cat.sort ?? categories.length + 1,
          visible: cat.visible ?? true,
          parent_id: cat.parent_id ?? null,
        });
      }
      await refreshCatalog();
      showToast('تم حفظ القسم', 'success');
    },
    [categories.length, isDemoMode, refreshCatalog, showToast]
  );

  const deleteCategory = useCallback(
    async (id: string) => {
      if (isDemoMode || !supabase) {
        setCategories((prev) => prev.filter((c) => c.id !== id && c.parent_id !== id));
        showToast('تم حذف القسم', 'success');
        return;
      }
      await supabase.from('categories').delete().eq('id', id);
      await refreshCatalog();
      showToast('تم حذف القسم', 'success');
    },
    [isDemoMode, refreshCatalog, showToast]
  );

  const reorderCategories = useCallback(
    async (orderedIds: string[]) => {
      if (isDemoMode || !supabase) {
        setCategories((prev) => {
          const orderMap = new Map(orderedIds.map((id, idx) => [id, idx + 1]));
          return prev.map((c) => (orderMap.has(c.id) ? {...c, sort: orderMap.get(c.id)!} : c));
        });
        return;
      }
      for (let i = 0; i < orderedIds.length; i++) {
        await supabase.from('categories').update({sort: i + 1}).eq('id', orderedIds[i]);
      }
      await refreshCatalog();
    },
    [isDemoMode, refreshCatalog]
  );

  const saveBanner = useCallback(
    async (ban: Partial<Banner> & {title: string}) => {
      if (isDemoMode || !supabase) {
        if (ban.id) {
          setBanners((prev) => prev.map((b) => (b.id === ban.id ? {...b, ...ban} : b)));
        } else {
          const newBan: Banner = {
            id: `ban-${Date.now()}`,
            image_url: ban.image_url ?? null,
            title: ban.title,
            subtitle: ban.subtitle ?? '',
            btn_text: ban.btn_text ?? 'تسوقي الآن',
            link: ban.link ?? '/catalog',
            active: ban.active ?? true,
            sort: ban.sort ?? banners.length + 1,
            type: ban.type ?? 'message',
            product_id: ban.product_id ?? null,
            category_id: ban.category_id ?? null,
            ends_at: ban.ends_at ?? null,
          };
          setBanners((prev) => [...prev, newBan]);
        }
        showToast('تم حفظ الإعلان', 'success');
        return;
      }
      if (ban.id) {
        await supabase
          .from('banners')
          .update({
            image_url: ban.image_url,
            title: ban.title,
            subtitle: ban.subtitle,
            btn_text: ban.btn_text,
            link: ban.link,
            active: ban.active,
            sort: ban.sort,
            type: ban.type ?? 'message',
            product_id: ban.product_id ?? null,
            category_id: ban.category_id ?? null,
            ends_at: ban.ends_at ?? null,
          })
          .eq('id', ban.id);
      } else {
        await supabase.from('banners').insert({
          image_url: ban.image_url ?? null,
          title: ban.title,
          subtitle: ban.subtitle ?? '',
          btn_text: ban.btn_text ?? 'تسوقي الآن',
          link: ban.link ?? '/catalog',
          active: ban.active ?? true,
          sort: ban.sort ?? banners.length + 1,
          type: ban.type ?? 'message',
          product_id: ban.product_id ?? null,
          category_id: ban.category_id ?? null,
          ends_at: ban.ends_at ?? null,
        });
      }
      await refreshCatalog();
      showToast('تم حفظ الإعلان', 'success');
    },
    [banners.length, isDemoMode, refreshCatalog, showToast]
  );

  const deleteBanner = useCallback(
    async (id: string) => {
      if (isDemoMode || !supabase) {
        setBanners((prev) => prev.filter((b) => b.id !== id));
        showToast('تم حذف الإعلان', 'success');
        return;
      }
      await supabase.from('banners').delete().eq('id', id);
      await refreshCatalog();
      showToast('تم حذف الإعلان', 'success');
    },
    [isDemoMode, refreshCatalog, showToast]
  );

  const reorderBanners = useCallback(
    async (orderedIds: string[]) => {
      if (isDemoMode || !supabase) {
        setBanners((prev) =>
          orderedIds
            .map((id, idx) => {
              const found = prev.find((b) => b.id === id);
              return found ? {...found, sort: idx + 1} : null;
            })
            .filter(Boolean) as Banner[]
        );
        return;
      }
      for (let i = 0; i < orderedIds.length; i++) {
        await supabase.from('banners').update({sort: i + 1}).eq('id', orderedIds[i]);
      }
      await refreshCatalog();
    },
    [isDemoMode, refreshCatalog]
  );

  const saveSettings = useCallback(
    async (next: StoreSettings) => {
      const safeExpiryDays = Math.max(1, Math.round(Number(next.expiry_days) || 10));
      const safeRetentionDays = Math.max(
        1,
        Math.round(Number(next.backup_retention_days) || 7)
      );
      const normalizedNext: StoreSettings = {
        ...next,
        expiry_days: safeExpiryDays,
        backup_retention_days: safeRetentionDays,
      };
      if (isDemoMode || !supabase) {
        setSettings(normalizedNext);
        showToast('تم حفظ الإعدادات', 'success');
        return;
      }
      const {error: setErr} = await supabase
        .from('settings')
        .upsert({
          id: 1,
          store_name: normalizedNext.store_name,
          logo_url: normalizedNext.logo_url,
          whatsapp: normalizedNext.whatsapp,
          messenger_url: normalizedNext.messenger_url,
          instagram_url: normalizedNext.instagram_url,
          facebook_url: normalizedNext.facebook_url,
          whatsapp_group_url: normalizedNext.whatsapp_group_url,
          welcome: normalizedNext.welcome,
          order_intro: normalizedNext.order_intro,
          trust_items: normalizedNext.trust_items,
          pixel_id: normalizedNext.pixel_id,
          caption_template: normalizedNext.caption_template,
          expiry_days: safeExpiryDays,
          backup_retention_days: safeRetentionDays,
          features: normalizedNext.features,
        });
      if (setErr) throw setErr;
      setSettings(normalizedNext);
      showToast('تم حفظ الإعدادات', 'success');
    },
    [isDemoMode, showToast]
  );

  const markOrderDelivered = useCallback(
    async (orderId: string) => {
      if (isDemoMode || !supabase) {
        const order = orders.find((o) => o.id === orderId);
        const sizeIds = new Set(order?.items.map((i) => i.size_id).filter(Boolean));
        setOrders((prev) =>
          prev.map((o) => (o.id === orderId ? {...o, status: 'delivered'} : o))
        );
        setProducts((prev) =>
          prev.map((p) => ({
            ...p,
            colors: p.colors.map((c) => ({
              ...c,
              sizes: c.sizes.map((s) =>
                sizeIds.has(s.id) ? {...s, status: 'sold', sold_at: new Date().toISOString()} : s
              ),
            })),
          }))
        );
        showToast('تم تأكيد التسليم وتعليم القطع كمُباعة', 'success');
        return;
      }
      const {error: rpcErr} = await supabase.rpc('mark_order_delivered', {order_id: orderId});
      if (rpcErr) throw rpcErr;
      await Promise.all([fetchOrders(), refreshCatalog()]);
      showToast('تم تأكيد التسليم وتعليم القطع كمُباعة', 'success');
    },
    [fetchOrders, isDemoMode, orders, refreshCatalog, showToast]
  );

  const markOrderCancelled = useCallback(
    async (orderId: string) => {
      if (isDemoMode || !supabase) {
        setOrders((prev) =>
          prev.map((o) => (o.id === orderId ? {...o, status: 'cancelled'} : o))
        );
        showToast('تم إلغاء الطلب', 'info');
        return;
      }
      const {error: updErr} = await supabase
        .from('orders')
        .update({status: 'cancelled'})
        .eq('id', orderId);
      if (updErr) throw updErr;
      await fetchOrders();
      showToast('تم إلغاء الطلب', 'info');
    },
    [fetchOrders, isDemoMode, showToast]
  );

  const markOrderUndo = useCallback(
    async (orderId: string) => {
      const order = orders.find((o) => o.id === orderId);
      const wasDelivered = order?.status === 'delivered';
      if (isDemoMode || !supabase) {
        const sizeIds = new Set(order?.items.map((i) => i.size_id).filter(Boolean));
        setOrders((prev) => prev.map((o) => (o.id === orderId ? {...o, status: 'new'} : o)));
        if (wasDelivered) {
          setProducts((prev) =>
            prev.map((p) => ({
              ...p,
              colors: p.colors.map((c) => ({
                ...c,
                sizes: c.sizes.map((s) =>
                  sizeIds.has(s.id) ? {...s, status: 'available', sold_at: null} : s
                ),
              })),
            }))
          );
        }
        showToast(
          wasDelivered ? 'تم التراجع وإرجاع القطع للمتاح' : 'تمت إعادة فتح الطلب كطلب جديد',
          'success'
        );
        return;
      }
      const {error: rpcErr} = await supabase.rpc('mark_order_undo', {order_id: orderId});
      if (rpcErr) throw rpcErr;
      await Promise.all([fetchOrders(), ...(wasDelivered ? [refreshCatalog()] : [])]);
      showToast(
        wasDelivered ? 'تم التراجع وإرجاع القطع للمتاح' : 'تمت إعادة فتح الطلب كطلب جديد',
        'success'
      );
    },
    [fetchOrders, isDemoMode, orders, refreshCatalog, showToast]
  );

  const deleteOrder = useCallback(
    async (orderId: string) => {
      if (isDemoMode || !supabase) {
        setOrders((prev) => prev.filter((o) => o.id !== orderId));
        showToast('تم حذف الطلب نهائيًا', 'success');
        return;
      }
      const {error: delErr} = await supabase.from('orders').delete().eq('id', orderId);
      if (delErr) throw delErr;
      setOrders((prev) => prev.filter((o) => o.id !== orderId));
      showToast('تم حذف الطلب نهائيًا', 'success');
    },
    [isDemoMode, showToast]
  );

  const deleteAllCancelledOrders = useCallback(async (): Promise<number> => {
    const cancelledCount = orders.filter((o) => o.status === 'cancelled').length;
    if (cancelledCount === 0) return 0;
    if (isDemoMode || !supabase) {
      setOrders((prev) => prev.filter((o) => o.status !== 'cancelled'));
      showToast(`تم حذف ${cancelledCount} طلب ملغي نهائيًا`, 'success');
      return cancelledCount;
    }
    const {error: delErr} = await supabase.from('orders').delete().eq('status', 'cancelled');
    if (delErr) throw delErr;
    setOrders((prev) => prev.filter((o) => o.status !== 'cancelled'));
    showToast(`تم حذف ${cancelledCount} طلب ملغي نهائيًا`, 'success');
    return cancelledCount;
  }, [isDemoMode, orders, showToast]);

  // ============================================================================
  // BACKUPS & PIN RESET
  // ============================================================================

  const fetchBackups = useCallback(async () => {
    const retention = Math.max(1, catalogStateRef.current.settings.backup_retention_days || 7);
    if (isDemoMode || !supabase) {
      const cutoff = Date.now() - retention * 86400000;
      setBackups((prev) => {
        const next = prev.filter((b) => new Date(b.created_at).getTime() >= cutoff);
        return next.length === prev.length ? prev : next;
      });
      return;
    }
    setBackupsLoading(true);
    try {
      const {data: prunedPaths} = await supabase.rpc('prune_backups');
      if (Array.isArray(prunedPaths) && prunedPaths.length > 0) {
        await deleteStoragePathsWithPinning(prunedPaths.map(String));
      }
      const {data, error: bkErr} = await supabase
        .from('backups')
        .select('*')
        .order('created_at', {ascending: false});
      if (bkErr) throw bkErr;
      setBackups(
        (data || []).map((row) => ({
          id: row.id,
          created_at: row.created_at,
          label: row.label || 'نسخة يدوية',
          counts: row.counts || {products: 0, categories: 0, banners: 0},
          image_paths: Array.isArray(row.image_paths) ? row.image_paths : [],
          snapshot: row.snapshot as BackupSnapshot,
        }))
      );
    } catch {
      showToast('تعذر تحميل النسخ الاحتياطية', 'warning');
    } finally {
      setBackupsLoading(false);
    }
  }, [deleteStoragePathsWithPinning, isDemoMode, showToast]);

  const buildDemoBackupRecord = useCallback(
    (label?: string): BackupRecord => {
      const imgPaths = new Set<string>();
      for (const p of products) {
        for (const c of p.colors) {
          for (const img of c.images) {
            if (img.full && !img.full.startsWith('/assets/')) imgPaths.add(img.full);
            if (img.thumb && img.thumb !== img.full && !img.thumb.startsWith('/assets/')) {
              imgPaths.add(img.thumb);
            }
          }
        }
      }
      const snapshot: BackupSnapshot = {
        categories: JSON.parse(JSON.stringify(categories)),
        products: products.map(({colors: _c, ...rest}) => JSON.parse(JSON.stringify(rest))),
        product_colors: products.flatMap((p) =>
          p.colors.map(({sizes: _s, ...colRest}) => JSON.parse(JSON.stringify(colRest)))
        ),
        product_sizes: products.flatMap((p) =>
          p.colors.flatMap((c) => c.sizes.map((s) => JSON.parse(JSON.stringify(s))))
        ),
        banners: JSON.parse(JSON.stringify(banners)),
        settings: JSON.parse(JSON.stringify(settings)),
      };
      return {
        id: `bk-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        created_at: new Date().toISOString(),
        label: (label || '').trim() || 'نسخة يدوية',
        counts: {
          products: products.length,
          categories: categories.length,
          banners: banners.length,
        },
        image_paths: Array.from(imgPaths),
        snapshot,
      };
    },
    [banners, categories, products, settings]
  );

  const createBackup = useCallback(
    async (label?: string): Promise<BackupRecord | null> => {
      if (isDemoMode || !supabase) {
        const cutoff = Date.now() - Math.max(1, settings.backup_retention_days || 7) * 86400000;
        const rec = buildDemoBackupRecord(label);
        setBackups((prev) => [
          rec,
          ...prev.filter((b) => new Date(b.created_at).getTime() >= cutoff),
        ]);
        showToast('تم حفظ النسخة الاحتياطية بنجاح', 'success');
        return rec;
      }

      const {data: bkId, error: rpcErr} = await supabase.rpc('create_backup', {
        p_label: (label || '').trim(),
      });
      if (rpcErr) throw rpcErr;
      await fetchBackups();
      const {data: row} = await supabase
        .from('backups')
        .select('*')
        .eq('id', bkId)
        .maybeSingle();
      showToast('تم حفظ النسخة الاحتياطية بنجاح', 'success');
      if (!row) return null;
      return {
        id: row.id,
        created_at: row.created_at,
        label: row.label || 'نسخة يدوية',
        counts: row.counts || {products: 0, categories: 0, banners: 0},
        image_paths: Array.isArray(row.image_paths) ? row.image_paths : [],
        snapshot: row.snapshot as BackupSnapshot,
      };
    },
    [buildDemoBackupRecord, fetchBackups, isDemoMode, settings.backup_retention_days, showToast]
  );

  const deleteBackup = useCallback(
    async (backupId: string) => {
      const target = backups.find((b) => b.id === backupId);
      const candidatePaths = target?.image_paths || [];

      if (isDemoMode || !supabase) {
        setBackups((prev) => prev.filter((b) => b.id !== backupId));
        const inUse = computeDemoPathsInUse(undefined, new Set([backupId]));
        let deletedImages = 0;
        let pinnedImages = 0;
        for (const p of candidatePaths) {
          if (inUse.has(p)) pinnedImages += 1;
          else deletedImages += 1;
        }
        showToast(
          `تم حذف النسخة (تم تنظيف ${deletedImages} صورة غير مستخدمة، وبقيت ${pinnedImages} صورة مستخدمة)`,
          'success'
        );
        return;
      }

      const {error: delErr} = await supabase.from('backups').delete().eq('id', backupId);
      if (delErr) throw delErr;
      setBackups((prev) => prev.filter((b) => b.id !== backupId));

      let deletedImages = 0;
      let pinnedImages = 0;
      if (candidatePaths.length > 0) {
        const res = await deleteStoragePathsWithPinning(candidatePaths);
        deletedImages = res.deletedImages;
        pinnedImages = res.pinnedImages;
      }
      showToast(
        `تم حذف النسخة (تم تنظيف ${deletedImages} صورة غير مستخدمة، وبقيت ${pinnedImages} صورة مستخدمة)`,
        'success'
      );
    },
    [backups, computeDemoPathsInUse, deleteStoragePathsWithPinning, isDemoMode, showToast]
  );

  const restoreBackup = useCallback(
    async (backupId: string): Promise<Product[]> => {
      if (isDemoMode || !supabase) {
        const target = backups.find((b) => b.id === backupId);
        if (!target) throw new Error('Backup not found');
        // Always auto-create safety backup before restore
        const safety = buildDemoBackupRecord('قبل الاستعادة');
        setBackups((prev) => [safety, ...prev]);

        const snap = target.snapshot;
        const sizeMap = new Map<string, ProductSize[]>();
        for (const s of snap.product_sizes || []) {
          const arr = sizeMap.get(s.color_id) || [];
          arr.push(s);
          sizeMap.set(s.color_id, arr);
        }
        const colMap = new Map<string, ProductColor[]>();
        for (const c of snap.product_colors || []) {
          const arr = colMap.get(c.product_id) || [];
          arr.push({
            ...c,
            images: normalizeProductImages(c.images),
            sizes: sizeMap.get(c.id) || [],
          });
          colMap.set(c.product_id, arr);
        }
        const restoredProducts: Product[] = (snap.products || []).map((p) => ({
          ...p,
          colors: colMap.get(p.id) || [],
        }));

        setCategories(snap.categories || []);
        setProducts(restoredProducts);
        setBanners(snap.banners || []);
        if (snap.settings) {
          setSettings((prev) => ({
            ...prev,
            ...snap.settings,
            id: 1,
          }));
        }
        showToast('تمت استعادة النسخة الاحتياطية بنجاح', 'success');
        return restoredProducts;
      }

      // 1. Always create safety backup first
      const {error: safetyErr} = await supabase.rpc('create_backup', {
        p_label: 'قبل الاستعادة',
      });
      if (safetyErr) throw safetyErr;

      // 2. Atomically restore in DB (orders remain untouched)
      const {error: resErr} = await supabase.rpc('restore_backup', {
        p_backup_id: backupId,
      });
      if (resErr) throw resErr;

      const [restoredProducts] = await Promise.all([refreshCatalog(), fetchBackups()]);
      showToast('تمت استعادة النسخة الاحتياطية بنجاح', 'success');
      return restoredProducts;
    },
    [backups, buildDemoBackupRecord, fetchBackups, isDemoMode, refreshCatalog, showToast]
  );

  const verifyDemoPinState = useCallback((pin: string) => {
    const now = Date.now();
    const saved = readJsonStorage<{
      pinHash: string;
      failedAttempts: number;
      lockedUntil: number | null;
    }>(DEMO_PIN_STORAGE_KEY, {
      pinHash: hashDemoPin('1234'),
      failedAttempts: 0,
      lockedUntil: null,
    });

    if (saved.lockedUntil && saved.lockedUntil > now) {
      return {
        ok: false as const,
        error: 'locked' as const,
        lockedUntil: new Date(saved.lockedUntil).toISOString(),
      };
    }

    if (hashDemoPin(pin) !== saved.pinHash) {
      const nextAttempts =
        saved.lockedUntil && saved.lockedUntil <= now ? 1 : (saved.failedAttempts || 0) + 1;
      if (nextAttempts >= 5) {
        const lockedMs = now + 5 * 60 * 1000;
        try {
          localStorage.setItem(
            DEMO_PIN_STORAGE_KEY,
            JSON.stringify({pinHash: saved.pinHash, failedAttempts: 0, lockedUntil: lockedMs})
          );
        } catch {
          // Ignore
        }
        return {
          ok: false as const,
          error: 'locked' as const,
          lockedUntil: new Date(lockedMs).toISOString(),
        };
      }
      try {
        localStorage.setItem(
          DEMO_PIN_STORAGE_KEY,
          JSON.stringify({pinHash: saved.pinHash, failedAttempts: nextAttempts, lockedUntil: null})
        );
      } catch {
        // Ignore
      }
      return {
        ok: false as const,
        error: 'invalid_pin' as const,
        attemptsLeft: 5 - nextAttempts,
      };
    }

    try {
      localStorage.setItem(
        DEMO_PIN_STORAGE_KEY,
        JSON.stringify({pinHash: saved.pinHash, failedAttempts: 0, lockedUntil: null})
      );
    } catch {
      // Ignore
    }
    return {ok: true as const, savedHash: saved.pinHash};
  }, []);

  const resetAllProducts = useCallback(
    async (pin: string, takeBackup: boolean, deleteStorage: boolean) => {
      if (isDemoMode || !supabase) {
        const authCheck = verifyDemoPinState(pin);
        if (!authCheck.ok) return authCheck;

        const nextBackups = [...backups];
        if (takeBackup) {
          const safety = buildDemoBackupRecord('قبل التصفير');
          nextBackups.unshift(safety);
          setBackups(nextBackups);
        }

        const candidateKeys = new Set<string>();
        for (const prod of products) {
          for (const col of prod.colors) {
            for (const img of col.images) {
              if (img.full && !img.full.startsWith('/assets/')) candidateKeys.add(img.full);
              if (img.thumb && img.thumb !== img.full && !img.thumb.startsWith('/assets/')) {
                candidateKeys.add(img.thumb);
              }
            }
          }
        }

        const pinnedSet = new Set<string>();
        if (deleteStorage) {
          for (const bk of nextBackups) {
            for (const pPath of bk.image_paths || []) pinnedSet.add(pPath);
          }
          if (settings.logo_url && !settings.logo_url.startsWith('/assets/')) {
            pinnedSet.add(settings.logo_url);
          }
          for (const c of categories) if (c.image_url) pinnedSet.add(c.image_url);
          for (const b of banners) if (b.image_url) pinnedSet.add(b.image_url);
        }

        let deletedImages = 0;
        let pinnedImages = 0;
        if (deleteStorage) {
          for (const k of candidateKeys) {
            if (pinnedSet.has(k)) pinnedImages += 1;
            else deletedImages += 1;
          }
        }

        const deletedCount = products.length;
        setProducts([]);
        setOrders((prev) =>
          prev.map((o) => ({
            ...o,
            items: o.items.map((item) => ({
              ...item,
              product_id: null,
              color_id: null,
              size_id: null,
            })),
          }))
        );

        return {
          ok: true,
          deletedProducts: deletedCount,
          deletedImages,
          pinnedImages,
          failedPaths: [],
        };
      }

      const {data, error: rpcErr} = await supabase.rpc('reset_products', {
        pin,
        take_backup: takeBackup,
      });
      if (rpcErr || !data) {
        return {ok: false, error: 'unknown' as const};
      }
      if (!data.ok) {
        return {
          ok: false,
          error: (data.error as 'locked' | 'invalid_pin') || 'unknown',
          attemptsLeft: data.attempts_left,
          lockedUntil: data.locked_until ?? null,
        };
      }

      const candidatePaths: string[] = Array.isArray(data.candidate_paths)
        ? data.candidate_paths.map(String)
        : [];
      let deletedImages = 0;
      let pinnedImages = 0;
      let failedPaths: string[] = [];

      if (deleteStorage && candidatePaths.length > 0) {
        const storageRes = await deleteStoragePathsWithPinning(candidatePaths);
        deletedImages = storageRes.deletedImages;
        pinnedImages = storageRes.pinnedImages;
        failedPaths = storageRes.failedPaths;
      }

      await Promise.all([refreshCatalog(), fetchBackups()]);
      return {
        ok: true,
        deletedProducts: Number(data.deleted_products) || 0,
        deletedImages,
        pinnedImages,
        failedPaths,
      };
    },
    [
      backups,
      banners,
      buildDemoBackupRecord,
      categories,
      deleteStoragePathsWithPinning,
      fetchBackups,
      isDemoMode,
      products,
      refreshCatalog,
      settings.logo_url,
      verifyDemoPinState,
    ]
  );

  const changeResetPin = useCallback(
    async (oldPin: string, newPin: string) => {
      if (!/^\d{4}$/.test(newPin)) {
        return {ok: false, error: 'invalid_new_pin' as const};
      }
      if (isDemoMode || !supabase) {
        const authCheck = verifyDemoPinState(oldPin);
        if (!authCheck.ok) return authCheck;
        try {
          localStorage.setItem(
            DEMO_PIN_STORAGE_KEY,
            JSON.stringify({pinHash: hashDemoPin(newPin), failedAttempts: 0, lockedUntil: null})
          );
        } catch {
          // Ignore
        }
        setPinIsDefault(newPin === '1234');
        return {ok: true};
      }

      const {data, error: rpcErr} = await supabase.rpc('change_reset_pin', {
        old_pin: oldPin,
        new_pin: newPin,
      });
      if (rpcErr || !data) return {ok: false, error: 'unknown' as const};
      if (!data.ok) {
        return {
          ok: false,
          error: (data.error as 'locked' | 'invalid_pin' | 'invalid_new_pin') || 'unknown',
          attemptsLeft: data.attempts_left,
          lockedUntil: data.locked_until ?? null,
        };
      }
      setPinIsDefault(newPin === '1234');
      return {ok: true};
    },
    [isDemoMode, verifyDemoPinState]
  );

  const value = useMemo<StoreContextValue>(
    () => ({
      isDemoMode,
      loading,
      error,
      categories,
      products,
      banners,
      settings,
      orders,
      ordersLoading,
      backups,
      backupsLoading,
      cart,
      recentlyViewed,
      toast,
      cartBounceKey,
      flyAnim,
      cartIconRef,
      adminEmail,
      isAdmin,
      authLoading,
      pinIsDefault,
      storageUsageBytes,
      checkIsDefaultPin,
      fetchStorageUsageBytes,
      signInAdmin,
      signOutAdmin,
      refreshCatalog,
      showToast,
      addToCart,
      updateCartQty,
      removeFromCart,
      clearCart,
      recordRecentlyViewed,
      createOrder,
      fetchOrders,
      uploadImage,
      uploadProductImagePair,
      uploadArchiveImageFromBlob,
      saveProduct,
      upsertRestoredProduct,
      ensureArchiveCategories,
      duplicateProduct,
      deleteProducts,
      renewProduct,
      makeProductPermanent,
      permanentlyDeleteProducts,
      retryDeleteStoragePaths,
      cleanupDraftImageUrls,
      bulkUpdateProducts,
      quickUpdateProductPrices,
      toggleProductSoldAll,
      toggleSizeStatus,
      saveCategory,
      deleteCategory,
      reorderCategories,
      saveBanner,
      deleteBanner,
      reorderBanners,
      saveSettings,
      markOrderDelivered,
      markOrderCancelled,
      markOrderUndo,
      deleteOrder,
      deleteAllCancelledOrders,
      fetchBackups,
      createBackup,
      deleteBackup,
      restoreBackup,
      resetAllProducts,
      changeResetPin,
    }),
    [
      isDemoMode,
      loading,
      error,
      categories,
      products,
      banners,
      settings,
      orders,
      ordersLoading,
      backups,
      backupsLoading,
      cart,
      recentlyViewed,
      toast,
      cartBounceKey,
      flyAnim,
      adminEmail,
      isAdmin,
      authLoading,
      pinIsDefault,
      storageUsageBytes,
      checkIsDefaultPin,
      fetchStorageUsageBytes,
      signInAdmin,
      signOutAdmin,
      refreshCatalog,
      showToast,
      addToCart,
      updateCartQty,
      removeFromCart,
      clearCart,
      recordRecentlyViewed,
      createOrder,
      fetchOrders,
      uploadImage,
      uploadProductImagePair,
      uploadArchiveImageFromBlob,
      saveProduct,
      upsertRestoredProduct,
      ensureArchiveCategories,
      duplicateProduct,
      deleteProducts,
      renewProduct,
      makeProductPermanent,
      permanentlyDeleteProducts,
      retryDeleteStoragePaths,
      cleanupDraftImageUrls,
      bulkUpdateProducts,
      quickUpdateProductPrices,
      toggleProductSoldAll,
      toggleSizeStatus,
      saveCategory,
      deleteCategory,
      reorderCategories,
      saveBanner,
      deleteBanner,
      reorderBanners,
      saveSettings,
      markOrderDelivered,
      markOrderCancelled,
      markOrderUndo,
      deleteOrder,
      deleteAllCancelledOrders,
      fetchBackups,
      createBackup,
      deleteBackup,
      restoreBackup,
      resetAllProducts,
      changeResetPin,
    ]
  );

  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
};

export function useStore(): StoreContextValue {
  const ctx = useContext(StoreContext);
  if (!ctx) throw new Error('useStore must be used inside StoreProvider');
  return ctx;
}
