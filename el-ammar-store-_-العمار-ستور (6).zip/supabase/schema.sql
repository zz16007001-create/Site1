-- ============================================================================
-- El-Ammar-store (العمار ستور) — Complete Supabase Schema, RLS, RPCs & Seed
-- ============================================================================

create extension if not exists "pgcrypto" with schema extensions;

-- ----------------------------------------------------------------------------
-- 1. Tables
-- ----------------------------------------------------------------------------

create table if not exists public.admin_emails (
  email text primary key
);

create table if not exists public.categories (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  image_url text,
  sort integer not null default 0,
  visible boolean not null default true,
  parent_id uuid references public.categories(id) on delete cascade
);

alter table public.categories
  add column if not exists parent_id uuid references public.categories(id) on delete cascade;

create table if not exists public.products (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  category_id uuid references public.categories(id) on delete set null,
  subcategory_id uuid references public.categories(id) on delete set null,
  description text default '',
  price numeric(10, 2) not null check (price >= 0),
  old_price numeric(10, 2) check (old_price is null or old_price >= 0),
  visible boolean not null default true,
  featured boolean not null default false,
  is_permanent boolean not null default false,
  listed_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

alter table public.products
  add column if not exists subcategory_id uuid references public.categories(id) on delete set null,
  add column if not exists is_permanent boolean not null default false,
  add column if not exists listed_at timestamptz not null default now();

create table if not exists public.product_colors (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  name text,
  hex text,
  images jsonb not null default '[]'::jsonb,
  sort integer not null default 0
);

do $$
begin
  if exists (
    select 1 from information_schema.columns
    where table_schema = 'public'
      and table_name = 'product_colors'
      and column_name = 'images'
      and data_type = 'ARRAY'
  ) then
    alter table public.product_colors
      alter column images drop default;
    alter table public.product_colors
      alter column images type jsonb using to_jsonb(images);
    alter table public.product_colors
      alter column images set default '[]'::jsonb;
  end if;
end $$;

create table if not exists public.product_sizes (
  id uuid primary key default gen_random_uuid(),
  color_id uuid not null references public.product_colors(id) on delete cascade,
  size text,
  status text not null default 'available' check (status in ('available', 'sold')),
  sold_at timestamptz
);

create table if not exists public.banners (
  id uuid primary key default gen_random_uuid(),
  image_url text,
  title text not null default '',
  subtitle text not null default '',
  btn_text text not null default 'تسوقي الآن',
  link text not null default '/catalog',
  active boolean not null default true,
  sort integer not null default 0,
  type text not null default 'message',
  product_id uuid references public.products(id) on delete set null,
  category_id uuid references public.categories(id) on delete set null,
  ends_at timestamptz
);

alter table public.banners
  add column if not exists type text not null default 'message',
  add column if not exists product_id uuid references public.products(id) on delete set null,
  add column if not exists category_id uuid references public.categories(id) on delete set null,
  add column if not exists ends_at timestamptz;

create table if not exists public.settings (
  id integer primary key default 1 check (id = 1),
  store_name text not null default 'العمار ستور',
  logo_url text not null default '/assets/aistudio/logo_be4d7522.png',
  whatsapp text not null default '',
  messenger_url text not null default '',
  instagram_url text not null default '',
  facebook_url text not null default '',
  whatsapp_group_url text not null default '',
  welcome text not null default 'أهلاً بكِ في العمار ستور — اختاري إطلالتك بأجمل الأحذية والشنط والدهب الصيني',
  order_intro text not null default 'أرسلي الطلب وهنرد عليكي فوراً بتفاصيل التوافر والشحن.',
  trust_items jsonb not null default '[]'::jsonb,
  pixel_id text not null default '',
  expiry_days integer not null default 10 check (expiry_days >= 1),
  backup_retention_days integer not null default 7 check (backup_retention_days >= 1),
  caption_template text not null default E'✨ {name} من {store_name}\n\n💰 السعر: {price}{discount_line}\n{colors_line}{sizes_line}\n🛍️ شوفي باقي الكتالوج واطلبي من المتجر:\n{link}\n\nالشحن بيتحدد معاكي في الشات 💛',
  features jsonb not null default '{
    "announcement_bar": {"enabled": true, "text": "تشكيلة جديدة وصلت الآن · الشحن يتحدد معاكي في الشات"},
    "offers_countdown": {"enabled": false, "end_date": ""},
    "share_button": {"enabled": false},
    "recently_viewed": {"enabled": false},
    "customer_reviews": {"enabled": false, "items": []},
    "floating_chat": {"enabled": true},
    "trust_strip": {"enabled": true},
    "follow_us": {"enabled": true}
  }'::jsonb
);

alter table public.settings
  add column if not exists whatsapp_group_url text not null default '',
  add column if not exists trust_items jsonb not null default '[]'::jsonb,
  add column if not exists pixel_id text not null default '',
  add column if not exists expiry_days integer not null default 10 check (expiry_days >= 1),
  add column if not exists backup_retention_days integer not null default 7 check (backup_retention_days >= 1),
  add column if not exists caption_template text not null default E'✨ {name} من {store_name}\n\n💰 السعر: {price}{discount_line}\n{colors_line}{sizes_line}\n🛍️ شوفي باقي الكتالوج واطلبي من المتجر:\n{link}\n\nالشحن بيتحدد معاكي في الشات 💛';

create table if not exists public.backups (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  label text not null default '',
  counts jsonb not null default '{}'::jsonb,
  image_paths jsonb not null default '[]'::jsonb,
  snapshot jsonb not null default '{}'::jsonb
);

create table if not exists public.admin_secrets (
  id integer primary key default 1 check (id = 1),
  reset_pin_hash text not null,
  failed_attempts integer not null default 0,
  locked_until timestamptz
);

create sequence if not exists public.orders_order_no_seq start with 1001 increment by 1;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  order_no integer not null unique default nextval('public.orders_order_no_seq'),
  created_at timestamptz not null default now(),
  status text not null default 'new' check (status in ('new', 'delivered', 'cancelled')),
  channel text not null default 'whatsapp' check (channel in ('whatsapp', 'messenger'))
);

create table if not exists public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  color_id uuid references public.product_colors(id) on delete set null,
  size_id uuid references public.product_sizes(id) on delete set null,
  name_snapshot text not null,
  color_snapshot text,
  size_snapshot text,
  price_snapshot numeric(10, 2) not null,
  qty integer not null default 1 check (qty >= 1)
);

-- Indexes for fast queries
create index if not exists idx_categories_parent on public.categories(parent_id);
create index if not exists idx_products_category on public.products(category_id);
create index if not exists idx_products_subcategory on public.products(subcategory_id);
create index if not exists idx_product_colors_product on public.product_colors(product_id);
create index if not exists idx_product_sizes_color on public.product_sizes(color_id);
create index if not exists idx_order_items_order on public.order_items(order_id);

-- ----------------------------------------------------------------------------
-- 2. Helper Functions
-- ----------------------------------------------------------------------------

create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_emails ae
    where lower(ae.email) = lower(coalesce(auth.jwt() ->> 'email', ''))
  );
$$;

create or replace function public.is_current_user_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.is_admin();
$$;

grant execute on function public.is_current_user_admin() to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 3. Row Level Security (RLS)
-- ----------------------------------------------------------------------------

alter table public.admin_emails enable row level security;
alter table public.categories enable row level security;
alter table public.products enable row level security;
alter table public.product_colors enable row level security;
alter table public.product_sizes enable row level security;
alter table public.banners enable row level security;
alter table public.settings enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.backups enable row level security;
alter table public.admin_secrets enable row level security;

drop policy if exists "admin_emails_admin_all" on public.admin_emails;
create policy "admin_emails_admin_all" on public.admin_emails
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "categories_public_select" on public.categories;
create policy "categories_public_select" on public.categories
  for select to anon, authenticated
  using (visible = true or public.is_admin());

drop policy if exists "categories_admin_all" on public.categories;
create policy "categories_admin_all" on public.categories
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "products_public_select" on public.products;
create policy "products_public_select" on public.products
  for select to anon, authenticated
  using (visible = true or public.is_admin());

drop policy if exists "products_admin_all" on public.products;
create policy "products_admin_all" on public.products
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "product_colors_public_select" on public.product_colors;
create policy "product_colors_public_select" on public.product_colors
  for select to anon, authenticated
  using (
    public.is_admin()
    or exists (
      select 1 from public.products p
      where p.id = product_colors.product_id and p.visible = true
    )
  );

drop policy if exists "product_colors_admin_all" on public.product_colors;
create policy "product_colors_admin_all" on public.product_colors
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "product_sizes_public_select" on public.product_sizes;
create policy "product_sizes_public_select" on public.product_sizes
  for select to anon, authenticated
  using (
    public.is_admin()
    or exists (
      select 1
      from public.product_colors pc
      join public.products p on p.id = pc.product_id
      where pc.id = product_sizes.color_id and p.visible = true
    )
  );

drop policy if exists "product_sizes_admin_all" on public.product_sizes;
create policy "product_sizes_admin_all" on public.product_sizes
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "banners_public_select" on public.banners;
create policy "banners_public_select" on public.banners
  for select to anon, authenticated
  using (active = true or public.is_admin());

drop policy if exists "banners_admin_all" on public.banners;
create policy "banners_admin_all" on public.banners
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "settings_public_select" on public.settings;
create policy "settings_public_select" on public.settings
  for select to anon, authenticated
  using (true);

drop policy if exists "settings_admin_all" on public.settings;
create policy "settings_admin_all" on public.settings
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "orders_admin_all" on public.orders;
create policy "orders_admin_all" on public.orders
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "order_items_admin_all" on public.order_items;
create policy "order_items_admin_all" on public.order_items
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "backups_admin_all" on public.backups;
create policy "backups_admin_all" on public.backups
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

drop policy if exists "admin_secrets_admin_only" on public.admin_secrets;
create policy "admin_secrets_admin_only" on public.admin_secrets
  for all to authenticated
  using (public.is_admin())
  with check (public.is_admin());

-- ----------------------------------------------------------------------------
-- 4. RPCs (SECURITY DEFINER)
-- ----------------------------------------------------------------------------

create or replace function public.create_order(items jsonb, channel text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid;
  v_order_no integer;
  v_item jsonb;
  v_product record;
  v_color record;
  v_size record;
  v_qty integer;
  v_channel text;
  v_inserted_count integer := 0;
begin
  if items is null or jsonb_typeof(items) <> 'array' or jsonb_array_length(items) = 0 then
    raise exception 'Cart items cannot be empty';
  end if;

  v_channel := case when channel in ('whatsapp', 'messenger') then channel else 'whatsapp' end;

  insert into public.orders (status, channel)
  values ('new', v_channel)
  returning id, order_no into v_order_id, v_order_no;

  for v_item in select * from jsonb_array_elements(items)
  loop
    v_qty := greatest(1, coalesce((v_item ->> 'qty')::integer, 1));

    select id, name, price, visible
    into v_product
    from public.products
    where id = (v_item ->> 'product_id')::uuid and visible = true;

    if not found then
      raise exception 'Product not available';
    end if;

    select id, name
    into v_color
    from public.product_colors
    where id = (v_item ->> 'color_id')::uuid and product_id = v_product.id;

    if not found then
      raise exception 'Color not valid for product';
    end if;

    select id, size, status
    into v_size
    from public.product_sizes
    where id = (v_item ->> 'size_id')::uuid and color_id = v_color.id;

    if not found then
      raise exception 'Size not valid for color';
    end if;

    if v_size.status <> 'available' then
      raise exception 'Selected item is no longer available';
    end if;

    insert into public.order_items (
      order_id, product_id, color_id, size_id,
      name_snapshot, color_snapshot, size_snapshot, price_snapshot, qty
    ) values (
      v_order_id, v_product.id, v_color.id, v_size.id,
      v_product.name, v_color.name, v_size.size, v_product.price, v_qty
    );

    v_inserted_count := v_inserted_count + 1;
  end loop;

  if v_inserted_count = 0 then
    raise exception 'No valid items in order';
  end if;

  return jsonb_build_object('id', v_order_id, 'order_no', v_order_no);
end;
$$;

grant execute on function public.create_order(jsonb, text) to anon, authenticated;

create or replace function public.mark_order_delivered(order_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  update public.orders
  set status = 'delivered'
  where id = order_id;

  update public.product_sizes ps
  set status = 'sold',
      sold_at = now()
  from public.order_items oi
  where oi.order_id = mark_order_delivered.order_id
    and oi.size_id = ps.id;
end;
$$;

grant execute on function public.mark_order_delivered(uuid) to authenticated;

create or replace function public.mark_order_undo(order_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_prev_status text;
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  select status into v_prev_status
  from public.orders
  where id = order_id;

  update public.orders
  set status = 'new'
  where id = order_id;

  if v_prev_status = 'delivered' then
    update public.product_sizes ps
    set status = 'available',
        sold_at = null
    from public.order_items oi
    where oi.order_id = mark_order_undo.order_id
      and oi.size_id = ps.id;
  end if;
end;
$$;

grant execute on function public.mark_order_undo(uuid) to authenticated;

create or replace function public.extract_images_path(p_url text)
returns text
language plpgsql
immutable
as $$
declare
  v_clean text;
  v_marker text;
  v_idx integer;
  v_markers text[] := array[
    '/storage/v1/object/public/images/',
    '/storage/v1/object/sign/images/',
    '/storage/v1/object/authenticated/images/',
    '/storage/v1/render/image/public/images/'
  ];
begin
  if p_url is null then
    return null;
  end if;
  v_clean := split_part(split_part(btrim(p_url), '?', 1), '#', 1);
  if v_clean = '' or v_clean like 'data:%' or v_clean like 'blob:%' or v_clean like '/assets/%' then
    return null;
  end if;
  foreach v_marker in array v_markers loop
    v_idx := strpos(v_clean, v_marker);
    if v_idx > 0 then
      return ltrim(substr(v_clean, v_idx + length(v_marker)), '/');
    end if;
  end loop;
  return null;
end;
$$;

create or replace function public.image_paths_in_use()
returns text[]
language plpgsql
security definer
set search_path = public
as $$
declare
  v_paths text[];
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  with all_urls as (
    select img ->> 'full' as u
    from public.product_colors pc
    cross join lateral jsonb_array_elements(coalesce(pc.images, '[]'::jsonb)) as img
    union all
    select img ->> 'thumb' as u
    from public.product_colors pc
    cross join lateral jsonb_array_elements(coalesce(pc.images, '[]'::jsonb)) as img
    union all
    select c.image_url as u from public.categories c where c.image_url is not null
    union all
    select b.image_url as u from public.banners b where b.image_url is not null
    union all
    select s.logo_url as u from public.settings s where s.id = 1
    union all
    select rev ->> 'image_url' as u
    from public.settings s
    cross join lateral jsonb_array_elements(coalesce(s.features -> 'customer_reviews' -> 'items', '[]'::jsonb)) as rev
    where s.id = 1
  ),
  extracted as (
    select public.extract_images_path(u) as path from all_urls
    union all
    select p_elem #>> '{}' as path
    from public.backups bk
    cross join lateral jsonb_array_elements(coalesce(bk.image_paths, '[]'::jsonb)) as p_elem
  )
  select coalesce(array_agg(distinct path), '{}'::text[])
  into v_paths
  from extracted
  where path is not null and btrim(path) <> '';

  return v_paths;
end;
$$;

grant execute on function public.image_paths_in_use() to authenticated;

create or replace function public.prune_backups()
returns text[]
language plpgsql
security definer
set search_path = public
as $$
declare
  v_retention integer := 7;
  v_removed_paths text[];
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  select greatest(1, coalesce(backup_retention_days, 7))
  into v_retention
  from public.settings
  where id = 1;

  with deleted as (
    delete from public.backups
    where created_at < now() - make_interval(days => v_retention)
    returning image_paths
  )
  select coalesce(array_agg(distinct elem #>> '{}'), '{}'::text[])
  into v_removed_paths
  from deleted
  cross join lateral jsonb_array_elements(coalesce(deleted.image_paths, '[]'::jsonb)) as elem
  where elem #>> '{}' is not null and btrim(elem #>> '{}') <> '';

  return v_removed_paths;
end;
$$;

grant execute on function public.prune_backups() to authenticated;

create or replace function public.create_backup(p_label text default '')
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_backup_id uuid;
  v_snapshot jsonb;
  v_image_paths jsonb;
  v_counts jsonb;
  v_prod_count integer;
  v_cat_count integer;
  v_ban_count integer;
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  perform public.prune_backups();

  select count(*) into v_prod_count from public.products;
  select count(*) into v_cat_count from public.categories;
  select count(*) into v_ban_count from public.banners;

  v_counts := jsonb_build_object(
    'products', v_prod_count,
    'categories', v_cat_count,
    'banners', v_ban_count
  );

  with prod_urls as (
    select img ->> 'full' as u
    from public.product_colors pc
    cross join lateral jsonb_array_elements(coalesce(pc.images, '[]'::jsonb)) as img
    union all
    select img ->> 'thumb' as u
    from public.product_colors pc
    cross join lateral jsonb_array_elements(coalesce(pc.images, '[]'::jsonb)) as img
  )
  select coalesce(jsonb_agg(distinct p_path), '[]'::jsonb)
  into v_image_paths
  from (
    select public.extract_images_path(u) as p_path from prod_urls
  ) t
  where p_path is not null and btrim(p_path) <> '';

  v_snapshot := jsonb_build_object(
    'categories', coalesce((
      select jsonb_agg(to_jsonb(c) order by c.parent_id nulls first, c.sort asc)
      from public.categories c
    ), '[]'::jsonb),
    'products', coalesce((
      select jsonb_agg(to_jsonb(p) order by p.created_at desc)
      from public.products p
    ), '[]'::jsonb),
    'product_colors', coalesce((
      select jsonb_agg(to_jsonb(pc) order by pc.sort asc)
      from public.product_colors pc
    ), '[]'::jsonb),
    'product_sizes', coalesce((
      select jsonb_agg(to_jsonb(ps))
      from public.product_sizes ps
    ), '[]'::jsonb),
    'banners', coalesce((
      select jsonb_agg(to_jsonb(b) order by b.sort asc)
      from public.banners b
    ), '[]'::jsonb),
    'settings', coalesce((
      select jsonb_build_object(
        'id', s.id,
        'store_name', s.store_name,
        'logo_url', s.logo_url,
        'whatsapp', s.whatsapp,
        'messenger_url', s.messenger_url,
        'instagram_url', s.instagram_url,
        'facebook_url', s.facebook_url,
        'whatsapp_group_url', s.whatsapp_group_url,
        'welcome', s.welcome,
        'order_intro', s.order_intro,
        'trust_items', s.trust_items,
        'pixel_id', s.pixel_id,
        'expiry_days', s.expiry_days,
        'backup_retention_days', s.backup_retention_days,
        'caption_template', s.caption_template,
        'features', s.features
      )
      from public.settings s
      where s.id = 1
    ), '{}'::jsonb)
  );

  insert into public.backups (label, counts, image_paths, snapshot)
  values (coalesce(nullif(btrim(p_label), ''), 'نسخة يدوية'), v_counts, v_image_paths, v_snapshot)
  returning id into v_backup_id;

  return v_backup_id;
end;
$$;

grant execute on function public.create_backup(text) to authenticated;

create or replace function public.restore_backup(p_backup_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_snap jsonb;
  v_settings jsonb;
  v_cat_ids uuid[];
  v_prod_ids uuid[];
  v_col_ids uuid[];
  v_size_ids uuid[];
  v_ban_ids uuid[];
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  select snapshot into v_snap
  from public.backups
  where id = p_backup_id;

  if v_snap is null then
    raise exception 'Backup not found';
  end if;

  -- Upsert top-level categories first (parent_id is null)
  insert into public.categories (id, name, image_url, sort, visible, parent_id)
  select
    (c ->> 'id')::uuid,
    c ->> 'name',
    nullif(c ->> 'image_url', ''),
    coalesce((c ->> 'sort')::integer, 0),
    coalesce((c ->> 'visible')::boolean, true),
    null
  from jsonb_array_elements(coalesce(v_snap -> 'categories', '[]'::jsonb)) as c
  where nullif(c ->> 'parent_id', '') is null
  on conflict (id) do update set
    name = excluded.name,
    image_url = excluded.image_url,
    sort = excluded.sort,
    visible = excluded.visible,
    parent_id = null;

  -- Upsert child categories next
  insert into public.categories (id, name, image_url, sort, visible, parent_id)
  select
    (c ->> 'id')::uuid,
    c ->> 'name',
    nullif(c ->> 'image_url', ''),
    coalesce((c ->> 'sort')::integer, 0),
    coalesce((c ->> 'visible')::boolean, true),
    (c ->> 'parent_id')::uuid
  from jsonb_array_elements(coalesce(v_snap -> 'categories', '[]'::jsonb)) as c
  where nullif(c ->> 'parent_id', '') is not null
  on conflict (id) do update set
    name = excluded.name,
    image_url = excluded.image_url,
    sort = excluded.sort,
    visible = excluded.visible,
    parent_id = excluded.parent_id;

  -- Upsert products
  insert into public.products (
    id, name, category_id, subcategory_id, description, price, old_price,
    visible, featured, is_permanent, listed_at, created_at
  )
  select
    (p ->> 'id')::uuid,
    p ->> 'name',
    nullif(p ->> 'category_id', '')::uuid,
    nullif(p ->> 'subcategory_id', '')::uuid,
    coalesce(p ->> 'description', ''),
    coalesce((p ->> 'price')::numeric, 0),
    nullif(p ->> 'old_price', '')::numeric,
    coalesce((p ->> 'visible')::boolean, true),
    coalesce((p ->> 'featured')::boolean, false),
    coalesce((p ->> 'is_permanent')::boolean, false),
    coalesce(nullif(p ->> 'listed_at', '')::timestamptz, now()),
    coalesce(nullif(p ->> 'created_at', '')::timestamptz, now())
  from jsonb_array_elements(coalesce(v_snap -> 'products', '[]'::jsonb)) as p
  on conflict (id) do update set
    name = excluded.name,
    category_id = excluded.category_id,
    subcategory_id = excluded.subcategory_id,
    description = excluded.description,
    price = excluded.price,
    old_price = excluded.old_price,
    visible = excluded.visible,
    featured = excluded.featured,
    is_permanent = excluded.is_permanent,
    listed_at = excluded.listed_at,
    created_at = excluded.created_at;

  -- Upsert product_colors
  insert into public.product_colors (id, product_id, name, hex, images, sort)
  select
    (pc ->> 'id')::uuid,
    (pc ->> 'product_id')::uuid,
    nullif(pc ->> 'name', ''),
    nullif(pc ->> 'hex', ''),
    coalesce(pc -> 'images', '[]'::jsonb),
    coalesce((pc ->> 'sort')::integer, 0)
  from jsonb_array_elements(coalesce(v_snap -> 'product_colors', '[]'::jsonb)) as pc
  on conflict (id) do update set
    product_id = excluded.product_id,
    name = excluded.name,
    hex = excluded.hex,
    images = excluded.images,
    sort = excluded.sort;

  -- Upsert product_sizes
  insert into public.product_sizes (id, color_id, size, status, sold_at)
  select
    (ps ->> 'id')::uuid,
    (ps ->> 'color_id')::uuid,
    nullif(ps ->> 'size', ''),
    case when ps ->> 'status' = 'sold' then 'sold' else 'available' end,
    nullif(ps ->> 'sold_at', '')::timestamptz
  from jsonb_array_elements(coalesce(v_snap -> 'product_sizes', '[]'::jsonb)) as ps
  on conflict (id) do update set
    color_id = excluded.color_id,
    size = excluded.size,
    status = excluded.status,
    sold_at = excluded.sold_at;

  -- Remove rows that do not exist in the backup (orders & order_items remain untouched)
  select coalesce(array_agg((s ->> 'id')::uuid), '{}'::uuid[]) into v_size_ids
  from jsonb_array_elements(coalesce(v_snap -> 'product_sizes', '[]'::jsonb)) as s;
  delete from public.product_sizes where not (id = any(v_size_ids));

  select coalesce(array_agg((c ->> 'id')::uuid), '{}'::uuid[]) into v_col_ids
  from jsonb_array_elements(coalesce(v_snap -> 'product_colors', '[]'::jsonb)) as c;
  delete from public.product_colors where not (id = any(v_col_ids));

  select coalesce(array_agg((p ->> 'id')::uuid), '{}'::uuid[]) into v_prod_ids
  from jsonb_array_elements(coalesce(v_snap -> 'products', '[]'::jsonb)) as p;
  delete from public.products where not (id = any(v_prod_ids));

  select coalesce(array_agg((cat ->> 'id')::uuid), '{}'::uuid[]) into v_cat_ids
  from jsonb_array_elements(coalesce(v_snap -> 'categories', '[]'::jsonb)) as cat;
  delete from public.categories where parent_id is not null and not (id = any(v_cat_ids));
  delete from public.categories where parent_id is null and not (id = any(v_cat_ids));

  -- Upsert banners and remove banners not in backup
  insert into public.banners (
    id, image_url, title, subtitle, btn_text, link, active, sort, type, product_id, category_id, ends_at
  )
  select
    (b ->> 'id')::uuid,
    nullif(b ->> 'image_url', ''),
    coalesce(b ->> 'title', ''),
    coalesce(b ->> 'subtitle', ''),
    coalesce(b ->> 'btn_text', 'تسوقي الآن'),
    coalesce(b ->> 'link', '/catalog'),
    coalesce((b ->> 'active')::boolean, true),
    coalesce((b ->> 'sort')::integer, 0),
    coalesce(b ->> 'type', 'message'),
    nullif(b ->> 'product_id', '')::uuid,
    nullif(b ->> 'category_id', '')::uuid,
    nullif(b ->> 'ends_at', '')::timestamptz
  from jsonb_array_elements(coalesce(v_snap -> 'banners', '[]'::jsonb)) as b
  on conflict (id) do update set
    image_url = excluded.image_url,
    title = excluded.title,
    subtitle = excluded.subtitle,
    btn_text = excluded.btn_text,
    link = excluded.link,
    active = excluded.active,
    sort = excluded.sort,
    type = excluded.type,
    product_id = excluded.product_id,
    category_id = excluded.category_id,
    ends_at = excluded.ends_at;

  select coalesce(array_agg((b ->> 'id')::uuid), '{}'::uuid[]) into v_ban_ids
  from jsonb_array_elements(coalesce(v_snap -> 'banners', '[]'::jsonb)) as b;
  delete from public.banners where not (id = any(v_ban_ids));

  -- Restore storefront settings (never touching admin_emails or admin_secrets)
  v_settings := v_snap -> 'settings';
  if v_settings is not null and jsonb_typeof(v_settings) = 'object' and v_settings <> '{}'::jsonb then
    update public.settings set
      store_name = coalesce(v_settings ->> 'store_name', store_name),
      logo_url = coalesce(v_settings ->> 'logo_url', logo_url),
      whatsapp = coalesce(v_settings ->> 'whatsapp', whatsapp),
      messenger_url = coalesce(v_settings ->> 'messenger_url', messenger_url),
      instagram_url = coalesce(v_settings ->> 'instagram_url', instagram_url),
      facebook_url = coalesce(v_settings ->> 'facebook_url', facebook_url),
      whatsapp_group_url = coalesce(v_settings ->> 'whatsapp_group_url', whatsapp_group_url),
      welcome = coalesce(v_settings ->> 'welcome', welcome),
      order_intro = coalesce(v_settings ->> 'order_intro', order_intro),
      trust_items = coalesce(v_settings -> 'trust_items', trust_items),
      pixel_id = coalesce(v_settings ->> 'pixel_id', pixel_id),
      expiry_days = greatest(1, coalesce((v_settings ->> 'expiry_days')::integer, expiry_days)),
      backup_retention_days = greatest(1, coalesce((v_settings ->> 'backup_retention_days')::integer, backup_retention_days)),
      caption_template = coalesce(v_settings ->> 'caption_template', caption_template),
      features = coalesce(v_settings -> 'features', features)
    where id = 1;
  end if;
end;
$$;

grant execute on function public.restore_backup(uuid) to authenticated;

create or replace function public.reset_products(pin text, take_backup boolean default true)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_secret record;
  v_attempts integer;
  v_locked_until timestamptz;
  v_backup_id uuid := null;
  v_deleted_count integer := 0;
  v_candidate_paths text[];
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  if pin is null or pin !~ '^\d{4}$' then
    return jsonb_build_object('ok', false, 'error', 'invalid_pin');
  end if;

  select * into v_secret from public.admin_secrets where id = 1 for update;
  if not found then
    insert into public.admin_secrets (id, reset_pin_hash)
    values (1, extensions.crypt('1234', extensions.gen_salt('bf')))
    on conflict (id) do nothing;
    select * into v_secret from public.admin_secrets where id = 1 for update;
  end if;

  if v_secret.locked_until is not null and v_secret.locked_until > now() then
    return jsonb_build_object(
      'ok', false,
      'error', 'locked',
      'locked_until', v_secret.locked_until
    );
  end if;

  if extensions.crypt(pin, v_secret.reset_pin_hash) <> v_secret.reset_pin_hash then
    v_attempts := case
      when v_secret.locked_until is not null and v_secret.locked_until <= now() then 1
      else coalesce(v_secret.failed_attempts, 0) + 1
    end;
    if v_attempts >= 5 then
      v_locked_until := now() + interval '5 minutes';
      update public.admin_secrets
      set failed_attempts = 0, locked_until = v_locked_until
      where id = 1;
      return jsonb_build_object(
        'ok', false,
        'error', 'locked',
        'locked_until', v_locked_until
      );
    else
      update public.admin_secrets
      set failed_attempts = v_attempts, locked_until = null
      where id = 1;
      return jsonb_build_object(
        'ok', false,
        'error', 'invalid_pin',
        'attempts_left', 5 - v_attempts
      );
    end if;
  end if;

  update public.admin_secrets
  set failed_attempts = 0, locked_until = null
  where id = 1;

  if coalesce(take_backup, true) then
    v_backup_id := public.create_backup('قبل التصفير');
  end if;

  with prod_urls as (
    select img ->> 'full' as u
    from public.product_colors pc
    cross join lateral jsonb_array_elements(coalesce(pc.images, '[]'::jsonb)) as img
    union all
    select img ->> 'thumb' as u
    from public.product_colors pc
    cross join lateral jsonb_array_elements(coalesce(pc.images, '[]'::jsonb)) as img
  )
  select coalesce(array_agg(distinct p_path), '{}'::text[])
  into v_candidate_paths
  from (
    select public.extract_images_path(u) as p_path from prod_urls
  ) t
  where p_path is not null and btrim(p_path) <> '';

  select count(*) into v_deleted_count from public.products;

  delete from public.products;

  return jsonb_build_object(
    'ok', true,
    'deleted_products', v_deleted_count,
    'backup_id', v_backup_id,
    'candidate_paths', to_jsonb(v_candidate_paths)
  );
end;
$$;

grant execute on function public.reset_products(text, boolean) to authenticated;

create or replace function public.change_reset_pin(old_pin text, new_pin text)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_secret record;
  v_attempts integer;
  v_locked_until timestamptz;
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  if new_pin is null or new_pin !~ '^\d{4}$' then
    return jsonb_build_object('ok', false, 'error', 'invalid_new_pin');
  end if;

  select * into v_secret from public.admin_secrets where id = 1 for update;
  if not found then
    insert into public.admin_secrets (id, reset_pin_hash)
    values (1, extensions.crypt('1234', extensions.gen_salt('bf')))
    on conflict (id) do nothing;
    select * into v_secret from public.admin_secrets where id = 1 for update;
  end if;

  if v_secret.locked_until is not null and v_secret.locked_until > now() then
    return jsonb_build_object(
      'ok', false,
      'error', 'locked',
      'locked_until', v_secret.locked_until
    );
  end if;

  if old_pin is null or extensions.crypt(old_pin, v_secret.reset_pin_hash) <> v_secret.reset_pin_hash then
    v_attempts := case
      when v_secret.locked_until is not null and v_secret.locked_until <= now() then 1
      else coalesce(v_secret.failed_attempts, 0) + 1
    end;
    if v_attempts >= 5 then
      v_locked_until := now() + interval '5 minutes';
      update public.admin_secrets
      set failed_attempts = 0, locked_until = v_locked_until
      where id = 1;
      return jsonb_build_object(
        'ok', false,
        'error', 'locked',
        'locked_until', v_locked_until
      );
    else
      update public.admin_secrets
      set failed_attempts = v_attempts, locked_until = null
      where id = 1;
      return jsonb_build_object(
        'ok', false,
        'error', 'invalid_pin',
        'attempts_left', 5 - v_attempts
      );
    end if;
  end if;

  update public.admin_secrets
  set
    reset_pin_hash = extensions.crypt(new_pin, extensions.gen_salt('bf')),
    failed_attempts = 0,
    locked_until = null
  where id = 1;

  return jsonb_build_object('ok', true);
end;
$$;

grant execute on function public.change_reset_pin(text, text) to authenticated;

-- ----------------------------------------------------------------------------
-- 5. Storage Bucket ("images") & Policies
-- ----------------------------------------------------------------------------

insert into storage.buckets (id, name, public)
values ('images', 'images', true)
on conflict (id) do update set public = true;

drop policy if exists "images_public_read" on storage.objects;
create policy "images_public_read" on storage.objects
  for select to anon, authenticated
  using (bucket_id = 'images');

drop policy if exists "images_admin_insert" on storage.objects;
create policy "images_admin_insert" on storage.objects
  for insert to authenticated
  with check (bucket_id = 'images' and public.is_admin());

drop policy if exists "images_admin_update" on storage.objects;
create policy "images_admin_update" on storage.objects
  for update to authenticated
  using (bucket_id = 'images' and public.is_admin())
  with check (bucket_id = 'images' and public.is_admin());

drop policy if exists "images_admin_delete" on storage.objects;
create policy "images_admin_delete" on storage.objects
  for delete to authenticated
  using (bucket_id = 'images' and public.is_admin());

-- ----------------------------------------------------------------------------
-- 6. Seed Default Settings, Top-Level Categories & Subcategories (Idempotent)
-- ----------------------------------------------------------------------------

insert into public.settings (id)
values (1)
on conflict (id) do nothing;

insert into public.admin_secrets (id, reset_pin_hash)
values (1, extensions.crypt('1234', extensions.gen_salt('bf')))
on conflict (id) do nothing;

insert into public.categories (name, image_url, sort, visible, parent_id)
select v.name, null, v.sort, true, null
from (values
  ('أحذية حريمي', 1),
  ('شنطة', 2),
  ('دهب صيني', 3),
  ('إكسسوارات', 4)
) as v(name, sort)
where not exists (
  select 1 from public.categories c where c.parent_id is null and c.name = v.name
);

-- Subcategories seed matched by parent name
insert into public.categories (name, image_url, sort, visible, parent_id)
select sub.sub_name, null, sub.sort_order, true, p.id
from (values
  ('أحذية حريمي', 'كوتشي', 1),
  ('أحذية حريمي', 'شوز', 2),
  ('أحذية حريمي', 'هيلز', 3),
  ('أحذية حريمي', 'صابو', 4),
  ('أحذية حريمي', 'سليبر', 5),
  ('شنطة', 'شنط باك', 1),
  ('شنطة', 'شنط كروس', 2),
  ('شنطة', 'شنط شولدر', 3),
  ('دهب صيني', 'سلسلة', 1),
  ('دهب صيني', 'خاتم', 2),
  ('دهب صيني', 'حلق', 3),
  ('دهب صيني', 'إسورة', 4)
) as sub(parent_name, sub_name, sort_order)
join public.categories p on p.parent_id is null and p.name = sub.parent_name
where not exists (
  select 1 from public.categories existing
  where existing.parent_id = p.id and existing.name = sub.sub_name
);
