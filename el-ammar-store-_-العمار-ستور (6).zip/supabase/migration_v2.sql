-- ============================================================================
-- El-Ammar-store (العمار ستور) — Migration v2 (Idempotent)
-- Safe to run on top of supabase/schema.sql without losing any existing data.
-- ============================================================================

create extension if not exists "pgcrypto" with schema extensions;

-- ----------------------------------------------------------------------------
-- 1. Schema Additions: products.code & orders.customer_phone / channel
-- ----------------------------------------------------------------------------

alter table public.products
  add column if not exists code text;

create index if not exists idx_products_code
  on public.products (lower(code))
  where code is not null;

alter table public.orders
  add column if not exists customer_phone text;

do $$
declare
  v_constraint record;
begin
  for v_constraint in
    select conname
    from pg_constraint
    where conrelid = 'public.orders'::regclass
      and contype = 'c'
      and pg_get_constraintdef(oid) ilike '%channel%'
  loop
    execute format('alter table public.orders drop constraint if exists %I', v_constraint.conname);
  end loop;
end $$;

alter table public.orders
  add constraint orders_channel_check
  check (channel in ('whatsapp', 'messenger', 'callback'));

-- ----------------------------------------------------------------------------
-- 2. Updated create_order RPC (limits + duplicate spam guard + callback phone)
-- ----------------------------------------------------------------------------

drop function if exists public.create_order(jsonb, text);

create or replace function public.create_order(
  items jsonb,
  channel text,
  p_phone text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_order_id uuid;
  v_order_no integer;
  v_item jsonb;
  v_product record;
  v_color record;
  v_size record;
  v_qty integer;
  v_channel text;
  v_phone text;
  v_req_sizes uuid[];
  v_inserted_count integer := 0;
begin
  if items is null or jsonb_typeof(items) <> 'array' then
    raise exception 'Cart items cannot be empty';
  end if;

  if jsonb_array_length(items) < 1 or jsonb_array_length(items) > 20 then
    raise exception 'Order must contain between 1 and 20 items';
  end if;

  v_channel := case
    when channel in ('whatsapp', 'messenger', 'callback') then channel
    else 'whatsapp'
  end;

  v_phone := nullif(
    regexp_replace(
      translate(
        coalesce(p_phone, ''),
        '٠١٢٣٤٥٦٧٨٩۰۱۲۳۴۵۶۷۸۹',
        '01234567890123456789'
      ),
      '[^0-9]',
      '',
      'g'
    ),
    ''
  );

  if v_channel = 'callback' then
    if v_phone is null or length(v_phone) < 10 or length(v_phone) > 15 then
      raise exception 'Valid customer phone is required for callback orders';
    end if;
  elsif v_phone is not null and (length(v_phone) < 10 or length(v_phone) > 15) then
    raise exception 'Invalid customer phone length';
  end if;

  -- Reject duplicate orders for the exact same size_id set submitted within 1 minute
  select array_agg(distinct (elem ->> 'size_id')::uuid order by (elem ->> 'size_id')::uuid)
  into v_req_sizes
  from jsonb_array_elements(items) as elem
  where nullif(elem ->> 'size_id', '') is not null;

  if v_req_sizes is not null and array_length(v_req_sizes, 1) > 0 then
    if exists (
      select 1
      from public.orders o
      where o.created_at >= now() - interval '1 minute'
        and (
          select array_agg(distinct oi.size_id order by oi.size_id)
          from public.order_items oi
          where oi.order_id = o.id
            and oi.size_id is not null
        ) = v_req_sizes
    ) then
      raise exception 'Duplicate order submitted too quickly';
    end if;
  end if;

  insert into public.orders (status, channel, customer_phone)
  values ('new', v_channel, v_phone)
  returning id, order_no into v_order_id, v_order_no;

  for v_item in select * from jsonb_array_elements(items)
  loop
    v_qty := (v_item ->> 'qty')::integer;
    if v_qty is null or v_qty < 1 or v_qty > 10 then
      raise exception 'Item quantity must be between 1 and 10';
    end if;

    select id, name, price, visible
    into v_product
    from public.products
    where id = (v_item ->> 'product_id')::uuid and visible = true;

    if not found then
      raise exception 'Product not available';
    end if;

    select id, name
    into v_color
    from public.product_colors
    where id = (v_item ->> 'color_id')::uuid and product_id = v_product.id;

    if not found then
      raise exception 'Color not valid for product';
    end if;

    select id, size, status
    into v_size
    from public.product_sizes
    where id = (v_item ->> 'size_id')::uuid and color_id = v_color.id;

    if not found then
      raise exception 'Size not valid for color';
    end if;

    if v_size.status <> 'available' then
      raise exception 'Selected item is no longer available';
    end if;

    insert into public.order_items (
      order_id, product_id, color_id, size_id,
      name_snapshot, color_snapshot, size_snapshot, price_snapshot, qty
    ) values (
      v_order_id, v_product.id, v_color.id, v_size.id,
      v_product.name, v_color.name, v_size.size, v_product.price, v_qty
    );

    v_inserted_count := v_inserted_count + 1;
  end loop;

  if v_inserted_count = 0 then
    raise exception 'No valid items in order';
  end if;

  return jsonb_build_object('id', v_order_id, 'order_no', v_order_no);
end;
$$;

grant execute on function public.create_order(jsonb, text, text) to anon, authenticated;

-- ----------------------------------------------------------------------------
-- 3. Default Reset PIN Security Check RPC (Admin-only)
-- ----------------------------------------------------------------------------

create or replace function public.is_default_reset_pin()
returns boolean
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_hash text;
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  select reset_pin_hash into v_hash
  from public.admin_secrets
  where id = 1;

  if v_hash is null then
    return true;
  end if;

  return extensions.crypt('1234', v_hash) = v_hash;
end;
$$;

grant execute on function public.is_default_reset_pin() to authenticated;

-- ----------------------------------------------------------------------------
-- 4. Storage Usage Bytes RPC (Admin-only, reads storage.objects metadata.size)
-- ----------------------------------------------------------------------------

create or replace function public.get_storage_usage_bytes()
returns bigint
language plpgsql
security definer
set search_path = public, storage
as $$
declare
  v_total bigint;
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  select coalesce(sum(coalesce((metadata ->> 'size')::bigint, 0)), 0)::bigint
  into v_total
  from storage.objects
  where bucket_id = 'images';

  return v_total;
end;
$$;

grant execute on function public.get_storage_usage_bytes() to authenticated;

-- ----------------------------------------------------------------------------
-- 5. Update restore_backup to preserve products.code
-- ----------------------------------------------------------------------------

create or replace function public.restore_backup(p_backup_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  v_snap jsonb;
  v_settings jsonb;
  v_cat_ids uuid[];
  v_prod_ids uuid[];
  v_col_ids uuid[];
  v_size_ids uuid[];
  v_ban_ids uuid[];
begin
  if not public.is_admin() then
    raise exception 'Unauthorized';
  end if;

  select snapshot into v_snap
  from public.backups
  where id = p_backup_id;

  if v_snap is null then
    raise exception 'Backup not found';
  end if;

  insert into public.categories (id, name, image_url, sort, visible, parent_id)
  select
    (c ->> 'id')::uuid,
    c ->> 'name',
    nullif(c ->> 'image_url', ''),
    coalesce((c ->> 'sort')::integer, 0),
    coalesce((c ->> 'visible')::boolean, true),
    null
  from jsonb_array_elements(coalesce(v_snap -> 'categories', '[]'::jsonb)) as c
  where nullif(c ->> 'parent_id', '') is null
  on conflict (id) do update set
    name = excluded.name,
    image_url = excluded.image_url,
    sort = excluded.sort,
    visible = excluded.visible,
    parent_id = null;

  insert into public.categories (id, name, image_url, sort, visible, parent_id)
  select
    (c ->> 'id')::uuid,
    c ->> 'name',
    nullif(c ->> 'image_url', ''),
    coalesce((c ->> 'sort')::integer, 0),
    coalesce((c ->> 'visible')::boolean, true),
    (c ->> 'parent_id')::uuid
  from jsonb_array_elements(coalesce(v_snap -> 'categories', '[]'::jsonb)) as c
  where nullif(c ->> 'parent_id', '') is not null
  on conflict (id) do update set
    name = excluded.name,
    image_url = excluded.image_url,
    sort = excluded.sort,
    visible = excluded.visible,
    parent_id = excluded.parent_id;

  insert into public.products (
    id, name, code, category_id, subcategory_id, description, price, old_price,
    visible, featured, is_permanent, listed_at, created_at
  )
  select
    (p ->> 'id')::uuid,
    p ->> 'name',
    nullif(p ->> 'code', ''),
    nullif(p ->> 'category_id', '')::uuid,
    nullif(p ->> 'subcategory_id', '')::uuid,
    coalesce(p ->> 'description', ''),
    coalesce((p ->> 'price')::numeric, 0),
    nullif(p ->> 'old_price', '')::numeric,
    coalesce((p ->> 'visible')::boolean, true),
    coalesce((p ->> 'featured')::boolean, false),
    coalesce((p ->> 'is_permanent')::boolean, false),
    coalesce(nullif(p ->> 'listed_at', '')::timestamptz, now()),
    coalesce(nullif(p ->> 'created_at', '')::timestamptz, now())
  from jsonb_array_elements(coalesce(v_snap -> 'products', '[]'::jsonb)) as p
  on conflict (id) do update set
    name = excluded.name,
    code = excluded.code,
    category_id = excluded.category_id,
    subcategory_id = excluded.subcategory_id,
    description = excluded.description,
    price = excluded.price,
    old_price = excluded.old_price,
    visible = excluded.visible,
    featured = excluded.featured,
    is_permanent = excluded.is_permanent,
    listed_at = excluded.listed_at,
    created_at = excluded.created_at;

  insert into public.product_colors (id, product_id, name, hex, images, sort)
  select
    (pc ->> 'id')::uuid,
    (pc ->> 'product_id')::uuid,
    nullif(pc ->> 'name', ''),
    nullif(pc ->> 'hex', ''),
    coalesce(pc -> 'images', '[]'::jsonb),
    coalesce((pc ->> 'sort')::integer, 0)
  from jsonb_array_elements(coalesce(v_snap -> 'product_colors', '[]'::jsonb)) as pc
  on conflict (id) do update set
    product_id = excluded.product_id,
    name = excluded.name,
    hex = excluded.hex,
    images = excluded.images,
    sort = excluded.sort;

  insert into public.product_sizes (id, color_id, size, status, sold_at)
  select
    (ps ->> 'id')::uuid,
    (ps ->> 'color_id')::uuid,
    nullif(ps ->> 'size', ''),
    case when ps ->> 'status' = 'sold' then 'sold' else 'available' end,
    nullif(ps ->> 'sold_at', '')::timestamptz
  from jsonb_array_elements(coalesce(v_snap -> 'product_sizes', '[]'::jsonb)) as ps
  on conflict (id) do update set
    color_id = excluded.color_id,
    size = excluded.size,
    status = excluded.status,
    sold_at = excluded.sold_at;

  select coalesce(array_agg((s ->> 'id')::uuid), '{}'::uuid[]) into v_size_ids
  from jsonb_array_elements(coalesce(v_snap -> 'product_sizes', '[]'::jsonb)) as s;
  delete from public.product_sizes where not (id = any(v_size_ids));

  select coalesce(array_agg((c ->> 'id')::uuid), '{}'::uuid[]) into v_col_ids
  from jsonb_array_elements(coalesce(v_snap -> 'product_colors', '[]'::jsonb)) as c;
  delete from public.product_colors where not (id = any(v_col_ids));

  select coalesce(array_agg((p ->> 'id')::uuid), '{}'::uuid[]) into v_prod_ids
  from jsonb_array_elements(coalesce(v_snap -> 'products', '[]'::jsonb)) as p;
  delete from public.products where not (id = any(v_prod_ids));

  select coalesce(array_agg((cat ->> 'id')::uuid), '{}'::uuid[]) into v_cat_ids
  from jsonb_array_elements(coalesce(v_snap -> 'categories', '[]'::jsonb)) as cat;
  delete from public.categories where parent_id is not null and not (id = any(v_cat_ids));
  delete from public.categories where parent_id is null and not (id = any(v_cat_ids));

  insert into public.banners (
    id, image_url, title, subtitle, btn_text, link, active, sort, type, product_id, category_id, ends_at
  )
  select
    (b ->> 'id')::uuid,
    nullif(b ->> 'image_url', ''),
    coalesce(b ->> 'title', ''),
    coalesce(b ->> 'subtitle', ''),
    coalesce(b ->> 'btn_text', 'تسوقي الآن'),
    coalesce(b ->> 'link', '/catalog'),
    coalesce((b ->> 'active')::boolean, true),
    coalesce((b ->> 'sort')::integer, 0),
    coalesce(b ->> 'type', 'message'),
    nullif(b ->> 'product_id', '')::uuid,
    nullif(b ->> 'category_id', '')::uuid,
    nullif(b ->> 'ends_at', '')::timestamptz
  from jsonb_array_elements(coalesce(v_snap -> 'banners', '[]'::jsonb)) as b
  on conflict (id) do update set
    image_url = excluded.image_url,
    title = excluded.title,
    subtitle = excluded.subtitle,
    btn_text = excluded.btn_text,
    link = excluded.link,
    active = excluded.active,
    sort = excluded.sort,
    type = excluded.type,
    product_id = excluded.product_id,
    category_id = excluded.category_id,
    ends_at = excluded.ends_at;

  select coalesce(array_agg((b ->> 'id')::uuid), '{}'::uuid[]) into v_ban_ids
  from jsonb_array_elements(coalesce(v_snap -> 'banners', '[]'::jsonb)) as b;
  delete from public.banners where not (id = any(v_ban_ids));

  v_settings := v_snap -> 'settings';
  if v_settings is not null and jsonb_typeof(v_settings) = 'object' and v_settings <> '{}'::jsonb then
    update public.settings set
      store_name = coalesce(v_settings ->> 'store_name', store_name),
      logo_url = coalesce(v_settings ->> 'logo_url', logo_url),
      whatsapp = coalesce(v_settings ->> 'whatsapp', whatsapp),
      messenger_url = coalesce(v_settings ->> 'messenger_url', messenger_url),
      instagram_url = coalesce(v_settings ->> 'instagram_url', instagram_url),
      facebook_url = coalesce(v_settings ->> 'facebook_url', facebook_url),
      whatsapp_group_url = coalesce(v_settings ->> 'whatsapp_group_url', whatsapp_group_url),
      welcome = coalesce(v_settings ->> 'welcome', welcome),
      order_intro = coalesce(v_settings ->> 'order_intro', order_intro),
      trust_items = coalesce(v_settings -> 'trust_items', trust_items),
      pixel_id = coalesce(v_settings ->> 'pixel_id', pixel_id),
      expiry_days = greatest(1, coalesce((v_settings ->> 'expiry_days')::integer, expiry_days)),
      backup_retention_days = greatest(1, coalesce((v_settings ->> 'backup_retention_days')::integer, backup_retention_days)),
      caption_template = coalesce(v_settings ->> 'caption_template', caption_template),
      features = coalesce(v_settings -> 'features', features)
    where id = 1;
  end if;
end;
$$;

grant execute on function public.restore_backup(uuid) to authenticated;

notify pgrst, 'reload schema';
